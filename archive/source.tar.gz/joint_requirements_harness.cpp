// Test-only access to the exact native preprocessing implementation.
#pragma clang diagnostic push
// The renamed scanner entry point is never called; only real main has implicit return0.
#pragma clang diagnostic ignored "-Wreturn-type"
#define main c7_joint_scanner_main
#include "scan_component_atomic7_incremental_joint.cpp"
#undef main
#pragma clang diagnostic pop
int main() {
    unsigned radius;std::size_t count;
    if(!(std::cin>>radius>>count))return 1;
    std::vector<std::vector<Choice>> conditions;
    for(std::size_t i=0;i<count;++i) {
        std::size_t n;if(!(std::cin>>n))return 1;std::vector<Choice> lists;
        for(std::size_t j=0;j<n;++j) {
            std::size_t k;if(!(std::cin>>k))return 1;Choice b(k);
            for(int& v:b)if(!(std::cin>>v))return 1;
            if(!std::is_sorted(b.begin(),b.end()) || std::adjacent_find(b.begin(),b.end())!=b.end())return 1;
            lists.push_back(std::move(b));
        }
        conditions.push_back(minimal_requirements(std::move(lists)));
    }
    std::string extra;if(std::cin>>extra)return 1;
    auto joint=join_requirements(conditions,radius,20000);
    std::cout<<"{\"complete\":"<<(joint.complete?"true":"false")<<",\"sets\":[";
    for(std::size_t i=0;i<joint.sets.size();++i){if(i)std::cout<<',';print_words(joint.sets[i]);}
    std::cout<<"]}\n";
}
