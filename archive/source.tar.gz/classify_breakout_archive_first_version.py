"""Classify archived endpoints using complete components and explicit maps."""
import gzip
import hashlib
import json
from pathlib import Path
import struct

from breakout_conflicts import graph
from check_breakout_paths import map_core
from export_breakout_component import reconstruct
from recombine_sets import FILES
from search_plateau import search

HERE = Path(__file__).resolve().parent


def key(words):
    return struct.pack('<367H', *sorted(int(''.join(map(str, w)), 7) for w in words))


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    _, adjacency = graph(5)
    references = {}
    for label in ('PS', 'A', 'B', 'C'):
        words = [tuple(map(int, t)) for t in (HERE/FILES[label]).read_text().split()]
        component = search(words, 20, 20000)
        assert component['status'] == 'exhausted'
        keys, _ = reconstruct(component, set(struct.unpack('<367H', key(words))), adjacency)
        references[label] = (component, set(keys))
    components = []
    lookup = {}
    rows = []
    for seed in (20260920, 20260921):
        file = HERE/f'breakout-beyond-c-seed{seed}.json'
        data = json.loads(file.read_text())
        for index, candidate in enumerate(data['candidates']):
            words = [tuple(map(int, w)) for w in candidate['words']]
            encoded = key(words)
            if encoded not in lookup:
                component = search(words, 20, 20000)
                if component['status'] != 'exhausted':
                    raise RuntimeError('Incomplete classification; retain candidate for follow-up')
                source_core = set(map(tuple, component['fixed_across_visited_words']))
                classification = None
                for label, (reference, reference_keys) in references.items():
                    if component['states_visited'] != reference['states_visited']:
                        continue
                    target_core = set(map(tuple, reference['fixed_across_visited_words']))
                    mapping = map_core(source_core, target_core)
                    if mapping is None:
                        continue
                    perm, signs, shift = mapping
                    mapped = [tuple((signs[i]*w[perm[i]]+shift[i]) % 7 for i in range(5)) for w in words]
                    if key(mapped) in reference_keys:
                        classification = dict(family=label, permutation=perm, signs=signs, shift=shift,
                                              reference_component_sha256=reference['component_sha256'])
                        break
                keys, directed = reconstruct(component, set(struct.unpack('<367H', encoded)), adjacency)
                ci = len(components)
                meta = dict(states=len(keys), cardinality=367, component_sha256=component['component_sha256'],
                            classification=classification, directed_edges=directed,
                            first_file=str(file), first_candidate=index)
                # Unknown classes are retained for review, not silently labeled new.
                cache = HERE/f'breakout-discovered-component-{ci}.jsonl.gz'
                with gzip.open(cache, 'wt') as f:
                    f.write(json.dumps(meta)+'\n')
                    for k in keys:
                        f.write(json.dumps(list(struct.unpack('<367H', k)))+'\n')
                meta['cache'] = str(cache)
                (HERE/f'breakout-discovered-component-{ci}.json').write_text(json.dumps(component, indent=2)+'\n')
                for k in keys:
                    lookup[k] = ci
                components.append(meta)
                print(json.dumps(meta), flush=True)
            rows.append(dict(file=str(file), candidate=index, step=candidate['step'], component=lookup[encoded]))
    result = dict(components=components, candidates=rows,
                  source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  scope='Explicit coordinate map sends each representative into a complete reference component. Others classified by exact full-state membership; unclassified is not a new-family claim.')
    (HERE/'breakout-continuation-classification.json').write_text(json.dumps(result, indent=2)+'\n')


if __name__ == '__main__':
    main()
