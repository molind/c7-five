"""Solve the two remaining reduced faces using mandatory cover cliques.

If a clique's weight exceeds the cover's target slack, every target-size
independent set must meet that clique. Add this exact consequence explicitly.
"""
import argparse
import hashlib
from itertools import combinations
import json
from pathlib import Path
import time

import z3

from check_two_slice_covers import HERE, WORDS, check_cover, conflict
from search_exchanges import verify


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--seconds', type=float, default=10)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.seconds <= 0:
        parser.error('Positive search budget required')
    if args.output.exists():
        raise FileExistsError(args.output)
    source = HERE/'two-slice-cover-face-rebound-sep21.json'
    data = json.loads(source.read_text())
    faces_path = HERE/'two-slice-cover-face-sep21.json'
    faces = {r['index']: r for r in json.loads(faces_path.read_text())['results']}
    seed = [list(map(int, w)) for w in (HERE/'family-d-seed-words.txt').read_text().split()]
    report = dict(status='running', results=[], candidates=[], z3_version=z3.get_version_string(),
                  source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  input_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                  faces_sha256=hashlib.sha256(faces_path.read_bytes()).hexdigest(),
                  scope='Derived face constraints; unknown unresolved. UNSAT requires validity of the saved cover/face reductions. No exported formal UNSAT proof.')
    for row in data['results']:
        pool = row['pool']
        face = faces[row['index']]
        assert pool == [face['face'][i] for i in face['kept_face_indices']]
        assert row['target'] == face['target'] and row['forbidden'] == face['forbidden']
        total, den = check_cover(row, set(pool), {v: 1 for v in pool})
        gap = total-row['target']*den
        assert gap >= 0
        var = {v: z3.Bool(f'v_{v}') for v in pool}
        solver = z3.SolverFor('QF_FD')
        solver.set(timeout=max(1, int(args.seconds*1000)), random_seed=20260921)
        solver.add(z3.PbGe([(v, 1) for v in var.values()], row['target']))
        edges = [(u, v) for u, v in combinations(pool, 2) if conflict(u, v)]
        solver.add([z3.Or(z3.Not(var[u]), z3.Not(var[v])) for u, v in edges])
        mandatory = [c['vertices'] for c in row['cover'] if c['units'] > gap]
        solver.add([z3.Or(*(var[v] for v in c)) for c in mandatory])
        # The incumbent is just a starting preference, not an added constraint.
        hinted = {pool[i] for i in face['hint']}
        for v in pool:
            solver.set_initial_value(var[v], v in hinted)
        began = time.monotonic()
        status = solver.check()
        result = dict(index=row['index'], forbidden=row['forbidden'], status=str(status),
                      pool=pool, target=row['target'], mandatory_cliques=mandatory,
                      gap_units=gap, seconds=time.monotonic()-began)
        if status == z3.sat:
            model = solver.model()
            axis, start = map(int, row['pool_key'].split(':'))
            fixed = [w for w in seed if (w[axis]-start) % 7 >= 2]
            selected = [v for v in pool if z3.is_true(model.eval(var[v]))]
            solution = fixed+[list(WORDS[v]) for v in selected]
            pairs = verify(solution)
            assert len(solution) >= 367 and row['forbidden'] not in selected
            report['candidates'].append(dict(step=row['index'], words=[''.join(map(str, w)) for w in solution],
                                             verified_pairs=pairs))
            report['status'] = 'candidate_found'
        elif status == z3.unknown:
            result['reason'] = solver.reason_unknown()
        report['results'].append(result)
        tmp = args.output.with_name(args.output.name+'.tmp')
        tmp.write_text(json.dumps(report, indent=2)+'\n')
        tmp.replace(args.output)
        print(json.dumps({k: v for k, v in result.items() if k not in ('pool', 'mandatory_cliques')} |
                         {'mandatory_cliques': len(mandatory)}), flush=True)
        if report['candidates']:
            break
    else:
        report['status'] = 'queries_complete'
    tmp = args.output.with_name(args.output.name+'.tmp')
    tmp.write_text(json.dumps(report, indent=2)+'\n')
    tmp.replace(args.output)


if __name__ == '__main__':
    main()
