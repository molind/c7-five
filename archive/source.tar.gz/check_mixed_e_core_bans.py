"""Verify E-core exclusions on already checked complete mixed-domain models."""
import gzip
import hashlib
from itertools import combinations
import json
from pathlib import Path
import struct

HERE = Path(__file__).parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def ids(tokens):
    assert all(len(w) == 5 and set(w) <= set('0123456') for w in tokens)
    return [int(w, 7) for w in tokens]


def word(v):
    return tuple(v//7**i % 7 for i in range(4, -1, -1))


def pairs(values):
    assert len(values) == len(set(values)) and all(type(v) is int and 0 <= v < 16807 for v in values)
    assert all(any((x-y) % 7 in (2, 3, 4, 5) for x, y in zip(word(a), word(b)))
               for a, b in combinations(values, 2))
    return len(values)*(len(values)-1)//2


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    output = HERE/'mixed-e-core-ban-verification-sep21.json'
    candidates_path = HERE/'mixed-e-core-ban-candidates-sep21.json'
    if output.exists() or candidates_path.exists():
        raise FileExistsError('Choose fresh output paths')
    selection_path = HERE/'mixed-e-core-ban-selection-sep21.json'
    selection = json.loads(selection_path.read_text())
    prior_path = HERE/'mixed-e-three-layer-search-verification-sep21.json'
    prior = json.loads(prior_path.read_text())
    validated = {row['file']:row for row in prior['searches']}
    assert [row['index'] for row in selection['rows']] == [3, 11]
    rows, candidates = [], []
    for selected in selection['rows']:
        prepared_path = Path(selected['prepared'])
        assert sha(prepared_path) == selected['prepared_sha256']
        prepared = json.loads(prepared_path.read_text())
        source_path = Path(prepared['source'])
        assert sha(source_path) == prepared['source_sha256'] == validated[str(source_path)]['sha256']
        source = json.loads(source_path.read_text())
        model = prepared['model']
        assert model == source['model'] and prepared['status'] == 'prepared'
        component_path = Path(prepared['core_component'])
        assert sha(component_path) == prepared['core_component_sha256']
        with gzip.open(component_path, 'rt') as f:
            meta = json.loads(next(f))
            states = [set(json.loads(line)) for line in f]
        assert len(states) == meta['states'] == 2 and meta['classification']['family'] == 'E'
        packed = sorted(struct.pack('<367H', *sorted(s)) for s in states)
        assert len(set(packed)) == 2 and hashlib.sha256(b''.join(packed)).hexdigest() == meta['component_sha256']
        for state in states:
            pairs(sorted(state))
        hint = set(model['fixed']) | {model['pool'][j] for j in model['hint']}
        assert hint in states
        core = set.intersection(*states)
        banned = selected['forbidden']
        assert banned == prepared['forbidden'] and banned in core and banned in model['pool']
        assert len(core) == selected['core_size'] == 366 and banned not in model['fixed']
        path = HERE/f"mixed-e-core-ban{selected['index']:02d}-search-sep21.json"
        run = json.loads(path.read_text())
        assert run['status'] == 'query_complete' and run['solver'] == 'native'
        assert run['input'] == str(prepared_path) and run['input_sha256'] == sha(prepared_path)
        result = run['result']
        assert result['forbidden'] == banned and result['target'] == 368-len(model['fixed'])
        assert result['initial_size'] == len(model['hint'])-1
        full_size = None
        witness_pairs = 0
        if 'vertices' in result:
            chosen = result['vertices']
            assert set(chosen) <= set(model['pool']) and banned not in chosen
            chosen_set = set(chosen)
            for members, capacity in zip(model['members'], model['capacities']):
                assert sum(model['pool'][i] in chosen_set for i in members) <= capacity
            full = sorted(model['fixed']+chosen)
            witness_pairs = pairs(full)
            full_size = len(full)
            assert full_size == result['full_size'] >= 366 and witness_pairs == result['verified_pairs']
            assert banned not in full
            if full_size >= 367:
                candidates.append(dict(step=selected['index'], size=full_size,
                    words=[''.join(map(str, word(v))) for v in full], verified_pairs=witness_pairs))
            assert (result['status'] == 'model_found') == (full_size >= 368)
        assert bool(run['candidates']) == (full_size is not None and full_size >= 368)
        for candidate in run['candidates']:
            values = ids(candidate['words'])
            assert set(values) == set(full) and pairs(values) == candidate['verified_pairs']
        rows.append(dict(index=selected['index'], forbidden=banned, core_size=366,
            component_sha256=meta['component_sha256'], prepared_sha256=sha(prepared_path),
            result_sha256=sha(path), initial_full_size=366, returned_size=full_size,
            direct_witness_pairs=witness_pairs, solver_status=result['solver_status']))
    report = dict(selection_sha256=sha(selection_path), prior_model_verification_sha256=sha(prior_path),
        checker_sha256=sha(Path(__file__)), results=rows,
        target_witness_found=any((r['returned_size'] or 0) >= 368 for r in rows),
        scope='Two exact residual-word bans on independently checked complete models. Returned codes checked directly. Solver limits are unresolved; no claim about other bans or the unrestricted problem.')
    candidates_path.write_text(json.dumps(dict(candidates=candidates), indent=2)+'\n')
    output.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report), flush=True)


if __name__ == '__main__':
    main()
