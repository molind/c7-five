"""Check the new public Family-D seed using the existing exact C++ kernel.
Graph export is checked fully by coordinate-mask intersections before searching.
"""
import gzip
import hashlib
from itertools import combinations, product
import json
from pathlib import Path
import struct
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
if not __debug__:
    raise RuntimeError('Run without -O')
word_file = HERE/'family-d-seed-words.txt'
tokens = word_file.read_text().split()
seed = [tuple(map(int, t)) for t in tokens]
assert len(seed) == len(set(seed)) == 367
assert all(len(w)==5 and all(0<=v<7 for v in w) for w in seed)
conflict = lambda a,b: all((x-y)%7 in (0,1,6) for x,y in zip(a,b))
assert not any(conflict(a,b) for a,b in combinations(seed,2))
seed_hash = hashlib.sha256(' '.join(tokens).encode()).hexdigest()
cache = HERE/'breakout-perturb64-sep20-2049-component-0.jsonl.gz'
with gzip.open(cache, 'rt') as f:
    metadata = json.loads(next(f))
    known = {struct.pack('<367H',*json.loads(line)) for line in f}
assert len(known)==384 and hashlib.sha256(b''.join(sorted(known))).hexdigest()==metadata['component_sha256']
source = HERE/'exchange_dfs_before_pair_counts.cpp'
source_hash = hashlib.sha256(source.read_bytes()).hexdigest()
assert source_hash=='c0eb2f1b798c0aaab2d14086d23bd9dd011a133dd3325900b4fdf37b37d8232e'
binary = HERE/'exchange_dfs_family_d'
subprocess.run(['clang++','-std=c++17','-O3',str(source),'-o',str(binary)],check=True,timeout=30)
coordinates = [[0]*7 for _ in range(5)]
for i,w in enumerate(seed):
    for k,x in enumerate(w): coordinates[k][x] |= 1<<i
occupied = set(seed)
candidates = []
for w in product(range(7),repeat=5):
    if w in occupied: continue
    blockers = (1<<367)-1
    for k,x in enumerate(w):
        blockers &= coordinates[k][(x-1)%7] | coordinates[k][x] | coordinates[k][(x+1)%7]
    assert blockers, 'Seed admits a free insertion'
    candidates.append((w,blockers))
report = dict(seed_sha256=seed_hash,source_sha256=source_hash,component_sha256=metadata['component_sha256'],
              internal_limit_seconds=45,parent_limit_seconds=55,rows=[],outside={},
              driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
output = HERE/'family-d-seed-exchanges.json'
for radius in range(1,7):
    pool = sorted((c for c in candidates if c[1].bit_count()<=radius),key=lambda c:c[1].bit_count())
    graph_file = HERE/f'family-d-seed-d{radius}.txt'
    with graph_file.open('w') as out:
        subprocess.run([sys.executable,str(HERE/'export_exchange_graph.py'),str(word_file),seed_hash,str(radius)],
                       stdout=out,check=True,timeout=40)
    pc = [[0]*7 for _ in range(5)]
    for i,(w,_) in enumerate(pool):
        for k,x in enumerate(w): pc[k][x] |= 1<<i
    full = (1<<len(pool))-1
    with graph_file.open() as f:
        assert list(map(int,f.readline().split()))==[len(pool),6,radius]
        for w,blockers in pool:
            values=[int(x,16) for x in f.readline().split()]
            assert len(values)==6+(len(pool)+63)//64
            assert sum(v<<(64*j) for j,v in enumerate(values[:6]))==blockers
            forbidden=full
            for k,x in enumerate(w): forbidden &= pc[k][(x-1)%7] | pc[k][x] | pc[k][(x+1)%7]
            assert sum(v<<(64*j) for j,v in enumerate(values[6:]))==full^forbidden
        assert not f.read().strip()
    graph_hash=hashlib.sha256(graph_file.read_bytes()).hexdigest()
    for neutral in (False,True):
        began=time.monotonic()
        with graph_file.open() as inp:
            try:
                run=subprocess.run([str(binary),'45','--subset',*(['--neutral'] if neutral else [])],
                                   stdin=inp,text=True,capture_output=True,check=True,timeout=55)
                result=json.loads(run.stdout)
            except subprocess.TimeoutExpired:
                result=dict(status='parent_timeout')
        if result['status']=='exhausted': assert result['nodes_started']==result['nodes_completed']
        selections=result.get('neutral',[])+result.get('improving',[])
        if result['status']=='witness' and result.get('chosen'): selections.append(result['chosen'])
        targets=set()
        for selected in selections:
            removed=0
            for i in selected: removed |= pool[i][1]
            target=tuple(sorted({w for i,w in enumerate(seed) if not (removed>>i)&1}|{pool[i][0] for i in selected}))
            assert removed.bit_count()<=radius and len(target)>=367
            assert not any(conflict(a,b) for a,b in combinations(target,2))
            ids=tuple(int(''.join(map(str,w)),7) for w in target)
            encoded=struct.pack('<'+str(len(ids))+'H',*ids)
            targets.add(encoded)
            if encoded not in known:
                words=[''.join(map(str,w)) for w in target]
                h=hashlib.sha256(' '.join(words).encode()).hexdigest()
                report['outside'][h]=dict(words=words,size=len(target),radius=radius,neutral=neutral)
        row=dict(radius=radius,neutral=neutral,candidates=len(pool),graph_sha256=graph_hash,
                 full_graph_verified=True,search=result,distinct_targets=len(targets),
                 outside_targets=sum(t not in known for t in targets),wall_seconds=time.monotonic()-began)
        report['rows'].append(row)
        output.write_text(json.dumps(report,indent=2)+'\n')
        print(json.dumps({k:v for k,v in row.items() if k!='search'}|{'status':result['status'],'nodes':result.get('nodes_started')}),flush=True)
        if report['outside']:
            raise SystemExit('New target saved and directly verified; classify before further searches')
