"""Prepare replayable E3 entries that delete an A-cap2 fixed word and add outside its support."""
import gzip
import hashlib
from itertools import combinations, product
import json
from pathlib import Path

from search_low_conflict import WORDS, TOKENS, counts_for

HERE = Path(__file__).resolve().parent


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    run = json.loads((HERE / 'family-a-cap2-export-run.json').read_text())
    profile = json.loads((HERE / 'family-a-cap2-export-verification.json').read_text())
    assert profile['passed'] and profile['maximum_distance'] == 14
    assert run['states_sha256'] == profile['states_sha256'] == 'ed82aacd25dc5a8fa3a63121cfe481141255bc31f4432dbba82ad5c6ccef492b'
    export = Path(run['states_export']['path'])
    assert hashlib.sha256(export.read_bytes()).hexdigest() == run['states_export']['sha256']
    with gzip.open(export, 'rt') as stream:
        header = json.loads(next(stream))
        rows = [json.loads(line) for line in stream]
    assert header['count'] == len(rows) == 29336
    support = {int(w, 7) for row in rows for w in row['words'].split()}
    fixed = {int(w, 7) for w in profile['fixed_words']}
    assert len(support) == 659 and len(fixed) == 146
    adjacency = [tuple(2401*a+343*b+49*c+7*d+e
        for a,b,c,d,e in product(*[((x-1)%7,x,(x+1)%7) for x in w])
        if 2401*a+343*b+49*c+7*d+e != v) for v,w in enumerate(WORDS)]
    farthest = profile['furthest_state_indices']
    chosen = [farthest[i * len(farthest) // 12] for i in range(12)]
    entries = []
    for index in chosen:
        row = rows[index]
        state = {int(w, 7) for w in row['words'].split()}
        assert row['index'] == index and row['energy'] == 2 and fixed <= state
        counts = counts_for(state, adjacency)
        candidates = []
        for added, count in enumerate(counts):
            if added in support or count != 2:
                continue
            blockers = state.intersection(adjacency[added])
            for removed in sorted(blockers & fixed):
                if counts[removed] == 0:
                    candidates.append((added, removed))
        if not candidates:
            entries.append(dict(source_index=index, status='no_selected_boundary_entry'))
            continue
        added, removed = candidates[0]
        target = state - {removed} | {added}
        conflicts = [(a,b) for a,b in combinations(sorted(target),2)
                     if all((x-y)%7 in (0,1,6) for x,y in zip(WORDS[a],WORDS[b]))]
        assert len(target) == 368 and len(conflicts) == 3
        path = []
        cursor = index
        while rows[cursor]['parent'] is not None:
            parent_row = rows[cursor]
            path.append({key: parent_row[key] for key in ('removed','added','energy')})
            cursor = parent_row['parent']
        path.reverse()
        path.append(dict(removed=TOKENS[removed], added=TOKENS[added], energy=3))
        entries.append(dict(source_index=index, status='verified_entry',
                            eligible_entries=len(candidates), path=path,
                            final_words=[TOKENS[w] for w in sorted(target)],
                            conflict_edges=[[TOKENS[a],TOKENS[b]] for a,b in conflicts]))
    result = dict(start_words=run['start_words'], entries=entries,
                  source_archive_sha256=run['states_export']['sha256'],
                  scope='Twelve selected farthest cap2 sources; one E3 entry per source when available. No cooling/search beyond the entries and no independent367 escape claimed.')
    (HERE / 'family-a-cap3-boundary-entries.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps([dict(source_index=e['source_index'],status=e['status'],
                           eligible_entries=e.get('eligible_entries'),path_length=len(e.get('path',[]))) for e in entries]))


if __name__ == '__main__':
    main()
