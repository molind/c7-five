"""Check saved translation matchings as explicit clique covers.

Rebuild cross edges from neighborhoods of the opposite parent and find strong
components with iterative Kosaraju, independently of the search's Tarjan code.
Every maximum hybrid assigns a whole strong component together. Consequently
its distance from at least one parent is bounded by the total noncommon weight
outside the heaviest component. This is a bound inside each two-parent union.
"""
import argparse
from collections import Counter
import hashlib
from itertools import combinations, product
import json
from pathlib import Path
import struct

import numpy as np


def components(graph):
    n = len(graph)
    reverse = [[] for _ in range(n)]
    for i, row in enumerate(graph):
        for j in row:
            reverse[j].append(i)
    seen, order = set(), []
    for root in range(n):
        if root in seen:
            continue
        seen.add(root)
        stack = [(root, iter(graph[root]))]
        while stack:
            v, edges = stack[-1]
            w = next(edges, None)
            if w is None:
                stack.pop()
                order.append(v)
            elif w not in seen:
                seen.add(w)
                stack.append((w, iter(graph[w])))
    seen, groups = set(), []
    for root in reversed(order):
        if root in seen:
            continue
        stack, group = [root], []
        seen.add(root)
        while stack:
            v = stack.pop()
            group.append(v)
            for w in reverse[v]:
                if w not in seen:
                    seen.add(w)
                    stack.append(w)
        groups.append(group)
    return groups


def verify_words(words):
    assert all(len(w) == 5 and all(type(x) is int and 0 <= x < 7 for x in w) for w in words)
    assert len(set(map(tuple,words))) == len(words)
    count = 0
    for a,b in combinations(words,2):
        assert any((x-y)%7 in (2,3,4,5) for x,y in zip(a,b))
        count += 1
    return count


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    args = p.parse_args()
    assert __debug__ and not args.output.exists()
    sha = lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
    d = json.loads(args.input.read_text())
    assert all(sha(f) == h for f,h in d['dependencies'].items())
    assert sha(d['parents_file']) == d['parents_sha256']
    assert sha(d['matching_file']) == d['matching_sha256']
    parents = json.loads(Path(d['parents_file']).read_text())['bases']
    ids = [sorted(p['words']) for p in parents]
    assert len(ids) == 2 and all(len(x) == 367 and len(set(x)) == 367 for x in ids)
    assert all(type(v) is int and 0 <= v < 16807 for x in ids for v in x)
    coords = np.array(list(product(range(7),repeat=5)),dtype=np.int16)
    powers = np.array([2401,343,49,7,1],dtype=np.int32)
    a,b = (coords[x] for x in ids)
    parent_pairs = [verify_words(x.tolist()) for x in (a,b)]
    shifts = np.array(list(product((-1,0,1),repeat=5)),dtype=np.int16)
    posting = [[] for _ in range(16807)]
    for i,word in enumerate(a):
        for v in (((word+shifts)%7)@powers).tolist():
            posting[v].append(i)
    records = d['rows']
    assert [r['shift'] for r in records] == list(range(d['start'],d['next_shift']))
    raw = Path(d['matching_file']).read_bytes()
    assert len(raw) == len(records)*734
    assert d['status'] in ('timeout','exhausted','candidate_limit','improved')
    if d['status'] == 'exhausted':
        assert d['next_shift'] == d['requested_stop']
    histogram = Counter()
    pairs = edges = 0
    aset = set(ids[0])
    for offset,row in enumerate(records):
        mate = struct.unpack_from('<367H',raw,734*offset)
        assert sorted(mate) == list(range(367))
        shift = coords[row['shift']]
        shifted = (b+shift)%7
        shifted_ids = (shifted@powers).tolist()
        # Each matching edge is checked directly as a two-word clique.
        delta = (a-shifted[list(mate)])%7
        assert np.all((delta == 0)|(delta == 1)|(delta == 6))
        pairs += 367
        inverse = [0]*367
        for i,j in enumerate(mate):
            inverse[j] = i
        graph = [[] for _ in range(367)]
        for j,v in enumerate(shifted_ids):
            for i in posting[v]:
                graph[i].append(inverse[j])
                edges += 1
        groups = components(graph)
        weights = [sum(ids[0][i] != shifted_ids[mate[i]] for i in group) for group in groups]
        common = len(aset & set(shifted_ids))
        largest = max(weights,default=0)
        outside = 367-common-largest
        assert row == dict(shift=row['shift'],common=common,components=len(groups),
                           largest_weight=largest,outside_largest=outside)
        histogram[outside] += 1
    assert dict(histogram) == {int(k):v for k,v in d['outside_largest_histogram'].items()}
    candidate_pairs = 0
    for c in d['candidates']:
        candidate_pairs += verify_words(c['words'])
        shifted_ids = (((b+coords[c['step']])%7)@powers).tolist()
        child = set((np.array(c['words'])@powers).tolist())
        assert child <= aset | set(shifted_ids)
        if c.get('improved'):
            assert len(child) >= 368
        else:
            assert len(child) == 367
            assert c['distances'] == [len(child-aset),len(child-set(shifted_ids))]
    out = dict(passed=True,start=d['start'],next_shift=d['next_shift'],
               clique_cover_pairs_checked=pairs,reconstructed_cross_edges=edges,
               parent_pair_checks=parent_pairs,candidate_pair_checks=candidate_pairs,
               maximum_distance_from_nearest_parent_bound=max(histogram,default=0),
               outside_largest_histogram=dict(histogram),
               dependencies={str(args.input):sha(args.input),d['matching_file']:sha(d['matching_file']),
                             d['parents_file']:sha(d['parents_file'])},
               checker_sha256=sha(__file__),
               scope='Only the specified pair and completed translations; no global C7 bound.')
    args.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out))


if __name__ == '__main__':
    main()
