"""Free core words while reoptimizing all five movable P4 components."""
import argparse
import hashlib
import json
import time

import z3

from search_exchanges import graph_data, verify
from search_rounding import ROOT, maximum_independent


def solve(core, vertices, ids, blockers, cliques, radius, target, timeout):
    original = set(ids)
    candidates = [v for v, bs in enumerate(blockers) if v not in original and len(bs) <= radius]
    remove = [z3.Bool(f"remove_{i}") for i in range(len(core))]
    add = {v: z3.Bool(f"add_{v}") for v in candidates}
    solver = z3.SolverFor("QF_FD")
    solver.set(timeout=int(timeout*1000), random_seed=20260915)
    solver.add(z3.PbEq([(b, 1) for b in remove], radius))
    solver.add(z3.PbGe([(b, 1) for b in add.values()], target-len(core)+radius))
    free = [v for v in candidates if not blockers[v]]
    free_conflicts = []
    for v in free:
        free_conflicts.append(sum(1 << j for j, u in enumerate(free) if u != v and
            all(int(x-y) % 7 in (0, 1, 6) for x, y in zip(vertices[v], vertices[u]))))
    maximum, capacity_status, _ = maximum_independent(free_conflicts, 1000000)
    if capacity_status != "optimal":
        raise ArithmeticError("No certified bound for the free subgraph")
    free_capacity = len(maximum)
    solver.add(z3.PbLe([(add[v], 1) for v in free], free_capacity))
    blocked_additions = [b for v, b in add.items() if blockers[v]]
    required = target-len(core)+radius-free_capacity
    if blocked_additions:
        solver.add(z3.PbGe([(b, 1) for b in blocked_additions], required))
    elif required > 0:
        solver.add(False)
    for v, var in add.items():
        for b in blockers[v]:
            solver.add(z3.Or(z3.Not(var), remove[b]))
    unique = {tuple(sorted(int(v) for v in clique if v in add)) for clique in cliques}
    unique = {key for key in unique if len(key) > 1}
    for key in sorted(unique):
        solver.add(z3.AtMost(*(add[v] for v in key), 1))
    began = time.monotonic()
    status = solver.check()
    result = {"removed_core_words": radius, "target_words": target,
              "candidate_count": len(candidates), "clique_count": len(unique),
              "free_subgraph_capacity": free_capacity,
              "status": str(status), "solver_seconds": time.monotonic()-began,
              "timeout_seconds": timeout}
    if status == z3.unknown:
        result["reason"] = solver.reason_unknown()
    elif status == z3.sat:
        m = solver.model()
        kept = [w for i, w in enumerate(core) if not z3.is_true(m.eval(remove[i]))]
        inserted = [vertices[v].tolist() for v, b in add.items() if z3.is_true(m.eval(b))]
        words = kept+inserted
        verify(words)
        if len(words) < target:
            raise ArithmeticError("Solver result is too small")
        result.update(words=words, size=len(words))
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--radii", type=int, nargs="+", default=[0, 1, 2, 3, 4])
    parser.add_argument("--timeout", type=float, default=45)
    parser.add_argument("--output", type=str, default="core-escape-results.json")
    args = parser.parse_args()
    source = ROOT / "plateau-two-results.json"
    core = json.loads(source.read_text())["fixed_across_visited_words"]
    verify(core)
    vertices, ids, blockers, cliques = graph_data(core)
    control = solve(core, vertices, ids, blockers, cliques, 0, 367, 10)
    if control["status"] != "sat":
        raise ArithmeticError("Failed to restore a 367-word completion of the core")
    report = {"core_size": len(core), "input_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
              "positive_control": control, "results": []}
    for r in args.radii:
        result = solve(core, vertices, ids, blockers, cliques, r, 368, args.timeout)
        report["results"].append(result)
        (ROOT / args.output).write_text(json.dumps(report, indent=2)+"\n")
        print(json.dumps({k: v for k, v in result.items() if k != "words"}), flush=True)
        if result["status"] == "sat":
            break
