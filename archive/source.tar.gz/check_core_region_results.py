"""Verify sampled and reduced core domains, integer covers and returned words.

Only stored exact covers below the relevant target give exclusions. Search
statuses, floating bounds and absence of a witness are not proof certificates.
"""
import argparse
import hashlib
from itertools import combinations, product
import json
from pathlib import Path

import numpy as np

from check_common314_covers import decode
from check_common313_covers import verify_cover


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--base',type=Path,required=True)
    p.add_argument('--regions',type=Path,required=True)
    p.add_argument('--shrink',type=Path)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();assert __debug__ and not args.output.exists()
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    base=json.loads(args.base.read_text());assert sha(base['input'])==base['input_sha256']
    parents=json.loads(Path(base['input']).read_text())['bases']
    core=sorted(set(parents[0]['words'])&set(parents[1]['words']))
    assert core==sorted(base['fixed']) and len(core)==315
    coords=np.array(list(product(range(7),repeat=5)),dtype=np.int16)
    # Full coordinate comparison, independent of the generator's shifted boxes.
    masks=[0]*16807
    for bit,word in enumerate(core):
        diff=(coords-coords[word])%7
        for v in np.flatnonzero(np.all((diff==0)|(diff==1)|(diff==6),axis=1)):
            masks[int(v)]|=1<<bit
    core_index={v:i for i,v in enumerate(core)}
    dependencies={str(args.base):sha(args.base),base['input']:sha(base['input'])}
    witness_checks=0
    def direct(words):
        nonlocal witness_checks
        assert len(words)==len(set(words)) and all(type(v) is int and 0<=v<16807 for v in words)
        for a,b in combinations(words,2):
            assert any((x-y)%7 in (2,3,4,5) for x,y in zip(decode(a),decode(b)))
            witness_checks+=1
        return len(words)*(len(words)-1)//2
    assert direct(base['witness'])==67161 and set(core)<=set(base['witness'])
    def verify(row):
        omitted=row['omitted'];assert len(omitted)==len(set(omitted)) and set(omitted)<=set(core)
        mask=sum(1<<core_index[v] for v in omitted)
        pool={v for v,bk in enumerate(masks) if not(bk&~mask)}
        assert pool==set(row['pool']) and len(pool)==len(row['pool'])
        fixed=set(core)-set(omitted);assert not pool&fixed
        if 'fixed' in row:assert set(row['fixed'])==fixed
        if 'fixed_size' in row:assert row['fixed_size']==len(fixed)
        assert row['target']==368-len(fixed)
        D=row['denominator'];assert type(D) is int and D>0
        total=verify_cover(pool,row['cover'],D);assert total==row['total_units']
        excludes=total<row['target']*D
        if 'cover_excludes368' in row:assert excludes==row['cover_excludes368']
        search=row.get('milp',{})
        if 'witness' in search:
            w=search['witness'];assert fixed<=set(w)<=pool|fixed
            assert direct(w)==search['pair_checks'] and len(w)==search['size']
        return excludes
    sample=json.loads(args.regions.read_text());assert sample['status'] in ('complete_sample','verified_improvement')
    assert all(sha(f)==h for f,h in sample['dependencies'].items())
    dependencies[str(args.regions)]=sha(args.regions)
    closed=[];opened=[];seen=set()
    for ordinal,row in enumerate(sample['rows']):
        assert ordinal==row['ordinal'];key=tuple(row['omitted']);assert key not in seen;seen.add(key)
        (closed if verify(row) else opened).append(ordinal)
    if sample['improved_words'] is not None:assert len(sample['improved_words'])==368 and direct(sample['improved_words'])==67528
    reduced=None
    if args.shrink:
        shrink=json.loads(args.shrink.read_text());assert shrink['status'] in ('complete_attempt','verified_improvement')
        assert all(sha(f)==h for f,h in shrink['dependencies'].items())
        dependencies[str(args.shrink)]=sha(args.shrink)
        excludes=verify(shrink)
        reduced=dict(omissions=len(shrink['omitted']),pool=len(shrink['pool']),target=shrink['target'],
            total_units=shrink['total_units'],exclusion_by_exact_cover=excludes,
            milp_status=shrink['milp']['status'],witness_size=shrink['milp'].get('size'))
        if shrink['improved_words'] is not None:assert len(shrink['improved_words'])==368 and direct(shrink['improved_words'])==67528
    for helper in ('check_common313_covers.py','check_common314_covers.py'):
        path=Path(__file__).with_name(helper);dependencies[str(path)]=sha(path)
    out=dict(passed=True,sampled_domains=len(sample['rows']),exactly_closed_cases=closed,
        open_cases=opened,reduced=reduced,witness_pair_checks=witness_checks,
        checker_sha256=sha(__file__),dependencies=dependencies,
        scope='Listed domains only. Open covers and solver timeouts do not imply feasibility or exclusion. Greedy shrink optimality is not certified.')
    args.output.write_text(json.dumps(out,indent=2)+'\n');print(out)


if __name__=='__main__':main()
