"""Fixed-cardinality search with learned penalties on repeatedly violated edges.

There is no hard conflict-energy ceiling. The unweighted number of forbidden
pairs remains the actual objective; learned weights only steer proposals.
"""
import argparse
from collections import deque
import hashlib
from itertools import combinations, product
import json
from pathlib import Path
import random
import time

import numpy as np

from recombine_sets import conflict
from search_low_conflict import family_start, TOKENS, WORDS


def graph(d):
    words = np.array(list(product(range(7), repeat=d)), dtype=np.int16)
    shifts = np.array([s for s in product((-1, 0, 1), repeat=d) if any(s)], dtype=np.int16)
    powers = 7**np.arange(d-1, -1, -1)
    adjacency = np.zeros((len(words), len(shifts)), dtype=np.int32)
    for i in range(d):
        adjacency += ((words[:, i, None]+shifts[None, :, i]) % 7)*powers[i]
    # Negating a nonzero shift reverses its position in lexicographic order.
    assert all(np.array_equal(shifts[i], -shifts[-1-i]) for i in range(len(shifts)))
    return words, adjacency


class State:
    def __init__(self, adjacency, chosen):
        self.adj = adjacency
        self.selected = np.zeros(len(adjacency), dtype=bool)
        self.count = np.zeros(len(adjacency), dtype=np.int64)
        self.score = np.zeros(len(adjacency), dtype=np.int64)
        self.weight = np.ones(adjacency.shape, dtype=np.int32)
        for v in chosen:
            self.add(v)

    def add(self, v):
        assert not self.selected[v]
        self.selected[v] = True
        self.count[self.adj[v]] += 1
        self.score[self.adj[v]] += self.weight[v]

    def drop(self, v):
        assert self.selected[v]
        self.selected[v] = False
        self.count[self.adj[v]] -= 1
        self.score[self.adj[v]] -= self.weight[v]

    def penalize(self):
        edges = 0
        for u in np.flatnonzero(self.selected):
            for k in np.flatnonzero(self.selected[self.adj[u]] & (self.adj[u] > u)):
                v = self.adj[u, k]
                self.weight[u, k] += 1
                self.weight[v, self.adj.shape[1]-1-k] += 1
                self.score[u] += 1
                self.score[v] += 1
                edges += 1
        return edges

    def check(self, words):
        chosen = np.flatnonzero(self.selected)
        actual_count = np.zeros(len(words), dtype=np.int64)
        actual_score = np.zeros(len(words), dtype=np.int64)
        for v in range(len(words)):
            for u in chosen:
                if u != v and conflict(words[u], words[v]):
                    actual_count[v] += 1
                    k = int(np.flatnonzero(self.adj[u] == v)[0])
                    assert self.adj[v, self.adj.shape[1]-1-k] == u
                    assert self.weight[u, k] == self.weight[v, self.adj.shape[1]-1-k]
                    actual_score[v] += self.weight[u, k]
        assert np.array_equal(actual_count, self.count)
        assert np.array_equal(actual_score, self.score)


def self_test():
    rng = random.Random(20260920)
    steps = 0
    for d in (1, 2):
        words, adjacency = graph(d)
        for u in range(len(words)):
            assert set(adjacency[u]) == {v for v in range(len(words)) if v != u and conflict(words[u], words[v])}
        state = State(adjacency, rng.sample(range(len(words)), min(8, len(words)-1)))
        for i in range(100):
            if i % 3 == 0:
                state.penalize()
            if i % 20 == 19:
                state.weight.fill(1)
                state.score[:] = state.count
            old = rng.choice(np.flatnonzero(state.selected).tolist())
            state.drop(old)
            new = rng.choice(np.flatnonzero(~state.selected).tolist())
            state.add(new)
            state.check(words)
            steps += 1
    return {'direct_graph_dimensions': [1, 2], 'weighted_random_swaps': steps}


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--steps', type=int, default=30000)
    parser.add_argument('--seconds', type=float, default=45)
    parser.add_argument('--seed', type=int, default=20260920)
    parser.add_argument('--penalty-period', type=int, default=32, help='0 disables learned penalties')
    parser.add_argument('--learning-steps', type=int, help='Then discard weights and repair with the true conflict count')
    parser.add_argument('--continue-after-escape', action='store_true', help='Archive distinct outside-A367 subsets and keep walking')
    parser.add_argument('--candidate-limit', type=int, default=256)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.steps < 1 or args.seconds <= 0 or args.penalty_period < 0 or args.candidate_limit < 1 or (args.learning_steps is not None and args.learning_steps < 1):
        parser.error('Positive steps/time and nonnegative penalty period required')
    if args.self_test:
        result = self_test()
        args.output.write_text(json.dumps(result, indent=2)+'\n')
        print(json.dumps(result)); return
    start, known = family_start('A')
    _, adjacency = graph(5)
    state = State(adjacency, sorted(start))
    rng = random.Random(args.seed)
    tabu = deque(maxlen=8)
    best_energy = int(state.count[state.selected].sum())//2
    best = sorted(start)
    assert best_energy == sum(conflict(WORDS[a], WORDS[b]) for a,b in combinations(best, 2)) == 1
    max_energy = best_energy
    max_distance = 0
    penalties = steps = 0
    independent = None
    first_escape = None
    archived = {}
    e1_states = set()
    trace = []
    moves = []
    status = 'step_limit'
    began = time.monotonic()
    for step in range(args.steps):
        if time.monotonic()-began >= args.seconds:
            status = 'timeout'; break
        conflicted = np.flatnonzero(state.selected & (state.count > 0)).tolist()
        if not conflicted:
            status = 'independent368'; independent = np.flatnonzero(state.selected).tolist(); break
        old = rng.choice(conflicted)
        state.drop(old)
        eligible = ~state.selected
        eligible[old] = False
        for v in tabu:
            eligible[v] = False
        # A record always overrides recency restrictions.
        if state.count[state.selected].sum() == 0:
            free = (~state.selected) & (state.count == 0)
            if np.any(free):
                eligible = free
        candidates = np.flatnonzero(eligible)
        minimum = state.score[candidates].min()
        new = rng.choice(candidates[state.score[candidates] == minimum].tolist())
        state.add(new)
        tabu.append(old)
        steps = step+1
        energy = int(state.count[state.selected].sum())//2
        moves.append([old, new, energy])
        assert int(state.selected.sum()) == 368 and energy >= 0
        max_energy = max(max_energy, energy)
        chosen = frozenset(np.flatnonzero(state.selected).tolist())
        distance = len(start-chosen)
        max_distance = max(max_distance, distance)
        if energy < best_energy or (energy == best_energy and distance > len(start-set(best))):
            best_energy, best = energy, sorted(chosen)
        if energy == 0:
            status = 'independent368'; independent = sorted(chosen); break
        if energy == 1:
            e1_states.add(b''.join(v.to_bytes(2, 'little') for v in sorted(chosen)))
        # A single deletion also repairs any conflict star with energy > 1.
        for v in np.flatnonzero(state.selected & (state.count == energy)):
            recovered = chosen-{int(v)}
            if recovered not in known:
                if first_escape is None:
                    first_escape = dict(step=steps, energy=energy, distance=distance)
                if recovered not in archived:
                    recovered_words = sorted(recovered)
                    assert not any(conflict(WORDS[a], WORDS[b]) for a,b in combinations(recovered_words, 2))
                    archived[recovered] = dict(step=steps, energy=energy, removed=int(v),
                                               words=[TOKENS[w] for w in recovered_words])
                if not args.continue_after_escape:
                    independent = sorted(recovered)
                    status = 'outside_labelled_A_component_367'
                    break
                if len(archived) >= args.candidate_limit:
                    status = 'candidate_limit'
                    break
        if independent is not None:
            break
        if status == 'candidate_limit':
            break
        if args.learning_steps == steps:
            state.weight.fill(1)
            state.score[:] = state.count
        if args.penalty_period and steps % args.penalty_period == 0 and (args.learning_steps is None or steps < args.learning_steps):
            penalties += state.penalize()
        if steps % 1000 == 0:
            trace.append(dict(step=steps, energy=energy, distance=distance, learned_edge_increments=penalties))
    if independent is not None:
        assert len(set(independent)) == len(independent)
        assert not any(conflict(WORDS[a], WORDS[b]) for a,b in combinations(independent, 2))
    final = np.flatnonzero(state.selected).tolist()
    final_energy = sum(conflict(WORDS[a], WORDS[b]) for a,b in combinations(final, 2))
    assert final_energy == int(state.count[state.selected].sum())//2
    assert best_energy == sum(conflict(WORDS[a], WORDS[b]) for a,b in combinations(best, 2))
    result = dict(status=status, seed=args.seed, steps=steps, step_limit=args.steps, time_limit=args.seconds,
                  penalty_period=args.penalty_period, seconds=time.monotonic()-began,
                  learning_steps=args.learning_steps, moves=moves, start_words=[TOKENS[v] for v in sorted(start)],
                  continue_after_escape=args.continue_after_escape, candidate_limit=args.candidate_limit,
                  candidates=list(archived.values()), candidate_count=len(archived),
                  best_energy=best_energy, max_energy=max_energy, max_distance_from_start=max_distance,
                  unique_E1_states=len(e1_states), learned_edge_increments=penalties,
                  best_words=[TOKENS[v] for v in best], final_words=[TOKENS[v] for v in final],
                  final_energy=final_energy, first_escape=first_escape,
                  independent_words=None if independent is None else [TOKENS[v] for v in independent], trace=trace,
                  source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  scope='Heuristic, no hard energy cap. Outside labelled A is not a new isomorphism class. No exclusion from budget limits.')
    args.output.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('best_words','final_words','independent_words','trace','moves','start_words','candidates')}))


if __name__ == '__main__':
    main()
