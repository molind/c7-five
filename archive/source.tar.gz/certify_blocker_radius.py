"""Round an LP dual into an exact bound for a finite blocker-trade radius.

For A*v<=b and 0<=v<=1, nonnegative row weights Y and upper-bound
weights U certify g*v <= (b*Y+sum(U))/D when A^T*Y+U >= D*g.
Here g is +1 for insertions and -1 for removals. Final arithmetic is integer.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path

import numpy as np
from scipy.optimize import linprog

from solve_two_blocker_mip import build_model


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',required=True,type=Path)
    p.add_argument('--caps',required=True,nargs='+',type=int)
    p.add_argument('--max-four-insertions',type=int)
    p.add_argument('--denominator',type=int,default=1000000)
    p.add_argument('--output',required=True,type=Path)
    a=p.parse_args();assert __debug__ and not a.output.exists()
    assert a.denominator>0
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    model=json.loads(a.input.read_text());assert model['status']=='complete'
    assert len(a.caps)==len(model['rows'])
    out=dict(input=str(a.input),input_sha256=sha(a.input),source_sha256=sha(__file__),
             builder_sha256=sha(Path(__file__).with_name('solve_two_blocker_mip.py')),
             rows=[],scope=__doc__,status='complete')
    for domain,cap in zip(model['rows'],a.caps):
        A,lo,hi,c=build_model(domain,'improve',max_removals=cap,max_four_insertions=a.max_four_insertions)
        assert np.all(np.isneginf(lo))
        lp=linprog(c,A_ub=A,b_ub=hi,bounds=(0,1),method='highs-ipm',options={'time_limit':30})
        assert lp.success,lp.message
        denominator=a.denominator;weights=[max(0,math.ceil(-v*denominator)) for v in lp.ineqlin.marginals]
        csr=A.tocsr();coefficients=[0]*len(c);total=0;rows=[]
        for i,weight in enumerate(weights):
            if not weight:continue
            assert float(hi[i]).is_integer()
            terms=[]
            for k in range(csr.indptr[i],csr.indptr[i+1]):
                j=int(csr.indices[k]);value=csr.data[k];assert float(value).is_integer()
                terms.append([j,int(value)]);coefficients[j]+=int(value)*weight
            total+=int(hi[i])*weight
            rows.append(dict(terms=terms,rhs=int(hi[i]),weight=weight))
        upper=[max(0,-int(cost)*denominator-v) for cost,v in zip(c,coefficients)]
        total+=sum(upper)
        assert all(v+u>=-int(cost)*denominator for v,u,cost in zip(coefficients,upper,c))
        assert 0<=total<denominator, 'Rounding did not certify gain below one.'
        row=dict(base=domain['base'],max_removals=cap,variables=len(c),denominator=denominator,
                 constraints=rows,upper_units=upper,total_units=total,integer_gain_upper=total//denominator,
                 numerical_gain_bound=-float(lp.fun))
        if a.max_four_insertions is not None:
            row['max_four_insertions']=a.max_four_insertions
        out['rows'].append(row)
        print(json.dumps({k:v for k,v in row.items() if k not in ('constraints','upper_units')}),flush=True)
    a.output.write_text(json.dumps(out,indent=2)+'\n')


if __name__=='__main__':main()
