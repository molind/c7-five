"""Create a frozen experiment using posting-list intersection counts.

The original joint scanner and binaries remain unchanged for active jobs.
"""
from pathlib import Path

r = Path(__file__).resolve().parent
source = r / 'scan_component_atomic9_incremental_joint.cpp'
target = r / 'scan_component_atomic9_incremental_joint_count.cpp'
assert not target.exists()
text = source.read_text()
text = text.replace('        unsigned minimum_degree=10;', '''        unsigned minimum_degree=10;
        std::vector<unsigned> intersection_counts;
        std::vector<std::uint64_t> stamps;
        std::uint64_t generation=0;''')
text = text.replace('        indices.push_back(std::move(index));', '''        index.intersection_counts.resize(index.requirements.size());
        index.stamps.resize(index.requirements.size());
        indices.push_back(std::move(index));''')
begin = text.index('        for(const auto& index:indices) {')
end = text.index('        return true;\n    };', begin)
text = text[:begin] + '''        for(auto& index:indices) {
            if(index.minimum_degree<=remaining)continue;
            // Every q vertex visits each containing requirement once. Reaching
            // |U intersect q| >= |U|-remaining is exactly |U-q| <= remaining.
            // Stamps avoid clearing the whole index for every generated prefix.
            if(++index.generation==0) {
                std::fill(index.stamps.begin(),index.stamps.end(),0);
                index.generation=1;
            }
            bool found=false;
            for(int b:q) {
                for(int i:index.at[b]) {
                    if(index.stamps[i]!=index.generation) {
                        index.stamps[i]=index.generation;
                        index.intersection_counts[i]=0;
                    }
                    ++index.intersection_counts[i];
                    if(index.intersection_counts[i]+remaining>=index.requirements[i].size()) {
                        found=true;break;
                    }
                }
                if(found)break;
            }
            if(!found)return false;
        }
''' + text[end:]
text = text.replace('Usage: scan_component_atomic9_incremental_joint ',
                    'Usage: scan_component_atomic9_incremental_joint_count ')
target.write_text(text)
