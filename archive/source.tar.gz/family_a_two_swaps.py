"""Exhaust all exact two-for-two moves from the seven pinned Family-A states."""
import hashlib
from itertools import combinations, product
import json
from pathlib import Path

from family_a_component import WORDS, TOKENS

HERE = Path(__file__).parent
data = json.loads((HERE/'family-a-component.json').read_text())
states = []
for row in data['states']:
    tokens = Path(row['words_file']).read_text().split()
    assert hashlib.sha256(' '.join(tokens).encode()).hexdigest() == row['sha256']
    states.append(tuple(int(w, 7) for w in tokens))
known = {frozenset(s): i for i, s in enumerate(states)}
outside, rows = {}, []
for si, state in enumerate(states):
    occupied = set(state)
    cb = [0]*len(WORDS)
    for i, wi in enumerate(state):
        for a, b, c, d, e in product(*[((x-1) % 7, x, (x+1) % 7) for x in WORDS[wi]]):
            cb[2401*a + 343*b + 49*c + 7*d + e] |= 1 << i
    pool = [v for v in range(len(WORDS)) if v not in occupied and cb[v].bit_count() <= 2]
    targets, pairs_checked, legal = set(), 0, 0
    for a, b in combinations(pool, 2):
        pairs_checked += 1
        union = cb[a] | cb[b]
        if union.bit_count() > 2:
            continue
        if not any((x-y) % 7 in (2, 3, 4, 5) for x, y in zip(WORDS[a], WORDS[b])):
            continue
        assert union.bit_count() == 2, 'An improving <=1 exchange was found'
        removed = [state[i] for i in range(len(state)) if union >> i & 1]
        target = frozenset((occupied-set(removed)) | {a, b})
        assert len(target) == 367
        legal += 1
        if target in known:
            targets.add(known[target])
        else:
            text = ' '.join(TOKENS[v] for v in sorted(target))
            digest = hashlib.sha256(text.encode()).hexdigest()
            outside.setdefault(digest, dict(parent=si, removed=[TOKENS[v] for v in removed],
                                            added=[TOKENS[a], TOKENS[b]], words=text))
    rows.append(dict(state=si, pool=len(pool), pairs_checked=pairs_checked,
                     legal_two_swaps=legal, known_targets=sorted(targets)))
report = dict(rows=rows, distinct_outside_states=len(outside), outside=outside,
              scope='All exact two-for-two replacements; one-for-one closure checked separately')
(HERE/'family-a-two-swaps.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({k: v for k, v in report.items() if k != 'outside'}, indent=2))
