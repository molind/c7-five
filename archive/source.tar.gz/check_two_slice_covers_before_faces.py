"""Check two-slice certificates with integer arithmetic, Python standard library.

Rebuilds the complete domains, checks each clique and every vertex's coverage,
then checks which forbidden-core decisions follow. Also re-enumerates all
maximum independent extensions of the full D core. Imports no search/LP code.
"""
from collections import Counter
from functools import lru_cache
import gzip
import hashlib
from itertools import combinations, product
import json
from pathlib import Path
import struct
import time

HERE = Path(__file__).resolve().parent
WORDS = list(product(range(7), repeat=5))


def conflict(a, b):
    return all((x-y) % 7 in (0, 1, 6) for x, y in zip(WORDS[a], WORDS[b]))


def vertex(w):
    value = 0
    for x in w:
        value = 7*value+x
    return value


@lru_cache(None)
def closed(v):
    return frozenset(vertex(w) for w in product(*[((x-1) % 7, x, (x+1) % 7) for x in WORDS[v]]))


def check_cover(row, domain, demands):
    den = row['denominator']
    assert type(den) is int and den > 0 and set(demands) == domain
    cover = {v: 0 for v in domain}
    total = 0
    for entry in row['cover']:
        vs, n = entry['vertices'], entry['units']
        assert type(n) is int and n > 0 and vs and len(vs) == len(set(vs))
        assert set(vs) <= domain and all(conflict(a, b) for a, b in combinations(vs, 2))
        for v in vs:
            cover[v] += n
        total += n
    assert all(cover[v] >= demands[v]*den for v in domain)
    assert total == row['total_units']
    return total, den


def check_core_extensions(core, states):
    pool = sorted(set(range(7**5))-set.union(*(set(closed(v)) for v in core)))
    adj = [sum(1 << j for j, u in enumerate(pool) if j != i and conflict(v, u))
           for i, v in enumerate(pool)]

    @lru_cache(None)
    def optimum(mask):
        if not mask:
            return 0
        v = (mask & -mask).bit_length()-1
        rest = mask ^ (1 << v)
        return max(optimum(rest), 1+optimum(rest & ~adj[v]))

    def enumerate_maxima(mask, needed, chosen):
        if needed == 0:
            yield frozenset(chosen)
            return
        if optimum(mask) < needed:
            return
        v = (mask & -mask).bit_length()-1
        rest = mask ^ (1 << v)
        yield from enumerate_maxima(rest, needed, chosen)
        yield from enumerate_maxima(rest & ~adj[v], needed-1, chosen+[pool[v]])

    full = (1 << len(pool))-1
    size = optimum(full)
    maxima = set(enumerate_maxima(full, size, []))
    assert len(pool) == 23 and size == 11 and len(maxima) == 384
    assert maxima == {frozenset(s-core) for s in states}
    for m in maxima:
        assert len(m | core) == 367 and all(not conflict(a, b) for a, b in combinations(m | core, 2))
    return dict(pool_size=len(pool), residual_alpha=size, maxima=len(maxima),
                all_maxima_are_cached_D=True, all_maxima_direct_pair_checks=384*67161)


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    began = time.monotonic()
    cache = HERE/'breakout-perturb64-sep20-2049-component-0.jsonl.gz'
    with gzip.open(cache, 'rt') as f:
        metadata = json.loads(next(f))
        states = [set(json.loads(line)) for line in f]
    packed = sorted(struct.pack('<367H', *sorted(s)) for s in states)
    assert len(set(packed)) == 384
    assert hashlib.sha256(b''.join(packed)).hexdigest() == metadata['component_sha256']
    core = set.intersection(*states)
    seed_words = (HERE/'family-d-seed-words.txt').read_text().split()
    seed = {int(w, 7) for w in seed_words}
    assert len(seed) == len(seed_words) == 367 and len(core) == 356 and core <= seed
    assert all(not conflict(a, b) for a, b in combinations(seed, 2))
    files = ['two-slice-lp-d-core-barrier-sep21.json', 'two-slice-lp-d-six-open-sep21.json']
    reports = [json.loads((HERE/n).read_text()) for n in files]
    assert all(r['status'] == 'queries_complete' for r in reports)
    expected = set()
    domains = {}
    for axis in range(5):
        for start in range(7):
            key = f'{axis}:{start}'
            fixed = {v for v in seed if (WORDS[v][axis]-start) % 7 >= 2}
            pool = set(range(7**5))-set.union(*(set(closed(v)) for v in fixed))
            original = seed-fixed
            assert original <= pool
            domains[key] = pool, len(original), core & pool
            expected.update((key, v) for v in core & pool)
    assert len(expected) == 3560
    covered = set()
    checked = []
    for report in reports:
        for key, saved in report['pools'].items():
            pool, target, _ = domains[key]
            assert sorted(pool) == saved['pool'] and saved['fixed_size'] == 367-target
        for row in report['results']:
            key = row['pool_key']
            pool, target, local_core = domains[key]
            assert target == row['target']
            if report['core_barrier']:
                multiplier = len(local_core)+1
                assert row['multiplier'] == multiplier and row['core_in_pool'] == sorted(local_core)
                demands = {v: multiplier-int(v in core) for v in pool}
                assert row['demands'] == [{'vertex': v, 'weight': demands[v]} for v in sorted(pool)]
                total, den = check_cover(row, pool, demands)
                threshold = multiplier*target-len(local_core)+1
                forces = total < threshold*den
                assert row['weighted_escape_threshold'] == threshold and row['forces_all_core'] == forces
                if forces:
                    covered.update((key, v) for v in local_core)
                checked.append(dict(pool_key=key, mode='weighted', forces_all_core=forces,
                                    local_size_upper=(total+len(local_core)*den)//(multiplier*den)))
            else:
                forbidden = row['forbidden']
                assert forbidden in local_core
                domain = pool-{forbidden}
                total, den = check_cover(row, domain, {v: 1 for v in domain})
                excludes = total < target*den
                assert excludes == row['excludes_target']
                if excludes:
                    covered.add((key, forbidden))
                checked.append(dict(pool_key=key, mode='single_ban', forbidden=forbidden,
                                    excludes_target=excludes, local_size_upper=total//den))
    # Negative controls: a missing cover and a non-clique cannot be certificates.
    first = reports[0]['results'][0]
    pool, _, local_core = domains[first['pool_key']]
    demands = {v: len(local_core)+1-int(v in core) for v in pool}
    bad = dict(first, cover=[])
    try:
        check_cover(bad, pool, demands)
    except AssertionError:
        pass
    else:
        raise AssertionError('Empty cover accepted')
    pair = next((a, b) for a, b in combinations(sorted(pool), 2) if not conflict(a, b))
    bad = dict(first, cover=[{'vertices': list(pair), 'units': 1}])
    try:
        check_cover(bad, pool, demands)
    except AssertionError:
        pass
    else:
        raise AssertionError('Non-clique accepted')
    full_core = check_core_extensions(core, states)
    out = dict(checked_certificates=len(checked), expected_forbidden_core_cases=len(expected),
               covered_forbidden_core_cases=len(covered), uncovered=sorted(expected-covered),
               all_two_slice_core_escapes_excluded=(expected == covered),
               checked=checked, full_core=full_core, negative_controls_passed=2,
               seconds=time.monotonic()-began,
               hashes={n: hashlib.sha256((HERE/n).read_bytes()).hexdigest() for n in files},
               checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               scope='Only the pinned D seed and two adjacent coordinate values. Local separately implemented checker; no external replay or global bound.')
    path = HERE/'two-slice-cover-verification-sep21.json'
    if path.exists():
        raise FileExistsError(path)
    path.write_text(json.dumps(out, indent=2)+'\n')
    print(json.dumps({k: v for k, v in out.items() if k not in ('checked', 'hashes')}), flush=True)


if __name__ == '__main__':
    main()
