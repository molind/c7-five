"""Replay every saved replacement using direct coordinate counts.

Validates domain, fixed exterior, overlap cap, cardinality and true conflict
energy. Does not re-execute the heuristic's weighted proposal selection.
"""
import argparse
import hashlib
import json
from pathlib import Path
import struct

import numpy as np
from check_cardinality_projection import conflicts,verify
from search_cardinality_projection import load_projection_model


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();assert __debug__ and not a.output.exists()
    report=json.loads(a.input.read_text());source=Path(report['input'])
    assert hashlib.sha256(source.read_bytes()).hexdigest()==report['input_sha256']
    trajectory=json.loads(source.read_text());verify(trajectory)
    _,model,_,_,cap,bounded=load_projection_model(Path(trajectory['input']),Path(trajectory['base_verification']),Path(trajectory['overlap']['certificate']))
    fixed=set(model['fixed']);pool=set(model['pool']);limited={model['pool'][i] for i in bounded}
    allowed_starts=[sorted(model['fixed']+row['rounded_vertices']) for row in trajectory['rows']]
    if report.get('start_source') is not None:
        origin=report['start_source'];assert hashlib.sha256(Path(origin['file']).read_bytes()).hexdigest()==origin['sha256']
        prior=json.loads(Path(origin['file']).read_text())
        assert prior['input_sha256']==report['input_sha256']
        assert prior['fixed']==model['fixed'] and prior['pool']==model['pool'] and set(prior['limited'])==limited and prior['cap']==cap
        kind=origin.get('kind','best');assert kind in ('best','final')
        allowed_starts=[run[kind+'_words'] for run in prior['runs']]
    words=np.array([[v//7**j%7 for j in range(5)] for v in range(16807)])
    released=report.get('released_fixed',[])
    assert len(released)==len(set(released)) and set(released)<=fixed
    if released:
        fixed-=set(released);available=np.ones(16807,dtype=bool)
        for v in fixed:
            delta=(words-words[v])%7
            available &= ~np.all((delta==0)|(delta==1)|(delta==6),axis=1)
        pool=set(np.flatnonzero(available).tolist());limited=set();cap=0
    assert report['fixed']==sorted(fixed) and report['pool']==sorted(pool)
    assert set(report['limited'])==limited and report['cap']==cap
    def adjacent_count(v,others):
        delta=(words[list(others)]-words[v])%7
        return int(sum(np.all((delta==0)|(delta==1)|(delta==6),axis=1)))
    verified=[];one_edge_states=set();independent_removed_sets=set();checks=0
    for ri,run in enumerate(report['runs']):
        selected=set(run['start']);assert len(selected)==len(run['start'])==368
        assert fixed<=selected and selected-fixed<=pool and len(selected&limited)<=cap
        assert run['start'] in allowed_starts
        energy=conflicts(run['start']);best=energy;best_words=sorted(selected)
        assert run['steps']==len(run['moves'])
        learning_steps=run.get('learning_steps');reset=run.get('phase_reset');checked_reset=False
        for step,(old,new,saved_energy) in enumerate(run['moves'],1):
            assert old in selected-fixed and new in pool-selected
            selected.remove(old);energy-=adjacent_count(old,selected)
            if energy==0:
                independent_removed_sets.add(tuple(sorted(selected)))
            energy+=adjacent_count(new,selected);selected.add(new)
            assert energy==saved_energy and len(selected&limited)<=cap
            checks+=2*367
            if energy<best:best=energy;best_words=sorted(selected)
            if energy==1:one_edge_states.add(tuple(sorted(selected)))
            if step==learning_steps and energy>0:
                assert reset is not None and reset['after_step']==step and reset['conflicts']==energy
                assert reset['selected_sha256']==hashlib.sha256(struct.pack('<368H',*sorted(selected))).hexdigest()
                assert type(reset['maximum_weight_before']) is int and reset['maximum_weight_before']>=1
                checked_reset=True
        assert sorted(selected)==run['final_words']
        assert best==run['best_conflicts'] and best_words==run['best_words']
        assert conflicts(run['final_words'])==energy and conflicts(best_words)==best
        assert (run['status']=='independent')==(best==0)
        period=run['penalty_period']
        penalty_steps=max(0,run['steps']-int(best==0))
        if learning_steps is not None:penalty_steps=min(penalty_steps,learning_steps-1)
        expected=penalty_steps//period if period else 0
        assert expected==run['penalty_updates']
        if learning_steps is not None:
            assert (reset is not None)==checked_reset
            assert run['unit_score_checks']==max(0,run['steps']-learning_steps)
        verified.append(dict(run=ri,moves=run['steps'],best_conflicts=best,final_conflicts=energy,reset_checked=checked_reset,
                             unit_score_checks=run.get('unit_score_checks',0)))
    if report['candidates']:
        for candidate in report['candidates']:
            assert len(candidate['vertices'])==candidate['size']==368 and not conflicts(candidate['vertices'])
            assert candidate['pair_checks']==67528
            assert any(run['best_words']==candidate['vertices'] for run in report['runs'])
    found=any(row['best_conflicts']==0 for row in report['runs'])
    assert (report['status']=='verified_target')==found
    result=dict(input=str(a.input),input_sha256=hashlib.sha256(a.input.read_bytes()).hexdigest(),
                checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),runs=verified,
                moves=sum(r['moves'] for r in verified),coordinate_pair_tests=checks,
                one_edge_states=[list(s) for s in sorted(one_edge_states)],
                independent_removed_sets=[list(s) for s in sorted(independent_removed_sets)],target_witness_found=found,scope=__doc__)
    a.output.write_text(json.dumps(result,separators=(',',':'))+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('one_edge_states','independent_removed_sets')}|
                     {'one_edge_states':len(one_edge_states),'independent_removed_sets':len(independent_removed_sets)}),flush=True)


if __name__=='__main__':main()
