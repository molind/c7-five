"""Target empty/full budgets and blocker bits across machine-word boundaries."""
import json
from pathlib import Path
import subprocess
import sys

from check_exchange_dfs import graph_text

HERE = Path(__file__).parent
positions = [0, 63, 64, 127, 128, 191, 192, 255]
cases = []
for radius in range(9):
    mask = sum(1 << i for i in positions[:radius])
    n = radius + 1
    cases.append((f'shared-r{radius}', radius, [mask]*n, True))
    cases.append((f'one-extra-r{radius}', radius, [mask]*(n-1) + [mask | (1 << 511)], False))
cases.append(('unsaturated-must-grow', 1, [0, 1], True))
cases.append(('zero-blockers-positive', 6, [0]*7, True))
records = []
for executable in ['exchange_dfs', 'exchange_dfs_sanitized']:
    for name, radius, cb, expected in cases:
        n = len(cb)
        comp = [((1 << n)-1) ^ (1 << i) for i in range(n)]
        graph = graph_text(cb, comp, radius, 8)
        answers = []
        for options in [[], ['--subset']]:
            run = subprocess.run([str((HERE/executable).resolve()), '5', *options],
                                 input=graph, capture_output=True, text=True, check=True, timeout=7)
            result = json.loads(run.stdout)
            assert result['status'] == ('witness' if expected else 'exhausted'), (name, result)
            answers.append(result['chosen'])
        assert answers[0] == answers[1]
        records.append(dict(binary=executable, case=name, witness=expected))
report = dict(cases_per_binary=len(cases), binaries=2, modes=2, runs=len(records)*2,
              blocker_bit_positions=positions+[511], controls=records)
(HERE/'subset-boundary-controls.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k != 'controls'}))
