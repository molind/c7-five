"""Exhaustive tests of per-candidate requirements on a prefix's selected count."""
from itertools import combinations
import json,random,subprocess,sys
from pathlib import Path
from check_exchange_dfs import graph_text,controls
binary=Path(sys.argv[1]).resolve();rng=random.Random(2026091818);positive=0
for case in range(240):
    n=rng.randrange(1,12);d=rng.randrange(1,7);prefix=rng.randrange(n+1)
    cb=[sum(1<<x for x in rng.sample([0,1,63,64,128,307,366,511],rng.randrange(4))) for _ in range(n)]
    comp=[0]*n
    for i,j in combinations(range(n),2):
        if rng.randrange(4):comp[i]|=1<<j;comp[j]|=1<<i
    req=[rng.randrange(d+3) if rng.randrange(3) else 0 for _ in range(n)]
    for neutral in [False,True]:
        target=d if neutral else d+1;expected={'neutral':[],'improving':[]};witness=[]
        for chosen in combinations(range(n),target):
            mask=0
            for i in chosen:mask|=cb[i]
            if mask.bit_count()>d or sum(i<prefix for i in chosen)<max(req[i] for i in chosen):continue
            if not all(comp[i]>>j&1 for i,j in combinations(chosen,2)):continue
            if not witness:witness=list(chosen)
            expected['neutral' if mask.bit_count()==d else 'improving'].append(list(chosen))
        positive+=bool(witness)
        for subset in [False,True]:
            args=['--anchor-bounds',str(prefix)]+(['--neutral'] if neutral else [])+(['--subset'] if subset else [])
            data=graph_text(cb,comp,d,8)+' '.join(map(str,req))+'\n'
            r=json.loads(subprocess.run([str(binary),'5',*args],input=data,text=True,capture_output=True,check=True,timeout=7).stdout)
            if neutral:
                assert r['status']=='exhausted' and all(r[k]==v for k,v in expected.items())
                assert r['nodes_started']==r['nodes_completed']
            else:
                assert r['status']==('witness' if witness else 'exhausted') and r['chosen']==witness
# The last usable prefix bit is required; indices straddle u64 boundaries.
for n in [63,64,65,127,128,129]:
    for prefix in [n-2,n-1,n]:
        comp=[0]*n;comp[n-2]=1<<(n-1);comp[n-1]=1<<(n-2)
        data=graph_text([1]*n,comp,1,1)+' '.join(['2']*n)+'\n'
        for opts in [[],['--subset']]:
            r=json.loads(subprocess.run([str(binary),'5','--anchor-bounds',str(prefix),*opts],input=data,text=True,capture_output=True,check=True,timeout=7).stdout)
            assert r['chosen']==([n-2,n-1] if prefix==n else [])
for prefix,trailer in [('4','0 0 0'),('3',''),('3','0 -1 0'),('3','0 20001 0')]:
    r=subprocess.run([str(binary),'5','--anchor-bounds',prefix],input=graph_text([1]*3,[6,5,3],2,1)+trailer,text=True,capture_output=True,timeout=7);assert r.returncode!=0
report=dict(cases=240,modes=4,positive_mode_cases=positive,boundary_runs=36,invalid_controls=4,binary=str(binary),seed=2026091818)
Path(__file__).with_name(binary.name+'-anchor-count-controls.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
controls(binary);controls(binary,['--subset'])
