"""Resume a restricted neutral search using an existing checked native graph.

The blocker-degree prefix is an intentional exploration filter, not a complete
neutral-neighborhood claim. No gain-only count certificate is used. Native
timeout/output-limit results remain partial; next_root skips only finished roots.
"""
import argparse
import hashlib
from itertools import product
import json
from pathlib import Path
import subprocess
import time

import numpy as np


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--graph-query',required=True,type=Path)
    p.add_argument('--base',required=True,type=int)
    p.add_argument('--start',required=True,type=int)
    p.add_argument('--previous',type=Path)
    p.add_argument('--end',type=int,help='Optional exclusive endpoint for a first-word interval.')
    p.add_argument('--minimum-blocker-degree',type=int,default=5)
    p.add_argument('--seconds',type=float,default=60)
    p.add_argument('--output',required=True,type=Path)
    a=p.parse_args();assert __debug__ and not a.output.exists() and 0<a.seconds<=600
    here=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    query=json.loads(a.graph_query.read_text());assert query['status']=='complete'
    mp=Path(query['input']);assert sha(mp)==query['input_sha256'];model=json.loads(mp.read_text())
    geometry=Path(query['geometry_proof']);assert sha(geometry)==query['geometry_proof_sha256']
    proof=json.loads(geometry.read_text());assert proof['model_sha256']==sha(mp)
    assert proof['checker_sha256']==sha(here/'check_blocker_trade_results.py')
    bp=Path(model['input']);assert sha(bp)==model['input_sha256']
    old=json.loads(bp.read_text())['bases'][a.base]['words'];assert old==sorted(set(old)) and len(old)==367
    domain=next(r for r in model['rows'] if r['base']==a.base)
    ref=next(r for r in query['rows'] if r['base']==a.base)
    order=ref['kernel_order'];n=len(order);assert sorted(order)==list(range(n))
    pool=domain['pool_ids'];blocked=domain['blocker_sets'];assert n==len(pool)
    prefix=sum(len(b)>=a.minimum_blocker_degree for b in blocked)
    assert all((len(blocked[i])>=a.minimum_blocker_degree)==(j<prefix) for j,i in enumerate(order))
    end=prefix if a.end is None else a.end
    assert 0<=a.start<=end<=prefix
    radius=query['max_removals'];graph=Path(ref['graph']);assert sha(graph)==ref['graph_sha256']
    inv={v:i for i,v in enumerate(order)};bad=[1<<i for i in range(n)]
    for u,v in domain['conflict_edges']:
        i,j=inv[u],inv[v];bad[i]|=1<<j;bad[j]|=1<<i
    cw=(n+63)//64;full=(1<<n)-1
    with graph.open() as f:
        assert list(map(int,next(f).split()))==[n,6,radius]
        for j,i in enumerate(order):
            values=[int(v,16) for v in next(f).split()]
            assert len(values)==6+cw and all(0<=v<1<<64 for v in values)
            assert sum(v<<(64*k) for k,v in enumerate(values[:6]))==sum(1<<v for v in blocked[i])
            assert sum(v<<(64*k) for k,v in enumerate(values[6:]))==full^bad[j]
        assert not f.read().strip(), 'Neutral input must not contain gain-only anchor rules'
    binary=here/'exchange_dfs_residual_two'
    command=[str(binary),str(a.seconds),'--subset','--budget-bitsets','--binary-budget','--residual-budget',
             '--neutral','--root-start',str(a.start),'--root-prefix',str(end)]
    out=dict(status='running',input=str(mp),input_sha256=sha(mp),base=a.base,radius=radius,
             source_sha256=sha(__file__),graph_query=str(a.graph_query),graph_query_sha256=sha(a.graph_query),
             graph=str(graph),graph_sha256=sha(graph),kernel=str(binary),kernel_sha256=sha(binary),
             kernel_source_sha256=sha(binary.with_suffix('.cpp')),command=command,
             root_start=a.start,root_end=end,full_prefix_end=prefix,minimum_blocker_degree=a.minimum_blocker_degree,
             graph_rows_checked=n,candidates=[],scope=__doc__)
    if a.previous:
        prior=json.loads(a.previous.read_text());k=prior.get('kernel_result',prior)
        assert k['enumerate_neutral'] and k['root_end']==end and k['next_root']==a.start
        if 'graph_sha256' in prior:assert prior['graph_sha256']==sha(graph)
        out.update(previous=str(a.previous),previous_sha256=sha(a.previous),previous_has_graph_binding='graph_sha256' in prior)
    def save():
        tmp=a.output.with_suffix('.tmp');tmp.write_text(json.dumps(out,indent=2)+'\n');tmp.replace(a.output)
    save();began=time.monotonic()
    with graph.open() as f:
        run=subprocess.run(command,stdin=f,text=True,capture_output=True,check=True,timeout=a.seconds+20)
    result=json.loads(run.stdout);out.update(kernel_result=result,wall_seconds=time.monotonic()-began,status='validating');save()
    assert result['status'] in ('exhausted','timeout','output_limit') and result['enumerate_neutral']
    assert result['root_start']==a.start and result['root_end']==end and a.start<=result['next_root']<=end
    assert not result['anchor_bounds'] and not result['pair_bounds'] and not result['noncore_bound']
    if result['status']=='exhausted':assert result['nodes_started']==result['nodes_completed'] and result['next_root']==end
    coords=np.array(list(product(range(7),repeat=5)),dtype=np.int16);seen=set()
    for kind in ('neutral','improving'):
        for index,chosen in enumerate(result[kind]):
            assert len(chosen)==len(set(chosen))==radius and all(type(i) is int and 0<=i<n for i in chosen)
            assert a.start<=min(chosen)<end
            selected=[order[i] for i in chosen];removed=sorted({j for i in selected for j in blocked[i]})
            assert len(removed)<=radius and (len(removed)==radius)==(kind=='neutral')
            words=tuple(sorted((set(old)-{old[j] for j in removed})|{pool[i] for i in selected}))
            assert len(words)==len(set(words))==367+radius-len(removed)
            if words in seen:continue
            seen.add(words);points=coords[list(words)]
            delta=(points[:,None,:]-points[None,:,:])%7
            conflicts=np.all((delta==0)|(delta==1)|(delta==6),axis=2)
            assert np.array_equal(conflicts,np.eye(len(words),dtype=bool))
            out['candidates'].append(dict(step=len(out['candidates']),source_base=a.base,native_kind=kind,native_index=index,
                chosen_indices=selected,removed_indices=removed,size=len(words),pair_checks=len(words)*(len(words)-1)//2,
                words=[''.join(map(str,coords[v])) for v in words]))
    out['status']='verified_target' if any(c['size']>=368 for c in out['candidates']) else 'complete'
    save();print(json.dumps(dict(base=a.base,status=result['status'],root_start=a.start,next_root=result['next_root'],
                                root_end=end,neutral=len(result['neutral']),improving=len(result['improving']),unique=len(seen))),flush=True)


if __name__=='__main__':main()
