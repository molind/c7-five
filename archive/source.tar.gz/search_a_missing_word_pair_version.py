"""Bounded cap3 BFS while keeping selected cap2-core words absent."""
import argparse
from collections import deque
import hashlib
from itertools import combinations, product
import json
from pathlib import Path
import struct
import time

from search_low_conflict import WORDS, TOKENS, family_start, independent_target, successors

HERE = Path(__file__).resolve().parent


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--entry',type=int,required=True)
    parser.add_argument('--states',type=int,default=20000)
    parser.add_argument('--seconds',type=float,default=45)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--start-result',type=Path,
                        help='Continue from a previously verified positive result endpoint')
    args = parser.parse_args()
    source = HERE/'family-a-diverse-cap3-entries.json'
    data = json.loads(source.read_text())
    if args.states<1 or args.seconds<=0 or not 0<=args.entry<len(data['entries']):
        parser.error('Positive budgets and a valid entry index required')
    entry = data['entries'][args.entry]
    fixed = {int(w,7) for w in json.loads((HERE/'family-a-cap2-export-verification.json').read_text())['fixed_words']}
    base=None
    if args.start_result:
        base=json.loads(args.start_result.read_text())
        assert base['entry']==args.entry and base['final_words']
    start = frozenset(int(w,7) for w in (base or entry)['final_words'])
    omitted=fixed-start
    assert len(start)==368 and omitted
    if base is None:assert omitted=={int(entry['boundary_move']['removed'],7)}
    conflict=lambda a,b:all((x-y)%7 in (0,1,6) for x,y in zip(WORDS[a],WORDS[b]))
    assert sum(conflict(a,b) for a,b in combinations(start,2))==3
    _,known = family_start('A')
    adjacency = [tuple(2401*a+343*b+49*c+7*d+e
        for a,b,c,d,e in product(*[((x-1)%7,x,(x+1)%7) for x in w])
        if 2401*a+343*b+49*c+7*d+e != v) for v,w in enumerate(WORDS)]
    root = struct.pack('<368H',*sorted(start))
    parents = {root:None}
    queue = deque([root])
    popped = examined = allowed = skipped_restore = 0
    status = 'exhausted'
    found = independent = None
    began = time.monotonic()
    while queue:
        if time.monotonic()-began>=args.seconds:
            status='timeout'
            break
        key = queue.popleft()
        state = frozenset(struct.unpack('<368H',key))
        popped += 1
        for target,energy,removed,added,conflicts in successors(state,adjacency,3):
            examined += 1
            if examined%1024==0 and time.monotonic()-began>=args.seconds:
                status='timeout'
                break
            if added in omitted:
                skipped_restore += 1
                continue
            allowed += 1
            target_key = struct.pack('<368H',*sorted(target))
            if target_key in parents:
                continue
            independent = independent_target(target,conflicts,known)
            if independent is not None:
                status='independent368' if energy==0 else 'outside_A367'
            elif energy<=2:
                # Every state in the completed old cap2 component contains omitted.
                status='new_cap2_component'
            elif removed in fixed:
                status='more_missing_fixed_words'
            if status!='exhausted':
                parents[target_key]=(key,removed,added,energy)
                found=target_key
                break
            if len(parents)>=args.states:
                status='state_limit'
                break
            parents[target_key]=(key,removed,added,energy)
            queue.append(target_key)
        if status!='exhausted':
            break
    path = []
    if found is not None:
        cursor=found
        while parents[cursor] is not None:
            previous,removed,added,energy=parents[cursor]
            path.append(dict(removed=TOKENS[removed],added=TOKENS[added],energy=energy))
            cursor=previous
        path.reverse()
        replay=set(start)
        energy=sum(conflict(a,b) for a,b in combinations(replay,2))
        assert energy==3
        for move in path:
            removed,added=int(move['removed'],7),int(move['added'],7)
            assert removed in replay and added not in replay and added not in omitted
            replay.remove(removed)
            energy+=sum(conflict(added,v)-conflict(removed,v) for v in replay)
            replay.add(added)
            assert len(replay)==368 and energy==move['energy'] and 0<=energy<=3
        assert replay==set(struct.unpack('<368H',found))
        if status=='more_missing_fixed_words':assert len(fixed-replay)==len(omitted)+1
        if status=='new_cap2_component':assert not omitted.intersection(replay) and energy<=2
        if independent is not None:
            assert len(independent) in (367,368) and independent not in known
            assert not any(conflict(a,b) for a,b in combinations(independent,2))
    result=dict(status=status,entry=args.entry,kept_absent_words=[TOKENS[v] for v in sorted(omitted)],
                source_index=entry['source_index'],states=len(parents),popped=popped,queued=len(queue),
                examined=examined,allowed_directed=allowed,skipped_restore=skipped_restore,
                seconds=time.monotonic()-began,state_limit=args.states,time_limit=args.seconds,
                path=path,final_words=None if found is None else [TOKENS[v] for v in struct.unpack('<368H',found)],
                independent_words=None if independent is None else [TOKENS[v] for v in sorted(independent)],
                source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                entries_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                start_result=None if args.start_result is None else str(args.start_result),
                start_result_sha256=None if args.start_result is None else hashlib.sha256(args.start_result.read_bytes()).hexdigest(),
                scope='Single selected E3 start, cap3 and selected forbidden re-insertions. Exhaustion applies only to this constrained reachable component; budget stops give no exclusion. More omissions/new cap2 are intermediate targets, not independent-set results.')
    if status=='exhausted':
        assert popped==len(parents) and not queue
        result['states_sha256']=hashlib.sha256(b''.join(sorted(parents))).hexdigest()
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('path','final_words','independent_words')}))


if __name__=='__main__':
    main()
