"""Reconstruct placed slices and verify the complete saved finite library.

Uses direct coordinate differences for blocked masks and an independent sparse
max-plus matrix recurrence for the seven-walk maximum. Does not certify the
absence of placements discarded by the numerical FFT discovery filter.
"""
import argparse
from collections import Counter
import hashlib
from itertools import combinations, permutations, product
import json
from pathlib import Path

import numpy as np


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def geometry(slices):
    points = np.array(list(product(range(7), repeat=4)), dtype=np.int16)
    weights = np.array([343, 49, 7, 1], dtype=np.int64)
    masks, blocked = [], []
    within_pairs = 0
    for sl in slices:
        array = np.array(sl, dtype=np.int16)
        assert len(array) > 0 and array.shape == (len(sl), 4)
        assert all(type(x) is int and 0 <= x < 7 for w in sl for x in w)
        ids = array @ weights
        assert len(ids) == len(set(map(int, ids)))
        d = (array[:, None, :] - array[None, :, :]) % 7
        assert not np.any(np.triu(np.all((d == 0) | (d == 1) | (d == 6), axis=2), 1))
        within_pairs += len(sl)*(len(sl)-1)//2
        d = (points[:, None, :] - array[None, :, :]) % 7
        bad = np.any(np.all((d == 0) | (d == 1) | (d == 6), axis=2), axis=1)
        blocked.append(int.from_bytes(np.packbits(bad, bitorder='little').tobytes(), 'little'))
        masks.append(sum(1 << int(v) for v in ids))
    adj = [[] for _ in slices]
    for i in range(len(slices)):
        for j in range(i):
            if blocked[i] & masks[j] == 0:
                adj[i].append(j)
                adj[j].append(i)
    return adj, within_pairs


def matrix_optimum(weights, adj, length=7):
    n = len(weights)
    scores = np.full((n, n), -100000, dtype=np.int64)
    np.fill_diagonal(scores, 0)
    for _ in range(length):
        newer = np.full_like(scores, -100000)
        for v, neighbors in enumerate(adj):
            if neighbors:
                newer[:, v] = np.max(scores[:, neighbors], axis=1) + weights[v]
        scores = newer
    best = int(np.max(np.diag(scores)))
    return best if best >= 0 else -1


def controls():
    count = 0
    for n in range(1, 5):
        pairs = list(combinations(range(n), 2))
        for mask in range(1 << len(pairs)):
            adj = [[] for _ in range(n)]
            for i, (u, v) in enumerate(pairs):
                if mask >> i & 1:
                    adj[u].append(v)
                    adj[v].append(u)
            weights = list(range(1, n+1))
            for length in (3, 5, 7):
                best = max((sum(weights[v] for v in walk) for walk in product(range(n), repeat=length)
                    if all(walk[(i+1) % length] in adj[walk[i]] for i in range(length))), default=-1)
                assert matrix_optimum(weights, adj, length) == best
                count += 1
    # Every pair of one-word slices also checks wraparound and bit numbering.
    points = list(product(range(7), repeat=4))
    chosen = points[::41] + [(6, 6, 6, 6), (0, 0, 0, 0)]
    chosen = list(dict.fromkeys(chosen))
    adj, pairs_checked = geometry([[w] for w in chosen])
    for i, j in combinations(range(len(chosen)), 2):
        expected = any((x-y) % 7 in (2, 3, 4, 5) for x, y in zip(chosen[i], chosen[j]))
        assert (j in adj[i]) == expected
    return dict(exhaustive_weighted_graph_cases=count, single_word_slice_pairs=len(chosen)*(len(chosen)-1)//2)


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    if args.self_test:
        result = controls()
        args.output.write_text(json.dumps(result, indent=2)+'\n')
        print(json.dumps(result))
        return
    if args.input is None:
        parser.error('Input required')
    r = json.loads(args.input.read_text())
    assert r['status'] in ('complete', 'candidate_found')
    source_path, verification_path = Path(r['input']), Path(r['verification'])
    assert digest(source_path) == r['input_sha256']
    assert digest(verification_path) == r['verification_sha256']
    assert json.loads(verification_path.read_text())['input_sha256'] == r['input_sha256']
    source = json.loads(source_path.read_text())
    base_count, parent_count = len(source['slices']), len(source['parents'])
    slices = r['slices']
    assert slices[:base_count] == source['slices']
    keys = [tuple(map(tuple, sl)) for sl in slices]
    assert len(set(keys)) == len(keys)
    assert all(tuple(sorted(key)) == key for key in keys)
    transforms = [(p, s) for p in permutations(range(4)) for s in product((-1, 1), repeat=4)]
    assert [t['index'] for t in r['transforms']] == list(range(r['count']))
    assert 1 <= r['count'] <= 384
    exact = r.get('method') == 'integer_translation_intersection'
    anchor = list(range(base_count)) if exact else source['parents'][r['anchor']]['slices']
    referenced = set(range(base_count))
    identities = set()
    by_transform = Counter()
    edge_counts = Counter()
    for p in r['placements']:
        ti, pi, shift = p['transform'], p['parent'], p['shift']
        assert 0 <= ti < r['count'] and 0 <= pi < parent_count
        assert len(shift) == 4 and all(type(x) is int and 0 <= x < 7 for x in shift)
        identity = (ti, pi, tuple(shift))
        assert identity not in identities
        identities.add(identity)
        perm, signs = transforms[ti]
        expected = [tuple(sorted(tuple((signs[k]*w[perm[k]]+shift[k]) % 7 for k in range(4))
                               for w in source['slices'][v])) for v in source['parents'][pi]['slices']]
        assert len(p['slices']) == 7
        assert [keys[v] for v in p['slices']] == expected
        referenced.update(p['slices'])
        assert p['cross_edges']
        by_transform[ti] += 1
        edge_counts[ti] += len(p['cross_edges'])
    assert referenced == set(range(len(slices)))
    adj, within_pairs = geometry(slices)
    assert adj == r['adjacency']
    for p in r['placements']:
        assert p['cross_edges'] == [[i, j] for i in range(len(anchor)) for j in range(7) if p['slices'][j] in adj[anchor[i]]]
    for t in r['transforms']:
        assert t['placements'] == by_transform[t['index']]
        if exact:
            assert t['slice_pairs'] == base_count**2
            assert t['cross_edges'] == edge_counts[t['index']]
        else:
            assert t['pairs'] == parent_count
            assert t['checked_edges'] == edge_counts[t['index']]
            assert 0 <= t['max_rounding_residual'] < 1e-7
    weights = list(map(len, slices))
    assert weights == r['weights']
    best = matrix_optimum(weights, adj)
    assert best == r['best'] >= 367
    cycle = r['cycle']
    assert len(cycle) == 7 and sum(weights[v] for v in cycle) == best
    assert all(cycle[(i+1) % 7] in adj[cycle[i]] for i in range(7))
    words = sorted(''.join(map(str, (layer, *w))) for layer, v in enumerate(cycle) for w in slices[v])
    assert len(r['candidates']) == 1
    c = r['candidates'][0]
    assert c['words'] == words and len(words) == len(set(words)) == c['size'] == best
    assert c['verified_pairs'] == best*(best-1)//2
    assert all(any((int(x)-int(y)) % 7 in (2, 3, 4, 5) for x, y in zip(a, b))
               for a, b in combinations(words, 2))
    statistics = dict(transforms=r['count'], retained_placements=len(r['placements']),
        unique_placed_cycles=len({tuple(sorted(p['slices'])) for p in r['placements']}),
        slices=len(slices), edges=sum(map(len, adj))//2, degree_histogram={str(k):v for k,v in Counter(map(len, adj)).items()})
    if exact:
        statistics.update(slice_pairs=r['count']*base_count**2, parameter_combinations=r['count']*parent_count**2*2401)
    else:
        statistics.update(cycle_pairs=parent_count*r['count'], parameter_combinations=2401*parent_count*r['count'])
    assert r['statistics'] == statistics
    assert (r['status'] == 'candidate_found') == (best >= 368)
    result = dict(input_sha256=digest(args.input), checker_sha256=digest(Path(__file__)),
        slices=len(slices), placements=len(r['placements']), direct_within_slice_pairs=within_pairs,
        direct_slice_compatibility_pairs=len(slices)*(len(slices)-1)//2,
        edges=sum(map(len, adj))//2, optimum=best, returned_witness_pairs=best*(best-1)//2,
        target_witness_found=best >= 368,
        scope='Exact saved finite-library optimum; placement enumeration completeness is outside this checker.')
    args.output.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
