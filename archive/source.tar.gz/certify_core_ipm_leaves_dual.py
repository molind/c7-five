"""Convert numerical infeasible branch leaves to exact integer contradictions.

For signed row weights y, row bounds imply (yA)x <= sum(y+*upper+y-*lower).
The minimum of (yA)x over the variable box is computed with Python integers.
A strictly larger minimum proves this leaf impossible, independently of HiGHS.
"""
import argparse
import json
from pathlib import Path
import time

import numpy as np
from scipy.optimize import linprog
from scipy.sparse import vstack, eye, csc_matrix

from check_two_slice_covers import closed
from search_core_radius_cut import sha
from search_core_ipm_branches import propagate
from solve_core_radius_ipm import build_model, load_radius_model, model_digest


def integer_contradiction(matrix, lower, upper, variable_lo, variable_hi, ray):
    csr = matrix.tocsr()
    assert np.all(np.isfinite(ray))
    assert np.all(matrix.data == np.rint(matrix.data))
    for scale in (1000, 1000000, 1000000000):
        for sign in (1, -1):
            weights = [int(round(float(v) * scale)) * sign for v in ray]
            coefficients = [0] * matrix.shape[1]
            rhs = 0
            for row, weight in enumerate(weights):
                if not weight:
                    continue
                bound = upper[row] if weight > 0 else lower[row]
                assert float(bound).is_integer()
                rhs += weight * int(bound)
                for j in range(csr.indptr[row], csr.indptr[row + 1]):
                    coefficients[csr.indices[j]] += weight * int(csr.data[j])
            minimum = sum(c * int(variable_lo[j] if c > 0 else variable_hi[j]) for j, c in enumerate(coefficients))
            if minimum > rhs:
                return dict(multipliers=[[j, w] for j, w in enumerate(weights) if w],
                            minimum_lhs=minimum, rhs=rhs, positive_gap=minimum-rhs,
                            rounding_scale=scale, ray_sign=sign)
    return None


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--tree', required=True, type=Path)
    p.add_argument('--seconds', type=float, default=30)
    p.add_argument('--output', required=True, type=Path)
    args = p.parse_args()
    assert __debug__ and not args.output.exists() and args.seconds > 0
    tree = json.loads(args.tree.read_text())
    assert tree['status'] == 'bounded_attempt_complete'
    assert tree['source_sha256'] == sha(Path(__file__).with_name('search_core_ipm_branches.py'))
    assert all(sha(f) == h for f, h in tree['dependencies'].items())
    data, matrix, lower, upper, variable_upper, initial = load_radius_model(Path(tree['input']), tree['radius'])
    assert model_digest(matrix, lower, upper, variable_upper) == tree['original_model_sha256']
    lower[-3] = data['target']
    assert model_digest(matrix, lower, upper, variable_upper) == tree['target_model_sha256']
    pool, old = set(data['pool']), set(data['parent_words']) - set(data['fixed'])
    neighborhoods = {v: closed(v) & pool for v in pool}
    pos = {v: j for j, v in enumerate(data['pool'])}
    out = dict(status='running', tree=str(args.tree), source_sha256=sha(__file__),
               dependencies={str(args.tree): sha(args.tree)}, rows=[],
               scope='Exact arithmetic certificates for recorded numerical leaves; whole-tree coverage requires separate verification.')
    for name in ('search_core_ipm_branches.py', 'solve_core_radius_ipm.py', 'check_two_slice_covers.py'):
        path = Path(__file__).with_name(name)
        out['dependencies'][str(path)] = sha(path)
    args.output.write_text(json.dumps(out, indent=2) + '\n')
    for index, row in enumerate(tree['rows']):
        if row['status'] != 'Infeasible':
            continue
        forbidden = propagate(pool, old, neighborhoods, row['inside'], row['outside'], tree['radius'])
        assert forbidden is not None
        variable_lo, variable_hi = np.zeros(len(pool)), variable_upper.copy()
        for v in row['inside']:
            variable_lo[pos[v]] = 1
        for v in forbidden:
            variable_hi[pos[v]] = 0
        identity = eye(len(pool), format='csc')
        forced = np.flatnonzero(variable_lo)
        inequalities = vstack((matrix, -matrix, identity, -identity.tocsr()[forced]), format='csc')
        bounds = np.r_[upper, -lower, variable_hi, -variable_lo[forced]]
        began = time.monotonic()
        dual = linprog(bounds, A_ub=-inequalities.T, b_ub=np.zeros(len(pool)),
                       A_eq=csc_matrix(np.ones((1, inequalities.shape[0]))), b_eq=[1],
                       bounds=(0, None), method='highs-ipm', options={'time_limit': args.seconds})
        certificate = None
        if dual.success:
            count = matrix.shape[0]
            ray = dual.x[:count] - dual.x[count:2*count]
            certificate = integer_contradiction(matrix, lower, upper, variable_lo, variable_hi, ray)
        record = dict(tree_index=index, solver_status=int(dual.status), solver_message=dual.message,
                      dual_objective=dual.fun, certificate=certificate, seconds=time.monotonic()-began)
        out['rows'].append(record)
        args.output.write_text(json.dumps(out, indent=2) + '\n')
        print(dict(leaf=index, seconds=record['seconds'], certified=certificate is not None,
                   multipliers=len(certificate['multipliers']) if certificate else None,
                   gap=certificate['positive_gap'] if certificate else None), flush=True)
    out['status'] = 'complete_attempt'
    args.output.write_text(json.dumps(out, indent=2) + '\n')


if __name__ == '__main__':
    main()
