"""Check appended shape classes with exhaustive anchor-image transformations.

For a fixed signed permutation, the image of one chosen source point must be
one of the target points. This enumerates every possible translating map.
"""
import argparse
from collections import Counter, defaultdict
from itertools import permutations, product
import json
from pathlib import Path

from direct_slice_neighbors import sha


def key(points):
    hist = [Counter(w[i] for w in points) for i in range(4)]
    return tuple(sorted(min(tuple(h[(s*x+t) % 7] for x in range(7))
                            for s in (-1, 1) for t in range(7)) for h in hist))


def equivalent(source, target):
    target = set(target)
    if len(source) != len(target):
        return False
    for perm in permutations(range(4)):
        for signs in product((-1, 1), repeat=4):
            points = [tuple(signs[i]*w[perm[i]] % 7 for i in range(4)) for w in source]
            for anchor in target:
                shift = tuple((anchor[i]-points[0][i]) % 7 for i in range(4))
                if all(tuple((w[i]+shift[i]) % 7 for i in range(4)) in target for w in points):
                    return True
    return False


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--library', type=Path, required=True)
    p.add_argument('--partition', type=Path, required=True)
    p.add_argument('--prior-partition', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    if not __debug__:
        raise RuntimeError('Run without -O')
    if args.output.exists():
        raise FileExistsError(args.output)
    lib = json.loads(args.library.read_text())
    part = json.loads(args.partition.read_text())
    prior = json.loads(args.prior_partition.read_text())
    old_lib = json.loads(Path(lib['source_library']).read_text())
    assert lib['source_library_sha256'] == sha(lib['source_library']) == prior['input_sha256']
    assert part['input_sha256'] == sha(args.library)
    n = lib['original_count']
    assert lib['slices'][:n] == old_lib['slices']
    assert part['rows'][:n] == prior['rows']
    assert part['representatives'][:len(prior['representatives'])] == prior['representatives']
    slices = [tuple(map(tuple, s)) for s in lib['slices']]
    assert len(part['rows']) == len(slices)
    representatives = set(part['representatives'])
    assert len(representatives) == len(part['representatives'])
    assert all(type(i) is int and 0 <= i < len(slices) for i in representatives)
    for i, row in enumerate(part['rows']):
        assert row['index'] == i
        assert row['representative'] in representatives
        if i in representatives:
            assert row['representative'] == i
        t = row['transform']
        assert sorted(t['permutation']) == list(range(4)) and all(s in (-1, 1) for s in t['signs'])
        image = {tuple((t['signs'][j]*w[t['permutation'][j]]+t['shift'][j]) % 7 for j in range(4)) for w in slices[i]}
        assert image == set(slices[row['representative']]) and len(image) == len(slices[i])
    buckets = defaultdict(list)
    for rep in prior['representatives']:
        buckets[key(slices[rep])].append(rep)
    checked = []
    new = [i for i in part['representatives'] if i >= n]
    for rep in new:
        invariant = key(slices[rep])
        for other in buckets[invariant]:
            assert not equivalent(slices[rep], slices[other])
            checked.append([rep, other])
        buckets[invariant].append(rep)
    # A nontrivial transformed positive control exercises the same mapper.
    example = slices[new[0]]
    image = [((w[2]+3) % 7, (-w[0]+5) % 7, w[3], (-w[1]+1) % 7) for w in example]
    assert key(example) == key(image) and equivalent(example, image)
    result = dict(library_sha256=sha(args.library), partition_sha256=sha(args.partition),
                  prior_partition_sha256=sha(args.prior_partition), checker_sha256=sha(__file__),
                  old_slice_count=n, old_class_count=len(prior['representatives']),
                  new_classes=len(new), all_explicit_maps_replayed=len(slices),
                  anchor_image_negative_pairs=checked, transformed_positive_control=True,
                  scope='Prior partition preserved. All appended representatives inequivalent to prior and earlier appended representatives under signed permutations/translations. No global novelty claim.')
    args.output.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
