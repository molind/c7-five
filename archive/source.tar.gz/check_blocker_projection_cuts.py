"""Check strip/plane capacities and their substitution into trade variables."""
import argparse
from collections import Counter
import hashlib
from itertools import combinations, product
import json
from pathlib import Path
import random

import numpy as np

from probe_blocker_projection_cuts import projection_cuts
from solve_two_blocker_mip import build_model


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();assert __debug__ and not a.output.exists()
    coords=list(product(range(7),repeat=5));encode=lambda p:sum(x*7**(4-k) for k,x in enumerate(p))
    def compatible(u,v):return any((x-y)%7 in (2,3,4,5) for x,y in zip(coords[u],coords[v]))
    def rows_compatible(a,b):
        return all((i-j)%7 in (2,3,4,5) for i in range(7) if a>>i&1 for j in range(7) if b>>j&1)
    valid=[mask for mask in range(128) if all((i-j)%7 in (2,3,4,5) for i,j in combinations([k for k in range(7) if mask>>k&1],2))]
    assert max(v.bit_count() for v in valid)==3
    pairs=[(u,v) for u in valid for v in valid if rows_compatible(u,v)]
    assert all(u.bit_count()+v.bit_count()<=3 for u,v in pairs)
    # Every independent plane gives seven valid cyclic row masks. Thus the
    # preceding finite pair check proves 2*size<=7*3 and size<=10.
    neighbors={u:[v for x,v in pairs if x==u] for u in valid};best=(-1,None)
    for first in valid:
        states={first:(first.bit_count(),[first])}
        for _ in range(6):
            following={}
            for previous,(value,path) in states.items():
                for nxt in neighbors[previous]:
                    candidate=(value+nxt.bit_count(),path+[nxt])
                    if nxt not in following or candidate[0]>following[nxt][0]:following[nxt]=candidate
            states=following
        for last,(value,path) in states.items():
            if rows_compatible(last,first) and value>best[0]:best=(value,path)
    assert best[0]==10
    witness=[encode((row,col,0,0,0)) for row,mask in enumerate(best[1]) for col in range(7) if mask>>col&1]
    assert len(witness)==10 and all(compatible(u,v) for u,v in combinations(witness,2))
    def domain(pool,old):
        blocked=[[j for j,u in enumerate(old) if not compatible(v,u)] for v in pool]
        return dict(pool_ids=pool,blocker_sets=blocked,active_old_indices=sorted({j for group in blocked for j in group}),
                    conflict_edges=[list(pair) for pair in combinations(range(len(pool)),2) if not compatible(pool[pair[0]],pool[pair[1]])])
    rng=random.Random(2026092151);plane=[encode((i,j,0,0,0)) for i,j in product(range(7),repeat=2)]
    totals=Counter()
    for case in range(24):
        old=sorted(rng.sample(witness,5));pool=sorted(rng.sample([v for v in plane if v not in old],4+case%3))
        d=domain(pool,old);A0,lo0,hi0,c=build_model(d,'improve')
        cuts=projection_cuts(pool,old,[1,2]);d['projection_cuts']=cuts
        A1,lo1,hi1,_=build_model(d,'improve')
        values=np.array(list(product((0,1),repeat=len(c))),dtype=np.int8).T
        base=np.all(A0@values<=hi0[:,None],axis=0)
        extended=np.all(A1@values<=hi1[:,None],axis=0)
        assert np.array_equal(base,extended)
        # Use full sets as another reference, including fixed inactive old words.
        active=d['active_old_indices']
        for index in np.flatnonzero(base):
            chosen=values[:,index];full=[v for j,v in enumerate(pool) if chosen[j]]+[v for j,v in enumerate(old) if j not in active or not chosen[len(pool)+active.index(j)]]
            assert all(compatible(u,v) for u,v in combinations(full,2))
        inactive=set(range(len(old)))-set(active)
        totals['inactive_old_cut_terms']+=sum(len(inactive&set(c['old_indices'])) for c in cuts)
        totals['binary_assignments']+=values.shape[1];totals['valid_binary_sets']+=int(base.sum());totals['cuts']+=len(cuts)
    assert totals['inactive_old_cut_terms']>0
    # A plane at density .21 satisfies all strip cuts but violates capacity10.
    d=domain(plane,[]);d['projection_cuts']=projection_cuts(plane,[],[1])
    A,_,hi,_=build_model(d,'improve');fractional=np.full(49,.21);assert np.all(A@fractional<=hi)
    d['projection_cuts']=projection_cuts(plane,[],[1,2]);A,_,hi,_=build_model(d,'improve');assert np.any(A@fractional>hi)
    totals['plane_fractional_counterexample']=1
    here=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    out=dict(source_sha256=sha(__file__),builder_sha256=sha(here/'solve_two_blocker_mip.py'),generator_sha256=sha(here/'probe_blocker_projection_cuts.py'),
        ring_masks_checked=128,valid_ring_masks=len(valid),compatible_row_pairs=len(pairs),plane_upper_bound=10,plane_witness=witness,cases=24,totals=dict(totals),scope=__doc__)
    a.output.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))


if __name__=='__main__':main()
