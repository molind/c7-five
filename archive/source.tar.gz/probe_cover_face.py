"""Restrict unresolved single-ban queries using exact clique-cover excess.

For a target-size independent set, sum(coverage(v)-den) <= total-target*den.
Therefore a vertex whose individual excess exceeds that gap is impossible.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path

from check_two_slice_covers import check_cover
from search_two_slice_escape import load_input
from search_slices import HERE, build_pool, kernel
from search_exchanges import verify
from probe_slice_orders import reduce_domination


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--seconds', type=float, default=5)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.seconds <= 0:
        parser.error('Positive search budget required')
    if args.output.exists():
        raise FileExistsError(args.output)
    source = HERE/'two-slice-lp-d-six-open-sep21.json'
    lp = json.loads(source.read_text())
    words, vertices, ids, blockers, core, _ = load_input()
    report = dict(status='running', results=[], candidates=[],
                  input_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                  hashes={n: hashlib.sha256((HERE/n).read_bytes()).hexdigest() for n in
                          (Path(__file__).name, 'check_two_slice_covers.py', 'search_two_slice_escape.py',
                           'search_slices.py', 'slice_clique', 'slice_clique.cpp', 'probe_slice_orders.py')},
                  scope='Target-preserving cover-excess pruning followed by verified domination and exact C++ search. Timeouts remain unresolved.')

    def save():
        report['statuses'] = dict(Counter(r['result']['status'] for r in report['results']))
        tmp = args.output.with_name(args.output.name+'.tmp')
        tmp.write_text(json.dumps(report, indent=2)+'\n')
        tmp.replace(args.output)

    for row in lp['results']:
        if row['excludes_target']:
            continue
        axis, start = map(int, row['pool_key'].split(':'))
        fixed, pool, adj, hint = build_pool(words, vertices, ids, blockers, axis, start, 2)
        assert pool == lp['pools'][row['pool_key']]['pool']
        assert row['target'] == len(hint) and row['forbidden'] in core
        domain = set(pool)-{row['forbidden']}
        total, den = check_cover(row, domain, {v: 1 for v in domain})
        gap = total-row['target']*den
        assert gap >= 0
        coverage = {v: 0 for v in domain}
        for entry in row['cover']:
            for v in entry['vertices']:
                coverage[v] += entry['units']
        face = [i for i, v in enumerate(pool) if v in domain and coverage[v]-den <= gap]
        mapping = {v: i for i, v in enumerate(face)}
        small = [[mapping[v] for v in adj[u] if v in mapping] for u in face]
        small_hint = {mapping[v] for v in hint if v in mapping}
        kept, mapped_hint, steps = reduce_domination(small, small_hint)
        # Check each deletion's set-inclusion condition explicitly.
        active = set(range(len(small)))
        for v, u in steps:
            assert u != v and u in small[v] and u in active and v in active
            assert ({u} | set(small[u])) & active <= ({v} | set(small[v])) & active
            active.remove(v)
        assert set(kept) == active
        local = {v: i for i, v in enumerate(kept)}
        reduced = [[local[v] for v in small[u] if v in local] for u in kept]
        reduced_hint = sorted(local[v] for v in mapped_hint)
        result = kernel(HERE/'slice_clique', reduced, reduced_hint, row['target'], args.seconds)
        chosen = [pool[face[kept[v]]] for v in result['vertices']]
        solution = fixed+[vertices[v].tolist() for v in chosen]
        pairs = verify(solution)
        assert row['forbidden'] not in chosen and len(solution) == len(fixed)+result['best_size']
        record = dict(index=row['index'], pool_key=row['pool_key'], forbidden=row['forbidden'],
                      original_domain=len(domain), face=[pool[v] for v in face], gap_units=gap,
                      domination_steps=steps, kept_face_indices=kept, hint=reduced_hint,
                      target=row['target'], result=result, full_size=len(solution), verified_pairs=pairs)
        report['results'].append(record)
        if len(solution) >= 367:
            report['candidates'].append(dict(step=row['index'], words=[''.join(map(str, w)) for w in solution],
                                             omitted_core=sorted(core-set(chosen)-{int(''.join(map(str,w)), 7) for w in fixed})))
            report['status'] = 'candidate_found'
        save()
        print(json.dumps({k: v for k, v in record.items() if k not in ('face', 'domination_steps', 'kept_face_indices', 'hint', 'result')} |
                         {'face_vertices': len(face), 'reduced_vertices': len(kept), 'result': result['status']}), flush=True)
        if report['candidates']:
            break
    else:
        report['status'] = 'queries_complete'
    save()


if __name__ == '__main__':
    main()
