"""Seek one verified E3 entry per fixed word, using the saved cap2 component."""
import gzip
import hashlib
from itertools import product
import json
from pathlib import Path
import time
import numpy as np

HERE = Path(__file__).resolve().parent


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    run = json.loads((HERE/'family-a-cap2-export-run.json').read_text())
    profile = json.loads((HERE/'family-a-cap2-export-verification.json').read_text())
    archive = Path(run['states_export']['path'])
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == run['states_export']['sha256']
    assert profile['passed'] and run['states_sha256'] == profile['states_sha256'] == 'ed82aacd25dc5a8fa3a63121cfe481141255bc31f4432dbba82ad5c6ccef492b'
    with gzip.open(archive, 'rt') as stream:
        header = json.loads(next(stream))
        rows = [json.loads(line) for line in stream]
    assert header['count'] == len(rows) == 29336
    words = list(product(range(7),repeat=5))
    coordinates = np.array(words,dtype=np.int16)
    tokens = [''.join(map(str,w)) for w in words]
    support = {int(w,7) for row in rows for w in row['words'].split()}
    missing = {int(w,7) for w in profile['fixed_words']}
    assert len(support) == 659 and len(missing) == 146
    outside = np.array([v not in support for v in range(len(words))])
    adjacency = np.array([tuple(2401*a+343*b+49*c+7*d+e
        for a,b,c,d,e in product(*[((x-1)%7,x,(x+1)%7) for x in w])
        if 2401*a+343*b+49*c+7*d+e != v) for v,w in enumerate(words)],dtype=np.uint16)
    entries = []
    scanned = 0
    began = time.monotonic()
    status = 'exhausted_selected_rule'
    for row in rows:
        if time.monotonic()-began > 90:
            status = 'timeout'
            break
        scanned += 1
        if row['energy'] != 2:
            continue
        ids = [int(w,7) for w in row['words'].split()]
        state = set(ids)
        counts = np.bincount(adjacency[ids].ravel(),minlength=len(words))
        assert counts[ids].sum() == 4
        for added in map(int,np.flatnonzero(outside & (counts == 2))):
            blockers = state.intersection(map(int,adjacency[added]))
            for removed in sorted(blockers & missing):
                if counts[removed] != 0:
                    continue
                target = state - {removed} | {added}
                target_words = coordinates[sorted(target)]
                diff = (target_words[:,None,:]-target_words[None,:,:])%7
                conflicts = np.all((diff==0)|(diff==1)|(diff==6),axis=2)
                assert len(target) == 368 and int(np.triu(conflicts,1).sum()) == 3
                entries.append(dict(source_index=row['index'],status='verified_entry',
                                    entry_rule='outside-support two-blocker addition',
                                    boundary_move=dict(removed=tokens[removed],added=tokens[added],energy=3),
                                    final_words=[tokens[v] for v in sorted(target)]))
                missing.remove(removed)
        if not missing:
            status = 'covered_all_fixed_words'
            break
    restricted_coverage = len(entries)
    fallback_scanned = 0
    # Complete one-replacement formula for any remaining fixed words. Prefer
    # additions outside the support, but allow inside-support additions as well.
    for row in rows:
        if not missing or time.monotonic()-began > 90:
            break
        fallback_scanned += 1
        ids = [int(w,7) for w in row['words'].split()]
        state = set(ids)
        counts = np.bincount(adjacency[ids].ravel(),minlength=len(words))
        for removed in sorted(missing):
            desired = 3-row['energy']+int(counts[removed])
            allowed = counts == desired
            neighbors = adjacency[removed]
            allowed[neighbors] = counts[neighbors] == desired+1
            allowed[ids] = False
            candidates = np.flatnonzero(allowed & outside)
            if not len(candidates):
                candidates = np.flatnonzero(allowed)
            if not len(candidates):
                continue
            added = int(candidates[0])
            target = state - {removed} | {added}
            target_words = coordinates[sorted(target)]
            diff = (target_words[:,None,:]-target_words[None,:,:])%7
            conflicts = np.all((diff==0)|(diff==1)|(diff==6),axis=2)
            assert len(target) == 368 and int(np.triu(conflicts,1).sum()) == 3
            entries.append(dict(source_index=row['index'],status='verified_entry',
                                entry_rule='full single-replacement rule',
                                boundary_move=dict(removed=tokens[removed],added=tokens[added],energy=3),
                                final_words=[tokens[v] for v in sorted(target)]))
            missing.remove(removed)
    if not missing:
        status = 'covered_all_fixed_words'
    elif time.monotonic()-began > 90:
        status = 'timeout'
    else:
        status = 'exhausted_full_rule'
    result = dict(start_words=run['start_words'],entries=entries,
                  source_archive=str(archive),source_archive_sha256=run['states_export']['sha256'],
                  scan_status=status,states_scanned=scanned,seconds=time.monotonic()-began,
                  restricted_rule_coverage=restricted_coverage,fallback_states_scanned=fallback_scanned,
                  missing_fixed_words=[tokens[v] for v in sorted(missing)],
                  scope='One individually verified E3 entry per covered fixed word. Replay archive parent path to source_index, then boundary_move. First try outside-support two-blocker additions; for remaining words use the full single-replacement energy formula. No simultaneous removal or independent367 escape claimed.')
    (HERE/'family-a-diverse-cap3-entries.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('entries','start_words','missing_fixed_words')},indent=2))
    print(json.dumps(dict(entries=len(entries),missing_fixed_words=len(missing))))


if __name__ == '__main__':
    main()
