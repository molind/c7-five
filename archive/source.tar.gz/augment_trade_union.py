"""Recover hidden gains from the union of an old and a neutral replacement set.

The two sides are individually independent, so a bipartite matching and vertex
cover certify the union maximum. Every recovered full set is checked directly.
"""
import argparse
import hashlib
from itertools import combinations, product
import json
from pathlib import Path

from analyze_bipartite_trade import analyze_trade


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--input',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();assert __debug__ and not a.output.exists()
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    data=json.loads(a.input.read_text());assert data['status']=='complete'
    mp=Path(data['input']);assert sha(mp)==data['input_sha256'];model=json.loads(mp.read_text())
    bp=Path(model['input']);assert sha(bp)==model['input_sha256'];bases=json.loads(bp.read_text())['bases']
    coords=list(product(range(7),repeat=5))
    def compatible(u,v):return any((x-y)%7 in (2,3,4,5) for x,y in zip(coords[u],coords[v]))
    out=dict(input=str(a.input),input_sha256=sha(a.input),source_sha256=sha(__file__),
        analyzer_sha256=sha(Path(__file__).with_name('analyze_bipartite_trade.py')),rows=[],candidates=[],status='complete',scope=__doc__)
    for index,c in enumerate(data['candidates']):
        original=bases[c['source_base']]['words'];full=sorted(int(w,7) for w in c['words'])
        assert len(original) in (366,367)
        assert len(original)==len(set(original))==len(full)==len(set(full))
        assert all(compatible(u,v) for group in (original,full) for u,v in combinations(group,2))
        old=sorted(set(original)-set(full));new=sorted(set(full)-set(original))
        if not old:continue
        analysis=analyze_trade(old,new,compatible)
        row=dict(candidate=index,base=c['source_base'],removed=old,added=new,analysis=analysis)
        if len(analysis['maximum'])>len(old):
            recovered=sorted((set(original)-set(old))|set(analysis['maximum']))
            assert len(recovered)==len(set(recovered))>len(original)
            assert all(compatible(u,v) for u,v in combinations(recovered,2))
            out['candidates'].append(dict(step=len(out['candidates']),source_candidate=index,source_base=c['source_base'],
                size=len(recovered),pair_checks=len(recovered)*(len(recovered)-1)//2,
                words=[''.join(map(str,coords[v])) for v in recovered]))
            row['recovered_size']=len(recovered)
            if len(recovered)>=368:out['status']='verified_target'
        out['rows'].append(row)
    a.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(dict(status=out['status'],trades=len(out['rows']),sizes=[c['size'] for c in out['candidates']])))


if __name__=='__main__':main()
