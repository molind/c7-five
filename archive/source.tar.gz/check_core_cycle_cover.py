"""Independently verify a full core-domain cover of cliques and lifted cycles."""
import argparse
import hashlib
from itertools import combinations, product
import json
from pathlib import Path

import numpy as np

from check_common314_covers import decode


def conflict(a,b):
    return all((x-y)%7 in (0,1,6) for x,y in zip(decode(a),decode(b)))


def verify_rows(pool,certificate):
    D=certificate['denominator'];assert type(D) is int and D>0
    coverage={v:0 for v in pool};total=cliques=cycles=lifted=0
    for row in certificate['rows']:
        words=row['words'];units=row['units'];capacity=row['capacity']
        assert type(units) is int and units>0 and type(capacity) is int and capacity>0
        assert words and len(words)==len(set(words)) and set(words)<=pool
        if row['kind']=='clique':
            assert capacity==1 and all(conflict(a,b) for a,b in combinations(words,2))
            cliques+=1
        else:
            assert row['kind']=='cycle' and len(words)==2*capacity+1 and len(words)>=3
            assert all(conflict(a,b) for a,b in zip(words,words[1:]+words[:1]))
            centers=row['centers'];assert len(centers)==len(set(centers)) and set(centers)<=pool
            assert not set(centers)&set(words)
            assert all(conflict(a,b) for a,b in combinations(centers,2))
            assert all(conflict(a,b) for a in centers for b in words)
            for v in centers:coverage[v]+=capacity*units
            cycles+=1;lifted+=bool(centers)
        for v in words:coverage[v]+=units
        total+=capacity*units
    assert min(coverage.values())>=D and total==certificate['total_units']
    assert min(coverage.values())==certificate['minimum_coverage']
    return dict(denominator=D,total_units=total,minimum_coverage=min(coverage.values()),
        cliques=cliques,cycles=cycles,lifted_cycles=lifted)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True)
    p.add_argument('--base',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();assert __debug__ and not args.output.exists()
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    d=json.loads(args.input.read_text());assert d['status']!='running'
    assert all(sha(f)==h for f,h in d['dependencies'].items())
    base=json.loads(args.base.read_text());assert sha(base['input'])==base['input_sha256']
    parents=json.loads(Path(base['input']).read_text())['bases']
    core=set(parents[0]['words'])&set(parents[1]['words']);assert len(core)==315 and core==set(base['fixed'])
    omitted=d['omitted'];assert len(omitted)==len(set(omitted)) and set(omitted)<=core
    fixed=core-set(omitted);assert fixed==set(d['fixed']) and len(fixed)==len(d['fixed'])
    coords=np.array(list(product(range(7),repeat=5)),dtype=np.int16);eligible=np.ones(16807,dtype=bool)
    for v in fixed:
        delta=(coords-coords[v])%7;eligible &= ~np.all((delta==0)|(delta==1)|(delta==6),axis=1)
    pool=set(np.flatnonzero(eligible).tolist());assert pool==set(d['pool']) and len(pool)==len(d['pool'])
    assert d['target']==368-len(fixed)
    checked=verify_rows(pool,d['certificate']);bound=len(fixed)+checked['total_units']//checked['denominator']
    if d['status']=='strict_integer_cover':assert bound<368
    witness=base['witness'];assert len(witness)==len(set(witness))==367
    assert fixed<=set(witness)<=fixed|pool
    count=0
    for a,b in combinations(witness,2):assert not conflict(a,b);count+=1
    assert count==67161
    out=dict(passed=True,fixed=len(fixed),pool=len(pool),target=d['target'],**checked,
        full_integer_upper_bound=bound,excludes368=bound<368,witness_size=367,witness_pair_checks=count,
        checker_sha256=sha(__file__),dependencies={str(args.input):sha(args.input),str(args.base):sha(args.base),base['input']:sha(base['input'])},
        scope='This exact complete fixed-core domain only; integer arithmetic verifies every coefficient and coverage inequality.')
    args.output.write_text(json.dumps(out,indent=2)+'\n');print(out)


if __name__=='__main__':main()
