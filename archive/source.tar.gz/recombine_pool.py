"""Bounded exact decision queries on unions of three or more C7^5 parents."""
import argparse
from collections import Counter
import hashlib
from itertools import combinations, product
import json
from pathlib import Path
import random
import time

import z3

from recombine_sets import HERE, FILES, conflict, cross_graph, verify


def solve_pool(pool, target, seconds):
    words = sorted(pool)
    adj = cross_graph(words, words)
    edges = [(u, v) for u, neighbors in enumerate(adj) for v in neighbors if u < v]
    chosen = [z3.Bool(f'w{i}') for i in range(len(words))]
    solver = z3.SolverFor('QF_FD')
    solver.set(timeout=max(1, int(seconds*1000)), random_seed=20260920)
    solver.add(z3.PbGe([(v, 1) for v in chosen], target))
    solver.add([z3.Or(z3.Not(chosen[u]), z3.Not(chosen[v])) for u, v in edges])
    began = time.monotonic()
    status = solver.check()
    result = dict(status=str(status), vertices=len(words), edges=len(edges),
                  target=target, solve_seconds=time.monotonic()-began)
    if status == z3.sat:
        model = solver.model()
        solution = [w for w, var in zip(words, chosen) if z3.is_true(model.eval(var))]
        verify(solution)
        assert len(solution) >= target
        result['words'] = solution
    elif status == z3.unknown:
        result['reason'] = solver.reason_unknown()
    return result


def self_test():
    rng = random.Random(20260920)
    domain = list(product(range(7), repeat=2))
    cases = 0
    for _ in range(30):
        pool = [(0, 0, 0, *w) for w in rng.sample(domain, 9)]
        optimum = max(len(subset) for k in range(10) for subset in combinations(pool, k)
                      if not any(conflict(a, b) for a, b in combinations(subset, 2)))
        for target in (optimum, optimum+1):
            r = solve_pool(pool, target, 2)
            assert r['status'] == ('sat' if target == optimum else 'unsat')
            cases += 1
    return {'brute_force_decision_controls': cases}


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--seconds', type=float, default=4)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.seconds <= 0:
        parser.error('Positive per-query solver budget required')
    if args.self_test:
        result = self_test()
        args.output.write_text(json.dumps(result, indent=2)+'\n')
        print(json.dumps(result)); return
    parents = {k: {tuple(map(int, w)) for w in (HERE/f).read_text().split()} for k, f in FILES.items()}
    for words in parents.values():
        assert len(words) == 367
        verify(sorted(words))
    base = set.union(*parents.values())
    jobs = [('four_original_parents', base)]
    for coordinate in range(5):
        for offset in (1, 2):
            transformed = {tuple((c+offset) % 7 if i == coordinate else c for i, c in enumerate(w))
                           for w in base}
            jobs.append((f'four_parents_plus_c{coordinate}_shift{offset}', base | transformed))
    rng = random.Random(20260920)
    for trial in range(3):
        pool = set(base)
        for parent in parents.values():
            perm = rng.sample(range(5), 5)
            signs = rng.choices((-1, 1), k=5)
            shifts = rng.choices(range(7), k=5)
            pool.update(tuple((signs[i]*w[perm[i]]+shifts[i]) % 7 for i in range(5)) for w in parent)
        jobs.append((f'four_original_plus_four_random_{trial}', pool))
    rows = []
    began = time.monotonic()
    for label, pool in jobs:
        result = solve_pool(pool, 368, args.seconds)
        result.update(label=label, pool_words=sorted(pool))
        rows.append(result)
        print(json.dumps({k: v for k, v in result.items() if k not in ('words', 'pool_words')}), flush=True)
        if result['status'] == 'sat':
            break
    report = dict(results=rows, statuses=dict(Counter(r['status'] for r in rows)),
                  seconds=time.monotonic()-began, per_query_solver_seconds=args.seconds,
                  source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  shared_source_sha256=hashlib.sha256((HERE/'recombine_sets.py').read_bytes()).hexdigest(),
                  inputs_sha256={k:hashlib.sha256((HERE/f).read_bytes()).hexdigest() for k,f in FILES.items()},
                  solver_version=z3.get_version_string(),
                  scope='Exact decision within each saved finite union only. unknown is unresolved. SAT solutions directly pair-checked; UNSAT has no exported formal certificate. No global bound.')
    args.output.write_text(json.dumps(report, indent=2)+'\n')


if __name__ == '__main__':
    main()
