"""Keep projection cuts with nonzero LP dual weights, then recheck the LP bound.

Every removed cut is valid for binary independent sets. Sparsification may weaken
other fractional faces. Agreement of root objectives is numerical evidence only.
"""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import time

import numpy as np
from scipy.optimize import linprog

from solve_two_blocker_mip import build_model


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--input',required=True,type=Path)
    p.add_argument('--output',required=True,type=Path);p.add_argument('--seconds',type=float,default=30)
    a=p.parse_args();assert __debug__ and not a.output.exists() and a.seconds>0
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    data=json.loads(a.input.read_text());assert data['status']=='complete'
    out=copy.deepcopy(data);out['status']='running'
    out['projection_pruning']=dict(input=str(a.input),input_sha256=sha(a.input),source_sha256=sha(__file__),
        builder_sha256=sha(Path(__file__).with_name('solve_two_blocker_mip.py')),rows=[],scope=__doc__)
    def save():
        temp=a.output.with_suffix('.tmp');temp.write_text(json.dumps(out,separators=(',',':'))+'\n');temp.replace(a.output)
    save()
    for domain in out['rows']:
        original=list(domain['projection_cuts']);objectives=[]
        for label in ('full','dual_support'):
            A,lo,hi,c=build_model(domain,'improve');assert np.all(np.isneginf(lo))
            start=time.monotonic()
            lp=linprog(c,A_ub=A,b_ub=hi,bounds=(0,1),method='highs-ipm',options={'time_limit':a.seconds})
            assert lp.success,lp.message
            assert np.all(A@lp.x<=hi+1e-6)
            objectives.append(float(lp.fun))
            row=dict(base=domain['base'],label=label,projection_cuts=len(domain['projection_cuts']),rows=A.shape[0],
                     gain_bound=-float(lp.fun),seconds=time.monotonic()-start)
            out['projection_pruning']['rows'].append(row)
            if label=='full':
                # Projection rows are last in the improve model (no target rows).
                offset=A.shape[0]-len(original)
                weights=np.asarray(lp.ineqlin.marginals[offset:]);assert len(weights)==len(original)
                assert np.max(weights)<=1e-7
                domain['projection_cuts']=[cut for cut,w in zip(original,weights) if w < -1e-10]
            else:assert abs(objectives[0]-objectives[1])<1e-6
            save();print(json.dumps(row),flush=True)
    out['status']='complete';save()


if __name__=='__main__':main()
