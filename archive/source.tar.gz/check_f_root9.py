"""Join complete F width-eight closure with degree-split selected-root9 searches.

Does not close radius nine across all F states. Gain and neutral searches have
separate coverage requirements; the old neutral kernel selects exactly9 words.
"""
import argparse,gzip,hashlib,json,struct
from pathlib import Path
from check_all_word_root_intervals import audit


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--lower-proof',required=True,type=Path)
    p.add_argument('--output',required=True,type=Path)
    args=p.parse_args();assert __debug__ and not args.output.exists()
    r=Path('research/c7');deps={}
    def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
    def read(p):
        deps[str(p)]=sha(p)
        return json.loads(Path(p).read_text())
    lower=read(args.lower_proof)
    checkers=['check_component_atomic8_incremental.py','check_component_atomic8_incremental_v2.py']
    assert lower['checker_sha256'] in [sha(r/x) for x in checkers]
    assert all(sha(p)==h for p,h in lower['dependencies'].items());deps.update(lower['dependencies'])
    assert lower['complete_atomic8'] and lower['width8_component_equals_width7']
    assert lower['eight_removal_augmentations_excluded'] and not lower['outside']
    mp=r/'component-F-rooted8-sep22-input.json';m=read(mp)
    assert lower['dependencies'][str(mp)]==sha(mp)
    assert sha(m['source'])==m['source_sha256']
    with gzip.open(m['source'],'rt') as f:
        meta=json.loads(next(f));states=[json.loads(line) for line in f]
    starts_path=r/'cardinality367-trade-starts-sep21.json';starts=read(starts_path);words=starts['bases'][1]['words']
    assert words==sorted(set(words)) and len(words)==367
    assert words==states[0] and len(states)==lower['states']==m['states']==meta['states']==36
    digest=hashlib.sha256(b''.join(sorted(struct.pack('<367H',*s) for s in states))).hexdigest()
    assert digest==m['component_sha256']==meta['component_sha256']
    gain_path=r/'reference367-full-radius9-final-verification-sep21.json';gain=read(gain_path)
    assert gain['checker_sha256']==sha(r/'check_all_word_root_intervals.py')
    replay=json.loads(json.dumps(audit(**gain['inputs'])))
    assert all(gain[k]==v for k,v in replay.items());deps.update(gain['dependencies'])
    for row in gain['rows']:
        for segment in row['segments']:
            assert sha(segment['file'])==segment['sha256'];deps[segment['file']]=segment['sha256']
    gain_row=next(x for x in gain['rows'] if x['base']==1)
    assert gain_row['complete_radius9'] and gain_row['minimum_removed_for_any_368_set']==10
    coverage=read(gain['inputs']['coverage']);domain=read(coverage['model'])
    assert domain['input']==str(starts_path) and domain['input_sha256']==sha(starts_path)
    assert domain['min_blockers']==1 and domain['max_blockers']==9
    low_proof=read(r/'reference367-F-atomic9-complete-verification-sep22.json')
    assert low_proof['checker_sha256']==sha(r/'check_reference_atomic.py')
    low_coverage=next(x for x in low_proof['coverage'] if x['base']==1)
    assert low_coverage['radius']==9 and low_coverage['complete'] and low_coverage['start']==0
    for seg in low_coverage['segments']:
        low=read(seg['file']);assert low_proof['inputs'][seg['file']]==sha(seg['file'])
        assert low['input']==str(starts_path) and low['input_sha256']==sha(starts_path)
        assert low['radius']==9 and low['max_blockers']==4 and low['atomic_only']
        assert low['kernel_sha256']==sha(r/'exchange_dfs_residual_two')
        assert low['kernel_source_sha256']==sha(r/'exchange_dfs_residual_two.cpp')
        rows=[x for x in low_proof['rows'] if x['base']==1 and x['input']==seg['file']]
        assert len(rows)==1 and rows[0]['neutral']==rows[0]['improving']==0
    high=read(r/'reference367-F-neutral9-root-recheck-sep22.json')
    assert high['checker_sha256']==sha(r/'check_reference_neutral_results.py')
    assert high['graph_proofs']=={str(gain_path):sha(gain_path)}
    assert len(high['rows'])==1
    hr=high['rows'][0]
    assert hr['base']==1 and hr['radius']==9 and hr['minimum_blocker_degree']==5
    assert hr['restricted_prefix_exhausted'] and hr['model']==coverage['model']
    for rec in high['results']:
        assert rec['sets']==0 and rec['pair_checks']==0 and rec['sha256']==sha(rec['file'])
        row=read(rec['file']);assert row['base']==1 and row['input']==coverage['model']
        assert row['input_sha256']==sha(coverage['model'])
        assert row['graph_sha256']==sha(row['graph'])==gain['graphs']['1']['sha256']
        assert row['kernel_sha256']==sha(row['kernel'])
        assert row['kernel_source_sha256']==sha(Path(row['kernel']).with_suffix('.cpp'))
        deps[row['graph']]=sha(row['graph'])
    for name in checkers+['check_all_word_root_intervals.py','check_reference_atomic.py','check_reference_neutral_results.py']:
        deps[str(r/name)]=sha(r/name)
    deps[m['source']]=sha(m['source'])
    result=dict(passed=True,checker_sha256=sha(__file__),dependencies=deps,component_states=36,component_sha256=digest,
                reference_forest_index=0,root_words=words,root_sha256=hashlib.sha256(struct.pack('<367H',*words)).hexdigest(),
                lower_component_radius=8,checked_root_radius=9,neutral_radius9_stays_in_component=True,
                no_augmentation_through_radius9=True,whole_component_width9_closed=False,
                scope='One exact selected F root only. Whole-component width8closure reduces reducible9moves; exhaustive low/high blocker cases exclude the irreducible neutral9moves. Separate full radius9 gain audit excludes augmentations. Native search is tested computation, not formal proof-tree replay.')
    args.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ('dependencies','root_words')}))


if __name__=='__main__':main()
