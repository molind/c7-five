"""Exhaustive checks for complementation and IPM-search conflict propagation."""
import argparse
from itertools import combinations
import json
from pathlib import Path
import random

import numpy as np
from scipy.sparse import csc_matrix

from search_core_radius_cut import sha
from solve_core_radius_complement import complement_model
from search_core_ipm_branches_v2 import propagate


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    assert __debug__ and not args.output.exists()
    rng = random.Random(922301)
    bits_checked = surviving_sets = queries = 0
    for _ in range(45):
        n = rng.randrange(4, 10)
        pool = set(range(n))
        edges = [p for p in combinations(pool, 2) if rng.random() < .28]
        neighbors = {v: {v} for v in pool}
        for u, v in edges:
            neighbors[u].add(v)
            neighbors[v].add(u)
        independent = [set(i for i in pool if mask >> i & 1) for mask in range(1 << n)
                       if all(not (mask >> u & 1 and mask >> v & 1) for u, v in edges)]
        old = rng.choice([s for s in independent if s])
        initial = np.array([float(i in old) for i in range(n)])
        dense = np.zeros((len(edges), n))
        for i, (u, v) in enumerate(edges):
            dense[i, u] = dense[i, v] = 1
        matrix = csc_matrix(dense)
        lower, upper = np.zeros(len(edges)), np.ones(len(edges))
        a, lo, hi, c = complement_model(matrix, lower, upper, np.ones(n), initial)
        for mask in range(1 << n):
            y = np.array([float(mask >> i & 1) for i in range(n)])
            x = initial + (1 - 2 * initial) * y
            assert np.array_equal(matrix @ x, a @ y + matrix @ initial)
            assert np.all(matrix @ x <= upper) == np.all(a @ y <= hi)
            assert np.all(matrix @ x >= lower) == np.all(a @ y >= lo)
            assert -sum(x) == c @ y - sum(initial)
            bits_checked += 1
        for _ in range(20):
            inside = set(rng.sample(sorted(pool), rng.randrange(min(3, n) + 1)))
            outside = set(rng.sample(sorted(pool), rng.randrange(min(3, n) + 1)))
            radius = rng.randrange(len(old) + 1)
            forbidden = propagate(pool, old, neighbors, inside, outside, radius)
            eligible = [s for s in independent if inside <= s and not (outside & s) and len(old - s) <= radius]
            if forbidden is None:
                assert not eligible
            else:
                assert all(not (s & forbidden) for s in eligible)
            queries += 1
            surviving_sets += len(eligible)
    out = dict(passed=True, graphs=45, binary_vectors_checked=bits_checked,
               propagation_queries=queries, feasible_sets_preserved=surviving_sets,
               source_sha256=sha(__file__), dependencies={})
    for name in ('solve_core_radius_complement.py', 'search_core_ipm_branches_v2.py'):
        path = Path(__file__).with_name(name)
        out['dependencies'][str(path)] = sha(path)
    args.output.write_text(json.dumps(out, indent=2) + '\n')
    print(out)


if __name__ == '__main__':
    main()
