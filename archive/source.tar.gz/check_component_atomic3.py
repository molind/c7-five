"""Check all saved atomic trades and the width-two component premise.

For a width-two-closed component, any neutral three-removal escape or gain
can be chosen with no one-blocker insertion and no two insertions sharing
exactly two blockers. Either forbidden pattern allows a neutral width-one/two
step first, leaving at most two old removals. Those moves/augmentations are
already covered by width-two closure. Thus the atomic scan covers the remaining
three-removal cases. Exhaustion itself relies on the tested C++ enumerator.
"""
import argparse
import gzip
import hashlib
from itertools import combinations, product
import json
from pathlib import Path
import struct

import numpy as np


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', required=True, type=Path)
    parser.add_argument('--width-two-proof', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    assert __debug__ and not args.output.exists()
    here = Path(__file__).resolve().parent
    sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
    read = lambda p: json.loads(Path(p).read_text())
    run = read(args.run)
    assert run['status'] == 'complete'
    assert run['kernel_sha256'] == sha(run['kernel']) == sha(here/'scan_component_atomic3')
    assert run['kernel_source_sha256'] == sha(here/'scan_component_atomic3.cpp')
    assert run['manifest_sha256'] == sha(run['input_manifest'])
    manifest = read(run['input_manifest'])
    assert manifest['source_sha256'] == sha(manifest['source'])
    assert run['input_sha256'] == manifest['input_sha256'] == sha(manifest['input'])
    with gzip.open(manifest['source'], 'rt') as f:
        meta = json.loads(next(f))
        states = [json.loads(line) for line in f]
    keys = [struct.pack('<367H', *s) for s in states]
    assert all(s == sorted(set(s)) and len(s) == 367 for s in states)
    assert len(keys) == len(set(keys)) == manifest['states'] == meta['states']
    assert hashlib.sha256(b''.join(sorted(keys))).hexdigest() == manifest['component_sha256'] == meta['component_sha256']
    expected_input = f'{len(states)} 367\n' + '\n'.join(' '.join(map(str, s)) for s in states) + '\n'
    assert Path(manifest['input']).read_text() == expected_input
    known = set(keys)
    walk = read(args.width_two_proof)
    assert walk['source_sha256'] == sha(here/'search_plateau.py')
    assert walk['input_sha256'] == sha(walk['input'])
    assert walk['component_sha256'] == manifest['component_sha256'] and walk['states_visited'] == len(states)
    assert walk['neutral_exchange_width'] == walk['augmentation_checked_through'] == 2
    assert walk['status'] == 'exhausted' and walk['initial_size'] == 367 and walk['improved_words'] is None
    assert run['native_sha256'] == sha(run['native_file'])
    records = [json.loads(line) for line in Path(run['native_file']).read_text().splitlines()]
    assert records == run['rows']
    footer = records[-1]
    assert footer['status'] in ('exhausted', 'timeout', 'escape', 'witness')
    assert footer['start_state'] == 0 and 0 <= footer['next_state'] <= len(states) == footer['total_states']
    if footer['status'] == 'exhausted':
        assert footer['next_state'] == len(states)
    coords = np.array(list(product(range(7), repeat=5)), dtype=np.int16)
    seen = set()
    neutral = internal = improving = pairs = 0
    outside = []
    full_candidates = []
    for row in records[:-1]:
        index = row['state']
        assert type(index) is int and footer['start_state'] <= index < footer['next_state']
        if row['event'] == 'candidate':
            full_candidates.append(row)
            continue
        assert row['event'] == 'trade'
        old = states[index]
        removed, added = row['removed'], row['added']
        assert len(removed) == len(set(removed)) == 3 and set(removed) <= set(old)
        assert len(added) == len(set(added)) in (3, 4) and not set(added) & set(old)
        assert all(type(v) is int and 0 <= v < 16807 for v in added)
        assert (index, tuple(sorted(added))) not in seen
        seen.add((index, tuple(sorted(added))))
        delta = (coords[added, None, :] - coords[np.array(old)[None, :], :]) % 7
        bad = np.all((delta == 0) | (delta == 1) | (delta == 6), axis=2)
        blockers = [tuple(old[i] for i in np.flatnonzero(r)) for r in bad]
        assert all(len(b) in (2, 3) for b in blockers)
        assert {v for b in blockers for v in b} == set(removed)
        assert all(not (len(a) == 2 and a == b) for a, b in combinations(blockers, 2))
        words = sorted((set(old) - set(removed)) | set(added))
        points = coords[words]
        diff = (points[:, None, :] - points[None, :, :]) % 7
        conflicts = np.all((diff == 0) | (diff == 1) | (diff == 6), axis=2)
        assert np.array_equal(conflicts, np.eye(len(words), dtype=bool))
        pairs += len(words)*(len(words)-1)//2
        if len(words) == 367:
            neutral += 1
            if struct.pack('<367H', *words) in known:
                internal += 1
            else:
                outside.append(dict(state=index, words=words))
        else:
            assert len(words) == 368
            improving += 1
            outside.append(dict(state=index, words=words))
    assert neutral == footer['neutral'] and internal == footer['internal_neutral'] and improving == footer['improving']
    assert bool(outside) == bool(full_candidates)
    for row in full_candidates:
        assert row['size'] == len(row['words'])
        assert dict(state=row['state'], words=row['words']) in outside
    if footer['status'] in ('escape', 'witness'):
        assert outside
        assert (footer['status'] == 'witness') == bool(improving)
    else:
        assert not outside

    # Exhaustively check the elementary reduction used to lift the filter to
    # component closure. New vertices are mutually independent in any trade.
    reductions = retained = 0
    for n in (3, 4):
        for masks in product(range(1, 8), repeat=n):
            if (masks[0] | masks[1] | masks[2] | (masks[3] if n == 4 else 0)) != 7:
                continue
            short = next(([i] for i, b in enumerate(masks) if b.bit_count() == 1), None)
            if short is None:
                short = next(([i,j] for i,j in combinations(range(n),2)
                              if masks[i] == masks[j] and masks[i].bit_count() == 2), None)
            if short is None:
                retained += 1
                continue
            blocked = 0
            for i in short:
                blocked |= masks[i]
            assert blocked.bit_count() == len(short) in (1, 2)
            assert 3 - blocked.bit_count() <= 2
            # The inserted prefix is compatible with all retained old vertices,
            # and its remaining target insertions were already independent.
            assert all(masks[i] & ~blocked == 0 for i in short)
            reductions += 1
    complete = footer['status'] == 'exhausted' and not outside
    deps = [args.run,args.width_two_proof,run['input_manifest'],manifest['source'],manifest['input'],run['native_file'],run['kernel'],here/'scan_component_atomic3.cpp',here/'search_plateau.py']
    out = dict(checker_sha256=sha(__file__), dependencies={str(p):sha(p) for p in deps},
               scope=__doc__, states=len(states), checked_trades=len(seen), pair_checks=pairs,
               neutral=neutral, internal_neutral=internal, improving=improving, outside=outside,
               start_state=0, next_state=footer['next_state'], complete_atomic3=complete,
               width3_component_equals_width2=complete, three_removal_augmentations_excluded=complete,
               reduction_controls=dict(reduced=reductions, retained_atomic=retained))
    args.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k not in ('dependencies','scope','outside')}))


if __name__ == '__main__':
    main()
