"""Pack previously replayed366 states for exact duplicate rejection of new seeds.

This is a finite visited-state cache, not a complete component or pruning proof.
Each gzip record is732 bytes:366 sorted unsigned little-endian16-bit word IDs.
"""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import struct


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,nargs='+',required=True)
    p.add_argument('--verification',type=Path,nargs='+',required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();assert __debug__ and len(a.input)==len(a.verification) and not a.output.exists()
    manifest=a.output.with_suffix('.json');assert not manifest.exists()
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    all_states=set();refs=[]
    for path,proof_path in zip(a.input,a.verification):
        data=json.loads(path.read_text());proof=json.loads(proof_path.read_text())
        assert proof['input']==str(path) and proof['input_sha256']==sha(path)
        source=Path(data['input']);assert sha(source)==data['input_sha256'];bases=json.loads(source.read_text())['bases']
        for row,checked in zip(data['rows'],proof['rows']):
            assert row['base']==checked['base'];initial=bases[row['base']]['words'];assert len(initial)==366
            states=[struct.pack('<366H',*initial)]
            for parent,old,new in row['result']['discovery']:
                if isinstance(old,int):old,new=[old],[new]
                assert 0<=parent<len(states)
                ids=set(struct.unpack('<366H',states[parent]));assert set(old)<=ids and set(new).isdisjoint(ids)
                current=sorted((ids-set(old))|set(new));assert len(current)==366
                states.append(struct.pack('<366H',*current))
            distinct=set(states);assert len(distinct)==len(states)==checked['states']==row['result']['states_visited']
            assert hashlib.sha256(b''.join(sorted(distinct))).hexdigest()==row['result']['component_sha256']
            all_states.update(distinct)
        assert len(data['rows'])==len(proof['rows'])
        refs.append(dict(input=str(path),input_sha256=sha(path),verification=str(proof_path),verification_sha256=sha(proof_path)))
    digest=hashlib.sha256()
    with gzip.open(a.output,'wb') as f:
        for key in sorted(all_states):f.write(key);digest.update(key)
    with gzip.open(a.output,'rb') as f:read_back=f.read()
    assert len(read_back)==len(all_states)*732 and hashlib.sha256(read_back).hexdigest()==digest.hexdigest()
    assert {read_back[i:i+732] for i in range(0,len(read_back),732)}==all_states
    out=dict(file=str(a.output),sha256=sha(a.output),uncompressed_sha256=digest.hexdigest(),states=len(all_states),cardinality=366,
             stride=732,inputs=refs,source_sha256=sha(__file__),scope=__doc__)
    manifest.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ('inputs','scope')}))


if __name__=='__main__':main()
