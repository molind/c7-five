"""Check the extension solver against brute force and verify rounded codes."""
import itertools
import json
import random

from search_exchanges import verify
from search_rounding import ROOT, RoundingSearch, maximum_independent

rng = random.Random(81915)
checks = limited = 0
for n in range(1, 15):
    for case in range(10):
        density = rng.random()
        adj = [0]*n
        for i, j in itertools.combinations(range(n), 2):
            if rng.random() < density:
                adj[i] |= 1 << j
                adj[j] |= 1 << i
        expected = max(mask.bit_count() for mask in range(1 << n)
                       if all(not (mask & adj[i]) for i in range(n) if mask >> i & 1))
        actual, status, _ = maximum_independent(adj, 1000000)
        if status != "optimal" or len(actual) != expected or any(
                adj[i] >> j & 1 for i, j in itertools.combinations(actual, 2)):
            raise ArithmeticError((n, case, expected, actual, status))
        partial, reason, _ = maximum_independent(adj, 1)
        if any(adj[i] >> j & 1 for i, j in itertools.combinations(partial, 2)):
            raise ArithmeticError("Invalid budget-limited result")
        checks += 1
        limited += reason == "node_limit"
if maximum_independent([])[0] != []:
    raise ArithmeticError("Empty graph")
engine = RoundingSearch()
rounded = []
for _ in range(10):
    configuration = list(engine.default)
    for j in range(5, 35):
        configuration[j] += rng.randint(-2, 2)
    result = engine.evaluate(tuple(configuration), 10000)
    if "words" in result:
        verify(result["words"])
        rounded.append({"size": result["size"], "status": result["status"]})
report = {"bruteforce_graph_checks": checks, "limited_graph_checks": checks,
          "node_limit_triggered": limited, "empty_graph_checked": True,
          "rounded_codes_checked_directly": rounded}
(ROOT / "fourth-control-results.json").write_text(json.dumps(report, indent=2)+"\n")
print(json.dumps(report))
