"""Construct an explicit identification of the escape endpoint with Family C."""
from collections import deque
from itertools import combinations, product
import hashlib
import json
from pathlib import Path
import time

HERE=Path(__file__).resolve().parent
WORDS=list(product(range(7),repeat=5))
INDEX={w:i for i,w in enumerate(WORDS)}
def conflict(a,b):
    return all((x-y)%7 in (0,1,6) for x,y in zip(a,b))
def transform(w):
    return ((w[3]+2)%7,(w[4]+6)%7,(2-w[0])%7,(-w[1])%7,(2-w[2])%7)
def token(w): return ''.join(map(str,w))


def main():
    if not __debug__: raise RuntimeError('Run without -O')
    endpoint={tuple(map(int,w)) for w in (HERE/'two-conflict-escape-words.txt').read_text().split()}
    target=set(map(tuple,json.loads((HERE/'valley-floor365-seed2-farthest.json').read_text())['words']))
    source_core=set(map(tuple,json.loads((HERE/'two-conflict-endpoint-component.json').read_text())['fixed_across_visited_words']))
    core=set(map(tuple,json.loads((HERE/'valley-floor365-plateau.json').read_text())['fixed_across_visited_words']))
    start={transform(w) for w in endpoint}
    assert len(endpoint)==len(target)==len(start)==367
    assert {transform(w) for w in source_core}==core and core<=start and core<=target
    assert not any(conflict(a,b) for s in (start,target) for a,b in combinations(s,2))
    blocked=set()
    for w in core:
        blocked.update(product(*[((x-1)%7,x,(x+1)%7) for x in w]))
    free=sorted(set(WORDS)-blocked);assert len(free)==189
    local={w:i for i,w in enumerate(free)}
    masks=[sum(1<<j for j,u in enumerate(free) if conflict(w,u)) for w in free]
    first=sum(1<<local[w] for w in start-core)
    last=sum(1<<local[w] for w in target-core)
    parents={first:None};queue=deque([first]);all_free=(1<<len(free))-1
    began=time.monotonic()
    while queue and last not in parents:
        if len(parents)>100000 or time.monotonic()-began>30:
            raise RuntimeError('Bounded path search incomplete')
        state=queue.popleft();remaining=all_free^state
        while remaining:
            bit=remaining&-remaining;remaining^=bit;v=bit.bit_length()-1
            blockers=masks[v]&state
            assert blockers
            if blockers.bit_count()!=1: continue
            nxt=state^blockers^bit
            if nxt not in parents:
                parents[nxt]=(state,blockers.bit_length()-1,v);queue.append(nxt)
    assert last in parents
    path=[];cur=last
    while parents[cur] is not None:
        prev,removed,added=parents[cur]
        path.append(dict(removed=token(free[removed]),added=token(free[added])));cur=prev
    path.reverse()
    # Verify the constructive certificate directly in full coordinates.
    state=set(start)
    for move in path:
        removed=tuple(map(int,move['removed']));added=tuple(map(int,move['added']))
        assert removed in state and added not in state
        state.remove(removed);state.add(added)
        assert len(state)==367 and not any(conflict(a,b) for a,b in combinations(state,2))
    assert state==target
    result=dict(permutation=[3,4,0,1,2],signs=[1,1,-1,-1,-1],shifts=[2,6,2,0,2],
                component_states=5971,core_size=len(core),path=path,path_length=len(path),
                path_search_states_discovered=len(parents),
                endpoint_sha256=hashlib.sha256(' '.join(sorted(map(token,endpoint))).encode()).hexdigest(),
                target_sha256=hashlib.sha256(' '.join(sorted(map(token,target))).encode()).hexdigest(),
                scope='Explicit graph automorphism followed by independent single-word moves reaches the published Family-C seed; endpoint is not a new family up to this automorphism.')
    (HERE/'two-conflict-endpoint-classification.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))


if __name__=='__main__': main()
