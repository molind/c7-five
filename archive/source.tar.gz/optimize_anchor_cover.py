"""Bounded LP search for one U2-compatible-anchor domain; exact integer checks."""
import contextlib,hashlib,io,itertools,json,math,runpy,subprocess,sys,time
from pathlib import Path
P=Path(__file__).parent

def solve(anchor, second=None):
    import numpy as np
    import scipy
    from scipy.optimize import linprog
    from scipy.sparse import coo_matrix
    with contextlib.redirect_stdout(io.StringIO()):c=runpy.run_path(str(P/'shared_u2_compact_replay.py'))
    anchors=[tuple(map(int,x)) for x in [anchor,second] if x is not None]
    assert all(a in set(c['W'])-c['U2'] for a in anchors)
    if second is not None:
        assert any((x-y)%7 in (2,3,4,5) for x,y in zip(*anchors))
    words=sorted(w for w in c['U2'] if all(any((x-y)%7 in (2,3,4,5) for x,y in zip(a,w)) for a in anchors))
    masks={}
    for i,w in enumerate(words):
        for bits in itertools.product((0,1),repeat=5):
            origin=tuple((x-b)%7 for x,b in zip(w,bits))
            masks[origin]=masks.get(origin,0)|(1<<i)
    reps={mask:origin for origin,mask in sorted(masks.items())}
    columns=list(reps);rows=[];cols=[]
    for j,mask in enumerate(columns):
        while mask:
            bit=mask&-mask;mask^=bit;rows.append(bit.bit_length()-1);cols.append(j)
    matrix=coo_matrix((np.ones(len(rows)),(rows,cols)),shape=(len(words),len(columns))).tocsr()
    name=f'anchor-{anchor}' if second is None else f'pair-{anchor}-{second}'
    output=P/f'{name}-lp.json'
    report=dict(anchor=anchor,vertices=len(words),columns=len(columns),scipy=scipy.__version__,stage='solver',domain_sha256=hashlib.sha256(' '.join(''.join(map(str,w)) for w in words).encode()).hexdigest())
    if second is not None:report['second_anchor']=second
    output.write_text(json.dumps(report,indent=2)+'\n')
    began=time.monotonic()
    r=linprog(np.ones(len(columns)),A_ub=-matrix,b_ub=-np.ones(len(words)),bounds=(0,None),method='highs',options={'time_limit':30})
    report.update(numeric_status=int(r.status),message=r.message,solver_seconds=time.monotonic()-began)
    if r.x is not None:
        report['numeric_objective']=float(r.fun)
        den=1000000000
        cover=[dict(origin=reps[mask],units=math.ceil(max(0,float(x))*den)) for mask,x in zip(columns,r.x) if x>0]
        def loads(entries):
            load=dict.fromkeys(words,0)
            for e in entries:
                for w in itertools.product(*[(x,(x+1)%7) for x in e['origin']]):
                    if w in load:load[w]+=e['units']
            return load
        least=min(loads(cover).values());assert least>0
        if least<den:
            for e in cover:e['units']=(e['units']*den+least-1)//least
        least=min(loads(cover).values());assert least>=den
        total=sum(e['units'] for e in cover)
        report.update(denominator=den,cover=cover,cover_units=total,minimum_coverage=least,primal_exact_checked=True,below367=total<367*den)
        if second is not None:report['below366']=total<366*den
        # Downward rounding and scaling produce a separately checkable dual.
        if r.ineqlin.marginals is not None:
            dual={w:math.floor(max(0,-float(v))*den) for w,v in zip(words,r.ineqlin.marginals)}
            def maximum(values):
                return max(sum(values.get(w,0) for w in itertools.product(*[(x,(x+1)%7) for x in origin])) for origin in c['W'])
            top=maximum(dual)
            if top>den:dual={w:v*den//top for w,v in dual.items()}
            top=maximum(dual);assert top<=den
            report.update(dual=[dict(word=w,units=v) for w,v in dual.items() if v],dual_units=sum(dual.values()),maximum_box_load=top,dual_exact_checked=True)
    report['stage']='complete'
    output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ['cover','dual']}),flush=True)

if __name__=='__main__':
    tokens=[x for x in sys.argv[1:] if x!='--worker']
    assert len(tokens) in [1,2]
    assert all(len(x)==5 and set(x)<=set('0123456') for x in tokens)
    anchor=tokens[0];second=tokens[1] if len(tokens)==2 else None
    if '--worker' in sys.argv:solve(anchor,second)
    else:
        name=f'anchor-{anchor}' if second is None else f'pair-{anchor}-{second}'
        output=P/f'{name}-lp.json';assert not output.exists(),'Preserve prior run'
        output.write_text(json.dumps(dict(anchor=anchor,stage='starting'))+'\n')
        try:subprocess.run([sys.executable,'-u',__file__,*tokens,'--worker'],check=True,timeout=90)
        except subprocess.TimeoutExpired:
            report=json.loads(output.read_text());report.update(stage='parent_timeout',interpretation='Inconclusive; killed and reaped.')
            output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
