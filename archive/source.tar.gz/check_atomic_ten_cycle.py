"""Check the ten-word replacement directly, including all1024 insertion subsets.

The other356 words remain fixed. Each chosen insertion forbids its old blockers;
all other old words can be retained. This enumerates the best size possible for
every insertion subset in the20-word union, without a matching or SCC routine.
"""
import hashlib
from itertools import combinations
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent


def main():
    assert __debug__
    path=HERE/'two-blocker-atomic-ten-backbone-sep21.json';atomic=json.loads(path.read_text())
    p=Path(atomic['input']);assert hashlib.sha256(p.read_bytes()).hexdigest()==atomic['input_sha256'];cycle=json.loads(p.read_text())
    p=Path(cycle['input']);assert hashlib.sha256(p.read_bytes()).hexdigest()==cycle['input_sha256'];mip=json.loads(p.read_text())
    p=Path(mip['input']);assert hashlib.sha256(p.read_bytes()).hexdigest()==mip['input_sha256'];domain=json.loads(p.read_text())
    p=Path(domain['input']);assert hashlib.sha256(p.read_bytes()).hexdigest()==domain['input_sha256'];originals=json.loads(p.read_text())
    record=atomic['bases'][0];old=record['removed'];new=record['added'];final=record['words']
    initial=originals['bases'][cycle['bases'][0]['origin_base']]['words']
    assert len(set(old+new))==20 and len(old)==len(new)==10
    assert set(old)<=set(initial) and set(new).isdisjoint(initial)
    assert final==sorted((set(initial)-set(old))|set(new))
    def word(v):return tuple(v//7**j%7 for j in range(4,-1,-1))
    def independent(u,v):return any(2<=(x-y)%7<=5 for x,y in zip(word(u),word(v)))
    for ids in (initial,final):
        assert len(ids)==len(set(ids))==366 and all(type(v) is int and 0<=v<16807 for v in ids)
        assert all(independent(u,v) for u,v in combinations(ids,2))
    blockers=[sum(1<<j for j,u in enumerate(old) if not independent(u,v)) for v in new]
    assert all(b.bit_count()==2 for b in blockers)
    sizes=[];maximizers=[]
    for mask in range(1024):
        blocked=0
        for i,b in enumerate(blockers):
            if mask>>i&1:blocked|=b
        size=10-blocked.bit_count()+mask.bit_count();sizes.append(size)
        if size==10:maximizers.append(mask)
    assert max(sizes)==10 and maximizers==[0,1023]
    result=dict(input=str(path),input_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        old_words=[''.join(map(str,word(v))) for v in old],new_words=[''.join(map(str,word(v))) for v in new],
        pair_checks=2*66795,insertion_subsets=1024,maximum_union_size=10,only_maxima_are_endpoints=True,
        minimum_neutral_step_inside_union=10,scope=__doc__)
    out=HERE/'atomic-ten-cycle-verification-sep21.json';assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))


if __name__=='__main__':main()
