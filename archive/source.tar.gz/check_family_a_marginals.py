"""A neutral exchange changes even the unlabeled coordinate-marginal signature."""
from hashlib import sha256
from itertools import combinations
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def marginals(words):
    return [[sum(w[i] == str(d) for w in words) for d in range(7)]
            for i in range(5)]


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    before = (HERE / 'exchange-dfs-family-a-words.txt').read_text().split()
    assert sha256(' '.join(before).encode()).hexdigest() == (
        'dc27c8a0ff3bf27bbd55ea95398848bcb7ed3b871e5ec4c7d7f78cd6beeeefe1')
    assert '56665' in before and '55665' not in before
    after = sorted((set(before) - {'56665'}) | {'55665'})
    assert sha256(' '.join(after).encode()).hexdigest() == (
        '6359d03a45aaf6ca307d8bdfcc49678b94438de6e5a815217e42b63842e75deb')
    for words in (before, after):
        assert len(words) == len(set(words)) == 367
        assert all(len(w) == 5 and set(w) <= set('0123456') for w in words)
        assert all(any((int(a) - int(b)) % 7 in (2, 3, 4, 5)
                       for a, b in zip(u, v)) for u, v in combinations(words, 2))
    rows = [marginals(words) for words in (before, after)]
    # This coarser signature is preserved by ALL independent symbol relabelings
    # and coordinate permutations, hence also by the actual graph symmetries.
    signatures = [sorted(sorted(row) for row in matrix) for matrix in rows]
    assert signatures[0] != signatures[1]
    # Both sets remain in the same one-word component, by the explicit exchange.
    result = dict(
        removed='56665', added='55665', pair_checks_per_set=67161,
        before=rows[0], after=rows[1],
        unlabeled_signature_before=signatures[0],
        unlabeled_signature_after=signatures[1],
        conclusion='Marginal signatures distinguish these two symmetry orbits '
                   'but are not constant on a one-word exchange component.',
        scope='Two pinned independent367 sets in Family A; no global368 bound.')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
