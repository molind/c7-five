"""Run the existing exact exchange kernel on a supplied367 seed and component.

Rebuild every exported blocker and compatibility row with coordinate bitmasks
before searching. Verify all returned full codes directly; retain outside367
targets for classification and stop immediately on a verified improvement.
"""
import argparse
import gzip
import hashlib
from itertools import combinations, product
import json
from pathlib import Path
import struct
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def conflict(a, b):
    return all((x-y) % 7 in (0, 1, 6) for x, y in zip(a, b))


def coordinate_masks(words):
    result = [[0]*7 for _ in range(5)]
    for i, word in enumerate(words):
        for k, x in enumerate(word):
            result[k][x] |= 1 << i
    return result


def nearby(word, masks, size):
    result = (1 << size)-1
    for k, x in enumerate(word):
        result &= masks[k][(x-1) % 7] | masks[k][x] | masks[k][(x+1) % 7]
    return result


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--seed', required=True, type=Path)
    p.add_argument('--component', required=True, type=Path)
    p.add_argument('--prefix', required=True, type=Path)
    p.add_argument('--radii', nargs='+', type=int, default=[2, 3, 4, 5])
    p.add_argument('--improve-only',action='store_true')
    p.add_argument('--seconds', type=float, default=30)
    args = p.parse_args()
    if args.seconds <= 0 or not args.radii or any(r < 1 or r > 8 for r in args.radii):
        p.error('Positive time and radii1..8 required')
    if (Path(str(args.prefix)+'.json').exists() or Path(str(args.prefix)+'.tmp').exists()
            or list(args.prefix.parent.glob(args.prefix.name+'-d*.txt'))):
        raise FileExistsError('Choose a fresh prefix')
    tokens = args.seed.read_text().split()
    assert len(tokens) == len(set(tokens)) == 367
    assert all(len(t) == 5 and set(t) <= set('0123456') for t in tokens)
    seed = [tuple(map(int, t)) for t in tokens]
    assert not any(conflict(a, b) for a, b in combinations(seed, 2))
    with gzip.open(args.component, 'rt') as f:
        metadata = json.loads(next(f))
        raw_states = [json.loads(line) for line in f]
    assert metadata['cardinality'] == 367
    assert all(len(s) == len(set(s)) == 367 and s == sorted(s)
               and all(type(v) is int and 0 <= v < 16807 for v in s) for s in raw_states)
    known = {struct.pack('<367H', *s) for s in raw_states}
    assert len(known) == len(raw_states) == metadata['states']
    assert hashlib.sha256(b''.join(sorted(known))).hexdigest() == metadata['component_sha256']
    assert struct.pack('<367H', *sorted(int(t, 7) for t in tokens)) in known
    occupied = set(seed)
    masks = coordinate_masks(seed)
    outside = [(w, nearby(w, masks, 367)) for w in product(range(7), repeat=5) if w not in occupied]
    assert all(b for _, b in outside), 'Seed accepts immediate augmentation'
    binary, exporter = HERE/'exchange_dfs_residual_two', HERE/'export_exchange_graph.py'
    report = dict(seed_file=str(args.seed), seed_sha256=sha(args.seed),
                  token_sha256=hashlib.sha256(' '.join(tokens).encode()).hexdigest(),
                  component_file=str(args.component), component_file_sha256=sha(args.component),
                  kernel_sha256=sha(binary), kernel_source_sha256=sha(HERE/'exchange_dfs_residual_two.cpp'),
                  exporter_sha256=sha(exporter), driver_sha256=sha(__file__),
                  seconds_per_query=args.seconds, improve_only=args.improve_only, rows=[], candidates=[], improved_words=None,
                  status='running', scope='Pinned seed only. Exhausted queries have fully rebuilt inputs; budget limits exclude nothing. Outside-component367 targets require classification.')
    output = Path(str(args.prefix)+'.json')
    archived = set()
    def save():
        temp = output.with_suffix('.tmp')
        temp.write_text(json.dumps(report, indent=2)+'\n')
        temp.replace(output)
    save()
    for radius in args.radii:
        pool = sorted((v for v in outside if v[1].bit_count() <= radius), key=lambda v: v[1].bit_count())
        graph = Path(str(args.prefix)+f'-d{radius}.txt')
        with graph.open('x') as f:
            subprocess.run([sys.executable, str(exporter), str(args.seed), report['token_sha256'], str(radius)],
                           stdout=f, check=True, timeout=60)
        pc = coordinate_masks([w for w, _ in pool])
        full = (1 << len(pool))-1
        with graph.open() as f:
            assert list(map(int, next(f).split())) == [len(pool), 6, radius]
            for word, blockers in pool:
                row = [int(x, 16) for x in next(f).split()]
                assert len(row) == 6+(len(pool)+63)//64
                assert sum(v << (64*j) for j, v in enumerate(row[:6])) == blockers
                assert sum(v << (64*j) for j, v in enumerate(row[6:])) == full ^ nearby(word, pc, len(pool))
            assert not f.read().strip()
        for neutral in ((False,) if args.improve_only else (False, True)):
            began = time.monotonic()
            with graph.open() as f:
                try:
                    run = subprocess.run([str(binary), str(args.seconds), '--subset', '--budget-bitsets', '--binary-budget', '--residual-budget', *(['--neutral'] if neutral else [])],
                                         stdin=f, text=True, capture_output=True, check=True, timeout=args.seconds+15)
                    result = json.loads(run.stdout)
                except subprocess.TimeoutExpired:
                    result = dict(status='parent_timeout')
            if result['status'] == 'exhausted':
                assert result['nodes_started'] == result['nodes_completed']
            choices = result.get('neutral', [])+result.get('improving', [])
            if result['status'] == 'witness':
                choices.append(result['chosen'])
            outside_count = 0
            for chosen in choices:
                assert len(set(chosen)) == len(chosen) == (radius if neutral else radius+1)
                assert all(type(i) is int and 0 <= i < len(pool) for i in chosen)
                removed = 0
                for i in chosen:
                    removed |= pool[i][1]
                assert removed.bit_count() <= radius
                target = sorted({w for i, w in enumerate(seed) if not (removed >> i) & 1} | {pool[i][0] for i in chosen})
                assert len(target) == 367-removed.bit_count()+len(chosen)
                assert len(target) >= 367 and not any(conflict(a, b) for a, b in combinations(target, 2))
                encoded = struct.pack('<'+str(len(target))+'H', *(int(''.join(map(str, w)), 7) for w in target))
                if len(target) >= 368:
                    report['improved_words'] = [''.join(map(str, w)) for w in target]
                if encoded not in known:
                    outside_count += 1
                    if encoded not in archived:
                        archived.add(encoded)
                        report['candidates'].append(dict(step=len(report['rows']), radius=radius, neutral=neutral,
                            words=[''.join(map(str, w)) for w in target], size=len(target)))
            row = dict(radius=radius, neutral=neutral, pool=len(pool), input=str(graph), input_sha256=sha(graph),
                       full_graph_verified=True, result=result, outside_targets=outside_count,
                       elapsed_seconds=time.monotonic()-began)
            report['rows'].append(row)
            if report['improved_words'] is not None:
                report['status'] = 'verified_improvement'
            save()
            print(json.dumps({k:v for k,v in row.items() if k != 'result'} | {'status':result['status']}), flush=True)
            if report['improved_words'] is not None:
                return
    report['status'] = 'complete'
    save()


if __name__ == '__main__':
    main()
