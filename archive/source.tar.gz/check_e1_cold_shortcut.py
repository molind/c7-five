"""Compare complete cap3 scans with the E1 cooling restriction on fixed inputs."""
from itertools import combinations, product
import json
from pathlib import Path
import struct

from search_low_conflict import WORDS, family_start, successors, independent_target

if not __debug__: raise RuntimeError('Run without -O')
adjacency=[tuple(2401*a+343*b+49*c+7*d+e
    for a,b,c,d,e in product(*[((x-1)%7,x,(x+1)%7) for x in w])
    if 2401*a+343*b+49*c+7*d+e!=v) for v,w in enumerate(WORDS)]
rows=[]
for family in ('A','B'):
    start,known=family_start(family)
    lifts=sorted({a|b for a,b in combinations(known,2) if len(a-b)==1},key=lambda s:tuple(sorted(s)))
    assert len(lifts)==(6 if family=='A' else 163)
    # All six A sources, plus the B start as a real-data control. The general
    # proof and small-graph controls cover the rule, not just these samples.
    for index,state in enumerate(lifts if family=='A' else [start]):
        count=0;full_minimum=set();by_energy={}
        for target,energy,_,_,edges in successors(state,adjacency,3):
            count+=1;by_energy[energy]=by_energy.get(energy,0)+1
            assert independent_target(target,edges,known) is None
            if energy==1: full_minimum.add(struct.pack('<368H',*sorted(target)))
        assert 0 not in by_energy and full_minimum
        restricted=set()
        for target,energy,_,_,edges in successors(state,adjacency,1):
            assert energy==1 and independent_target(target,edges,known) is None
            restricted.add(struct.pack('<368H',*sorted(target)))
        assert restricted==full_minimum
        rows.append(dict(family=family,lift_index=index,full_successors=count,
                         full_energy_counts=by_energy,restricted_successors=len(restricted),
                         same_minimum_population=True,no_positive_target_skipped=True))
result=dict(rows=rows,scope='All6 A E1 lift states and1 B lift state; general proof is in family-a-cycles-followup.md.')
(Path(__file__).parent/'e1-cold-shortcut-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
