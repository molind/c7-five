"""Recompute a target-valid core inequality from all zero-to-three omissions.

This is conditional on reaching full_target. It is not a rank inequality for
smaller independent sets: the original 367-word F code violates the cut.
"""
import argparse
from collections import Counter
from functools import lru_cache
import hashlib
from itertools import combinations, product
import json
from pathlib import Path

import numpy as np
from census_core_triple_domains import census, controls


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def certify(core, target):
    assert len(core) == len(set(core)) >= 3
    assert all(type(v) is int and 0 <= v < 16807 for v in core)
    words = np.array(list(product(range(7), repeat=5)), dtype=np.int16)
    owners = [0]*16807
    for i, v in enumerate(core):
        delta = (words-words[v]) % 7
        near = np.all((delta == 0) | (delta == 1) | (delta == 6), axis=1)
        assert {w for w in core if near[w]} == {v}
        for w in np.flatnonzero(near):
            owners[w] |= 1 << i
    occupied = set(core)
    pool = [v for v in range(16807) if v not in occupied and owners[v].bit_count() <= 3]
    blockers = [owners[v] for v in pool]
    groups = {}
    for i, mask in enumerate(blockers):
        groups[mask] = groups.get(mask, 0) | (1 << i)
    adjacency = []
    for i, v in enumerate(pool):
        delta = (words[pool]-words[v]) % 7
        near = np.all((delta == 0) | (delta == 1) | (delta == 6), axis=1)
        near[i] = False
        adjacency.append(int.from_bytes(np.packbits(near, bitorder='little').tobytes(), 'little'))

    @lru_cache(maxsize=500000)
    def alpha(mask):
        if not mask:
            return 0
        bit = mask & -mask
        i = bit.bit_length()-1
        rest = mask ^ bit
        return max(alpha(rest), 1+alpha(rest & ~adjacency[i]))

    rows = []
    for removed in range(4):
        counts = Counter()
        if removed == 3:
            counts.update({mask: row[0] for mask, row in census(len(core), blockers, 'events').items()})
        else:
            for omission in combinations(range(len(core)), removed):
                domain = groups.get(0, 0)
                for size in range(1, removed+1):
                    for subset in combinations(omission, size):
                        domain |= groups.get(sum(1 << i for i in subset), 0)
                counts[domain] += 1
        histogram = Counter()
        for mask, multiplicity in counts.items():
            histogram[alpha(mask)] += multiplicity
        best = len(core)-removed+max(histogram)
        rows.append(dict(removed=removed, groups=sum(counts.values()),
                         distinct_domains=len(counts),
                         alpha_histogram={str(k):v for k,v in sorted(histogram.items())},
                         best_full_size=best))
    assert all(row['best_full_size'] < target for row in rows), 'Target has a surviving core case'
    return dict(core=core, full_target=target, max_retained_core=len(core)-4,
                eligible_noncore_pool=len(pool), cases=rows,
                scope='Every independent set reaching full_target must omit at least four of these core words. Smaller codes need not satisfy this inequality.')


def replay(report):
    source = Path(report['input'])
    assert digest(source) == report['input_sha256']
    core = json.loads(source.read_text())['core_words']
    expected = certify(core, report['cut']['full_target'])
    assert report['cut'] == expected
    return expected


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--target', type=int, default=368)
    p.add_argument('--verify', action='store_true')
    args = p.parse_args()
    assert __debug__ and not args.output.exists()
    source = json.loads(args.input.read_text())
    if args.verify:
        result = dict(input_sha256=digest(args.input), cut=replay(source), checker_sha256=digest(__file__))
    else:
        result = dict(input=str(args.input), input_sha256=digest(args.input),
                      source_sha256=digest(__file__), controls=controls(),
                      cut=certify(source['core_words'], args.target))
    args.output.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k:v for k,v in result['cut'].items() if k != 'core'}), flush=True)


if __name__ == '__main__':
    main()
