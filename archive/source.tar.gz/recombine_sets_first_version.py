"""Exact two-parent independent-set recombination, with bounded C7^5 sampling.

The common vertices are isolated in the union. The symmetric difference is
bipartite, so a maximum matching and its alternating forest give an optimum
independent subset of the union. No radius or conflict-energy cap is imposed.
"""
import argparse
from collections import Counter
import hashlib
from itertools import combinations, product
import json
from pathlib import Path
import random
import time

import numpy as np

HERE = Path(__file__).resolve().parent
FILES = {
    'PS': 'exchange-dfs-original-words.txt',
    'A': 'exchange-dfs-family-a-words.txt',
    'B': 'family-b-seed-words.txt',
    'C': 'exchange-dfs-family-c-words.txt',
}


def optimum(adj, nr):
    """Return matching and maximum independent set, as local vertex indices."""
    mate = [-1] * nr

    def augment(u, seen):
        for v in adj[u]:
            if v in seen:
                continue
            seen.add(v)
            if mate[v] == -1 or augment(mate[v], seen):
                mate[v] = u
                return True
        return False

    for u in range(len(adj)):
        augment(u, set())
    pairs = [(u, v) for v, u in enumerate(mate) if u != -1]
    matched_left = {u: v for u, v in pairs}
    left = set(range(len(adj))) - matched_left.keys()
    right = set()
    stack = list(left)
    while stack:
        u = stack.pop()
        for v in adj[u]:
            if matched_left.get(u) == v or v in right:
                continue
            right.add(v)
            assert mate[v] != -1, 'Unmatched augmenting path remains'
            if mate[v] not in left:
                left.add(mate[v])
                stack.append(mate[v])
    chosen_right = set(range(nr)) - right
    assert len({u for u, _ in pairs}) == len(pairs)
    assert all(v in adj[u] for u, v in pairs)
    assert not any(v in chosen_right for u in left for v in adj[u])
    assert len(left) + len(chosen_right) == len(adj) + nr - len(pairs)
    return pairs, left, chosen_right


def conflict(a, b):
    return all((x-y) % 7 in (0, 1, 6) for x, y in zip(a, b))


def verify(words):
    assert len(words) == len(set(words))
    assert all(len(w) == 5 and all(0 <= c < 7 for c in w) for w in words)
    assert not any(conflict(a, b) for a, b in combinations(words, 2))


def cross_graph(left, right):
    if not left or not right:
        return [[] for _ in left]
    a = np.array(left, dtype=np.int16)
    b = np.array(right, dtype=np.int16)
    delta = (a[:, None, :] - b[None, :, :]) % 7
    edges = np.all((delta == 0) | (delta == 1) | (delta == 6), axis=2)
    return [np.flatnonzero(row).tolist() for row in edges]


def self_test():
    cases = 0
    for nl, nr in [(0, 3), (3, 0), (3, 3), (4, 3)]:
        for mask in range(1 << (nl*nr)):
            adj = [[v for v in range(nr) if mask >> (u*nr+v) & 1] for u in range(nl)]
            pairs, left, right = optimum(adj, nr)
            # Enumerating the chosen left side determines all admissible rights.
            expected = max(bits.bit_count() + nr - len({v for u in range(nl)
                if bits >> u & 1 for v in adj[u]}) for bits in range(1 << nl))
            assert len(left) + len(right) == expected
            assert nl+nr-len(pairs) == expected
            cases += 1
    # Equal-sized parents, but their union admits a strict improvement (Hall defect).
    pairs, left, right = optimum([[0], [0]], 2)
    assert len(pairs) == 1 and len(left) + len(right) == 3
    rng = random.Random(20260920)
    vertices = list(product(range(7), repeat=5))
    a, b = rng.sample(vertices, 31), rng.sample(vertices, 37)
    actual = cross_graph(a, b)
    assert actual == [[j for j, v in enumerate(b) if conflict(u, v)] for u in a]
    return {'exhaustive_bipartite_graphs': cases, 'positive_equal_parent_control': True,
            'direct_coordinate_cross_pairs': len(a)*len(b)}


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--trials', type=int, default=2000)
    parser.add_argument('--seconds', type=float, default=90)
    parser.add_argument('--seed', type=int, default=20260920)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.trials < 1 or args.seconds <= 0:
        parser.error('Positive budgets required')
    if args.self_test:
        result = self_test()
        args.output.write_text(json.dumps(result, indent=2)+'\n')
        print(json.dumps(result)); return
    parents = {k: [tuple(map(int, w)) for w in (HERE/f).read_text().split()] for k, f in FILES.items()}
    for words in parents.values():
        assert len(words) == 367
        verify(words)
    rng = random.Random(args.seed)
    initial_pairs = [(a, b) for i, a in enumerate(parents) for b in list(parents)[i:]]
    rows = []
    best = None
    began = time.monotonic()
    for trial in range(args.trials):
        if time.monotonic()-began >= args.seconds:
            break
        perm, signs, shift = list(range(5)), [1]*5, [0]*5
        if trial < len(initial_pairs):
            pa, pb = initial_pairs[trial]
            mode = 'identity'
        else:
            pa, pb = rng.choices(list(parents), k=2)
            if trial % 2:
                mode = 'one_coordinate'
                i = rng.randrange(5)
                signs[i], shift[i] = rng.choice([-1, 1]), rng.randrange(7)
            else:
                mode = 'full_automorphism_sample'
                rng.shuffle(perm)
                signs = rng.choices([-1, 1], k=5)
                shift = rng.choices(range(7), k=5)
        a = set(parents[pa])
        b = {tuple((signs[i]*w[perm[i]]+shift[i]) % 7 for i in range(5)) for w in parents[pb]}
        common = a & b
        left, right = sorted(a-b), sorted(b-a)
        adj = cross_graph(left, right)
        matching, il, ir = optimum(adj, len(right))
        child = sorted(common | {left[i] for i in il} | {right[i] for i in ir})
        size = len(child)
        assert size == len(a | b)-len(matching) and size >= 367
        row = dict(trial=trial, parents=[pa, pb], mode=mode,
                   permutation=perm, signs=signs, shift=shift, common=len(common),
                   union=len(a | b), cross_edges=sum(map(len, adj)), matching=len(matching), optimum=size)
        rows.append(row)
        if best is None or size > best['size']:
            verify(child)
            best = dict(size=size, trial=trial, words=child, matching=matching)
        if size >= 368:
            break
    result = dict(status='improved' if best['size'] >= 368 else
                  ('trial_limit' if len(rows) == args.trials else 'timeout'),
                  trials=len(rows), seconds=time.monotonic()-began, seed=args.seed,
                  requested_trials=args.trials, time_limit=args.seconds,
                  optimum_histogram=dict(Counter(row['optimum'] for row in rows)), best=best, rows=rows,
                  source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  input_sha256={k: hashlib.sha256((HERE/f).read_bytes()).hexdigest() for k, f in FILES.items()},
                  scope='Each sampled two-parent union solved exactly and primal/dual sizes matched. Sampling does not cover all automorphisms or independent sets; no global exclusion.')
    args.output.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('best', 'rows')}))


if __name__ == '__main__':
    main()
