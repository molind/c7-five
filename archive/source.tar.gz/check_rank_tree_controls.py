"""Check tree coverage using real include-branch certificates and an open sibling."""
import copy
import argparse
import hashlib
import json
from pathlib import Path

from check_two_slice_covers import HERE
from search_rank_tree import replay


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=HERE/'rank-tree-structure-controls-sep21.json')
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    path = HERE/'three-slice-branches02-sep21.json'
    source = json.loads(path.read_text())
    take, omit = source['results'][:2]
    assert take['action'] == 'include' and take['excludes_target']
    assert omit['action'] == 'exclude' and not omit['excludes_target']

    def node(index, row, selected, status):
        return dict(id=index, pool=row['pool'], remaining_pool=row['pool'], selected=selected,
                    rounds=[dict(pool=row['pool'], certificate=row['certificate'],
                                 excludes_target=row['excludes_target'], pruning_applied=False, removed=[])],
                    status=status)

    root = node(0, source['root'], [], 'split')
    root.update(split_vertex=take['vertex'], children=dict(include=1, exclude=2))
    left = node(1, take, [take['vertex']], 'cover_closed')
    right = node(2, omit, [], 'pending')
    right['rounds'] = []
    tree = dict(input=source['input'], input_sha256=source['input_sha256'], full_target=source['full_target'],
                nodes=[root,left,right], candidates=[], excludes_target=False, status='incomplete')
    checked = replay(tree)
    assert checked['nodes'] == 3 and not checked['excludes_target']
    assert checked['statistics']['cover_closed'] == checked['statistics']['pending'] == 1
    rejected = []
    bad = copy.deepcopy(tree);bad['excludes_target'] = True
    try:
        replay(bad)
    except AssertionError:
        rejected.append('One closed child cannot close its open parent')
    else:
        raise AssertionError('Open sibling was ignored')
    bad = copy.deepcopy(tree);bad['nodes'][0]['children']['exclude'] = 1
    try:
        replay(bad)
    except AssertionError:
        rejected.append('Both children must represent their own branch')
    else:
        raise AssertionError('Duplicated child was accepted')
    bad = copy.deepcopy(tree);bad['nodes'][2]['pool'] = bad['nodes'][2]['pool'][1:]
    bad['nodes'][2]['remaining_pool'] = bad['nodes'][2]['pool']
    try:
        replay(bad)
    except AssertionError:
        rejected.append('A candidate cannot disappear without a proved reduction')
    else:
        raise AssertionError('Unjustified child restriction was accepted')
    result = dict(real_fixture_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                  open_tree_verification=checked, negative_controls=rejected,
                  source_sha256=hashlib.sha256((HERE/'search_rank_tree.py').read_bytes()).hexdigest())
    output = args.output
    output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result),flush=True)


if __name__ == '__main__':
    main()
