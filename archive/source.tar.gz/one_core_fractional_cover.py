"""Exact rational clique-cover certificates for the one-core deletion branches.

Each adjacent 2x2x2x2x2 box is a conflict clique. Nonnegative weights covering
every candidate by at least one bound any independent set by their total weight.
Z3 only discovers weights; check_cover validates them using Python Fractions.
"""
import hashlib,itertools,json,time
from fractions import Fraction
from pathlib import Path
import z3
from search_exchanges import graph_data,verify

ROOT=Path(__file__).resolve().parent
OFFSETS=list(itertools.product((0,1),repeat=5))

def conflict(a,b):
    return all((int(x)-int(y))%7 in (0,1,6) for x,y in zip(a,b))

def covered(word,origin):
    return all((a-b)%7 in (0,1) for a,b in zip(word,origin))

def check_cover(words,certificate,target):
    total=Fraction(0);coverage=[Fraction(0) for _ in words]
    for item in certificate:
        origin=item['origin'];assert len(origin)==5 and all(type(x) is int and 0<=x<7 for x in origin)
        weight=Fraction(item['weight']);assert weight>=0;total+=weight
        for i,word in enumerate(words):
            if covered(word,origin):coverage[i]+=weight
    assert all(w>=1 for w in coverage)
    assert total<target
    return str(total)

def find_cover(words,target):
    boxes={}
    for i,word in enumerate(words):
        for d in OFFSETS:
            origin=tuple((a-b)%7 for a,b in zip(word,d));boxes[origin]=boxes.get(origin,0)|(1<<i)
    representatives={mask:origin for origin,mask in sorted(boxes.items())}
    maximal=[]
    for mask in sorted(representatives,key=lambda m:(-m.bit_count(),m)):
        if not any(mask&m==mask for m in maximal):maximal.append(mask)
    weights=[z3.Real(f'w{i}') for i in range(len(maximal))]
    solver=z3.SolverFor('QF_LRA');solver.set(timeout=2000)
    solver.add(*[w>=0 for w in weights]);solver.add(z3.Sum(weights)<target)
    for i in range(len(words)):
        solver.add(z3.Sum([w for w,m in zip(weights,maximal) if m>>i&1])>=1)
    start=time.monotonic();status=solver.check()
    result={'candidate_count':len(words),'cliques':len(maximal),'solver_status':str(status),'seconds':time.monotonic()-start}
    if status==z3.sat:
        model=solver.model();certificate=[]
        for var,mask in zip(weights,maximal):
            value=model.eval(var);weight=Fraction(value.numerator_as_long(),value.denominator_as_long())
            if weight:certificate.append({'origin':representatives[mask],'weight':str(weight)})
        result.update(certificate=certificate,total=check_cover(words,certificate,target),excluded=True)
    else:
        result['excluded']=False
        if status==z3.unknown:result['reason']=solver.reason_unknown()
    return result

def main():
    source=ROOT/'valley-floor365-plateau.json';prior=ROOT/'one-core-pairs-results.json'
    core=json.loads(source.read_text())['fixed_across_visited_words'];verify(core)
    vertices,core_ids,blockers,_=graph_data(core);core_ids=set(core_ids)
    free=[tuple(map(int,v)) for v,b in zip(vertices,blockers) if not b]
    report={'core':core,'input_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
            'prior_sha256':hashlib.sha256(prior.read_bytes()).hexdigest(),'z3':z3.get_version_string(),
            'free_bound':find_cover(free,60),'cases':[]}
    output=ROOT/'one-core-fractional-results.json';began=time.monotonic()
    for index in range(len(core)):
        # Include the removed core word itself: the bound then applies to any
        # independent set retaining the other 307, even if this word is re-added.
        group=[tuple(map(int,vertices[v])) for v,b in enumerate(blockers) if b==[index]]
        candidates=free+group
        direct=find_cover(candidates,61)
        row={'removed_word':core[index],'core_index':index,'direct':direct,'pairs':[]}
        row['excluded']=direct['excluded']
        report['cases'].append(row);report['seconds']=time.monotonic()-began
        output.write_text(json.dumps(report,indent=2)+'\n')
        print(json.dumps({'removed_word':row['removed_word'],'direct_bound':direct.get('total'),
            'excluded':row['excluded'],'pair_certificates':sum(p['excluded'] for p in row['pairs']),
            'pairs':len(row['pairs'])}),flush=True)
        if time.monotonic()-began>150:break

if __name__=='__main__':main()
