"""Select five transformed slices to close with two unrestricted adjacent layers.

Four-edge path optimization is complete for each chosen root. Selection of
endpoint domains is heuristic; no whole-model exclusion follows from this file.
"""
import argparse
from collections import Counter, defaultdict
from itertools import combinations, product
import json
from pathlib import Path
import time

from search_aligned_slice_library import digest, encode
from search_slice_library import conflicts
from search_slice_orbits import IDENTITY, compose, moved
from search_slice_placements_exact import minus_shift, rotation_data
from search_slice_symmetries import transforms


def prepare(source, roots, limit, min_hint):
    base_path = Path(source['input'])
    assert digest(base_path) == source['input_sha256']
    original = json.loads(base_path.read_text())
    base, parents = original['slices'], original['parents']
    ts = transforms()
    templates = [[] for _ in base]
    for placement in source['placements']:
        perm, signs = ts[placement['transform']]
        relative = (perm, signs, tuple(placement['shift']))
        for left, position in placement['cross_edges']:
            templates[left].append((parents[placement['parent']]['slices'][position], relative))
    data = rotation_data(4)
    free = []
    for sl in base:
        blocked = set()
        for w in sl:
            blocked.update(product(*[((x-1) % 7, x, (x+1) % 7) for x in w]))
        free.append([w for w in data[0] if w not in blocked])
    linear, domains, statistics = {}, {}, []
    for root in roots:
        nodes, lookup, adjacent = [], {}, {}

        def node(b, g):
            words = tuple(sorted(moved(w, g) for w in base[b]))
            if words in lookup:
                return lookup[words]
            perm, signs, shift = g
            key = (b, perm, signs)
            if key not in linear:
                linear[key] = sum(1 << encode(moved(w, (perm, signs, (0, 0, 0, 0)))) for w in free[b])
            allowed = minus_shift(linear[key], tuple(-x % 7 for x in shift), data[1], data[2])
            index = len(nodes)
            lookup[words] = index
            nodes.append(dict(base=b, transform=g, words=words,
                mask=sum(1 << encode(w) for w in words), allowed=allowed))
            return index

        def neighbors(u):
            if u not in adjacent:
                item = nodes[u]
                adjacent[u] = sorted({node(b, compose(item['transform'], g)) for b, g in templates[item['base']]})
            return adjacent[u]

        start = node(root, IDENTITY)
        scores, history = {start:len(base[root])}, []
        for _ in range(4):
            newer, previous = {}, {}
            for u, score in scores.items():
                for v in neighbors(u):
                    assert nodes[v]['mask'] & nodes[u]['allowed'] == nodes[v]['mask']
                    value = score+len(nodes[v]['words'])
                    if value > newer.get(v, -1):
                        newer[v], previous[v] = value, u
            scores = newer
            history.append(previous)

        def path(v):
            result = [v]
            for previous in reversed(history):
                result.append(previous[result[-1]])
            return list(reversed(result))

        eligible = 0
        root_neighbors = neighbors(start)
        for end, score in scores.items():
            options = [(len(nodes[u]['words'])+len(nodes[v]['words']), u, v)
                       for u in neighbors(end) for v in root_neighbors
                       if nodes[v]['mask'] & nodes[u]['allowed'] == nodes[v]['mask']]
            hint_pair = list(max(options)[1:]) if options else []
            hint = sorted({encode(w) for i in hint_pair for w in nodes[i]['words']})
            assert len(hint) == sum(len(nodes[i]['words']) for i in hint_pair)
            initial_size = score+len(hint)
            if initial_size < min_hint:
                continue
            eligible += 1
            pool_mask = nodes[start]['allowed'] | nodes[end]['allowed']
            pool = tuple(v for v in range(2401) if pool_mask >> v & 1)
            assert set(hint) <= set(pool)
            fixed_path = path(end)
            row = dict(root=root, path_size=score, target=368-score, initial_size=initial_size,
                frames=[dict(base=nodes[v]['base'], transform=nodes[v]['transform']) for v in fixed_path],
                hint_frames=[dict(base=nodes[v]['base'], transform=nodes[v]['transform']) for v in hint_pair],
                endpoint_words=[list(w) for w in nodes[end]['words']], pool=list(pool), hint=hint)
            if pool not in domains or (score, initial_size) > (domains[pool]['path_size'], domains[pool]['initial_size']):
                domains[pool] = row
        statistics.append(dict(root=root, nodes=len(nodes), endpoints=len(scores), eligible=eligible))
        print(json.dumps(statistics[-1] | dict(distinct_pools=len(domains))), flush=True)
    groups = defaultdict(list)
    for row in domains.values():
        groups[row['root'], row['path_size']].append(row)
    for values in groups.values():
        values.sort(key=lambda row:(-row['initial_size'], len(row['pool']), row['pool']))
    keys = sorted(groups, key=lambda key:(-groups[key][0]['initial_size'], -key[1], key[0]))
    chosen, depth = [], 0
    while len(chosen) < min(limit, len(domains)):
        for key in keys:
            if depth < len(groups[key]):
                chosen.append(groups[key][depth])
                if len(chosen) == limit:
                    break
        depth += 1
    for index, job in enumerate(chosen):
        full = []
        for layer, frame in enumerate(job['frames']+job['hint_frames']):
            full.extend((layer, *moved(w, frame['transform'])) for w in base[frame['base']])
        assert len(full) == len(set(full)) == job['initial_size']
        assert all(not conflicts(a, b) for a, b in combinations(full, 2))
        job.update(index=index, hint_words=[''.join(map(str, w)) for w in sorted(full)],
                   verified_hint_pairs=len(full)*(len(full)-1)//2)
    return chosen, dict(roots=statistics, distinct_pools=len(domains), selected=len(chosen),
        selected_initial_sizes=dict(Counter(j['initial_size'] for j in chosen)),
        groups=len(groups))


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path, required=True)
    p.add_argument('--coverage', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--start', type=int, default=177)
    p.add_argument('--count', type=int, default=38)
    p.add_argument('--limit', type=int, default=64)
    p.add_argument('--min-hint', type=int, default=365)
    args = p.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    source, coverage = json.loads(args.input.read_text()), json.loads(args.coverage.read_text())
    assert source['status'] in ('complete', 'candidate_found')
    assert coverage['input_sha256'] == digest(args.input) and coverage['complete_relative_placement_coverage']
    assert source['count'] == coverage['transforms'] == 384
    n = len(json.loads(Path(source['input']).read_text())['slices'])
    if args.start < 0 or args.count < 1 or args.start+args.count > n or args.limit < 1 or args.min_hint < 0:
        p.error('Valid root range and positive limit required')
    began = time.monotonic()
    jobs, stats = prepare(source, range(args.start, args.start+args.count), args.limit, args.min_hint)
    candidates = [dict(step=j['index'], size=j['initial_size'], words=j['hint_words'],
                       verified_pairs=j['verified_hint_pairs']) for j in jobs if j['initial_size'] >= 368]
    report = dict(status='candidate_found' if candidates else 'prepared', input=str(args.input),
        input_sha256=digest(args.input), coverage=str(args.coverage), coverage_sha256=digest(args.coverage),
        source_sha256=digest(Path(__file__)), start=args.start, count=args.count, limit=args.limit,
        min_hint=args.min_hint, jobs=jobs, candidates=candidates, statistics=stats,
        elapsed_seconds=time.monotonic()-began,
        scope='Selected transformed five-layer exteriors; two remaining adjacent layers arbitrary. Endpoint enumeration is followed by heuristic filtering and selection; no global bound.')
    args.output.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps({k:v for k,v in stats.items() if k != 'roots'}), flush=True)


if __name__ == '__main__':
    main()
