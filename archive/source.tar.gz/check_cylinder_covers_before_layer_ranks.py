"""Verify cylinder-cover arithmetic and geometry without numerical libraries.

Recursive capacities follow from adjacent-layer double counting. A report
using capacity33 in dimension3 additionally depends on Baumert et al.,
Theorem4 (1971); this checker does not replay that published computation.
"""
import argparse
import copy
from functools import lru_cache
import hashlib
from itertools import combinations
import json
from pathlib import Path
import subprocess

from check_two_slice_covers import HERE, WORDS, closed, conflict


@lru_cache(None)
def check_projection(projection, capacity):
    edges = [(i, j) for i, a in enumerate(projection) for j, b in enumerate(projection) if i < j and
             (a//7-b//7) % 7 in (0, 1, 6) and (a % 7-b % 7) % 7 in (0, 1, 6)]
    data = f'{len(projection)} {len(edges)} {capacity+1} 2000 0\n\n'
    data += ''.join(f'{u} {v}\n' for u, v in edges)
    run = subprocess.run([str(HERE/'slice_clique')], input=data, text=True,
                         capture_output=True, check=True, timeout=5)
    result = json.loads(run.stdout)
    assert result['status'] == 'exhausted' and result['best_size'] == capacity
    selected = result['vertices']
    assert len(selected) == len(set(selected)) == capacity
    assert all(type(v) is int and 0 <= v < len(projection) for v in selected)
    pairs = list(combinations([projection[v] for v in selected], 2))
    assert all((a//7-b//7) % 7 not in (0, 1, 6) or (a % 7-b % 7) % 7 not in (0, 1, 6) for a, b in pairs)
    return True


def check_entries(certificate, pool, capacities):
    den = certificate['denominator']
    assert type(den) is int and den > 0
    covered = {v: 0 for v in pool}
    total = 0
    for c in certificate['cover']:
        free, origin = c['free'], c['origin']
        assert len(free) == len(set(free)) and all(type(i) is int and 0 <= i < 5 for i in free)
        assert len(origin) == 5 and all(type(x) is int for x in origin)
        assert all(origin[i] == -1 if i in free else 0 <= origin[i] < 7 for i in range(5))
        assert type(c['units']) is int and c['units'] > 0
        vs = c['vertices']
        assert len(vs) == len(set(vs)) and set(vs) <= set(pool)
        if c.get('projected_rank'):
            assert len(free) == 2
            projection = tuple(sorted({7*WORDS[v][free[0]]+WORDS[v][free[1]] for v in vs}))
            assert list(projection) == c['projection']
            assert check_projection(projection, c['capacity'])
        else:
            assert c['capacity'] == capacities[len(free)]
        for v in vs:
            assert all(i in free or (WORDS[v][i]-origin[i]) % 7 in (0, 1) for i in range(5))
            covered[v] += c['units']
        total += c['capacity']*c['units']
    assert all(v >= den for v in covered.values())
    assert total == certificate['total_units']
    assert certificate['integer_upper_bound'] == total//den
    return total, den


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--inputs', type=Path, nargs='+', required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    seed = {int(w, 7) for w in (HERE/'family-d-seed-words.txt').read_text().split()}
    assert len(seed) == 367 and all(not conflict(a, b) for a, b in combinations(seed, 2))
    base = [1]
    for _ in range(5):
        base.append(7*base[-1]//2)
    rows = []
    controls = 0
    for path in args.inputs:
        r = json.loads(path.read_text())
        assert r['status'] == 0
        axis, start, width = r['axis'], r['start'], r['width']
        fixed = {v for v in seed if (WORDS[v][axis]-start) % 7 >= width}
        assert fixed == set(r['fixed']) and len(fixed) == len(r['fixed'])
        domain = set(range(7**5))-set.union(*(set(closed(v)) for v in fixed))
        assert sorted(domain) == r['pool']
        capacities = r['capacity_sequence']
        dependency = r.get('published_cube_dependency')
        if dependency is None:
            assert capacities == base
        else:
            assert dependency['url'] == 'https://math.mit.edu/~rstan/pubs/pubfiles/17.pdf'
            assert dependency['theorem'] == 4 and not dependency['local_computation_replayed']
            assert hashlib.sha256((HERE/'sources/baumert-packing-1971.pdf').read_bytes()).hexdigest() == dependency['pdf_sha256']
            expected = base[:3]+[33]
            for _ in range(2):
                expected.append(7*expected[-1]//2)
            assert capacities == expected
        total, den = check_entries(r['certificate'], domain, capacities)
        for c in r['certificate']['cover']:
            assert len(seed & set(c['vertices'])) <= c['capacity']
        upper = len(fixed)+total//den
        assert upper >= 367
        rows.append(dict(file=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                         axis=axis, start=start, width=width, domain=len(domain), fixed=len(fixed),
                         total_units=total, denominator=den, global_size_upper=upper,
                         excludes368=upper < 368, published_cube_dependency=dependency))
        bad = copy.deepcopy(r['certificate'])
        bad['cover'][0]['capacity'] -= 1
        try:
            check_entries(bad, domain, capacities)
        except AssertionError:
            controls += 1
        else:
            raise AssertionError('Incorrect rank accepted')
        bad = dict(r['certificate'], cover=[])
        try:
            check_entries(bad, domain, capacities)
        except AssertionError:
            controls += 1
        else:
            raise AssertionError('Empty cover accepted')
    result = dict(results=rows, negative_controls_passed=controls,
                  projected_ranks_recomputed_by_cpp=check_projection.cache_info().currsize,
                  integer_kernel_sha256=hashlib.sha256((HERE/'slice_clique').read_bytes()).hexdigest(),
                  source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  scope='Exact geometry and integer arithmetic for each fixed-exterior domain; published-cube certificates additionally rely on the cited theorem33. No global C7^5 bound.')
    args.output.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
