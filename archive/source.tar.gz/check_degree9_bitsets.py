"""Compare degree-nine bitsets to exhaustive subsets and the previous raw kernel."""
import hashlib
from itertools import combinations
import json
from pathlib import Path
import random
import subprocess
import sys


def main():
    assert __debug__
    here=Path(__file__).resolve().parent;output=Path(sys.argv[1]);assert not output.exists()
    binary=here/'exchange_dfs_degree9';old=here/'exchange_dfs_before_degree9'
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    rng=random.Random(219999);records=[]
    for case in range(80):
        n=12 if case<72 else 70
        radius=(1+case%4) if case<64 else (9 if case<72 else 2)
        prefix=(1+case%12) if case<72 else (63,64,65,70)[case%4]
        need=1+case%min(radius+2,5);neutral=case%2==0
        target=radius if neutral else radius+1;bw=2
        space=[0,2,7,61,63,64,65,66,100,125,126,127]
        blocked=[sum(1<<j for j in rng.sample(space,rng.randint(0,9))) for _ in range(n)]
        if radius==9:blocked=[sum(1<<space[(i+j)%9] for j in range(9)) for i in range(n)]
        compat=[0]*n
        for i,j in combinations(range(n),2):
            if rng.random()<(1.0 if radius==9 else .78):
                compat[i]|=1<<j;compat[j]|=1<<i
        expected=[];tested=0
        for chosen in combinations(range(n),target):
            tested+=1
            if sum(i<prefix for i in chosen)<need:continue
            if any(not ((compat[i]>>j)&1) for i,j in combinations(chosen,2)):continue
            union=0
            for i in chosen:union|=blocked[i]
            if union.bit_count()<=radius:
                expected.append((list(chosen),union.bit_count()))
                if not neutral:break
        cw=(n+63)//64;mask=(1<<64)-1;lines=[f'{n} {bw} {radius}']
        for i in range(n):
            vals=[(blocked[i]>>(64*w))&mask for w in range(bw)]+[(compat[i]>>(64*w))&mask for w in range(cw)]
            lines.append(' '.join(format(v,'x') for v in vals))
        lines.append(' '.join([str(need)]*n));data='\n'.join(lines)+'\n'
        options=['--root-prefix',str(prefix),'--anchor-bounds',str(prefix)]
        if neutral:options+=['--neutral']
        if case%3:options+=['--subset']
        results=[]
        for executable,flags in [(binary,options+['--budget-bitsets'])]+([(old,options)] if radius<=9 else []):
            p=subprocess.run([str(executable),'5']+flags,input=data,text=True,capture_output=True,check=True,timeout=8)
            r=json.loads(p.stdout);assert r['status'] in ('witness','exhausted'),r
            if neutral:
                assert r['neutral']==[x for x,b in expected if b==radius]
                assert r['improving']==[x for x,b in expected if b<radius]
            else:
                assert (r['status']=='witness')==bool(expected)
                if expected:assert r['chosen']==expected[0][0]
            if r['status']=='exhausted':assert r['nodes_started']==r['nodes_completed']
            results.append(r)
        records.append(dict(case=case,n=n,radius=radius,neutral=neutral,subset=bool(case%3),
                            tested_subsets=tested,positive=len(expected),filters=results[0]['bitset_filters']))
    malformed='1 1 1\n3ff 0\n'
    r=subprocess.run([str(binary),'1','--budget-bitsets'],input=malformed,text=True,capture_output=True)
    assert r.returncode==1 and 'at most nine blockers' in r.stderr
    result=dict(source_sha256=sha(__file__),kernel_sha256=sha(binary),kernel_source_sha256=sha(here/'exchange_dfs.cpp'),
                previous_kernel_sha256=sha(old),cases=records,rejected_ten_blocker_input=True)
    output.write_text(json.dumps(result,indent=2)+'\n')
    print('cases',len(records),'subsets',sum(r['tested_subsets'] for r in records),
          'positive',sum(r['positive'] for r in records),'filters',sum(r['filters'] for r in records))


if __name__=='__main__':main()
