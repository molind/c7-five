"""Replay every relative placement using tables built from dense coordinate sums.

No cyclic bit rotation or search-script import is used. For each right point b,
table[b] contains translations t with b+t outside the left slice's neighborhood.
Intersections cover all 2401 translations, including those with no saved edge.
"""
import argparse
from itertools import permutations, product
import hashlib
import json
from pathlib import Path

import numpy as np


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    r = json.loads(args.input.read_text())
    assert r['status'] in ('complete', 'candidate_found')
    sp = Path(r['input'])
    assert hashlib.sha256(sp.read_bytes()).hexdigest() == r['input_sha256']
    source = json.loads(sp.read_text())
    base = [np.array(sl, dtype=np.int16) for sl in source['slices']]
    parents = source['parents']
    assert all(len(row['slices']) == 7 for row in parents)
    assert all(type(v) is int and 0 <= v < len(base) for row in parents for v in row['slices'])
    owners = [[(pi, pos) for pi, row in enumerate(parents) for pos, v in enumerate(row['slices']) if v == index]
              for index in range(len(base))]
    assert all(owners)
    points = np.array(list(product(range(7), repeat=4)), dtype=np.int16)
    strides = np.array([343, 49, 7, 1], dtype=np.int16)
    addition = np.zeros((2401, 2401), dtype=np.int16)
    for axis in range(4):
        addition += ((points[:, None, axis]+points[None, :, axis]) % 7)*strides[axis]
    tables = []
    for sl in base:
        delta = (points[:, None, :]-sl[None, :, :]) % 7
        allowed = ~np.any(np.all((delta == 0) | (delta == 1) | (delta == 6), axis=2), axis=1)
        packed = np.packbits(allowed[addition], axis=1, bitorder='little')
        tables.append([int.from_bytes(row.tobytes(), 'little') for row in packed])
    transforms = [(perm, signs) for perm in permutations(range(4)) for signs in product((-1, 1), repeat=4)]
    assert [t['index'] for t in r['transforms']] == list(range(r['count']))
    assert 1 <= r['count'] <= 384
    saved = [{} for _ in range(r['count'])]
    for placement in r['placements']:
        ti, pi = placement['transform'], placement['parent']
        shift = placement['shift']
        assert 0 <= ti < r['count'] and 0 <= pi < len(parents)
        assert len(shift) == 4 and all(type(x) is int and 0 <= x < 7 for x in shift)
        si = int(np.array(shift) @ strides)
        key = (pi, si)
        assert key not in saved[ti]
        saved[ti][key] = placement['cross_edges']
    checked_pairs = edges = 0
    for ti, (perm, signs) in enumerate(transforms[:r['count']]):
        actual = {}
        positive = 0
        for right, sl in enumerate(base):
            transformed = (sl[:, perm]*np.array(signs)) % 7
            ids = list(map(int, transformed @ strides))
            for left, table in enumerate(tables):
                result = (1 << 2401)-1
                for v in ids:
                    result &= table[v]
                    if result == 0:
                        break
                checked_pairs += 1
                positive += bool(result)
                while result:
                    bit = result & -result
                    result -= bit
                    si = bit.bit_length()-1
                    for pi, position in owners[right]:
                        actual.setdefault((pi, si), []).append([left, position])
        actual = {key: sorted(value) for key, value in actual.items()}
        assert actual == saved[ti], ('placement coverage mismatch', ti)
        edge_count = sum(map(len, actual.values()))
        assert r['transforms'][ti] == dict(index=ti, slice_pairs=len(base)**2,
            positive_slice_pairs=positive, placements=len(actual), cross_edges=edge_count)
        edges += edge_count
        if ti % 64 == 63:
            print(json.dumps(dict(transforms_checked=ti+1)), flush=True)
    result = dict(input_sha256=hashlib.sha256(args.input.read_bytes()).hexdigest(),
        checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        transforms=r['count'], direct_coordinate_sum_tables=len(base), parent_cycles=len(parents),
        slice_pairs=checked_pairs, compatible_relative_slice_placements=edges,
        complete_relative_placement_coverage=True,
        scope='All relative automorphisms in the recorded transform interval for every supplied seed slice. Cross edges count parent occurrences, including shared slices.')
    args.output.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
