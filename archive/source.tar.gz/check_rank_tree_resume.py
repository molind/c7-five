"""Replay a continued tree and check that it preserves its saved proof prefix."""
import argparse
import hashlib
import json
from pathlib import Path

from search_rank_tree import replay


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--before', type=Path, required=True)
    parser.add_argument('--after', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    before, after = [json.loads(p.read_text()) for p in (args.before, args.after)]
    assert before['status'] == 'incomplete' and after['status'] in ('incomplete', 'closed', 'candidate_found')
    assert before['input'] == after['input'] and before['input_sha256'] == after['input_sha256']
    assert before['full_target'] == after['full_target']
    expected = dict(file=str(args.before), sha256=hashlib.sha256(args.before.read_bytes()).hexdigest(),
                    source_sha256=before['source_sha256'], elapsed_seconds=before['elapsed_seconds'],
                    processed_nodes=before['processed_nodes'])
    assert after['run_history'] == before.get('run_history', [])+[expected]
    assert len(after['nodes']) >= len(before['nodes'])
    unchanged, extended = 0, 0
    for old in before['nodes']:
        new = after['nodes'][old['id']]
        if old['status'] in ('pending', 'unresolved'):
            assert all(new[k] == old[k] for k in ('id', 'pool', 'selected'))
            assert new['rounds'][:len(old['rounds'])] == old['rounds']
            assert set(new['remaining_pool']) <= set(old['remaining_pool'])
            extended += new != old
        else:
            assert new == old
            unchanged += 1
    checked = replay(after)
    result = dict(before=expected, after_sha256=hashlib.sha256(args.after.read_bytes()).hexdigest(),
                  preserved_finished_nodes=unchanged, extended_open_leaves=extended, verification=checked,
                  source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    args.output.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
