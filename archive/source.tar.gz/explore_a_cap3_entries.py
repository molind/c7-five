"""Bounded hot/cold excursions from the verified outside-support E3 entries."""
import argparse
import gzip
from itertools import combinations, product
import hashlib
import json
from pathlib import Path
import random
import struct
import time

from search_low_conflict import WORDS, TOKENS, family_start, independent_target, successors

HERE = Path(__file__).resolve().parent


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input',type=Path,default=HERE/'family-a-cap3-boundary-entries.json')
    parser.add_argument('--output',type=Path,default=HERE/'family-a-cap3-boundary-excursions.json')
    parser.add_argument('--hot-steps',type=int,default=50)
    parser.add_argument('--cold-steps',type=int,default=150)
    parser.add_argument('--entry-seconds',type=float,default=5)
    parser.add_argument('--seconds',type=float,default=60)
    parser.add_argument('--entry-offset',type=int,default=0)
    parser.add_argument('--entries',type=int,default=100000)
    args = parser.parse_args()
    if min(args.hot_steps,args.cold_steps,args.entry_offset)<0 or min(args.entry_seconds,args.seconds,args.entries)<=0 or args.hot_steps+args.cold_steps==0:
        parser.error('Positive budgets/count and nonnegative phases/offset required')
    source = args.input
    data = json.loads(source.read_text())
    archive = Path(data.get('source_archive',str(HERE/'family-a-cap2-complete.jsonl.gz')))
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == data['source_archive_sha256']
    with gzip.open(archive,'rt') as stream:
        header = json.loads(next(stream))
        assert header['status']=='exhausted' and header['count']==29336
        assert header['states_sha256']=='ed82aacd25dc5a8fa3a63121cfe481141255bc31f4432dbba82ad5c6ccef492b'
        known_cap2={struct.pack('<368H',*(int(w,7) for w in json.loads(line)['words'].split())) for line in stream}
    assert len(known_cap2)==29336
    original, known = family_start('A')
    assert {int(w,7) for w in data['start_words']} == original
    adjacency = [tuple(2401*a+343*b+49*c+7*d+e
        for a,b,c,d,e in product(*[((x-1)%7,x,(x+1)%7) for x in w])
        if 2401*a+343*b+49*c+7*d+e != v) for v,w in enumerate(WORDS)]
    results = []
    began = time.monotonic()
    for entry in data['entries'][args.entry_offset:args.entry_offset+args.entries]:
        if time.monotonic()-began > args.seconds:
            break
        if entry['status']!='verified_entry':
            continue
        state = frozenset(int(w,7) for w in entry['final_words'])
        rng = random.Random(2026092010 + entry['source_index'])
        path, examined, independent = [], 0, None
        status = 'step_limit'
        entry_began = time.monotonic()
        for step in range(args.hot_steps+args.cold_steps):
            if time.monotonic()-entry_began>args.entry_seconds or time.monotonic()-began>args.seconds:
                status='timeout'
                break
            choice, degree, best = None, 0, None
            for target, energy, removed, added, conflicts in successors(state, adjacency, 3):
                examined += 1
                if examined % 1024 == 0 and (time.monotonic()-entry_began > args.entry_seconds or time.monotonic()-began > args.seconds):
                    status = 'timeout'
                    break
                independent = independent_target(target, conflicts, known)
                if independent is not None:
                    choice = target, energy, removed, added
                    status = 'independent368' if energy == 0 else 'outside_A367'
                    break
                if energy<=2 and struct.pack('<368H',*sorted(target)) not in known_cap2:
                    choice = target, energy, removed, added
                    status = 'new_cap2_component'
                    break
                if step >= args.hot_steps:
                    if best is not None and energy > best:
                        continue
                    if best is None or energy < best:
                        best, degree = energy, 0
                degree += 1
                if rng.randrange(degree) == 0:
                    choice = target, energy, removed, added
            if status == 'timeout':
                break
            assert choice is not None
            state, energy, removed, added = choice
            path.append(dict(removed=TOKENS[removed], added=TOKENS[added], energy=energy))
            if independent is not None or status=='new_cap2_component':
                break
            if step >= args.hot_steps and energy == 1:
                status = 'returned_A_E1'
                break
        replay = {int(w,7) for w in entry['final_words']}
        conflict = lambda a,b: all((x-y)%7 in (0,1,6) for x,y in zip(WORDS[a],WORDS[b]))
        energy = sum(conflict(a,b) for a,b in combinations(replay,2))
        assert energy == 3
        for move in path:
            removed, added = int(move['removed'],7), int(move['added'],7)
            assert removed in replay and added not in replay
            replay.remove(removed)
            energy += sum(conflict(added,v)-conflict(removed,v) for v in replay)
            replay.add(added)
            assert len(replay) == 368 and energy == move['energy'] and 0 <= energy <= 3
        assert replay == state
        if independent is not None:
            assert len(independent) in (367,368) and independent not in known
            assert not any(conflict(a,b) for a,b in combinations(independent,2))
        if status=='new_cap2_component':
            assert energy<=2 and struct.pack('<368H',*sorted(state)) not in known_cap2
        results.append(dict(source_index=entry['source_index'], seed=2026092010+entry['source_index'],
                            status=status, steps=len(path), examined=examined, path=path,
                            final_energy=energy,
                            new_cap2_words=[TOKENS[v] for v in sorted(state)] if status=='new_cap2_component' else None,
                            independent_words=None if independent is None else [TOKENS[v] for v in sorted(independent)]))
        if independent is not None or status=='new_cap2_component':
            break
    report = dict(source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                  parameters={k:str(v) if isinstance(v,Path) else v for k,v in vars(args).items()},
                  results=results, total_seconds=time.monotonic()-began,
                  scope='Uniform hot moves followed by minimum-energy moves within explicit step/time guards. An E<=2 neighbor outside the complete known cap2 component is an intermediate success, not an independent367/368 result. Partial scans discarded. No exhaustive exclusion.')
    args.output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps([{k:v for k,v in r.items() if k not in ('path','independent_words','new_cap2_words')} for r in results]))


if __name__ == '__main__':
    main()
