"""Compare the exact C++ joint requirements with direct Python antichains."""
import gzip,hashlib,json,subprocess
from itertools import product
from pathlib import Path
import numpy as np
from profile_joint_critical_unions import minimal


def main():
    assert __debug__
    r=Path('research/c7');out=r/'joint-critical-union-native-verification-sep22.json';assert not out.exists();deps={}
    def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
    profile_path=r/'joint-critical-union-profile-sep22.json';profile=json.loads(profile_path.read_text());deps[str(profile_path)]=sha(profile_path)
    assert profile['source_sha256']==sha(r/'profile_joint_critical_unions.py')
    assert all(sha(p)==h for p,h in profile['dependencies'].items());deps.update(profile['dependencies'])
    coords=np.array(list(product(range(7),repeat=5)),dtype=np.int16);loaded={};rows=[]
    for record in profile['rows']:
        name=record['manifest'];index=record['state'];radius=record['radius']
        if name not in loaded:
            m=json.loads((r/name).read_text())
            with gzip.open(m['source'],'rt') as f:next(f);loaded[name]=[set(json.loads(x)) for x in f]
        states=loaded[name];state=states[index];old=sorted(state);parents=[];frozen=set()
        for j,other in enumerate(states[:index]):
            if len(state-other)==len(other-state)==1:
                x,=state-other;y,=other-state;parents.append((j,y));frozen.add(x)
        delta=(coords[:,None,:]-coords[np.array(old)[None,:],:])%7;bad=np.all((delta==0)|(delta==1)|(delta==6),axis=2);degree=bad.sum(axis=1)
        chosen=np.zeros(16807,dtype=bool);chosen[old]=True;pool=(degree>=2)&(degree<=radius)&~chosen
        if frozen:pool&=~np.any(bad[:,[old.index(x) for x in frozen]],axis=1)
        ids=np.flatnonzero(pool);bsets=[int.from_bytes(row.tobytes(),'little') for row in np.packbits(bad[ids],axis=1,bitorder='little')]
        assert len(ids)==record['pool'];conditions=[];encoded=[f'{radius} {len(parents)}']
        for j,y in parents:
            diff=(coords[ids]-coords[y])%7;flags=np.all((diff==0)|(diff==1)|(diff==6),axis=1);bs=[b for b,flag in zip(bsets,flags) if flag]
            conditions.append(minimal(bs));encoded.append(str(len(bs)))
            for b in bs:
                points=[i for i in range(367) if b>>i&1];encoded.append(str(len(points))+' '+' '.join(map(str,points)))
        current=[0]
        for condition in sorted(conditions,key=len):current=minimal({a|b for a in current for b in condition if (a|b).bit_count()<=radius})
        assert len(current)==record['joint_minimal']
        body='\n'.join(encoded)+'\n';p=subprocess.run([str(r/'joint_requirements_harness')],input=body,text=True,capture_output=True,check=True);native=json.loads(p.stdout)
        assert native['complete'];got={sum(1<<v for v in b) for b in native['sets']};assert len(got)==len(native['sets']) and got==set(current)
        rows.append(dict(manifest=name,state=index,radius=radius,joint_minimal=len(got),minimum_size=min(map(int.bit_count,got),default=None),input_sha256=hashlib.sha256(body.encode()).hexdigest(),native_sha256=hashlib.sha256(p.stdout.encode()).hexdigest(),stderr=p.stderr))
    for n in ['profile_joint_critical_unions.py','scan_component_atomic7_incremental_joint.cpp','joint_requirements_harness.cpp','joint_requirements_harness']:deps[str(r/n)]=sha(r/n)
    d=dict(passed=True,checker_sha256=sha(__file__),dependencies=deps,rows=rows,scope='Reconstructed actual C7 pools/critical conditions and compared every minimal joint union in C++ and Python for9 sampled states. Generic helper is tested at radii7/9; this is not a completed native state traversal.')
    out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(rows))


if __name__=='__main__':main()
