"""Probe include/exclude branches with newly computed projected rank cuts.

The input is a replayable target-preserving pruning chain. Every child admits
all remaining compatible words, and has its own checked integer cover.
Numerical failures and bounded graph-search timeouts remain unresolved.
"""
import argparse
from collections import Counter
import hashlib
from itertools import combinations
import json
from pathlib import Path
import time

from check_two_slice_covers import HERE, WORDS, closed, conflict
from check_cylinder_covers import check_entries
from prune_cylinder_cover import replay as replay_pruning

CAPACITIES = [1, 3, 10, 35, 122, 427]


def bound(pool, cache, seconds, cubic_ms):
    import numpy as np
    from scipy.optimize import linprog
    from cylinder_bounds import certify
    from lift_cylinder_ranks import lifted_constraints
    from probe_cubic_ranks import probe
    began = time.monotonic()
    members, desc, matrix, stats = lifted_constraints(pool)
    strengthened = 0
    for row in desc:
        if not row.get('layer_rank_bound'):
            continue
        projection = tuple(row['projection'])
        if projection not in cache:
            cache[projection] = dict(projection=list(projection), upper=row['capacity'],
                                     result=probe(projection, row['capacity'], cubic_ms))
        recorded = cache[projection]
        assert recorded['upper'] == row['capacity']
        r = recorded['result']
        if r['status'] == 'exhausted' and r['best_size'] < row['capacity']:
            row.pop('layer_rank_bound')
            row.update(capacity=r['best_size'], cubic_rank=True)
            strengthened += 1
    built = time.monotonic()
    solved = linprog(-np.ones(len(pool)), A_ub=matrix, b_ub=[d['capacity'] for d in desc],
                     bounds=(0, None), method='highs-ipm', options={'time_limit':seconds})
    result = dict(status=int(solved.status), message=solved.message, pool=pool,
                  build_seconds=built-began, solve_seconds=time.monotonic()-built,
                  stats=stats | {'exact_cubic_rows':strengthened})
    if solved.success:
        result['certificate'] = certify(pool, members, desc, -solved.ineqlin.marginals)
        check_entries(result['certificate'], pool, CAPACITIES)
        result['floating_bound'] = float(-solved.fun)
        result['primal'] = [[v, float(x)] for v, x in zip(pool, solved.x) if x > 1e-8]
    return result


def characterize(row, fixed, full_target):
    if 'certificate' not in row:
        row['excludes_target'] = False
        return None
    total, den = check_entries(row['certificate'], row['pool'], CAPACITIES)
    row['full_upper'] = len(fixed)+total//den
    row['excludes_target'] = total < (full_target-len(fixed))*den
    if all(abs(x-round(x)) < 1e-7 for v, x in row['primal']):
        chosen = sorted(fixed+[v for v, x in row['primal'] if x > .5])
        assert len(chosen) == len(set(chosen))
        assert all(not conflict(a, b) for a, b in combinations(chosen, 2))
        if len(chosen) >= 367:
            return dict(words=[''.join(map(str, WORDS[v])) for v in chosen], size=len(chosen),
                        verified_pairs=len(chosen)*(len(chosen)-1)//2)
    return None


def verify(report):
    path = Path(report['input'])
    assert hashlib.sha256(path.read_bytes()).hexdigest() == report['input_sha256']
    source = json.loads(path.read_text())
    replay_pruning(source)
    assert not source['excludes_target']
    pool, fixed, target = source['final_pool'], source['fixed'], source['full_target']
    assert report['full_target'] == target
    inherited_forbidden = set()
    for prior in report.get('exclude_proofs', []):
        prior_path = Path(prior['file'])
        assert hashlib.sha256(prior_path.read_bytes()).hexdigest() == prior['sha256']
        prior_report = json.loads(prior_path.read_text())
        assert prior_report['input_sha256'] == report['input_sha256']
        prior_check = verify(prior_report)
        assert not prior_check['excludes_target'] and prior_check['full_target'] == target
        inherited_forbidden.update(prior_check['forbidden_vertices'])
    pool = sorted(set(pool)-inherited_forbidden)
    checked = 0

    def verify_row(row, expected_pool, additions):
        nonlocal checked
        assert row['pool'] == expected_pool
        if 'certificate' not in row:
            assert not row['excludes_target']
            return False
        total, den = check_entries(row['certificate'], expected_pool, CAPACITIES)
        excluded = total < (target-len(fixed)-len(additions))*den
        assert row['excludes_target'] == excluded
        assert row['full_upper'] == len(fixed)+len(additions)+total//den
        checked += 1
        return excluded

    root_closed = verify_row(report['root'], pool, [])
    conditions = {}
    for row in report['results']:
        vertex, action = row['vertex'], row['action']
        assert vertex in pool and action in ('include', 'exclude')
        assert (vertex, action) not in conditions
        remaining = sorted(set(pool)-set(closed(vertex))) if action == 'include' else [v for v in pool if v != vertex]
        conditions[vertex, action] = verify_row(row, remaining, [vertex] if action == 'include' else [])
    excluded = root_closed or any(conditions.get((v, 'include')) and conditions.get((v, 'exclude')) for v in pool)
    assert report['excludes_target'] == excluded
    for c in report['candidates']:
        words = [int(w, 7) for w in c['words']]
        assert len(words) == len(set(words)) == c['size'] and set(fixed) <= set(words)
        assert set(words) <= set(fixed) | set(pool)
        assert all(not conflict(a, b) for a, b in combinations(words, 2))
        assert c['verified_pairs'] == len(words)*(len(words)-1)//2
    return dict(checked_covers=checked, conditional_branches=len(conditions),
                excluded_include_branches=sum(ok for (v, a), ok in conditions.items() if a == 'include'),
                excluded_exclude_branches=sum(ok for (v, a), ok in conditions.items() if a == 'exclude'),
                inherited_forbidden_vertices=sorted(inherited_forbidden),
                forbidden_vertices=sorted(inherited_forbidden | {v for (v, a), ok in conditions.items() if a == 'include' and ok}),
                full_target=target, excludes_target=excluded)


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--variables', type=int, default=6)
    p.add_argument('--seconds', type=float, default=10)
    p.add_argument('--cubic-ms', type=int, default=50)
    p.add_argument('--verify', action='store_true')
    p.add_argument('--exclude-proofs', type=Path, nargs='*', default=[])
    args = p.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    if args.variables < 1 or args.seconds <= 0 or args.cubic_ms < 1:
        p.error('Positive limits required')
    source = json.loads(args.input.read_text())
    if args.verify:
        result = verify(source)
        result['input_sha256'] = hashlib.sha256(args.input.read_bytes()).hexdigest()
        args.output.write_text(json.dumps(result, indent=2)+'\n')
        print(json.dumps(result), flush=True)
        return
    replay_pruning(source)
    assert not source['excludes_target']
    pool, fixed, target = source['final_pool'], source['fixed'], source['full_target']
    inherited_forbidden = set()
    exclude_proofs = []
    for prior_path in args.exclude_proofs:
        prior_report = json.loads(prior_path.read_text())
        assert prior_report['input_sha256'] == hashlib.sha256(args.input.read_bytes()).hexdigest()
        checked = verify(prior_report)
        assert not checked['excludes_target'] and checked['full_target'] == target
        inherited_forbidden.update(checked['forbidden_vertices'])
        exclude_proofs.append(dict(file=str(prior_path), sha256=hashlib.sha256(prior_path.read_bytes()).hexdigest()))
    pool = sorted(set(pool)-inherited_forbidden)
    cache_path = HERE/'three-slice-screen-sep21/cubic-probes.json'
    cache = {tuple(r['projection']): r for r in json.loads(cache_path.read_text())['results']}
    report = dict(status='running', input=str(args.input), full_target=target, results=[], candidates=[],
                  input_sha256=hashlib.sha256(args.input.read_bytes()).hexdigest(),
                  source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  cache_sha256=hashlib.sha256(cache_path.read_bytes()).hexdigest(),
                  excludes_target=False, variables_requested=args.variables, exclude_proofs=exclude_proofs,
                  scope='Separate conditional branches over one target-preserving domain; a pruned include branch forbids only that vertex, not the whole domain.')
    began = time.monotonic()

    def save():
        report['elapsed_seconds'] = time.monotonic()-began
        temp = args.output.with_name(args.output.name+'.tmp')
        temp.write_text(json.dumps(report, indent=2)+'\n')
        temp.replace(args.output)

    report['root'] = bound(pool, cache, args.seconds, args.cubic_ms)
    candidate = characterize(report['root'], fixed, target)
    if candidate:
        report['candidates'].append(candidate | {'step':0})
    report['excludes_target'] = report['root']['excludes_target']
    save()
    choices = sorted(((v, x) for v, x in report['root'].get('primal', []) if 1e-7 < x < 1-1e-7),
                     key=lambda vx: (abs(vx[1]-.5), vx[0]))[:args.variables]
    report['choices'] = choices
    if not report['excludes_target'] and not any(c['size'] >= target for c in report['candidates']):
        for vertex, fraction in choices:
            both = True
            for action in ('include', 'exclude'):
                child = sorted(set(pool)-set(closed(vertex))) if action == 'include' else [v for v in pool if v != vertex]
                row = bound(child, cache, args.seconds, args.cubic_ms)
                row.update(vertex=vertex, action=action, root_fraction=fraction)
                candidate = characterize(row, fixed+([vertex] if action == 'include' else []), target)
                report['results'].append(row)
                if candidate and not any(c['words'] == candidate['words'] for c in report['candidates']):
                    report['candidates'].append(candidate | {'step':len(report['results'])})
                both &= row['excludes_target']
                print(json.dumps(dict(vertex=vertex, action=action, pool=len(child), status=row['status'],
                                      full_upper=row.get('full_upper'), excludes_target=row['excludes_target'])), flush=True)
                save()
                if any(c['size'] >= target for c in report['candidates']):
                    break
            report['excludes_target'] |= both and not any(c['size'] >= target for c in report['candidates'])
            if report['excludes_target'] or any(c['size'] >= target for c in report['candidates']):
                break
    report['status'] = 'complete'
    report['cache_statuses'] = dict(Counter(r['result']['status'] for r in cache.values()))
    report['verification'] = verify(report)
    save()
    print(json.dumps(report['verification'] | {'candidates':len(report['candidates'])}), flush=True)


if __name__ == '__main__':
    main()
