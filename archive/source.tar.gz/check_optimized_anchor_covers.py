"""Exact replay of saved LP certificates, with an independent U2 reconstruction."""
from pathlib import Path
from itertools import product
from fractions import Fraction
import contextlib,io,json,runpy,hashlib
from check_one_core_covers import check
P=Path(__file__).parent
with contextlib.redirect_stdout(io.StringIO()):c=runpy.run_path(str(P/'shared_u2_compact_replay.py'))
# Build the domain again from coordinate incidence masks of the public core.
coord=[[0]*7 for _ in range(5)]
for i,w in enumerate(c['core']):
    for k,x in enumerate(w):coord[k][x]|=1<<i
u2=set()
for w in product(range(7),repeat=5):
    mask=(1<<308)-1
    for k,x in enumerate(w):mask&=coord[k][(x-1)%7]|coord[k][x]|coord[k][(x+1)%7]
    if mask.bit_count()<=2:u2.add(w)
assert u2==c['U2']
report=[]
for path in sorted(P.glob('anchor-?????-lp.json')):
    r=json.loads(path.read_text())
    if r['stage']!='complete':continue
    a=tuple(map(int,r['anchor']))
    neighbors=set(product(*[((x-1)%7,x,(x+1)%7) for x in a]))
    allowed=u2-neighbors
    digest=hashlib.sha256(' '.join(''.join(map(str,w)) for w in sorted(allowed)).encode()).hexdigest()
    assert digest==r['domain_sha256'] and len(allowed)==r['vertices']
    den=r['denominator']
    weights=[dict(origin=x['origin'],weight=str(Fraction(x['units'],den))) for x in r['cover']]
    total=check(weights,allowed,Fraction(368))
    assert total==Fraction(r['cover_units'],den)
    # The deliberately emptied cover must fail on this nonempty domain.
    try:check([],allowed,Fraction(367))
    except AssertionError:pass
    else:raise AssertionError('Empty certificate accepted')
    dual={tuple(x['word']):x['units'] for x in r['dual']}
    assert set(dual)<=allowed and all(type(v)is int and v>=0 for v in dual.values())
    # Expand all boxes, not only matrix columns retained by the LP generator.
    peak=max(sum(dual.get(w,0) for w in product(*[(x,(x+1)%7) for x in origin])) for origin in product(range(7),repeat=5))
    assert peak<=den and sum(dual.values())==r['dual_units']
    report.append(dict(anchor=r['anchor'],vertices=len(allowed),total=str(total),below367=total<367,dual_total=str(Fraction(sum(dual.values()),den)),all_16807_dual_boxes_checked=True))
(P/'optimized-anchor-cover-verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report),flush=True)
