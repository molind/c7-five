"""Exercise the terminal include path with the known 367-word D witness.

This is a positive control, not a new construction: the goal remains 368.
The fixture includes every seed word through valid binary branch decisions,
leaves all exclude siblings open, then resumes at a leaf needing zero words.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

from check_two_slice_covers import HERE, closed
from search_rank_tree import replay


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output-dir', type=Path, required=True)
    args = p.parse_args()
    args.output_dir.mkdir(exist_ok=False)
    original = json.loads((HERE/'three-slice-prune30-adaptive-sep21.json').read_text())
    seed = sorted(int(w, 7) for w in (HERE/'family-d-seed-words.txt').read_text().split())
    source = {k: original[k] for k in ('axis', 'start', 'width', 'fixed', 'initial_pool')}
    source.update(full_target=367, residual_target=367-len(source['fixed']), rounds=[],
                  final_pool=source['initial_pool'], excludes_target=False)
    source_path = args.output_dir/'source.json'
    source_path.write_text(json.dumps(source)+'\n')
    report = dict(input=str(source_path), input_sha256=hashlib.sha256(source_path.read_bytes()).hexdigest(),
                  full_target=367, candidates=[], excludes_target=False, status='incomplete',
                  elapsed_seconds=0, processed_nodes=0, nodes=[],
                  source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())

    def node(pool, selected):
        n = dict(id=len(report['nodes']), pool=pool, selected=selected, remaining_pool=pool,
                 rounds=[], status='pending')
        report['nodes'].append(n)
        return n

    current = node(source['final_pool'], [])
    for vertex in sorted(set(seed)-set(source['fixed'])):
        pool, selected = current['remaining_pool'], current['selected']
        assert vertex in pool
        take = node(sorted(set(pool)-set(closed(vertex))), sorted(selected+[vertex]))
        omit = node([v for v in pool if v != vertex], selected)
        current.update(status='split', split_vertex=vertex,
                       children=dict(include=take['id'], exclude=omit['id']))
        current = take
    assert not current['remaining_pool'] and len(current['selected'])+len(source['fixed']) == 367
    before = replay(report)
    fixture = args.output_dir/'tree.json'
    fixture.write_text(json.dumps(report)+'\n')
    result_path = args.output_dir/'resumed.json'
    subprocess.run([sys.executable, str(HERE/'search_rank_tree.py'), '--input', str(fixture),
                    '--output', str(result_path), '--resume', '--node-limit', '1', '--budget', '10'], check=True)
    result = json.loads(result_path.read_text())
    after = replay(result)
    assert result['status'] == 'candidate_found' and not result['excludes_target']
    assert len(result['candidates']) == 1
    candidate = result['candidates'][0]
    assert candidate['size'] == 367 and candidate['verified_pairs'] == 67161
    assert [int(w, 7) for w in candidate['words']] == seed
    assert all(result['nodes'][n['id']] == n for n in report['nodes'] if n['id'] != current['id'])
    summary = dict(before=before, after=after, known_seed_recovered=True, numerical_solver_needed=False,
                   open_siblings_preserved=True, target=367, production_goal=368,
                   source_sha256=hashlib.sha256((HERE/'search_rank_tree.py').read_bytes()).hexdigest())
    (args.output_dir/'verification.json').write_text(json.dumps(summary, indent=2)+'\n')
    print(json.dumps(summary), flush=True)


if __name__ == '__main__':
    main()
