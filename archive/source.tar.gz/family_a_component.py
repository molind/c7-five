"""Rebuild the entire one-word component without assuming a fixed core."""
from collections import deque
import hashlib
from itertools import combinations, product
import json
from pathlib import Path
import struct

HERE = Path(__file__).parent
WORDS = list(product(range(7), repeat=5))
TOKENS = [''.join(map(str, w)) for w in WORDS]


def component(seed):
    states, lookup, queue = [seed], {seed: 0}, deque([0])
    parent = [None]
    edges = []
    while queue:
        si = queue.popleft()
        state = states[si]
        occupied = set(state)
        # Every closed-neighborhood conflict in the full 7^5 domain.
        blockers = [0]*len(WORDS)
        for bit, wi in enumerate(state):
            for a, b, c, d, e in product(*[((x-1) % 7, x, (x+1) % 7) for x in WORDS[wi]]):
                blockers[2401*a + 343*b + 49*c + 7*d + e] |= 1 << bit
        for wi, mask in enumerate(blockers):
            if wi in occupied:
                continue
            assert mask, 'Free insertion would already improve this state'
            if mask.bit_count() == 1:
                old = state[mask.bit_length()-1]
                target = tuple(sorted((occupied-{old}) | {wi}))
                if target not in lookup:
                    lookup[target] = len(states)
                    states.append(target)
                    parent.append(dict(state=si, removed=TOKENS[old], added=TOKENS[wi]))
                    queue.append(lookup[target])
                edges.append((si, lookup[target]))
    return states, parent, edges


if __name__ == '__main__':
    if not __debug__:
        raise RuntimeError('Run without -O')
    tokens = (HERE/'exchange-dfs-family-a-words.txt').read_text().split()
    assert hashlib.sha256(' '.join(tokens).encode()).hexdigest() == 'dc27c8a0ff3bf27bbd55ea95398848bcb7ed3b871e5ec4c7d7f78cd6beeeefe1'
    seed = tuple(int(w, 7) for w in tokens)
    assert len(set(seed)) == 367 and tuple(sorted(seed)) == seed
    states, parent, edges = component(seed)
    assert len(states) == 7
    assert all((b, a) in edges for a, b in edges)
    packed = [struct.pack('<367H', *s) for s in states]
    digest = hashlib.sha256(b''.join(sorted(packed))).hexdigest()
    assert digest == '154ccb0b011225cf78bf2836141e1e926b6333b6806a26e910e5f192ba5943f0'
    rows = []
    for i, s in enumerate(states):
        assert all(any((x-y) % 7 in (2, 3, 4, 5) for x, y in zip(WORDS[a], WORDS[b]))
                   for a, b in combinations(s, 2))
        words = ' '.join(TOKENS[j] for j in s)
        file = HERE/f'family-a-state-{i}-words.txt'
        file.write_text(words+'\n')
        rows.append(dict(state=i, sha256=hashlib.sha256(words.encode()).hexdigest(),
                         parent=parent[i], words_file=str(file)))
    report = dict(states=rows, component_sha256=digest, directed_edges=edges,
                  method='Full-domain closed-neighborhood BFS; no fixed-core restriction',
                  pair_checks_per_state=67161)
    (HERE/'family-a-component.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report, indent=2))
