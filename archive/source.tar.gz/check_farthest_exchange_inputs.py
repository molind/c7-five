"""Rebuild new pinned exchange inputs using dense coordinate comparisons.

This checks full blocker and compatibility matrices and serialized input hashes.
It does not independently replay the native search trees or certify timeouts.
"""
import argparse
import hashlib
from itertools import product
import json
from pathlib import Path
import time

import numpy as np

from check_exchange_dfs import graph_text


def conflict_rows(left,right):
    for start in range(0,len(left),128):
        a=left[start:start+128]
        bad=np.ones((len(a),len(right)),dtype=bool)
        for k in range(5):
            delta=(a[:,k,None]-right[None,:,k])%7
            bad&=(delta==0)|(delta==1)|(delta==6)
        yield start,bad


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',required=True,type=Path)
    p.add_argument('--output',required=True,type=Path)
    a=p.parse_args();assert __debug__ and not a.output.exists()
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    d=json.loads(a.input.read_text());assert d['status']=='bounded_exchange_search_complete' and not d['candidates']
    src=Path(d['input']);assert sha(src)==d['input_sha256']
    bases=json.loads(src.read_text())['bases'];coords=np.array(list(product(range(7),repeat=5)),dtype=np.int16)
    assert d['dummy_blocker_bit']==366
    here=Path(__file__).resolve().parent
    assert sha(here/'exchange_dfs')==d['kernel_sha256'] and sha(here/'exchange_dfs.cpp')==d['kernel_source_sha256']
    assert sha(here/'check_two_edge_exchange_kernel.py')==d['source_sha256']
    out=dict(input=str(a.input),input_sha256=sha(a.input),checker_sha256=sha(__file__),
             scope=__doc__,status='running',rows=[],directed_compatibility_entries=0,
             blocker_coordinate_pairs=0,seed_pair_checks=0)
    began=time.monotonic()
    for bi,base in enumerate(bases):
        queries=[row for row in d['rows'] if row['base']==bi]
        if not queries:continue
        ids=base['words'];assert ids==sorted(set(ids)) and len(ids)==366 and all(type(v) is int and 0<=v<16807 for v in ids)
        selected=coords[ids];blockers=[]
        for start,bad in conflict_rows(coords,selected):
            blockers.extend(int.from_bytes(row.tobytes(),'little') for row in np.packbits(bad,axis=1,bitorder='little'))
        assert len(blockers)==16807
        assert all(blockers[v]==1<<i for i,v in enumerate(ids))
        outside=[v for v in range(16807) if v not in set(ids)]
        assert all(blockers[v] for v in outside)
        out['blocker_coordinate_pairs']+=16807*366
        out['seed_pair_checks']+=66795
        for row in queries:
            radius=row['real_radius'];assert row['kernel_radius']==radius+1 and row['target']==radius+2
            pool=sorted((v for v in outside if blockers[v].bit_count()<=radius),key=lambda v:blockers[v].bit_count())
            assert len(pool)==row['pool'];points=coords[pool];comp=[]
            for start,bad in conflict_rows(points,points):
                comp.extend(int.from_bytes(bits.tobytes(),'little') for bits in np.packbits(~bad,axis=1,bitorder='little'))
            cb=[blockers[v]|(1<<366) for v in pool]
            encoded=graph_text(cb,comp,radius+1,6)
            assert hashlib.sha256(encoded.encode()).hexdigest()==row['graph_sha256']
            result=row['result'];assert result['status'] in ('exhausted','timeout')
            if result['status']=='exhausted':assert result['nodes_started']==result['nodes_completed']
            out['rows'].append(dict(base=bi,radius=radius,pool=len(pool),status=result['status'],graph_sha256=row['graph_sha256']))
            out['directed_compatibility_entries']+=len(pool)**2
            out['seconds']=time.monotonic()-began
            a.output.write_text(json.dumps(out,indent=2)+'\n')
            print(json.dumps(out['rows'][-1]),flush=True)
    assert len(out['rows'])==len(d['rows'])
    out['status']='all_inputs_reconstructed';a.output.write_text(json.dumps(out,indent=2)+'\n')


if __name__=='__main__':main()
