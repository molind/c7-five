"""Replay exact rank covers for previously verified full completion domains."""
import argparse
import hashlib
import json
from pathlib import Path

from check_cylinder_covers import check_entries
from check_orbit_two_new import check_words
from cylinder_bounds import CAPACITY


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--domains', required=True, type=Path)
    p.add_argument('--screen', required=True, type=Path)
    p.add_argument('--output', required=True, type=Path)
    args = p.parse_args()
    if not __debug__:
        raise RuntimeError('Run without -O')
    if args.output.exists():
        raise FileExistsError(args.output)
    domains = json.loads(args.domains.read_text())
    screen = json.loads(args.screen.read_text())
    assert screen['status'] in ('complete', 'candidate_found') and screen['input_sha256'] == sha(args.domains)
    assert domains['status'] == 'prepared' and sha(domains['source']) == domains['source_sha256']
    source = json.loads(Path(domains['source']).read_text())
    prior = json.loads(Path(domains['verification']).read_text())
    assert sha(domains['verification']) == domains['verification_sha256'] and prior['input_sha256'] == sha(domains['source'])
    assert len({j['index'] for j in domains['jobs']}) == len(domains['jobs'])
    jobs = {j['index']:j for j in domains['jobs']}
    if screen['status'] == 'complete':
        assert [r['index'] for r in screen['results']] == [j['index'] for j in domains['jobs'][:screen['limit']]]
    rows = []
    for summary in screen['results']:
        assert sha(summary['file']) == summary['sha256']
        row = json.loads(Path(summary['file']).read_text())
        job = jobs[row['index']]
        original = source['rows'][row['index']]
        assert row['fixed'] == job['fixed'] == original['fixed']
        assert row['pool'] == job['pool'] == original['pool']
        assert row['hint'] == job['hint'] == [original['pool'][i] for i in original['hint']]
        assert row['initial_size'] == job['initial_size'] == original['full_size'] == 367
        assert row['target'] == job['target'] == original['target'] == 368-len(row['fixed'])
        upper = None
        if 'certificate' in row:
            assert row['capacity_sequence'] == CAPACITY
            total, denominator = check_entries(row['certificate'], row['pool'], CAPACITY)
            upper = len(row['fixed'])+total//denominator
            assert upper == row['full_upper'] == summary['full_upper'] >= 367
            assert row['excludes368'] == summary['excludes368'] == (upper < 368)
        else:
            assert summary['full_upper'] is None and not summary['excludes368']
        if 'integral_vertices' in row:
            full = row['integral_vertices']
            assert set(row['fixed']) <= set(full) <= set(row['fixed']) | set(row['pool'])
            check_words([tuple(v//7**i % 7 for i in range(4, -1, -1)) for v in full])
            assert upper is not None and len(full) <= upper
        rows.append(dict(index=row['index'], fixed=len(row['fixed']), pool=len(row['pool']),
                         full_upper=upper, certificate_sha256=sha(summary['file'])))
    for candidate in screen['candidates']:
        summary = next(r for r in screen['results'] if r['index'] == candidate['index'])
        row = json.loads(Path(summary['file']).read_text())
        assert sorted(int(w, 7) for w in candidate['words']) == sorted(row['integral_vertices'])
        assert len(candidate['words']) == candidate['size'] >= 368
    result = dict(domains_sha256=sha(args.domains), screen_sha256=sha(args.screen), checker_sha256=sha(__file__),
                  rows=rows, closed=sum(r['full_upper'] is not None and r['full_upper'] < 368 for r in rows),
                  open=[r['index'] for r in rows if r['full_upper'] is None or r['full_upper'] >= 368],
                  scope='Exact integer cover replay on hash-bound, previously reconstructed full domains; no global bound.')
    args.output.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(dict(checked=len(rows), closed=result['closed'], open=result['open'])), flush=True)


if __name__ == '__main__':
    main()
