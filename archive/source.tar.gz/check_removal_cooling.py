"""Check chosen cooling energies using direct full-domain coordinate comparisons."""
from itertools import product
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    result = json.loads((HERE / 'low-conflict-a-cap3-removal-cycle1000-sep20-08.json').read_text())
    state = {int(w, 7) for w in result['start_words']}
    words = np.array(list(product(range(7), repeat=5)), dtype=np.int16)
    samples = []
    energy = 1
    for step, move in enumerate(result['path']):
        if step in (1000, 1001, 1999, 3000, 3001):
            assert (step // result['phase_steps']) % 2 == 1
            selected = np.array(sorted(state))
            selected_words = words[selected]
            # Closed-neighborhood counts from coordinates, without the search's
            # successor generator or its precomputed adjacency lists.
            counts = np.empty(len(words), dtype=np.int16)
            for lo in range(0, len(words), 256):
                diff = (words[lo:lo+256, None, :] - selected_words[None, :, :]) % 7
                conflicts = np.all((diff == 0) | (diff == 1) | (diff == 6), axis=2)
                counts[lo:lo+256] = conflicts.sum(axis=1)
            degrees = counts[selected] - 1
            assert int(degrees.sum()) == 2 * energy
            highest = int(degrees.max())
            highest_words = selected_words[degrees == highest]
            diff = (words[:, None, :] - highest_words[None, :, :]) % 7
            touches_highest = np.any(np.all((diff == 0) | (diff == 1) | (diff == 6), axis=2), axis=1)
            # Best deletion benefit for a proposed addition is max degree plus
            # one exactly when it conflicts with a maximum-degree old word.
            attainable = energy + counts - highest - touches_highest.astype(np.int16)
            attainable[selected] = 32767
            minimum = int(attainable.min())
            assert move['energy'] == minimum
            samples.append(dict(step=step, source_energy=energy,
                                globally_minimum_energy=minimum, chosen_energy=move['energy']))
        removed, added = int(move['removed'], 7), int(move['added'], 7)
        assert removed in state and added not in state
        state.remove(removed)
        state.add(added)
        energy = move['energy']
    assert len(samples) == 5
    report = dict(samples=samples, passed=True,
                  scope='Five full-domain minimum-energy controls on the accepted removal-proposal cycle path; no search-space exclusion.')
    (HERE / 'removal-cooling-check.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report))


if __name__ == '__main__':
    main()
