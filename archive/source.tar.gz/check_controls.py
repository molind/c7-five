"""Compare both search encodings with exhaustive answers on an embedded C7."""

import contextlib
import io
import itertools
import json
from pathlib import Path

from search_cyclic import search
from search_exchanges import graph_data, solve_radius, verify
from search_regions import solve_region


def main():
    independent = [set(s) for size in range(1, 4)
                   for s in itertools.combinations(range(7), size)
                   if all((a - b) % 7 not in (1, 6)
                          for a, b in itertools.combinations(s, 2))]
    checks = {"exchange": 0, "region": 0, "sat": 0, "unsat": 0}
    for baseline in independent:
        words = [[0, 0, 0, 0, x] for x in sorted(baseline)]
        vertices, ids, blockers, cliques = graph_data(words)
        # The first seven lexicographic vertices induce exactly the cycle C7.
        vertices, blockers = vertices[:7], blockers[:7]
        # Retain only cliques touching that cycle, to keep this test fast.
        cliques = cliques[(cliques < 7).any(axis=1)]
        for radius in range(1, min(len(words), 2) + 1):
            expected = any(len(baseline - target) <= radius
                           and len(target - baseline) >= radius + 1
                           for target in independent)
            with contextlib.redirect_stdout(io.StringIO()):
                result, solution = solve_radius(words, vertices, ids, blockers,
                                                cliques, radius, 1000, 20260915)
            assert result["status"] == ("sat" if expected else "unsat"), result
            if expected:
                verify(solution)
            checks["exchange"] += 1
            checks[result["status"]] += 1
        for mask in range(1 << len(words)):
            removed = {i for i in range(len(words)) if mask & (1 << i)}
            fixed = {ids[i] for i in range(len(words)) if i not in removed}
            expected = any(fixed <= target and len(target) > len(baseline)
                           for target in independent)
            result, solution = solve_region(words, vertices, ids, blockers,
                                            cliques, removed, 1000, 20260915)
            status = result["status"]
            if status == "insufficient_candidates":
                status = "unsat"
            assert status == ("sat" if expected else "unsat"), result
            if expected:
                verify(solution)
            checks["region"] += 1
            checks[status] += 1

    invalid = [
        [[0, 0, 0, 0, 0], [0, 0, 0, 0, 0]],
        [[0, 0, 0, 0, 0], [1, 0, 0, 0, 0]],
        [[False, 0, 0, 0, 0]],
        [[7, 0, 0, 0, 0]],
        [[0, 0, 0, 0]],
    ]
    for words in invalid:
        try:
            verify(words)
        except ValueError:
            continue
        raise AssertionError(f"Validator accepted {words}")
    cyclic, solution = search(7, 1000)
    assert cyclic["status"] == "sat"
    verify(solution["words"])
    report = {"passed": True, "independent_baselines": len(independent),
              "brute_force_comparisons": checks,
              "invalid_inputs_rejected": len(invalid),
              "cyclic_positive_control": cyclic}
    Path(__file__).with_name("control-results.json").write_text(
        json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
