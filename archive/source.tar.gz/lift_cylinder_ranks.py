"""Add C7^3 cylinder bounds from exact two-dimensional layer ranks."""
import argparse
import hashlib
from itertools import combinations, product
import json
from pathlib import Path
import time

import numpy as np
from scipy.optimize import linprog
from scipy.sparse import csc_matrix

from cylinder_bounds import HERE, WORDS, certify
from refine_cylinder_ranks import refined_constraints
from layer_rank_bound import rank3_bound


def lifted_constraints(pool, exact_probe=None):
    members, desc, _, stats = refined_constraints(pool)
    rows = dict(zip(members, desc))
    tightened = 0
    exact_ranks = {}
    if exact_probe is not None:
        assert exact_probe['status'] == 'complete'
        for row in exact_probe['results']:
            result = row['result']
            if result['status'] == 'exhausted' and result['best_size'] < row['upper']:
                exact_ranks[tuple(row['projection'])] = (result['best_size'], row['upper'])
    applied = set()
    for free in combinations(range(5), 3):
        fixed = [i for i in range(5) if i not in free]
        buckets = {}
        for i, v in enumerate(pool):
            for values in product(*[((WORDS[v][k]-1) % 7, WORDS[v][k]) for k in fixed]):
                buckets.setdefault(values, []).append(i)
        for values, vs in buckets.items():
            projection = tuple(sorted({49*WORDS[pool[v]][free[0]]+7*WORDS[pool[v]][free[1]]+
                                       WORDS[pool[v]][free[2]] for v in vs}))
            bound = rank3_bound(projection)
            key, cap = tuple(vs), bound['capacity']
            if len(vs) <= cap or cap >= rows.get(key, {'capacity': len(vs)})['capacity']:
                continue
            origin = [-1]*5
            for k, v in zip(fixed, values):
                origin[k] = v
            rows[key] = dict(free=list(free), origin=origin, capacity=cap,
                             layer_rank_bound=bound, projection=list(projection))
            if projection in exact_ranks:
                exact, prior = exact_ranks[projection]
                assert prior == cap and 0 < exact < prior
                rows[key] = dict(free=list(free), origin=origin, capacity=exact,
                                 cubic_rank=True, projection=list(projection))
                applied.add(projection)
            tightened += 1
    assert applied == set(exact_ranks)
    members = sorted(rows)
    desc = [rows[c] for c in members]
    rr = [i for i, c in enumerate(members) for _ in c]
    cc = [v for c in members for v in c]
    matrix = csc_matrix((np.ones(len(rr)), (rr, cc)), shape=(len(members), len(pool)))
    return members, desc, matrix, stats | {'three_coordinate_rows': tightened,
                                         'distinct_3d_projections': rank3_bound.cache_info().currsize,
                                         'exact_cubic_projections_applied': len(applied)}


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--seconds', type=float, default=20)
    p.add_argument('--exact-probe', type=Path)
    args = p.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    if args.seconds <= 0:
        p.error('Positive limit required')
    source = json.loads(args.input.read_text())
    pool = source['pool']
    began = time.monotonic()
    exact_probe = None if args.exact_probe is None else json.loads(args.exact_probe.read_text())
    if exact_probe is not None:
        assert exact_probe['input_sha256'] == hashlib.sha256(args.input.read_bytes()).hexdigest()
    members, desc, matrix, stats = lifted_constraints(pool, exact_probe)
    caps = [d['capacity'] for d in desc]
    seed = {int(w, 7) for w in (HERE/'family-d-seed-words.txt').read_text().split()}
    assert np.all(matrix @ np.array([v in seed for v in pool], dtype=float) <= caps)
    built = time.monotonic()
    solved = linprog(-np.ones(len(pool)), A_ub=matrix, b_ub=caps, bounds=(0, None),
                     method='highs-ipm', options={'time_limit': args.seconds})
    report = {k: source[k] for k in ('axis', 'start', 'width', 'pool', 'fixed', 'target', 'capacity_sequence')}
    report.update(status=int(solved.status), message=solved.message, stats=stats,
                  constraints=len(members), nonzeros=int(matrix.nnz),
                  build_seconds=built-began, solve_seconds=time.monotonic()-built,
                  input_sha256=hashlib.sha256(args.input.read_bytes()).hexdigest(),
                  hashes={n: hashlib.sha256((HERE/n).read_bytes()).hexdigest() for n in
                          (Path(__file__).name, 'layer_rank_bound.py', 'refine_cylinder_ranks.py', 'square_rank.py')},
                  scope='Whole fixed-exterior domain. Three-dimensional ranks are upper bounds, not exact optima.')
    if args.exact_probe is not None:
        report['exact_probe_sha256'] = hashlib.sha256(args.exact_probe.read_bytes()).hexdigest()
    if solved.success:
        report['floating_bound'] = float(-solved.fun)
        report['certificate'] = certify(pool, members, desc, -solved.ineqlin.marginals)
        report['primal'] = [[v, float(x)] for v, x in zip(pool, solved.x) if x > 1e-8]
    args.output.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps({k: v for k, v in report.items() if k not in ('fixed', 'pool', 'primal', 'certificate')} |
                     {'integer_bound': report.get('certificate', {}).get('integer_upper_bound')}), flush=True)


if __name__ == '__main__':
    main()
