"""Independent stdlib reconstruction of the triple screen and stored covers.

No certificate-generator, solver, or public replay module is imported.
The screen uses observed-symbol unions rather than allowed-origin intersections.
"""
import hashlib
import itertools
import json
import math
from collections import Counter
from fractions import Fraction
from pathlib import Path
from check_one_core_covers import check
from check_two_core_covers import main as check_pairs

ROOT = Path(__file__).resolve().parent


def main():
    check_pairs()
    pair_source = ROOT / 'two-core-cover-results.json'
    pairs = json.loads(pair_source.read_text())
    screen_source = ROOT / 'three-core-screen-results.json'
    screen = json.loads(screen_source.read_text())
    screen_digest = hashlib.sha256(screen_source.read_bytes()).hexdigest()
    assert screen['parent_pair_certificate_sha256'] == hashlib.sha256(pair_source.read_bytes()).hexdigest()
    core = list(map(tuple, pairs['core']))
    assert [sum(x * 7**(4-k) for k, x in enumerate(w)) for w in core] == screen['core_ids']
    assert len(core) == 308
    blockers = {w: 0 for w in itertools.product(range(7), repeat=5)}
    for i, w in enumerate(core):
        for v in itertools.product(*[((x-1) % 7, x, (x+1) % 7) for x in w]):
            blockers[v] |= 1 << i
    pools = {}
    for w, mask in blockers.items():
        if mask.bit_count() <= 3:
            key = tuple(i for i in range(308) if mask >> i & 1)
            pools.setdefault(key, set()).add(w)
    observed = {}
    for key, words in pools.items():
        packed = 0
        for w in words:
            for k, x in enumerate(w):
                packed |= 1 << (7*k + x)
        observed[key] = packed
    # A coordinate's actual symbols must be contained in {a,a+1} modulo 7.
    valid = [any(mask & ~((1 << a) | (1 << ((a+1) % 7))) == 0
                 for a in range(7)) for mask in range(128)]

    def fits(mask):
        return (valid[mask & 127] and valid[(mask >> 7) & 127]
                and valid[(mask >> 14) & 127] and valid[(mask >> 21) & 127]
                and valid[(mask >> 28) & 127])

    singles = [observed[(i,)] for i in range(308)]
    doubles = [[0] * 308 for _ in range(308)]
    triples = {}
    for key, mask in observed.items():
        if len(key) == 2:
            i, j = key
            doubles[i][j] = doubles[j][i] = mask
        elif len(key) == 3:
            triples[key] = mask
    residual = []
    for i, j, k in itertools.combinations(range(308), 3):
        t = triples.get((i, j, k), 0)
        if (fits(singles[k] | doubles[i][k] | doubles[j][k] | t)
            or fits(singles[j] | doubles[i][j] | doubles[j][k] | t)
            or fits(singles[i] | doubles[i][j] | doubles[i][k] | t)):
            continue
        residual.append([i, j, k])
    assert residual == screen['residual']
    total = math.comb(308, 3)
    inherited = total - len(residual)
    assert total == screen['total_triples'] and inherited == screen['inherited']
    assert len(residual) == screen['unresolved']
    print('Independent observed-symbol screen:', inherited, 'inherited;', len(residual), 'residual.', flush=True)

    probe_source = ROOT / 'three-core-probe-results.json'
    probe = json.loads(probe_source.read_text())
    assert probe['screen_sha256'] == screen_digest
    cases = list(probe['cases'])
    continuation_source = ROOT / 'three-core-continuation.jsonl'
    for line in continuation_source.read_text().splitlines():
        item = json.loads(line)
        assert item['screen_sha256'] == screen_digest
        cases.append(item['case'])
    assert len(cases) <= len(residual)
    assert [c['triple'] for c in cases] == residual[:len(cases)]
    bounds = []
    for row in cases:
        indices = row['triple']
        allowed = set()
        for count in range(4):
            for key in itertools.combinations(indices, count):
                allowed.update(pools.get(key, set()))
        assert all(core[i] in allowed for i in indices)
        cover = row['cover']
        assert len(allowed) == cover['candidate_count']
        if cover['excluded']:
            bound = check(cover['certificate'], allowed, 63)
            assert bound == Fraction(cover['total'])
            bounds.append(bound)
    result = {
        'screen_sha256': screen_digest,
        'probe_sha256': hashlib.sha256(probe_source.read_bytes()).hexdigest(),
        'continuation_sha256': hashlib.sha256(continuation_source.read_bytes()).hexdigest(),
        'total_triples': total,
        'inherited_verified': inherited,
        'fresh_verified': len(bounds),
        'fresh_max_bound': str(max(bounds)) if bounds else None,
        'fresh_bound_distribution': dict(Counter(map(str, bounds))),
        'queried_without_certificate': len(cases) - len(bounds),
        'unqueried': len(residual) - len(cases),
        'all_triples_excluded': inherited + len(bounds) == total,
        'method': 'Verified parent pair certificates; independent observed-symbol screen of all triples; rebuilt full residual pools; exact Fractions and explicit 32-corner expansions.',
    }
    (ROOT / 'three-core-cover-verification.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2), flush=True)


if __name__ == '__main__':
    main()
