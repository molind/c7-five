"""Stdlib-only replay: reconstruct candidates independently and check covers.

No solver, NumPy, graph_data or certificate-generator imports are used.
"""
from fractions import Fraction
from itertools import combinations,product
import hashlib,json
from pathlib import Path

ROOT=Path(__file__).resolve().parent

def check(weights,allowed,threshold):
    coverage={w:Fraction(0) for w in allowed};total=Fraction(0)
    for entry in weights:
        origin=entry['origin'];assert len(origin)==5 and all(type(x) is int and 0<=x<7 for x in origin)
        weight=Fraction(entry['weight']);assert weight>=0;total+=weight
        # Expand the actual 32-word conflict clique, instead of testing membership
        # with the generator's modular predicate.
        clique=list(product(*[(x,(x+1)%7) for x in origin]))
        for word in clique:
            if word in coverage:coverage[word]+=weight
    assert all(v>=1 for v in coverage.values()),'Uncovered candidate'
    assert total<threshold,'Insufficient bound'
    return total

def main():
    path=ROOT/'one-core-fractional-results.json';data=json.loads(path.read_text());core=list(map(tuple,data['core']))
    assert len(core)==308 and len(set(core))==308
    assert all(len(w)==5 and all(type(x) is int and 0<=x<7 for x in w) for w in core)
    for a,b in combinations(core,2):assert any((x-y)%7 in (2,3,4,5) for x,y in zip(a,b))
    all_words=list(product(range(7),repeat=5));blockers={w:0 for w in all_words}
    for i,word in enumerate(core):
        for neighbor in product(*[((x-1)%7,x,(x+1)%7) for x in word]):blockers[neighbor]|=1<<i
    free=[w for w in all_words if blockers[w]==0]
    free_bound=check(data['free_bound']['certificate'],free,60)
    assert len(data['cases'])==308
    assert sorted(row['core_index'] for row in data['cases'])==list(range(308))
    results=[];full=(1<<308)-1
    for row in data['cases']:
        i=row['core_index'];assert tuple(row['removed_word'])==core[i]
        kept=full^(1<<i);allowed=[w for w in all_words if not blockers[w]&kept]
        assert core[i] in allowed
        assert len(allowed)==row['direct']['candidate_count']
        bound=check(row['direct']['certificate'],allowed,61)
        results.append({'removed_word':list(core[i]),'candidate_count':len(allowed),'bound':str(bound)})
    # Deliberately damaged certificates must not be accepted.
    for damaged in ([],[{'origin':[0,0,0,0,0],'weight':'-1'}]):
        try:check(damaged,free,60)
        except AssertionError:pass
        else:raise AssertionError('Damaged certificate accepted')
    result={'certificate_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
            'core_size':308,'free_candidates':len(free),'free_bound':str(free_bound),
            'deletions_checked':len(results),'all_bounds_strictly_below_61':True,
            'independent_reconstruction':'Cartesian neighborhoods; explicit 32-word cover expansion; Fraction arithmetic',
            'negative_controls_passed':2,'cases':results}
    (ROOT/'one-core-fractional-verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='cases'},indent=2))

if __name__=='__main__':main()
