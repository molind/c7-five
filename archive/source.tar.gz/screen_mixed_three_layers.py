"""Bound selected mixed fixed exteriors using existing certified cylinder rows."""
import argparse
import hashlib
from itertools import combinations
import json
from pathlib import Path
import time

import numpy as np
import scipy
from scipy.optimize import linprog

from check_two_slice_covers import WORDS, conflict
from check_cylinder_covers import check_entries
from cylinder_bounds import CAPACITY, certify
from lift_cylinder_ranks import lifted_constraints


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(value, indent=2)+'\n')
    temp.replace(path)


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path, required=True)
    p.add_argument('--output-dir', type=Path, required=True)
    p.add_argument('--seconds', type=float, default=5)
    p.add_argument('--limit', type=int, default=24)
    args = p.parse_args()
    if args.seconds <= 0 or args.limit < 1:
        p.error('Positive limits required')
    args.output_dir.mkdir(exist_ok=False)
    source = json.loads(args.input.read_text())
    assert source['status'] == 'prepared'
    universe = np.array(WORDS, dtype=np.int16)
    report = dict(status='running', input=str(args.input), input_sha256=digest(args.input),
        source_sha256=digest(Path(__file__)), scipy_version=scipy.__version__, seconds=args.seconds,
        limit=args.limit, results=[], candidates=[], scope='Only the selected mixed fixed exteriors, admitting every compatible word; no global bound.')
    began = time.monotonic()
    save(args.output_dir/'index.json', report)
    for job in source['jobs'][:args.limit]:
        started = time.monotonic()
        fixed, pool = job['fixed'], job['pool']
        assert len(fixed) == len(set(fixed)) == job['fixed_size']
        assert all(not conflict(a, b) for a, b in combinations(fixed, 2))
        allowed = np.ones(len(universe), dtype=bool)
        for v in fixed:
            d = (universe-universe[v]) % 7
            allowed &= ~np.all((d == 0) | (d == 1) | (d == 6), axis=1)
        assert np.flatnonzero(allowed).tolist() == pool
        members, desc, matrix, stats = lifted_constraints(pool)
        caps = [d['capacity'] for d in desc]
        hint_set = set(job['hint'])
        hint = np.array([v in hint_set for v in pool], dtype=float)
        assert len(fixed)+int(hint.sum()) == job['initial_size']
        assert np.all(matrix @ hint <= caps)
        built = time.monotonic()
        solved = linprog(-np.ones(len(pool)), A_ub=matrix, b_ub=caps, bounds=(0, None),
                         method='highs-ipm', options={'time_limit':args.seconds})
        row = dict(index=job['index'], fixed=fixed, pool=pool, hint=job['hint'], initial_size=job['initial_size'],
            target=job['target'], status=int(solved.status), message=solved.message,
            capacity_sequence=CAPACITY, stats=stats, constraints=len(members), nonzeros=int(matrix.nnz),
            build_seconds=built-started, solve_seconds=time.monotonic()-built)
        if solved.success:
            row['floating_bound'] = float(-solved.fun)
            row['certificate'] = certify(pool, members, desc, -solved.ineqlin.marginals)
            total, den = check_entries(row['certificate'], pool, CAPACITY)
            row['full_upper'] = len(fixed)+total//den
            assert row['full_upper'] >= row['initial_size']
            row['excludes368'] = row['full_upper'] < 368
            row['primal'] = [[v, float(x)] for v, x in zip(pool, solved.x) if x > 1e-8]
            if np.max(np.abs(solved.x-np.rint(solved.x))) < 1e-7:
                chosen = fixed+[v for v, x in zip(pool, solved.x) if x > .5]
                assert len(chosen) == len(set(chosen)) and all(not conflict(a, b) for a, b in combinations(chosen, 2))
                row['integral_vertices'] = chosen
                if len(chosen) >= 368:
                    report['candidates'].append(dict(index=job['index'], size=len(chosen),
                        words=[''.join(map(str, WORDS[v])) for v in chosen], verified_pairs=len(chosen)*(len(chosen)-1)//2))
        path = args.output_dir/f"domain{job['index']:02d}.json"
        save(path, row)
        report['results'].append(dict(index=job['index'], file=str(path), sha256=digest(path),
            pool=len(pool), fixed=len(fixed), initial_size=row['initial_size'], status=row['status'],
            full_upper=row.get('full_upper'), floating_full_bound=len(fixed)+row['floating_bound'] if 'floating_bound' in row else None,
            excludes368=row.get('excludes368', False)))
        report['elapsed_seconds'] = time.monotonic()-began
        save(args.output_dir/'index.json', report)
        print(json.dumps(report['results'][-1] | dict(elapsed_seconds=report['elapsed_seconds'])), flush=True)
        if report['candidates']:
            break
    report['status'] = 'candidate_found' if report['candidates'] else 'complete'
    save(args.output_dir/'index.json', report)


if __name__ == '__main__':
    main()
