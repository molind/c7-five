"""Allow one common-core word to disappear, with unrestricted noncore changes.
Exact residual MIS per omitted word; a global time budget leaves unfinished cases open.
"""
from functools import lru_cache
import gzip, hashlib, json, struct, time
from itertools import combinations, product
from pathlib import Path
HERE=Path(__file__).resolve().parent
if not __debug__:raise RuntimeError('Run without -O')
with gzip.open(HERE/'breakout-perturb64-sep20-2049-component-0.jsonl.gz','rt') as f:
    meta=json.loads(next(f));states=[set(json.loads(line)) for line in f]
assert hashlib.sha256(b''.join(sorted(struct.pack('<367H',*sorted(s)) for s in states))).hexdigest()==meta['component_sha256']
core=sorted(set.intersection(*states));core_set=set(core);assert len(core)==356
words=list(product(range(7),repeat=5))
coords=[[0]*7 for _ in range(5)]
for i,v in enumerate(core):
    for k,x in enumerate(words[v]):coords[k][x]|=1<<i
free=[];unique=[[] for _ in core]
for v,w in enumerate(words):
    if v in core_set:continue
    blockers=(1<<len(core))-1
    for k,x in enumerate(w):blockers&=coords[k][(x-1)%7]|coords[k][x]|coords[k][(x+1)%7]
    if not blockers:free.append(v)
    elif blockers.bit_count()==1:unique[blockers.bit_length()-1].append(v)
conflict=lambda a,b:all((x-y)%7 in (0,1,6) for x,y in zip(words[a],words[b]))
report=dict(core_size=356,baseline_free=len(free),rows=[],candidates=[],status='running',
            source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            scope='Each row fixes355 original core words and excludes the omitted core word; other words unrestricted.')
out=HERE/'family-d-core-release-result.json';began=time.monotonic();deadline=began+65
for omitted,extra in zip(core,unique):
    ids=free+extra;n=len(ids);adj=[sum(1<<j for j,b in enumerate(ids) if i!=j and conflict(a,b)) for i,a in enumerate(ids)]
    calls=0
    @lru_cache(None)
    def solve(mask):
        global calls
        calls+=1
        if calls%1024==0 and time.monotonic()>deadline:raise TimeoutError
        if not mask:return 0,0
        v=max((i for i in range(n) if mask>>i&1),key=lambda i:(adj[i]&mask).bit_count())
        bit=1<<v;remaining=mask^bit
        a,aa=solve(remaining);b,bb=solve(remaining&~adj[v]);b+=1
        return (a,aa) if a>=b else (b,bb|bit)
    try:
        if time.monotonic()>deadline:raise TimeoutError
        alpha,selected=solve((1<<n)-1)
    except TimeoutError:
        report['status']='timeout';report['unfinished_word']=''.join(map(str,words[omitted]));break
    target=sorted((core_set-{omitted})|{ids[i] for i in range(n) if selected>>i&1})
    assert len(target)==355+alpha and not any(conflict(a,b) for a,b in combinations(target,2))
    row=dict(omitted=''.join(map(str,words[omitted])),domain=n,alpha=alpha,dp_subproblems=solve.cache_info().currsize)
    report['rows'].append(row)
    if alpha>=12:
        report['status']='new_target';report['candidates'].append(dict(step=0,words=[''.join(map(str,words[v])) for v in target],source=row));break
else:report['status']='exhausted'
report['seconds']=time.monotonic()-began
out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(status=report['status'],completed=len(report['rows']),domains=sorted(set(r['domain'] for r in report['rows'])),alphas=sorted(set(r['alpha'] for r in report['rows'])),seconds=report['seconds'],candidates=len(report['candidates']))))
