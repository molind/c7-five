"""Transfer a completed narrow-domain exclusion to a wider nested core domain.

If the wide solution kept every additionally fixed narrow word, it would be a
solution of the excluded narrow problem with exactly the same parent deletions.
Thus at least one of those words must be absent. No solver is used here.
"""
import argparse
import hashlib
import json
from pathlib import Path


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--narrow-proof', type=Path, required=True)
    p.add_argument('--narrow-input', type=Path, required=True)
    p.add_argument('--wide-input', type=Path, required=True)
    p.add_argument('--radius-verification', type=Path, required=True)
    p.add_argument('--radius', type=int, required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    assert __debug__ and not args.output.exists()
    proof = json.loads(args.narrow_proof.read_text())
    assert proof['passed'] and proof['complete_branch_partition']
    assert proof['no368_in_this_fixed_domain_through_radius'] and proof['target'] == 368
    assert proof['deletion_radius'] == args.radius
    assert proof['checker_sha256'] == sha(Path(__file__).with_name('check_core_branch_certificates_v4.py'))
    narrow = json.loads(args.narrow_input.read_text())
    wide = json.loads(args.wide_input.read_text())
    prior = json.loads(args.radius_verification.read_text())
    assert prior['passed']
    assert prior['checker_sha256'] == sha(Path(__file__).with_name('check_core_radius_cut.py'))
    assert proof['dependencies'][str(args.narrow_input)] == sha(args.narrow_input)
    for path in (args.narrow_input, args.wide_input):
        assert prior['dependencies'][str(path)] == sha(path)
        assert any(r['file'] == str(path) and r['radius'] == args.radius for r in prior['rows'])
    visited = set()

    def check_links(path):
        path = Path(path)
        if path in visited or path.suffix != '.json':
            return
        visited.add(path)
        value = json.loads(path.read_text())
        dependencies = value.get('dependencies', {}) if isinstance(value, dict) else {}
        pairs = dependencies.items() if isinstance(dependencies, dict) else [(v['path'], v['sha256']) for v in dependencies]
        for file, digest in pairs:
            assert sha(file) == digest
            check_links(file)

    for path in (args.narrow_proof, args.radius_verification):
        check_links(path)
    assert narrow['parent_words'] == wide['parent_words'] == proof['exact_parent']
    assert narrow['fixed'] == proof['fixed']
    parent = set(narrow['parent_words'])
    nf, wf = set(narrow['fixed']), set(wide['fixed'])
    assert wf < nf <= parent and len(parent) == 367
    extra = nf - wf
    npool, wpool = set(narrow['pool']), set(wide['pool'])
    assert extra <= wpool and npool <= wpool
    coords = {v: tuple((v // power) % 7 for power in (2401, 343, 49, 7, 1)) for v in wpool}
    eligible = {v for v in wpool
                if all(any((a-b) % 7 in (2, 3, 4, 5) for a, b in zip(coords[v], coords[w]))
                       for w in extra)}
    assert eligible == npool
    old_narrow, old_wide = parent - nf, parent - wf
    assert not old_narrow & extra and old_wide == old_narrow | extra
    assert wide['target'] == narrow['target'] + len(extra)
    assert narrow['target'] == 368-len(nf) and wide['target'] == 368-len(wf)
    out = dict(passed=True, input=str(args.wide_input), target=368,
               deletion_radius=args.radius, fixed=wide['fixed'], exact_parent=wide['parent_words'],
               narrow_fixed_words=len(nf), wide_fixed_words=len(wf), free_pool=len(wpool),
               inside=sorted(extra), outside=[], inequality_upper=len(extra)-1,
               parent_deletion_count_preserved=True, eligible_pool_mapping_checked=True,
               checker_sha256=sha(__file__),
               dependencies={str(path): sha(path) for path in
                             (args.narrow_proof, args.narrow_input, args.wide_input, args.radius_verification)},
               scope='Any target368 solution in this wider core and radius must omit at least one listed word. This does not exclude the whole wider domain or solve C7.')
    args.output.write_text(json.dumps(out, indent=2) + '\n')
    print({k: v for k, v in out.items() if k not in ('fixed', 'exact_parent', 'inside', 'dependencies')})


if __name__ == '__main__':
    main()
