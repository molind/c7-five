"""Accumulate valid odd-cycle cuts and export an exact integer weighted cover.

Reuses the existing odd-walk separator and clique-center lifting. A numerical
LP bound is only a search diagnostic. Exported integer weights are checked for
coverage before drawing any exclusion. Missing sampled cuts proves nothing.
"""
import argparse
import hashlib
from itertools import product
import json
import math
from pathlib import Path
import random
import time

import numpy as np
from scipy.optimize import linprog

from check_two_slice_covers import closed
from search_core_regions import box_constraints, independence
from probe_odd_cycle_cuts import separate
from search_clique_cycle_cuts import check_cut, cut_key, find_cuts, lift, matrix_for


def exact_cover(matrix,caps,lp,model,cuts):
    D=1000000
    weights=[math.ceil(max(0,-float(x))*D) for x in lp.ineqlin.marginals]
    A=matrix.tocsc();coverage=[0]*A.shape[1]
    for v in range(A.shape[1]):
        for at in range(A.indptr[v],A.indptr[v+1]):
            coverage[v]+=int(A.data[at])*weights[int(A.indices[at])]
    # Repair any numerical dual deficit using an existing unit clique row.
    for v,value in enumerate(coverage):
        if value>=D:continue
        row=next(int(A.indices[t]) for t in range(A.indptr[v],A.indptr[v+1]) if A.indices[t]<len(model['members']))
        extra=D-value;weights[row]+=extra
        for w in model['members'][row]:coverage[w]+=extra
    assert min(coverage)>=D
    rows=[]
    for i,units in enumerate(weights):
        if not units:continue
        if i<len(model['members']):
            rows.append(dict(kind='clique',words=[model['pool'][v] for v in model['members'][i]],units=units,capacity=1))
        else:
            cut=cuts[i-len(model['members'])]
            rows.append(dict(kind='cycle',words=cut['cycle'],centers=cut['centers'],units=units,capacity=cut['capacity']))
    return dict(denominator=D,rows=rows,total_units=sum(int(c)*w for c,w in zip(caps,weights)),minimum_coverage=min(coverage))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True)
    p.add_argument('--case',type=int)
    p.add_argument('--base',type=Path,required=True)
    p.add_argument('--rounds',type=int,default=8)
    p.add_argument('--roots',type=int,default=256)
    p.add_argument('--wheel-seconds',type=float,default=20)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();assert __debug__ and not args.output.exists()
    assert args.rounds>0 and args.roots>0 and args.wheel_seconds>=0
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    data=json.loads(args.input.read_text());assert all(sha(f)==h for f,h in data['dependencies'].items())
    row=data['rows'][args.case] if args.case is not None else data
    base=json.loads(args.base.read_text());assert sha(base['input'])==base['input_sha256']
    parents=json.loads(Path(base['input']).read_text())['bases']
    core=set(parents[0]['words'])&set(parents[1]['words']);assert core==set(base['fixed']) and len(core)==315
    omitted=set(row['omitted']);assert omitted<=core and len(omitted)==len(row['omitted'])
    fixed=sorted(core-omitted);blocked=set().union(*(closed(v) for v in fixed))
    pool=sorted(set(range(16807))-blocked);assert pool==row['pool']
    target=368-len(fixed);assert target==row['target']
    coords=np.array(list(product(range(7),repeat=5)),dtype=np.int16)
    corners=np.array(list(product((0,1),repeat=5)));powers=np.array([2401,343,49,7,1])
    base_matrix=box_constraints(pool,coords,corners,powers).tocsr()
    members=[base_matrix.indices[base_matrix.indptr[i]:base_matrix.indptr[i+1]].tolist() for i in range(base_matrix.shape[0])]
    old=set(parents[1]['words']);assert independence(sorted(old))==67161
    hint=np.array([int(v in old) for v in pool]);assert int(hint.sum())+len(fixed)==367
    model=dict(pool=pool,fixed=fixed,members=members,capacities=[1]*len(members))
    local={v:i for i,v in enumerate(pool)}
    adjacency=[{local[w] for w in closed(v) if w!=v and w in local} for v in pool]
    edges=[(i,j) for i,row in enumerate(adjacency) for j in row if i<j]
    cuts=[];seen=set();rounds=[];began=time.monotonic()
    dependencies={str(args.input):sha(args.input),str(args.base):sha(args.base),base['input']:sha(base['input'])}
    for name in ('search_core_regions.py','probe_odd_cycle_cuts.py','search_clique_cycle_cuts.py','check_two_slice_covers.py'):
        path=Path(__file__).with_name(name);dependencies[str(path)]=sha(path)
    out=dict(status='running',pool=pool,fixed=fixed,omitted=sorted(omitted),target=target,cuts=cuts,rounds=rounds,
        source_sha256=sha(__file__),dependencies=dependencies,
        scope='Only this complete fixed-core domain. Sampled cut search is not exhaustive. Only a checked strict integer cover excludes368.')
    def save():
        out['seconds']=time.monotonic()-began
        args.output.write_text(json.dumps(out,indent=2)+'\n')
    save()
    for iteration in range(args.rounds+1):
        A,caps=matrix_for(model,cuts);assert np.all(A@hint<=caps)
        lp=linprog(-np.ones(len(pool)),A_ub=A,b_ub=caps,bounds=(0,None),method='highs')
        assert lp.success,lp.message
        assert np.all(A@lp.x<=caps+1e-6) and np.min(lp.x)>=-1e-6
        cover=exact_cover(A,caps,lp,model,cuts);out['certificate']=cover
        out['primal']=[[v,float(x)] for v,x in zip(pool,lp.x) if x>1e-8]
        out['floating_bound']=-float(lp.fun)
        rec=dict(iteration=iteration,cuts=len(cuts),floating_bound=-float(lp.fun),total_units=cover['total_units'])
        rounds.append(rec)
        if cover['total_units']<target*cover['denominator']:
            out['status']='strict_integer_cover';save();print(rec,flush=True);break
        if iteration==args.rounds:
            out['status']='round_limit';save();break
        roots=[i for i,x in enumerate(lp.x) if 1e-6<x<1-1e-6]
        random.Random(2026092260+iteration).shuffle(roots);roots=roots[:args.roots]
        additions=[]
        for found in separate(len(pool),edges,lp.x,roots) if roots else []:
            cycle=found['cycle'];centers=lift(cycle,adjacency,lp.x,pool)
            cut=dict(cycle=[pool[i] for i in cycle],centers=[pool[i] for i in centers],capacity=found['capacity'])
            key=cut_key(cut)
            if key not in seen:
                check_cut(cut,set(pool));seen.add(key);additions.append(cut)
        if not additions and args.wheel_seconds:
            additions,stats=find_cuts(model,adjacency,lp.x,seen,time.monotonic()+args.wheel_seconds,256)
            rec['wheel_separation']=stats
        rec['added']=len(additions);cuts.extend(additions)
        print(rec,flush=True)
        if not additions:
            out['status']='no_sampled_cut';save();break
        save()
    print(dict(status=out['status'],cuts=len(cuts),floating_bound=out['floating_bound'],target=target,seconds=out['seconds']))


if __name__=='__main__':main()
