"""Exact minimal blocker unions jointly satisfying earlier-neighbor conditions."""
import gzip,hashlib,json,time
from itertools import product
from pathlib import Path
import numpy as np


def minimal(values):
    out=[]
    for b in sorted(set(values),key=lambda x:(x.bit_count(),x)):
        if not any(a&b==a for a in out):out.append(b)
    return out


def main():
    r=Path('research/c7');out=r/'joint-critical-union-profile-sep22.json';assert not out.exists();deps={};rows=[]
    coords=np.array(list(product(range(7),repeat=5)),dtype=np.int16)
    for name,radius,samples in [('component-F-rooted8-sep22-input.json',9,[1,6,15,25,35]),('component-CB-incremental-sep22-input.json',7,[1038,1500,2500,5000])]:
        p=r/name;m=json.loads(p.read_text());deps[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
        assert hashlib.sha256(Path(m['source']).read_bytes()).hexdigest()==m['source_sha256'];deps[m['source']]=m['source_sha256']
        with gzip.open(m['source'],'rt') as f:next(f);states=[set(json.loads(x)) for x in f]
        for index in samples:
            began=time.monotonic();state=states[index];old=sorted(state);frozen=set();parents=[]
            for j,other in enumerate(states[:index]):
                if len(state-other)==len(other-state)==1:
                    x,=state-other;y,=other-state;frozen.add(x);parents.append((j,y))
            delta=(coords[:,None,:]-coords[np.array(old)[None,:],:])%7
            bad=np.all((delta==0)|(delta==1)|(delta==6),axis=2);degree=bad.sum(axis=1)
            chosen=np.zeros(16807,dtype=bool);chosen[old]=True
            pool=(degree>=2)&(degree<=radius)&~chosen
            if frozen:pool&=~np.any(bad[:,[old.index(x) for x in frozen]],axis=1)
            ids=np.flatnonzero(pool)
            bsets=[int.from_bytes(row.tobytes(),'little') for row in np.packbits(bad[ids],axis=1,bitorder='little')]
            conditions=[];sizes=[]
            for j,y in parents:
                diff=(coords[ids]-coords[y])%7;critical=np.all((diff==0)|(diff==1)|(diff==6),axis=1)
                bs=[b for b,flag in zip(bsets,critical) if flag];small=minimal(bs)
                assert all(any(a&b==a for a in small) for b in bs)
                sizes.append(dict(parent=j,candidates=len(bs),minimal=len(small)));conditions.append(small)
            current=[0];stages=[]
            for condition in sorted(conditions,key=len):
                combined={a|b for a in current for b in condition if (a|b).bit_count()<=radius}
                current=minimal(combined);stages.append(dict(raw=len(combined),minimal=len(current)))
            assert all(all(any(a&b==a for a in c) for c in conditions) for b in current)
            rows.append(dict(manifest=name,state=index,radius=radius,pool=len(ids),conditions=sizes,stages=stages,joint_minimal=len(current),minimum_joint_size=min(map(int.bit_count,current),default=None),joint_size_histogram={str(k):sum(b.bit_count()==k for b in current) for k in range(radius+1)},seconds=time.monotonic()-began))
            print(json.dumps(rows[-1]),flush=True)
    out.write_text(json.dumps(dict(source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),dependencies=deps,rows=rows,scope='Exact antichains of blocker unions covering all critical conditions for these sampled states. Ignores compatibility between critical candidates, so it is a necessary relaxation only. Not a native traversal or speed measurement.'),indent=2)+'\n')


if __name__=='__main__':main()
