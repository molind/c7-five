"""Constructive completion search with a replayed target-valid core cut."""
import argparse
from itertools import combinations
import json
from pathlib import Path
import time

from certify_target_core_cut import replay as replay_cut
from check_two_slice_covers import WORDS, conflict
from search_mixed_three_layers import prepare
from search_sparse_cylinders import solve_native, check_solution
from screen_mixed_three_layers import digest, save


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path, required=True)
    p.add_argument('--core-cut', type=Path, required=True)
    p.add_argument('--hint-words', type=Path, required=True)
    p.add_argument('--seconds', type=float, default=90)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    assert __debug__ and args.seconds > 0 and not args.output.exists()
    source = json.loads(args.input.read_text())
    cut = replay_cut(json.loads(args.core_cut.read_text()))
    assert cut['full_target'] == 368
    model = prepare(source)
    core = set(cut['core'])
    indices = [i for i,v in enumerate(model['pool']) if v in core]
    capacity = cut['max_retained_core']-len(core & set(model['fixed']))
    assert capacity >= 0
    model['members'].append(indices)
    model['capacities'].append(capacity)
    tokens = args.hint_words.read_text().split()
    assert all(len(w) == 5 and set(w) <= set('0123456') for w in tokens)
    hint = {int(w, 7) for w in tokens}
    assert len(hint) == len(tokens) == 367
    assert set(model['fixed']) <= hint <= set(model['fixed']+model['pool'])
    assert all(not conflict(a, b) for a,b in combinations(hint, 2))
    model['hint'] = [i for i,v in enumerate(model['pool']) if v in hint]
    local_hint = set(model['hint'])
    assert all(len(set(row) & local_hint) <= cap for row,cap in zip(model['members'],model['capacities']))
    report = dict(status='searching', input=str(args.input), input_sha256=digest(args.input),
                  source_sha256=digest(Path(__file__)), model=model, seconds=args.seconds,
                  target_core_cut=dict(file=str(args.core_cut), sha256=digest(args.core_cut),
                                       row_index=len(model['members'])-1),
                  hint_words=dict(file=str(args.hint_words), sha256=digest(args.hint_words)),
                  candidates=[], scope='Full compatible domain with a conditional inequality preserving all368solutions. Smaller independent sets can be excluded by the core cut.')
    save(args.output, report)
    print(json.dumps(dict(fixed=len(model['fixed']), pool=len(model['pool']),
                          core_variables=len(indices), core_capacity=capacity,
                          initial_size=len(hint))), flush=True)
    started = time.monotonic()
    result = solve_native(model, 368-len(model['fixed']), args.seconds)
    check_solution(model, result)
    report['result'] = result
    if result.get('full_size',0) >= 367:
        full = sorted(model['fixed']+result['vertices'])
        report['candidates'].append(dict(step=0, size=len(full),
            words=[''.join(map(str, WORDS[v])) for v in full], verified_pairs=result['verified_pairs']))
    report['status'] = 'candidate_found' if result.get('full_size',0) >= 368 else 'bounded_search_complete'
    report['solve_seconds'] = time.monotonic()-started
    save(args.output, report)
    print(json.dumps({k:v for k,v in result.items() if k != 'vertices'}), flush=True)


if __name__ == '__main__':
    main()
