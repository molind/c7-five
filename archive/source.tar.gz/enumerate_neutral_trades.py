"""Enumerate larger exchanges from maximal366 sets with the existing kernel.

Keep neutral exchanges whose union requires a step wider than two, and seek
improvements inside each bipartite union. This is a local property only, not
separation of global width2 components.
Status complete means the bounded batch finished; row statuses retain time/output
limits. The native kernel itself is unchanged.
"""
import argparse
import hashlib
from itertools import combinations,product
import json
from pathlib import Path
import subprocess
import time

from check_exchange_dfs import graph_text
from run_seed_exchanges import coordinate_masks,nearby,conflict
from search_exchanges import verify
from analyze_bipartite_trade import analyze_trade

HERE=Path(__file__).resolve().parent


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--indices',type=int,nargs='+',required=True)
    p.add_argument('--seconds',type=float,default=5)
    p.add_argument('--radius',type=int,choices=range(3,9),default=3)
    p.add_argument('--order',choices=('few_first','many_first'),default='few_first')
    p.add_argument('--atomic-only',action='store_true',help='Exclude one-blocker candidates and pairs sharing exactly two blockers; restricted search only.')
    a=p.parse_args();assert __debug__ and not a.output.exists() and 0<a.seconds<=600
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    source=json.loads(a.input.read_text());assert source['status']=='complete'
    assert len(a.indices)==len(set(a.indices)) and all(0<=i<len(source['bases']) for i in a.indices)
    universe=list(product(range(7),repeat=5));radius=a.radius
    report=dict(input=str(a.input),input_sha256=sha(a.input),source_sha256=sha(__file__),
                kernel_sha256=sha(HERE/'exchange_dfs'),kernel_source_sha256=sha(HERE/'exchange_dfs.cpp'),
                mask_source_sha256=sha(HERE/'run_seed_exchanges.py'),analysis_source_sha256=sha(HERE/'analyze_bipartite_trade.py'),seconds_per_query=a.seconds,radius=radius,order=a.order,atomic_only=a.atomic_only,
                indices=a.indices,rows=[],bases=[],candidates=[],status='running',scope=__doc__)
    seen=set();seen_candidates=set();began=time.monotonic()
    def save():
        report['seconds']=time.monotonic()-began
        temp=a.output.with_suffix('.tmp');temp.write_text(json.dumps(report,separators=(',',':'))+'\n');temp.replace(a.output)
    save()
    for bi in a.indices:
        ids=source['bases'][bi]['words'];assert len(ids)==len(set(ids))==366 and ids==sorted(ids)
        words=[universe[v] for v in ids];verify(words);masks=coordinate_masks(words);occupied=set(ids)
        outside=[(v,nearby(w,masks,366)) for v,w in enumerate(universe) if v not in occupied]
        assert all(b for v,b in outside),'Immediate extensions need separate handling'
        pool=sorted(((v,b) for v,b in outside if (2 if a.atomic_only else 1)<=b.bit_count()<=radius),key=lambda row:(-1 if a.order=='many_first' else 1)*row[1].bit_count())
        points=[universe[v] for v,b in pool];pm=coordinate_masks(points);full=(1<<len(pool))-1
        blockers=[b for v,b in pool];comp=[full^nearby(w,pm,len(pool)) for w in points]
        if a.atomic_only:
            # A perfect-matching trade can switch a sink SCC of size1 only
            # through a one-blocker word, and size2 only through two words
            # with the same exact blocker pair. Exclude those simple sinks.
            groups={}
            for i,b in enumerate(blockers):
                if b.bit_count()==2:groups[b]=groups.get(b,0)|(1<<i)
            for i,b in enumerate(blockers):
                if b.bit_count()==2:comp[i]&=~groups[b]
        encoded=graph_text(blockers,comp,radius,6)
        proc=subprocess.run([str(HERE/'exchange_dfs'),str(a.seconds),'--subset','--neutral'],input=encoded,text=True,capture_output=True,check=True,timeout=a.seconds+15)
        result=json.loads(proc.stdout);assert result['status'] in ('exhausted','timeout','output_limit')
        if result['status']=='exhausted':assert result['nodes_started']==result['nodes_completed']
        row=dict(base=bi,pool_ids=[v for v,b in pool],graph_sha256=hashlib.sha256(encoded.encode()).hexdigest(),
                 result=result,requires_wide_step=[],decomposable=0,union_improvements=[])
        report['rows'].append(row)
        for kind in ('neutral','improving'):
            for index,chosen in enumerate(result[kind]):
                assert len(chosen)==len(set(chosen))==radius and all(type(i) is int and 0<=i<len(pool) for i in chosen)
                used=0
                for i in chosen:used|=blockers[i]
                assert used.bit_count()<=radius and (used.bit_count()==radius)==(kind=='neutral')
                assert all(comp[i]>>j&1 for i,j in combinations(chosen,2))
                removed=[v for i,v in enumerate(ids) if used>>i&1];added=[pool[i][0] for i in chosen]
                new=tuple(sorted((occupied-set(removed))|set(added)))
                if kind=='neutral':
                    analysis=analyze_trade(removed,added,lambda u,v:not conflict(universe[u],universe[v]))
                    if analysis['matching_size']<radius:
                        row['union_improvements'].append(dict(native_index=index,analysis=analysis))
                        new=tuple(sorted((occupied-set(removed))|set(analysis['maximum'])))
                    else:
                        if a.atomic_only:assert analysis['minimum_step_width']>=3
                        if analysis['minimum_step_width']<=2:row['decomposable']+=1;continue
                        row['requires_wide_step'].append(index)
                        if new in seen:continue
                        checks=verify([universe[v] for v in new]);assert len(new)==366;seen.add(new)
                        report['bases'].append(dict(words=list(new),source_base=bi,native_index=index,removed=removed,added=added,analysis=analysis,pair_checks=checks))
                        continue
                if len(new)>366:
                    checks=verify([universe[v] for v in new]);assert len(new)>=367
                    if new in seen_candidates:continue
                    seen_candidates.add(new)
                    report['candidates'].append(dict(step=len(report['candidates']),source_base=bi,native_index=index,native_kind=kind,
                        words=[''.join(map(str,universe[v])) for v in new],size=len(new),pair_checks=checks))
                    if len(new)>=368:report['status']='verified_target';save();return
        save();print(json.dumps(dict(base=bi,status=result['status'],neutral=len(result['neutral']),improving=len(result['improving']),requires_wide_step=len(row['requires_wide_step']))),flush=True)
    report['status']='complete';report['enumeration_complete']=all(row['result']['status']=='exhausted' for row in report['rows']);save()


if __name__=='__main__':main()
