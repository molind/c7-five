"""Apply target-preserving cover pruning and exact cubic ranks to mixed domains."""
import argparse
from itertools import combinations
import json
from pathlib import Path
import time

from check_two_slice_covers import WORDS, closed, conflict
from check_cylinder_covers import check_entries
from probe_rank_branches import bound, CAPACITIES
from prune_cylinder_cover import exclusions


def digest(path):
    import hashlib
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, data):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(data, indent=2)+'\n')
    temp.replace(path)


def replay(report):
    rows = []
    for job in report['results']:
        source_path = Path(job['input'])
        assert digest(source_path) == job['input_sha256']
        source = json.loads(source_path.read_text())
        fixed = source['fixed']
        assert len(fixed) == len(set(fixed)) and all(not conflict(a, b) for a, b in combinations(fixed, 2))
        pool = sorted(set(range(16807))-set.union(*(set(closed(v)) for v in fixed)))
        assert pool == source['pool'] and job['target'] == 368-len(fixed)
        excluded = False
        for step in job['rounds']:
            assert not excluded and step['pool'] == pool
            total, den = check_entries(step['certificate'], pool, CAPACITIES)
            excluded = total < job['target']*den
            assert step['excludes368'] == excluded
            if excluded:
                assert step['removed'] == []
            else:
                expected = []
                for v in pool:
                    excess = sum(c['units'] for c in step['certificate']['cover'] if v in c['vertices'])-den
                    if excess > total-job['target']*den:
                        expected.append(dict(vertex=v, excess_units=excess))
                assert expected == step['removed']
                pool = sorted(set(pool)-{v['vertex'] for v in expected})
        assert job['final_pool'] == pool and job['excludes368'] == excluded
        rows.append(dict(index=source['index'], rounds=len(job['rounds']), original_pool=len(source['pool']),
            final_pool=len(pool), removed=len(source['pool'])-len(pool), excludes368=excluded))
    for candidate in report['candidates']:
        chosen = [int(w, 7) for w in candidate['words']]
        job = next(j for j in report['results'] if j['index'] == candidate['index'])
        original = json.loads(Path(job['input']).read_text())
        assert len(chosen) == len(set(chosen)) == candidate['size'] >= 367
        assert set(original['fixed']) <= set(chosen) <= set(original['fixed']+original['pool'])
        assert all(not conflict(a, b) for a, b in combinations(chosen, 2))
        assert candidate['verified_pairs'] == len(chosen)*(len(chosen)-1)//2
        assert not job['excludes368'] or len(chosen) < 368
    assert (report['status'] == 'candidate_found') == any(c['size'] >= 368 for c in report['candidates'])
    return dict(results=rows, cover_closed=sum(r['excludes368'] for r in rows),
        target_witness_found=any(c['size'] >= 368 for c in report['candidates']),
        scope='Pruning preserves every extension reaching368 in these exact fixed exteriors; no exclusion follows from an interrupted solver.')


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path, required=True)
    p.add_argument('--indices', type=int, nargs='+', default=[0, 2, 4, 5, 8, 12])
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--seconds', type=float, default=5)
    p.add_argument('--cubic-ms', type=int, default=50)
    p.add_argument('--rounds', type=int, default=3)
    p.add_argument('--verify', action='store_true')
    args = p.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    if args.seconds <= 0 or args.cubic_ms < 1 or args.rounds < 1:
        p.error('Positive limits required')
    source = json.loads(args.input.read_text())
    if args.verify:
        result = replay(source) | dict(input_sha256=digest(args.input), checker_sha256=digest(Path(__file__)))
        save(args.output, result)
        print(json.dumps(result), flush=True)
        return
    assert source['status'] == 'complete'
    summaries = {row['index']:row for row in source['results']}
    assert len(set(args.indices)) == len(args.indices) and set(args.indices) <= set(summaries)
    cache = {}
    began = time.monotonic()
    report = dict(status='running', input=str(args.input), input_sha256=digest(args.input),
        source_sha256=digest(Path(__file__)), results=[], candidates=[], requested_indices=args.indices,
        rounds_requested=args.rounds, seconds=args.seconds, cubic_ms=args.cubic_ms)
    save(args.output, report)
    for index in args.indices:
        path = Path(summaries[index]['file'])
        assert digest(path) == summaries[index]['sha256']
        row = json.loads(path.read_text())
        pool, certificate = row['pool'], row['certificate']
        job = dict(index=index, input=str(path), input_sha256=digest(path), target=368-len(row['fixed']),
            rounds=[], final_pool=pool, excludes368=False)
        report['results'].append(job)
        for iteration in range(args.rounds):
            total, den = check_entries(certificate, pool, CAPACITIES)
            excluded = total < job['target']*den
            removed = [] if excluded else exclusions(certificate, pool, job['target'])
            step = dict(pool=pool, certificate=certificate, removed=removed, excludes368=excluded)
            job['rounds'].append(step)
            pool = sorted(set(pool)-{v['vertex'] for v in removed})
            job.update(final_pool=pool, excludes368=excluded)
            report['elapsed_seconds'] = time.monotonic()-began
            save(args.output, report)
            print(json.dumps(dict(index=index, round=iteration, remaining=len(pool), removed=len(removed),
                full_upper=len(row['fixed'])+total//den, excludes368=excluded)), flush=True)
            if excluded or iteration+1 == args.rounds or (iteration > 0 and not removed):
                break
            stronger = bound(pool, cache, args.seconds, args.cubic_ms)
            step['next_lp'] = {k:v for k,v in stronger.items() if k not in ('pool', 'certificate', 'primal')}
            if 'certificate' not in stronger:
                save(args.output, report)
                break
            certificate = stronger['certificate']
            if all(abs(x-round(x)) < 1e-7 for _, x in stronger['primal']):
                chosen = sorted(row['fixed']+[v for v, x in stronger['primal'] if x > .5])
                assert all(not conflict(a, b) for a, b in combinations(chosen, 2))
                if len(chosen) >= 367:
                    report['candidates'].append(dict(index=index, step=iteration, size=len(chosen),
                        words=[''.join(map(str, WORDS[v])) for v in chosen], verified_pairs=len(chosen)*(len(chosen)-1)//2))
                if len(chosen) >= 368:
                    break
        if any(c['size'] >= 368 for c in report['candidates']):
            break
    report['status'] = 'candidate_found' if any(c['size'] >= 368 for c in report['candidates']) else 'complete'
    report['cubic_probes'] = list(cache.values())
    report['verification'] = replay(report)
    save(args.output, report)
    print(json.dumps(report['verification']), flush=True)


if __name__ == '__main__':
    main()
