"""Verify a completed state export, every parent move, and its coordinate energy."""
import argparse
from collections import Counter
import gzip
import hashlib
from itertools import product
import json
from pathlib import Path
import struct
import numpy as np


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('report', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    run = json.loads(args.report.read_text())
    assert run['status'] == 'exhausted'
    export = Path(run['states_export']['path'])
    assert hashlib.sha256(export.read_bytes()).hexdigest() == run['states_export']['sha256']
    coordinates = np.array(list(product(range(7), repeat=5)), dtype=np.int16)
    frequency = np.zeros(len(coordinates), dtype=np.int32)
    packed, energies, depths, lines = [], [], [], []
    energy_counts, distance_counts = Counter(), Counter()
    furthest, furthest_indices = -1, []
    with gzip.open(export, 'rt', encoding='ascii') as stream:
        header = json.loads(next(stream))
        assert header['format'] == 'c7-reachable-states-v1' and header['status'] == 'exhausted'
        assert header['count'] == run['states_discovered'] == run['states_popped']
        assert header['directed_edges'] == run['directed_transitions_examined']
        assert header['family'] == run['family'] and header['cap'] == run['cap']
        assert header['start_index'] == 0 and run['queued'] == 0
        for index, line in enumerate(stream):
            row = json.loads(line)
            assert row['index'] == index
            tokens = row['words'].split()
            assert len(tokens) == len(set(tokens)) == 368
            assert all(len(w) == 5 and set(w) <= set('0123456') for w in tokens)
            ids = tuple(int(w, 7) for w in tokens)
            assert ids == tuple(sorted(ids))
            current = set(ids)
            parent = row['parent']
            if index == 0:
                assert parent is None and tokens == run['start_words']
                start = current
                words = coordinates[list(ids)]
                diff = (words[:, None, :] - words[None, :, :]) % 7
                conflicts = np.all((diff == 0) | (diff == 1) | (diff == 6), axis=2)
                energy = int(np.triu(conflicts, 1).sum())
                depth = 0
            else:
                assert isinstance(parent, int) and 0 <= parent < index
                previous = set(struct.unpack('<368H', packed[parent]))
                removed, added = int(row['removed'], 7), int(row['added'], 7)
                assert previous - current == {removed} and current - previous == {added}
                retained = coordinates[sorted(previous - {removed})]
                diff = (coordinates[[removed, added], None, :] - retained[None, :, :]) % 7
                counts = np.all((diff == 0) | (diff == 1) | (diff == 6), axis=2).sum(axis=1)
                energy = energies[parent] - int(counts[0]) + int(counts[1])
                depth = depths[parent] + 1
            assert energy == row['energy'] and 0 <= energy <= header['cap']
            packed.append(struct.pack('<368H', *ids))
            energies.append(energy)
            depths.append(depth)
            lines.append((' '.join(tokens) + '\n').encode('ascii'))
            frequency[list(ids)] += 1
            energy_counts[energy] += 1
            distance = len(start - current)
            distance_counts[distance] += 1
            if distance > furthest:
                furthest, furthest_indices = distance, []
            if distance == furthest:
                furthest_indices.append(index)
    assert len(packed) == len(set(packed)) == header['count']
    digest = hashlib.sha256(b''.join(sorted(lines))).hexdigest()
    assert digest == header['states_sha256'] == run['states_sha256']
    fixed = np.flatnonzero(frequency == len(packed))
    result = dict(passed=True, states=len(packed), states_sha256=digest,
                  parent_moves_checked=len(packed)-1, states_by_energy=dict(energy_counts),
                  support_size=int(np.count_nonzero(frequency)),
                  fixed_words=[''.join(map(str, coordinates[i])) for i in fixed],
                  distance_from_start_histogram=dict(sorted(distance_counts.items())),
                  maximum_distance=furthest, furthest_state_indices=furthest_indices,
                  maximum_parent_depth=max(depths), export=str(export),
                  scope='All serialized states and parent energies checked directly; closure uses the recorded completed traversal, not a second successor census.')
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('fixed_words', 'furthest_state_indices')}))


if __name__ == '__main__':
    main()
