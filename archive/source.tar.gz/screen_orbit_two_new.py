"""Screen explicit transformed five-layer exteriors with exact projection covers."""
import argparse
from collections import Counter
import json
from pathlib import Path
import time

from check_orbit_two_new import digest, load_base, reconstruct, extend
from check_two_slice_covers import check_cover
from probe_slice_lp import build_cliques, solve_cover


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--seconds', type=float, default=2)
    args = p.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    if args.seconds <= 0:
        p.error('Positive time limit required')
    source = json.loads(args.input.read_text()); base = load_base(source)
    report = dict(status='running', input=str(args.input), input_sha256=digest(args.input),
        source_sha256=digest(__file__), helpers={n:digest(Path(__file__).with_name(n)) for n in
        ['check_orbit_two_new.py', 'probe_slice_lp.py', 'check_two_slice_covers.py']},
        results=[], candidates=[], seconds=args.seconds)
    began = time.monotonic()

    def save():
        report['elapsed_seconds'] = time.monotonic()-began
        tmp = args.output.with_suffix('.tmp')
        tmp.write_text(json.dumps(report, indent=2)+'\n'); tmp.replace(args.output)

    save()
    for i, job in enumerate(source['jobs']):
        assert job['index'] == i
        fixed, allowed, _ = reconstruct(job, base)
        pool = job['pool']; cliques = build_cliques(pool)
        cover = solve_cover(pool, cliques, None, args.seconds, method='highs-ipm', keep_primal=True)
        row = dict(index=i, cover=cover, excludes368=False)
        if cover['status'] == 'certified_cover':
            total, den = check_cover(cover, set(pool), {v:1 for v in pool})
            row.update(full_upper=job['path_size']+total//den, excludes368=total < job['target']*den)
            xs = cover['primal']
            if all(abs(x['value']-round(x['value'])) < 1e-7 for x in xs):
                selected = [x['vertex'] for x in xs if x['value'] > .5]
                words = extend(job, fixed, allowed, selected)
                row.update(selected=selected, words=words, full_size=len(words))
                if len(words) >= 368:
                    report['candidates'].append(dict(step=i, size=len(words), words=words,
                        verified_pairs=len(words)*(len(words)-1)//2))
        report['results'].append(row)
        if i % 10 == 0:
            save()
            print(json.dumps(dict(index=i, pool=len(pool), upper=row.get('full_upper'),
                closed=sum(r['excludes368'] for r in report['results']))), flush=True)
        if report['candidates']:
            break
    report['status'] = 'candidate_found' if report['candidates'] else 'complete'
    report['statistics'] = dict(Counter('closed' if r['excludes368'] else 'open' for r in report['results']))
    save(); print(json.dumps(dict(status=report['status'], statistics=report['statistics'],
        elapsed_seconds=report['elapsed_seconds'])), flush=True)


if __name__ == '__main__':
    main()
