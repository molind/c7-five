"""Check retained symmetry-screen graphs and their exact seven-walk maxima.

All 91 slice pairs at each recorded representative are rebuilt directly.
An independent max-plus matrix recurrence checks the weighted optimum.
Omitted FFT-screen translations are not certified by this checker.
"""
import argparse
from itertools import combinations
import hashlib
import json
from pathlib import Path

import numpy as np

from search_slice_symmetries import transforms


def main():
    if not __debug__:raise RuntimeError('Run without -O')
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--inputs',type=Path,nargs='+',required=True);p.add_argument('--output',type=Path,required=True)
    args=p.parse_args()
    if args.output.exists():raise FileExistsError(args.output)
    rows=[];total_graphs=0;found=False
    for path in args.inputs:
        r=json.loads(path.read_text());sp=Path(r['input']);vp=Path(r['verification'])
        assert hashlib.sha256(sp.read_bytes()).hexdigest()==r['input_sha256']
        assert hashlib.sha256(vp.read_bytes()).hexdigest()==r['verification_sha256']
        assert json.loads(vp.read_text())['input_sha256']==r['input_sha256']
        source=json.loads(sp.read_text());slices=source['slices'];parents=source['parents']
        assert r['status']in ('complete','budget_reached','candidate_found')
        if 'transforms'in r:
            records=r['transforms']
            assert [t['index']for t in records]==list(range(r['start'],r['start']+len(records)))
            assert len(records)<=r['count']
            if r['status']=='complete':assert len(records)==r['count']
        else:
            assert r['status']=='complete'and len(r['pairs'])==300
            records=[dict(index=None,permutation=list(range(4)),signs=[1]*4,hits=r['pairs'])]
        graphs=0;maxima=[]
        for rec in records:
            perm,signs=rec['permutation'],rec['signs']
            if rec['index']is not None:
                expected=transforms()[rec['index']];assert tuple(perm)==expected[0]and tuple(signs)==expected[1]
                if r['status']!='candidate_found':assert rec['pairs_processed']==325
                assert rec['distinct_graphs']==sum(len(h['graphs'])for h in rec['hits'])
            for hit in rec['hits']:
                pi,pj=hit['parents'];left=parents[pi]['slices'];right=parents[pj]['slices']
                assert 0<=pi<=pj<25
                seen=set()
                for g in hit['graphs']:
                    shift=g['first_shift'];assert len(shift)==4 and all(type(x)is int and 0<=x<7 for x in shift)
                    key=tuple(map(tuple,g['cross_edges']));assert key not in seen;seen.add(key)
                    actual=[np.array(slices[i],dtype=np.int16)for i in left]
                    actual += [np.array([[(signs[k]*w[perm[k]]+shift[k])%7 for k in range(4)]for w in slices[i]],dtype=np.int16)for i in right]
                    edges=set()
                    for i,j in combinations(range(14),2):
                        d=(actual[i][:,None,:]-actual[j][None,:,:])%7
                        if not np.any(np.all((d==0)|(d==1)|(d==6),axis=2)):edges.add((i,j))
                    assert sorted((i,j-7)for i,j in edges if i<7<=j)==[tuple(e)for e in g['cross_edges']]
                    expected_internal={(off+i,off+j)for off in (0,7)for i,j in combinations(range(7),2)if(i-j)%7 in (1,6)}
                    assert {(i,j)for i,j in edges if(i<7)==(j<7)}==expected_internal
                    weights=np.array([len(a)for a in actual],dtype=np.int64)
                    matrix=np.full((14,14),-100000,dtype=np.int64)
                    for i,j in edges:matrix[i,j]=weights[j];matrix[j,i]=weights[i]
                    power=np.full((14,14),-100000,dtype=np.int64);np.fill_diagonal(power,0)
                    for _ in range(7):power=np.max(power[:,:,None]+matrix[None,:,:],axis=1)
                    best=int(np.max(np.diag(power)));assert g['best']==best>=367
                    cycle=g['cycle'];assert len(cycle)==7 and all(type(v)is int and 0<=v<14 for v in cycle)
                    assert all(tuple(sorted((cycle[i],cycle[(i+1)%7])))in edges for i in range(7))
                    assert sum(int(weights[i])for i in cycle)==best
                    maxima.append(best);graphs+=1
        for c in r['candidates']:
            words=[tuple(map(int,w))for w in c['words']]
            assert len(words)==len(set(words))==c['size']>=368
            assert all(len(w)==5 and all(0<=x<7 for x in w)for w in words)
            array=np.array(words,dtype=np.int16);d=(array[:,None,:]-array[None,:,:])%7
            assert not np.any(np.triu(np.all((d==0)|(d==1)|(d==6),axis=2),k=1))
            assert c['verified_pairs']==len(words)*(len(words)-1)//2;found=True
        assert (r['status']=='candidate_found')==bool(r['candidates'])
        assert max(maxima,default=367)<368 or r['candidates']
        total_graphs+=graphs
        rows.append(dict(file=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
            retained_graphs_checked=graphs,direct_slice_pairs=91*graphs,best_retained_graph=max(maxima,default=367),
            numerical_filter_is_not_negative_certificate=True))
    result=dict(results=rows,total_graphs=total_graphs,target_witness_found=found,
        checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        scope='Recorded representative graphs and any returned368witness only; omitted FFT translations not certified.')
    args.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)


if __name__=='__main__':main()
