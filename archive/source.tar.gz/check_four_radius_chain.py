"""Check the certificate/input chain behind exhausted four-blocker radii.

Rechecks integer dual certificates and every exported native input row. Native
exhaustion is a result of the identified tested program, not a replayable proof
trace. The bound applies only to the exact saved reference and candidate pool.
"""
import argparse
import hashlib
import json
from pathlib import Path

from check_blocker_radius import check as check_radius


def check_chain(model, geometry, base_certificate, count_certificates, searches, kernels, sources):
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    read=lambda p:json.loads(Path(p).read_text())
    paths=[model,geometry,base_certificate]+count_certificates+searches+kernels+sources
    dependencies={str(p):sha(p) for p in paths}
    data=read(model);assert data['status']=='complete' and data['min_blockers']==1 and data['max_blockers']==4
    geom=read(geometry);assert geom['model_sha256']==sha(model)
    assert geom['checker_sha256']==sha(Path(__file__).with_name('check_blocker_trade_results.py'))
    assert len(kernels)==len(sources)>0
    allowed_programs={(sha(k),sha(s)) for k,s in zip(kernels,sources)}
    domains={d['base']:d for d in data['rows']}
    assert len(domains)==len(data['rows'])==len(geom['rows'])
    assert all(r['reference_size']==367 for r in geom['rows'])
    def certificate(path):
        cert=read(path);assert cert['status']=='complete' and cert['input_sha256']==sha(model)
        assert {r['base'] for r in cert['rows']}==set(domains)
        assert len(cert['rows'])==len(domains)
        return {r['base']:check_radius(r,domains[r['base']]) for r in cert['rows']}
    bounds=certificate(base_certificate)
    assert all('max_four_insertions' not in r for r in bounds.values())
    assert len(count_certificates)==len(searches)>0
    stages=[]
    for count_path,search_path in zip(count_certificates,searches):
        counts=certificate(count_path);run=read(search_path);radius=run['max_removals']
        assert type(radius) is int and 1<=radius<=9
        assert run['status']=='complete' and run['input_sha256']==sha(model)
        assert run['target_insertions']==radius+1 and not run['candidates']
        assert (run['kernel_sha256'],run['kernel_source_sha256']) in allowed_programs
        assert {r['base'] for r in run['rows']}==set(domains) and len(run['rows'])==len(domains)
        checked_rows=[]
        for row in run['rows']:
            bi=row['base'];d=domains[bi];c=counts[bi];previous=bounds[bi]
            assert previous['max_removals']==radius-1 and previous['integer_gain_upper']==0
            assert c['max_removals']>=radius and c['integer_gain_upper']==0
            need=c['minimum_four_insertions_for_gain']
            assert need==row['minimum_four_insertions'] and 1<=need<=radius+1
            pool=d['pool_ids'];blocked=d['blocker_sets'];n=len(pool)
            order=sorted(range(n),key=lambda i:(len(blocked[i])!=4,pool[i]))
            prefix=sum(len(b)==4 for b in blocked)
            assert row['kernel_order']==order and row['prefix']==prefix and row['rows_replayed']==n
            k=row['kernel_result']
            assert k['status']=='exhausted' and k['nodes_started']==k['nodes_completed']
            assert not k['chosen'] and not k['neutral'] and not k['improving']
            assert not k['enumerate_neutral'] and not k['noncore_bound'] and not k['pair_bounds']
            assert k['anchor_bounds'] and k['anchor_prefix']==prefix and k['root_prefix']==prefix
            graph=Path(row['graph']);assert sha(graph)==row['graph_sha256'];dependencies[str(graph)]=sha(graph)
            inverse={i:j for j,i in enumerate(order)};bad=[1<<j for j in range(n)]
            for u,v in d['conflict_edges']:
                i,j=inverse[u],inverse[v];bad[i]|=1<<j;bad[j]|=1<<i
            cw=(n+63)//64;full=(1<<n)-1
            with graph.open() as f:
                assert list(map(int,next(f).split()))==[n,6,radius]
                for j,i in enumerate(order):
                    words=[int(x,16) for x in next(f).split()];assert len(words)==6+cw
                    assert all(0<=v<1<<64 for v in words)
                    assert sum(v<<(64*w) for w,v in enumerate(words[:6]))==sum(1<<v for v in blocked[i])
                    assert sum(v<<(64*w) for w,v in enumerate(words[6:]))==full^bad[j]
                assert list(map(int,next(f).split()))==[need]*n and not f.read().strip()
            # Smaller positive trades use <=radius-1 old removals. Every
            # larger one contains a positive (radius+1)-insertion subtrade.
            bounds[bi]=dict(base=bi,max_removals=radius,integer_gain_upper=0)
            checked_rows.append(dict(base=bi,graph_rows=n,minimum_four=need,completed_nodes=k['nodes_completed']))
        stages.append(dict(radius=radius,rows=checked_rows))
    return dict(rows=[bounds[b] for b in sorted(bounds)],stages=stages,dependencies=dependencies)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for flag in ('model','geometry','base-certificate'):p.add_argument('--'+flag,required=True)
    for flag in ('count-certificates','searches','kernels','sources'):p.add_argument('--'+flag,required=True,nargs='+')
    p.add_argument('--output',required=True,type=Path)
    a=p.parse_args();assert __debug__ and not a.output.exists()
    inputs={k:v for k,v in vars(a).items() if k!='output'}
    result=check_chain(**inputs)
    out=dict(kind='exhaustive_radius_chain',inputs=inputs,checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
             radius_checker_sha256=hashlib.sha256(Path(__file__).with_name('check_blocker_radius.py').read_bytes()).hexdigest(),
             scope=__doc__,**result)
    a.output.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(rows=result['rows'],stages=len(result['stages']))))


if __name__=='__main__':main()
