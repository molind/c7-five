"""Check E exchange inputs directly from coordinates and bind completed runs."""
import argparse
import hashlib
from itertools import product
import json
from pathlib import Path

import numpy as np


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def packed64(values, words):
    data = np.packbits(values, bitorder='little').tobytes()
    return np.frombuffer(data+b'\0'*(8*words-len(data)), dtype='<u8')


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--inputs', type=Path, nargs='+', required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    root = Path(__file__).parent
    seed_path = root/'family-e-seed-words.txt'
    words = seed_path.read_text().split()
    seed = np.array([list(map(int, w)) for w in words], dtype=np.int16)
    assert seed.shape == (367, 5) and len(set(words)) == 367
    assert np.all((seed >= 0) & (seed < 7))
    d = (seed[:, None, :]-seed[None, :, :]) % 7
    assert not np.any(np.triu(np.all((d == 0) | (d == 1) | (d == 6), axis=2), 1))
    selected = set(map(tuple, seed.tolist()))
    outside = np.array([w for w in product(range(7), repeat=5) if w not in selected], dtype=np.int16)
    blocked = np.zeros((len(outside), 367), dtype=bool)
    for i in range(0, len(outside), 128):
        d = (outside[i:i+128, None, :]-seed[None, :, :]) % 7
        blocked[i:i+128] = np.all((d == 0) | (d == 1) | (d == 6), axis=2)
    counts = blocked.sum(axis=1)
    assert not np.any(counts == 0)
    rows = []
    for path in args.inputs:
        r = json.loads(path.read_text())
        assert r['status'] == 'complete' and r['candidates'] == []
        assert r['seed_sha256'] == sha(seed_path)
        assert r['token_sha256'] == hashlib.sha256(' '.join(words).encode()).hexdigest()
        assert r['kernel_sha256'] == sha(root/'exchange_dfs')
        assert r['kernel_source_sha256'] == sha(root/'exchange_dfs.cpp')
        assert r['exporter_sha256'] == sha(root/'export_exchange_graph.py')
        for run in r['results']:
            radius = run['radius']
            assert 2 <= radius <= 6
            chosen = sorted((i for i, n in enumerate(counts) if n <= radius), key=lambda i: int(counts[i]))
            pool = outside[chosen]
            graph = Path(run['input'])
            assert sha(graph) == run['input_sha256']
            with graph.open() as f:
                n, bw, saved_radius = map(int, next(f).split())
                assert n == len(pool) == run['candidates'] and bw == 6 and saved_radius == radius
                cw = (n+63)//64
                for i in range(n):
                    values = [int(x, 16) for x in next(f).split()]
                    assert len(values) == bw+cw
                    assert np.array_equal(np.array(values[:bw], dtype=np.uint64), packed64(blocked[chosen[i]], bw))
                    delta = (pool-pool[i]) % 7
                    compatible = ~np.all((delta == 0) | (delta == 1) | (delta == 6), axis=1)
                    assert np.array_equal(np.array(values[bw:], dtype=np.uint64), packed64(compatible, cw))
                assert not f.read().strip()
            result = run['result']
            assert result['status'] == 'exhausted' and result['nodes_started'] == result['nodes_completed'] > 0
            assert result['chosen'] == [] and result['subset_index']
            assert result['root_prefix'] == -1
            assert not any(result[k] for k in ('noncore_bound', 'enumerate_neutral', 'anchor_bounds', 'pair_bounds'))
            rows.append(dict(radius=radius, pool=n, all_blocker_rows=n, all_compatibility_rows=n,
                direct_compatibility_pairs_including_diagonal=n*n, nodes=result['nodes_completed'],
                graph_sha256=sha(graph), run_file=str(path), run_file_sha256=sha(path), exhausted=True))
            print(json.dumps(dict(radius=radius, pool=n, input_rebuilt=True, exhausted=True)), flush=True)
    assert sorted(row['radius'] for row in rows) == [2, 3, 4, 5, 6]
    report = dict(seed_sha256=sha(seed_path), checker_sha256=sha(Path(__file__)),
        kernel_sha256=sha(root/'exchange_dfs'), results=rows,
        outside_blocker_pair_checks=len(outside)*367,
        immediate_augmentation=False,
        scope='All radius2..6 input graphs directly rebuilt and bound to completed pinned-C++ traversals. With the separate radius1 component check, no improving exchange deleting at most6words from this exact E seed. No global bound.')
    args.output.write_text(json.dumps(report, indent=2)+'\n')


if __name__ == '__main__':
    main()
