"""Retain a best genuinely cross-parent seven-cycle from checked slice graphs."""
import argparse
import hashlib
from itertools import combinations
import json
from pathlib import Path

from search_slice_library import conflicts


def best_mixed(weights,adj):
    best=-1;cycle=[]
    for start in range(7):
        dp={(start,1):(weights[start],[start])}
        for _ in range(6):
            nxt={}
            for (u,mask),(score,path)in dp.items():
                for v in sorted(adj[u]):
                    key=(v,mask|(1 if v<7 else 2));value=score+weights[v]
                    if value>nxt.get(key,(-1,[]))[0]:nxt[key]=(value,path+[v])
            dp=nxt
        for (end,mask),(score,path)in dp.items():
            if mask==3 and start in adj[end]and score>best:best,cycle=score,path
    return best,cycle


def main():
    if not __debug__:raise RuntimeError('Run without -O')
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--verification',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    args=p.parse_args()
    if args.output.exists():raise FileExistsError(args.output)
    checked=json.loads(args.verification.read_text());candidates=[];rows=[]
    for entry in checked['results']:
        path=Path(entry['file']);assert hashlib.sha256(path.read_bytes()).hexdigest()==entry['sha256']
        r=json.loads(path.read_text());source=json.loads(Path(r['input']).read_text())
        assert hashlib.sha256(Path(r['input']).read_bytes()).hexdigest()==r['input_sha256']
        for t in r['transforms']:
            perm,signs=t['permutation'],t['signs']
            for h in t['hits']:
                pi,pj=h['parents'];a,b=source['parents'][pi],source['parents'][pj]
                if a['parent']==b['parent']:continue
                ids=a['slices']+b['slices'];weights=[source['weights'][i]for i in ids]
                for gi,g in enumerate(h['graphs']):
                    adj=[set()for _ in range(14)]
                    for off in (0,7):
                        for i in range(7):adj[off+i].update([off+(i-1)%7,off+(i+1)%7])
                    for i,j in g['cross_edges']:adj[i].add(7+j);adj[7+j].add(i)
                    best,cycle=best_mixed(weights,adj)
                    row=dict(source=str(path),transform=t['index'],parents=h['parents'],families=[a['parent'],b['parent']],graph=gi,best_mixed=best)
                    rows.append(row)
                    if best<367:continue
                    assert best==367
                    shift=g['first_shift'];slices=source['slices']
                    choices=[slices[i]for i in a['slices']]+[[tuple((signs[k]*w[perm[k]]+shift[k])%7 for k in range(4))for w in slices[i]]for i in b['slices']]
                    words=sorted((layer,*w)for layer,i in enumerate(cycle)for w in choices[i])
                    assert len(words)==len(set(words))==best and all(not conflicts(u,v)for u,v in combinations(words,2))
                    candidates.append(dict(step=len(rows)-1,size=best,words=[''.join(map(str,w))for w in words],verified_pairs=67161,
                        cycle=cycle,transform=t['index'],parents=h['parents'],families=row['families'],shift=shift))
    report=dict(status='complete',verification=str(args.verification),verification_sha256=hashlib.sha256(args.verification.read_bytes()).hexdigest(),
        source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=rows,candidates=candidates,
        scope='One maximum mixed witness per retained graph with distinct family labels; candidates still need orbit classification.')
    args.output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(dict(graphs=len(rows),candidates=len(candidates),families=[c['families']for c in candidates])),flush=True)


if __name__=='__main__':main()
