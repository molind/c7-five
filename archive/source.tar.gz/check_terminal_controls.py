"""Independent brute-force controls for weighted block searches."""

import contextlib
import io
import itertools
import json
import random
import time

from search_compositions import coefficients
from search_terminal import (LABELS, ROOT, independent_above, load_inputs,
                             search_exchanges, separated, verify_code, weight)


def main():
    rng = random.Random(20260915)
    words = [(c,) for c in LABELS]
    independent = [list(s) for k in range(1, 8)
                   for s in itertools.combinations(words, k)
                   if all(separated(a, b) for a, b in itertools.combinations(s, 2))]
    comparisons = positives = negatives = 0
    for trial in range(3):
        profile = [rng.randrange(1, 30) * 2**100 + rng.randrange(1, 100)
                   for _ in LABELS]
        values = [sum(profile[LABELS.index(w[0])] for w in s) for s in independent]
        for code in independent:
            before = set(code)
            baseline = sum(profile[LABELS.index(w[0])] for w in code)
            expected = any(value > baseline and len(before - set(target)) <= 2
                           for target, value in zip(independent, values))
            with contextlib.redirect_stdout(io.StringIO()):
                result = search_exchanges(code, [profile], 2, 5)
            actual = "new_cardinality" in result
            assert actual == expected, (trial, code, result)
            assert all(x["status"] != "timeout" for x in result["radii"])
            comparisons += 1
            positives += actual
            negatives += not actual

    # Test the branch-and-bound solver on unrelated random graphs and huge
    # weights, not just graphs produced by the block-search implementation.
    graph_checks = 0
    for _ in range(30):
        n = 8
        conflicts = {v: set() for v in range(n)}
        for v, u in itertools.combinations(range(n), 2):
            if rng.randrange(2):
                conflicts[v].add(u)
                conflicts[u].add(v)
        weights = [rng.randrange(1, 30) * 2**300 + rng.randrange(100) for _ in range(n)]
        optimum = max(sum(weights[v] for v in range(n) if mask & (1 << v))
                      for mask in range(1 << n)
                      if all(not (mask & (1 << v) and mask & (1 << u))
                             for v in range(n) for u in conflicts[v]))
        for threshold in (optimum - 1, optimum, optimum + 1):
            answer = independent_above(list(range(n)), conflicts, weights,
                                       threshold, time.monotonic() + 5)
            assert (answer is not None) == (threshold < optimum)
            graph_checks += 1

    bpz, claims, profile = load_inputs()
    code = bpz.K4a
    for axis in range(4):
        coeff = coefficients(code, [profile]*4, axis)
        altered = [profile]*4
        altered[axis] = bpz.sigma_vector(profile)
        assert sum(a*b for a,b in zip(coeff, altered[axis])) == verify_code(code, altered)
    bad_codes = [[("B",), ("B",)], [("B",), ("N",)], [("?",)]]
    for code in bad_codes:
        try:
            verify_code(code, [profile])
        except ValueError:
            continue
        raise AssertionError(code)
    report = {"passed": True, "weighted_exchange_comparisons": comparisons,
              "positive": positives, "negative": negatives,
              "random_weighted_graph_queries": graph_checks,
              "coordinate_coefficient_checks": 4, "invalid_codes_rejected": 3}
    (ROOT/"terminal-control-results.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps(report,indent=2))


if __name__ == "__main__":
    main()
