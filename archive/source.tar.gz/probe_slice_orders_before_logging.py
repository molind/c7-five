"""Test verified closed-neighborhood domination and orderings on open slabs."""
import argparse
import hashlib
from itertools import combinations
import json
from pathlib import Path
import random
import time

from search_slices import HERE, build_pool, kernel
from search_exchanges import graph_data, verify


def reduce_domination(adj, hint):
    """Delete v when N[u] is a subset of N[v], replacing hinted v by u.

    Closed neighborhoods are intersected with the current remaining vertices.
    Every maximum independent-set size is preserved; returned vertices retain
    original graph IDs and witnesses expand by identity (no invented vertices).
    """
    closed=[sum(1<<u for u in ns)|(1<<v) for v,ns in enumerate(adj)]
    active=(1<<len(adj))-1;chosen=set(hint);steps=[]
    while True:
        changed=False
        for v in range(len(adj)):
            if not(active>>v&1):continue
            nv=closed[v]&active
            for u in adj[v]:
                if not(active>>u&1):continue
                nu=closed[u]&active
                if nu&~nv==0:
                    assert u!=v and active>>u&1 and active>>v&1
                    if v in chosen:
                        assert u not in chosen
                        chosen.remove(v);chosen.add(u)
                    active^=1<<v;steps.append([v,u]);changed=True;break
        if not changed:break
    kept=[v for v in range(len(adj)) if active>>v&1]
    assert len(chosen)==len(hint) and chosen<=set(kept)
    assert not any(v in adj[u] for u,v in combinations(chosen,2))
    return kept,chosen,steps


def controls():
    rng=random.Random(20260921);cases=0
    for n in range(1,11):
        for trial in range(20):
            adj=[[] for _ in range(n)]
            for u,v in combinations(range(n),2):
                if rng.random()<trial/20:adj[u].append(v);adj[v].append(u)
            independent=[mask for mask in range(1<<n) if all(not(mask>>u&1 and mask>>v&1) for u,v in combinations(range(n),2) if v in adj[u])]
            optimum=max(m.bit_count() for m in independent)
            hint={i for i in range(n) if independent[-1]>>i&1}
            kept,chosen,steps=reduce_domination(adj,hint)
            active=set(range(n))
            for v,u in steps:
                assert ({u}|set(adj[u]))&active <= ({v}|set(adj[v]))&active
                active.remove(v)
            assert active==set(kept)
            mask=sum(1<<v for v in kept)
            assert max(m.bit_count() for m in independent if m&~mask==0)==optimum
            cases+=1
    return {'brute_force_graphs':cases,'all_reduction_steps_checked':True}


def main():
    if not __debug__:raise RuntimeError('Run without -O')
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--seconds',type=float,default=5)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    if args.seconds<=0:parser.error('positive budget required')
    if args.output.exists():raise FileExistsError(args.output)
    report={'controls':controls(),'results':[],'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    binary=HERE/'slice_clique'
    report['kernel_binary_sha256']=hashlib.sha256(binary.read_bytes()).hexdigest()
    words=[list(map(int,w)) for w in (HERE/'family-d-seed-words.txt').read_text().split()]
    report['input_sha256']=hashlib.sha256((HERE/'family-d-seed-words.txt').read_bytes()).hexdigest()
    vertices,ids,blockers,_=graph_data(words);verify(words)
    for start in (3,4,5):
        fixed,pool,adj,hint=build_pool(words,vertices,ids,blockers,0,start,2)
        kept,mapped,steps=reduce_domination(adj,hint)
        for mode in ('original','reduced_degree_ascending','reduced_degree_descending'):
            order=list(range(len(pool))) if mode=='original' else sorted(kept,key=lambda v:(len(set(adj[v])&set(kept)),v),reverse=mode.endswith('descending'))
            local={v:i for i,v in enumerate(order)}
            small=[[local[v] for v in adj[u] if v in local] for u in order]
            small_hint=sorted(local[v] for v in (hint if mode=='original' else mapped))
            result=kernel(binary,small,small_hint,len(hint)+1,args.seconds)
            selected=[pool[order[v]] for v in result['vertices']]
            solution=fixed+[vertices[v].tolist() for v in selected];verify(solution)
            assert len(solution)==len(fixed)+result['best_size']
            row={'start':start,'axis':0,'width':2,'mode':mode,'pool':pool,'order':order,
                 'reductions':[] if mode=='original' else steps,'result':result,
                 'full_size':len(solution),'seconds_limit':args.seconds}
            report['results'].append(row)
            if len(solution)>367:row['words']=solution
            tmp=args.output.with_name(args.output.name+'.tmp');tmp.write_text(json.dumps(report,indent=2)+'\n');tmp.replace(args.output)
            print(json.dumps({'start':start,'mode':mode,'vertices':len(order),'status':result['status'],'nodes':result['nodes'],'seconds':result['seconds'],'size':len(solution)}),flush=True)
            if len(solution)>367:return


if __name__=='__main__':main()
