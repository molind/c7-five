"""Rebuild a saved slice library and check every compatibility pair directly."""
import argparse
from collections import Counter
import gzip
import hashlib
from itertools import combinations
import json
from pathlib import Path
import struct

from search_slice_library import cycle_optimum


def compatible(a,b):
    return any((x-y)%7 in (2,3,4,5)for x,y in zip(a,b))


def check(r):
    expected=set()
    seeds={}
    for label,entry in r['files'].items():
        path=Path(entry['file'])
        assert hashlib.sha256(path.read_bytes()).hexdigest()==entry['sha256']
        words=[tuple(map(int,w))for w in path.read_text().split()]
        assert len(words)==len(set(words))==367
        assert all(compatible(a,b)for a,b in combinations(words,2))
        seeds[label]=words
        for axis in range(5):
            expected.update(tuple(sorted(w[:axis]+w[axis+1:]for w in words if w[axis]==value))for value in range(7))
    for c in r.get('components',[]):
        path=Path(c['file']);assert hashlib.sha256(path.read_bytes()).hexdigest()==c['sha256']
        with gzip.open(path,'rt')as handle:
            meta=json.loads(next(handle));states=[json.loads(line)for line in handle]
        assert len(states)==c['states'] and all(len(s)==len(set(s))==367 for s in states)
        assert hashlib.sha256(b''.join(sorted(struct.pack('<367H',*sorted(s))for s in states))).hexdigest()==c['component_sha256']==meta['component_sha256']
        perm,signs,shift=c['permutation'],c['signs'],c['shift'];axis=c['axis']
        assert sorted(perm)==list(range(5)) and len(signs)==len(shift)==5
        assert all(s in (-1,1)for s in signs)and all(type(v)is int and 0<=v<7 for v in shift)
        for state in states:
            layers=[[]for _ in range(7)]
            for v in state:
                assert type(v)is int and 0<=v<7**5
                w=tuple(v//7**i%7 for i in range(4,-1,-1))
                w=tuple((signs[i]*w[perm[i]]+shift[i])%7 for i in range(5))
                layers[w[axis]].append(w[:axis]+w[axis+1:])
            expected.update(tuple(sorted(layer))for layer in layers)
    slices=[tuple(map(tuple,s))for s in r['slices']]
    assert len(slices)==len(set(slices)) and set(slices)==expected
    for s in slices:
        assert s and len(s)==len(set(s))
        assert all(len(w)==4 and all(type(x)is int and 0<=x<7 for x in w)for w in s)
        assert all(compatible(a,b)for a,b in combinations(s,2))
    adjacency=[set(ns)for ns in r['adjacency']]
    assert len(adjacency)==len(slices)
    for i,ns in enumerate(adjacency):
        assert len(ns)==len(r['adjacency'][i])and i not in ns and all(0<=j<len(slices)for j in ns)
    pairs=0
    for i,a in enumerate(slices):
        for j in range(i):
            edge=all(compatible(x,y)for x in a for y in slices[j])
            assert edge==(j in adjacency[i])==(i in adjacency[j])
            pairs+=1
    weights=list(map(len,slices));assert r['weights']==weights
    for parent in r['parents']:
        axis=parent['axis'];ids=parent['slices'];words=seeds[parent['parent']]
        assert len(ids)==7
        for value,i in enumerate(ids):assert slices[i]==tuple(sorted(w[:axis]+w[axis+1:]for w in words if w[axis]==value))
    best,cycle=cycle_optimum(weights,r['adjacency'])
    assert best==r['best'] and cycle==r['cycle']
    full=sorted((layer,*w)for layer,i in enumerate(cycle)for w in slices[i])
    assert len(full)==len(set(full))==best and all(compatible(a,b)for a,b in combinations(full,2))
    assert r['candidates']==[dict(step=0,size=best,words=[''.join(map(str,w))for w in full],verified_pairs=best*(best-1)//2)]
    assert r['status']==('candidate_found'if best>=368 else 'complete')
    assert r['stats']==dict(slices=len(slices),compatibility_edges=sum(map(len,adjacency))//2,
        degree_histogram={str(k):v for k,v in Counter(map(len,adjacency)).items()},slice_sizes={str(k):v for k,v in Counter(weights).items()})
    return dict(slices=len(slices),direct_compatibility_pairs=pairs,edges=sum(map(len,adjacency))//2,
        parents_reconstructed=len(r['parents']),library_optimum=best,verified_witness_pairs=best*(best-1)//2,
        target_witness_found=best>=368,scope='Saved library only; no global upper bound. DP also has separate small-graph exhaustive controls.')


def main():
    if not __debug__:raise RuntimeError('Run without -O')
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    args=p.parse_args()
    if args.output.exists():raise FileExistsError(args.output)
    result=check(json.loads(args.input.read_text()))
    result.update(input_sha256=hashlib.sha256(args.input.read_bytes()).hexdigest(),checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    args.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)


if __name__=='__main__':main()
