# Save the published U2 certificate as u2.py; run without -O.
from pathlib import Path
from itertools import product
import base64,contextlib,hashlib,io,runpy,struct,sys,zlib
if not __debug__:raise RuntimeError('Run without -O')
with contextlib.redirect_stdout(io.StringIO()):
    c=runpy.run_path(sys.argv[1])
anchor=(2,2,3,5,0)
assert anchor not in c['U2']
allowed={w for w in c['U2'] if any((x-y)%7 in (2,3,4,5) for x,y in zip(anchor,w))}
assert len(allowed)==2214
DATA='c-l3XX>^sv8OQ%K?_IMm+$@BI1QJPz4G2VB!luDmViZi#t0F2&T%w$VP(@mCLje`*hM=}qMXPba^(a<c8aax9>p4|WYNJ-AA8ZM<s8zAQXP_VE%)HM$^X%KbNo8GJdt6ej@=|P=-q9a)f=la1H(Xnk4}1vlvo$74saXkq=^J&dlKKezPc>XkoDb71ReF1$uUYP7bvmy?;ODDGSGyd2%XtIz?(i*|55Ik^E97)Ms|xrY@6-XkHx*Y5*dFK>`;>mJ0u@GO(2XhSO4I|LEh^R{%F}O@R-XnTe<2bl)aWA}sT^P_P3OMX=c(M~fgjhItWFmx?VLVyG33Z-fH$|mYZCiBjnG-(e8Bk!Xbh-|Hx9ibz2#Cmo;OEvmr$j~BIg{m?njoJIp63C^r*{M3Eu~Sza0%cG|G`D0(Py+^c~i?3HUvHPlaxoZ`SXSd!4J+2H?58SjAe&i$1>FInMy^ZB?innT_Xj$Z#RBgSj68tOeZpeD@%CIWksgu)2K?K609?T3rSFGVJ_{inKzddJ3OLz^+jSo0aH9SFU0BeLVOxTmu%**Jxi3t+eK`mVkYyuhSXuo`&2Ny#0jpBKDDdw_y7Rut+<)rQm-!Hh2+QM`HgQT^;dJpyf!o&W+O3-uzNWG&oHoHa>#JUx=&o_<jk_efTRU;E&WTJ}HM>&G4u~&sDBNKXJZ~HIcXfz;-q8{T_OIvD|&cT`P39Mn|wR#7YV4U_6>a^MscBCarXhz`P!W#%K-G0`PD4ZNym}@K#;#j|g@<8XH{Z>d_$rJ`Ou2)Z+%}5bXFcG9QWUM<Lr)$dPt~$pfc9VXJSTdx7eS%M|evV;{`>xTgCOy^FM;a34pO_3Ulf>0{oVgxyYuUmyE?B(>ZzdZV%Bo6x)*KEtt51Nn2d8>TDac``AafzFM{ajvV>AoAvG?pK?<*y<ACyNS_f91+D`26@WxSvl`kz&GoPlneeEq*=-8@rCG{hIg)tBCoB`?t$l-$T@&4PvHy8gAaLg1^JeBBXl{QY9j{~D^m-0X@$<Etl#=HHZ0LnWH>Iwv(stFRmJ`Z_lwzQV+-^7YQFbD?;hlO5!?;fxB=Kh__B-dWypFL`@dDKC;ZId(^rV$_t0jvH{V2Bj6KePS0{MCm(?4O&ttmV=ZDx?hwu7;y@yWu&^{5q4XkEln$7-!`5Rk5z<vV$Iu#vzI4=P=i)>B4Ry*Yn)WtNim^{Ndr?lP2sUyd5J_tL-RmfYzNrQ7Q%XrQ8H6iAjiS2E&{B-&|tCcue5anrvKRv`)J+K;R{1p6f95mwONK83?l$zKT8>->>X@i>{;@a$Pb?b5{%_Ek7;QS)|Z{pmqoKR=BVaM}{;~$_k7X6PV>Zju0CB)Qh;^tCUtgJU(4%d3(rVyKs1b3pW)+XT(Kj_Yr#dcg*dW-ow9S)Bv@G8Y`=VJdlaPCImnecoIxYfOBu9TXa3mvPmIbaOZTJqp};^SLnd6o)xG0^eo``^H$ig=9ZJ273v-UVzSc=uzoXUsRm>|^+I6?gr}^945P26uzAxN`cD^@1!PhjJfT$IvO<Z3AZq-`&u9+*wV`5GRpNLAJHfn+xA+=R({SL3b>*ub;c^+}#aLPi>w?44sA?*MZlCzTL$CG<5$X{Q7yfly^(nFDBotek^j9mocsI`_JRyJ%;F8fS0#m+XDL0!{BW}7VAk}zDOJ05OA7^)wCL+|FkTR8?bFW#P@&T)edYVnpKh)>#%b#F|``}7m)2yWNh-e#6tu;p@*?+7kT&#-lSbKei*N2Y@-+%LR@^{hiEc*pE=9nA?Rm4FJD{1X@f^g$nAK@xuLpMBZ-+saG!`g&k?B`qXOPe=Dw8r`x<*ekg<bWaFVaqgpe-<)b#`s9?v;XuR~WcM;urT9YznbxE?`NTK{TNKDI3j`I)3Xc(ssUd*RpNs<e*p<FL!Ket$fA@Rp-%9saYqU}u!CLqiX%3Awq`S^q849q3*Pzbw8PASPy$54F5+;dTY@*J6u_)bPK;a~AL`fiH!QBR_^>(>cgE1>H^W_o=BB*!(N*&%st*=vhx(u1Cj0?A3_wKeC_fj88fJZ!kD%`hEuOs6W)16Um)6cv$W%!EaYHEqsBTS^Q81tq$lWRUT~rCGU2*GUQF*=Za8Arqdm)Z{LNjlHA<|zSX2M`0hiWsl3j@=U>btZOF5mIG8}q%mDu<`V~X#QCADCqv$1rL%rHxPi$3Cw_?<cv|4>>;I{+%<;dADi<e%lh-Rvtx^)vaxCq<ta#laO54_JF=(`1>wky^U`gIl?bi(V`*smA87kksCh<I=Z-sj`vp<yowd#%P{XX{71$;G+owU_V3zJdOcOFmfdNQL>Vg`Dg}&rUS!MDBqw^Ck5%dM=~ipMo4~s5P6>%W~oM;75C3t-~V6tZ8S5&GLxn6n!?X*L-n^)9J|GLkukTF=|kf{PpmmcSgyO`|m>2YTFI?;#!+MET53Ih*|X;WT~W{jsb5wYbU*X7WiiYuf`9{!VK!6T~E$e1%9b$5;#8C{TS|N;nh1?WyJrlf{Z@sR^kVd^KtH(i`d@^wup0=iwz1mrFE_!gWfT{O+G9mei!>+2Hz~;_A6xqk3#5-#QvW<t0{3}Dy|{q$+yV(tUnZ-YF6WcI#3(<w?_ws{Q4d}Ut-;h49C(rOUQ*@Z}ZD#?58o;j^n<T`Mn%{ZQiNF_bKL%X7&VfS|1x5<mhp^VXvUBRO7$r;6KY{Ld|%B%-KaQTL0e2d~huGAAsI!@UqCh8F&XWbh{>Ms`;f_%aL;rv*sM&AKMJ=_Rk7`gTq`|Pbh&-W$1|;@zL$r`c!Q7GWF?JU>2L_AZtySPa^8xFy;CL_0ut{r8JfOR&WQxd`RCQAKHLD;?m)F)C_vxcf`djz>e~j%w#q*R;e*`!94ns)uIfNdR7i{#K_QG-Ohc2)y5hH{y6S$#y7Vi?;K>gz_)4*@><<o2u>IMq>i}la28KPnWe2Z7iv;8BFq_^Wc4DU40Y6I=9So|op@RwdQXi0LSLkpYys~vVC_if!ONp|R^X$#$oeXFu-=vh&wP`N>fn&ecPYKHIOMqfUVOqO1D!r9WtNzmAj|Vy_B`+l^dSDcgZ+E(GH7Z&XA*hT7i^eAohlA>{0(e2$>oLlraSyDm>GVvS?u=u@zA!otY<G!jvGT9)~m*uKKBFv88|-7x7L>w!}hTm&`6Sh6G9AZMz0%?X%4W>c=$<pOhw<X!f$|l{aNYI!;6r5hO^(8wL#ZDV4e7W6n0y}`E#`BN8ereav`!@f}MBsy$!!L*&G7>cfi{TuPbaOr&d1$e7v{$#^J+wh{aX()JAYGX4&s$v&$N4?$rUOR8P`N40kGb8T-u%txx%W9J}=pJM%f$G1D2J9mrt4$!5pyFl#252W<XH(%<s&OpadVJQ*5?fcGHuHi36Kux|pL0(|Q9MwrDTVkv>X#5HRTzB7G$`8~cFncl=c`>^%LA#RdkPRU}&Gw|~v(2wX*R#R6nrz}L)HFRA2uV6LuT#p<(z_~Eg>Qs35A>Z$#?^^i0%>8C^rpabb-rN>uyFz`<zQI}S7h%V^Hi5GhS;~037g;BRKZSEIIuwK7WV2Z4=dmzrKF|GHmkjmZep|myUD-s1J`ee)@O$za+1p~>=BvVf5&7^CcApg4{|m`5i(ZG$7a;d_*z*zAaPlb&&qdy5vzcMOvYt93`oC^9p|4s`w7O!r&xe@LC3YM5ooBy+W5jTRxUVFh;-RJt@+Bc36iYC#T0H*`FB~cS'
raw=zlib.decompress(base64.b85decode(DATA))
assert len(raw)==4516 and hashlib.sha256(raw).hexdigest()=='d51ddc3583a3c2850fb8fc5e0de4d76c641ccd4eacb86aef6c52e332577276b4'
coverage=dict.fromkeys(allowed,0);total=0;index=0;seen=set()
for delta,units in struct.iter_unpack('<HH',raw):
    index+=delta
    assert index<len(c['W']) and index not in seen and units>0
    seen.add(index);total+=units
    for w in product(*[(x,(x+1)%7) for x in c['W'][index]]):
        if w in coverage:coverage[w]+=units
assert len(seen)==1129 and min(coverage.values())>=1024
assert total==374376 and total<366*1024
print('2214 vertices;1129 boxes;weight374376/1024<366;alpha(V(22350))<=365.')
print('Any 368-set containing 22350 needs at least3 words outside U2, including 22350.')
