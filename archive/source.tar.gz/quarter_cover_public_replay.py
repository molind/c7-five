import one_core_cover_replay as p
from itertools import product
items = '43615:4 04506:4 24606:4 43505:4 04405:3 15520:4 34560:4 43614:4 64466:4 64556:4 00520:4 06526:4 26626:4 23613:4 24466:4 23514:4 44524:4 63565:4 06620:4 25026:4 16120:4 44466:4 54624:4 04514:4 15606:4 14561:4 33024:4 44660:4 64415:1 54425:3 63546:4 65530:4 62216:4 10126:4 04010:4 13414:1 12424:4 13015:4 44424:1 64016:4 64236:4 10025:4 11224:4 12511:4 04162:4 15156:4 14522:4 14135:4 25206:4 26225:4 26646:4 26425:4 24061:4 35665:4 40665:4 41515:4 33436:4 43413:4 44561:4 55666:4 63403:4 54111:4 54203:4'
i=p.core.index(p.ID((5,4,5,6,2)))
kept=((1<<308)-1)^(1<<i)
coverage={v:0 for v,m in enumerate(p.blocked) if not m&kept}
total=0
for item in items.split():
 text,n=item.split(':');n=int(n);total+=n
 for w in product(*[(int(x),(int(x)+1)%7) for x in text]):
  v=p.ID(w)
  if v in coverage:coverage[v]+=n
assert total==241 and all(n>=4 for n in coverage.values())
print('Quarter-weight certificate verified:',total,'/4 < 61')
