"""Compare matching/SCC trade analysis with exhaustive independent subsets."""
import argparse
from collections import Counter
import hashlib
from itertools import combinations
import json
from pathlib import Path
import random

from analyze_bipartite_trade import analyze_trade


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();assert __debug__ and not a.output.exists()
    rng=random.Random(2026092120);totals=Counter();cases=0
    for r in range(1,7):
        for trial in range(160):
            edges={(i,j) for i in range(r) for j in range(r,2*r) if rng.random()<(trial%5+1)/6}
            compatible=lambda i,j:tuple(sorted((i,j))) not in edges
            result=analyze_trade(list(range(r)),list(range(r,2*r)),compatible)
            assert len(result['matching'])==result['matching_size']
            assert len({x for pair in result['matching'] for x in pair})==2*len(result['matching'])
            assert all(tuple(sorted(pair)) in edges for pair in result['matching'])
            independent=[]
            masks=[(1<<i)|(1<<j) for i,j in edges]
            for mask in range(1<<(2*r)):
                if all(mask&edge!=edge for edge in masks):independent.append(mask)
            maximum=max(map(int.bit_count,independent));assert len(result['maximum'])==maximum
            assert sum(1<<v for v in result['maximum']) in independent
            if result['matching_size']==r:
                states=[s for s in independent if s.bit_count()==r];start=(1<<r)-1;end=start<<r
                for width in range(1,r+1):
                    seen={start};queue=[start]
                    for s in queue:
                        for t in states:
                            if t not in seen and (s^t).bit_count()<=2*width:seen.add(t);queue.append(t)
                    if end in seen:break
                assert width==result['minimum_step_width'];totals[f'width{width}']+=1
            else:totals['gain'+str(maximum-r)]+=1
            cases+=1
    assert totals['width3'] and totals['width4'] and totals['gain1'] and totals['gain2']
    here=Path(__file__).resolve().parent
    report=dict(cases=cases,totals=dict(totals),source_sha256=hashlib.sha256((here/'analyze_bipartite_trade.py').read_bytes()).hexdigest(),checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope=__doc__)
    a.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))


if __name__=='__main__':main()
