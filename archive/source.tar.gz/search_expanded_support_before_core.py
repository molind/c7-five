"""Search a target-feasible LP support of a verified four-slice pilot.

The objective minimizes new words relative to the seed. Support restriction
is heuristic and cannot prove infeasibility of the whole four-slice domain.
"""
import argparse
import hashlib
import json
from pathlib import Path
import random
import time

import numpy as np
from scipy.optimize import linprog
from scipy.sparse import csc_matrix, vstack

from check_two_slice_covers import WORDS
from search_sparse_cylinders import solve_native, check_solution


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path, required=True)
    p.add_argument('--verification', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--lp-seconds', type=float, default=30)
    p.add_argument('--mip-seconds', type=float, default=90)
    p.add_argument('--seed', type=int, default=20260921)
    args = p.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    if min(args.lp_seconds,args.mip_seconds) <= 0:
        p.error('Positive limits required')
    source = json.loads(args.input.read_text())
    checked = json.loads(args.verification.read_text())
    assert checked['input_sha256'] == hashlib.sha256(args.input.read_bytes()).hexdigest()
    assert source['full_target'] == 368 and source['status'] == 'bounded_search_complete'
    model = source['model']
    pool, fixed = model['pool'], model['fixed']
    local = {v:i for i,v in enumerate(pool)}
    original_hint = set(model['hint'])
    for cut in source['learned_cuts']:
        model['members'].append([local[v] for v in cut['vertices']])
        model['capacities'].append(cut['capacity'])
    model['hint'] = sorted(original_hint-{local[v] for v in source['learned_hint_removed']})
    rr = [i for i,row in enumerate(model['members']) for _ in row]
    cc = [v for row in model['members'] for v in row]
    matrix = csc_matrix((np.ones(len(rr)),(rr,cc)),shape=(len(model['members']),len(pool)))
    matrix = vstack([matrix,-np.ones((1,len(pool)))],format='csc')
    target = 368-len(fixed)
    capacities = model['capacities']+[-target]
    rng = random.Random(args.seed)
    objective = np.array([float(i not in original_hint)+rng.random()*.005 for i in range(len(pool))])
    began = time.monotonic()
    report = dict(status='running', input=str(args.input),input_sha256=checked['input_sha256'],
                  verification=str(args.verification),verification_sha256=hashlib.sha256(args.verification.read_bytes()).hexdigest(),
                  source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),random_seed=args.seed,
                  fixed=fixed,full_target=368,candidates=[],scope='Heuristic support only; failure does not exclude any word from the full domain.')

    def save():
        report['elapsed_seconds'] = time.monotonic()-began
        temp = args.output.with_name(args.output.name+'.tmp')
        temp.write_text(json.dumps(report,indent=2)+'\n')
        temp.replace(args.output)

    save()
    lp = linprog(objective,A_ub=matrix,b_ub=capacities,bounds=(0,1),method='highs-ipm',options={'time_limit':args.lp_seconds})
    report['lp'] = dict(status=int(lp.status),message=lp.message,seconds=time.monotonic()-began)
    if not lp.success:
        report['status'] = 'lp_unresolved'
        save()
        return
    assert min(lp.x) >= -1e-7 and max(lp.x) <= 1+1e-7 and np.max(matrix@lp.x-capacities) < 1e-6
    report['lp'].update(objective=float(lp.fun),primal=[[v,float(x)] for v,x in zip(pool,lp.x) if x>1e-8])
    indices = sorted(original_hint|{i for i,x in enumerate(lp.x) if x>1e-8})
    reindex = {v:i for i,v in enumerate(indices)}
    rows = {}
    for members,cap in zip(model['members'],model['capacities']):
        row = tuple(reindex[v] for v in members if v in reindex)
        if len(row)>cap:
            rows[row] = min(cap,rows.get(row,cap))
    members = sorted(rows)
    restricted = dict(pool=[pool[i] for i in indices],fixed=fixed,
                      members=members,capacities=[rows[r] for r in members],
                      hint=sorted(reindex[v] for v in model['hint']))
    report.update(status='searching',model=restricted)
    save()
    print(json.dumps(dict(support=len(report['lp']['primal']),restricted_pool=len(indices),rows=len(rows),
                          new_word_objective=float(lp.fun),starting_size=len(fixed)+len(restricted['hint']))),flush=True)
    result = solve_native(restricted,target,args.mip_seconds)
    check_solution(restricted,result)
    report['result'] = result
    if result.get('full_size',0)>=367:
        chosen=sorted(fixed+result['vertices'])
        report['candidates'].append(dict(step=0,size=len(chosen),words=[''.join(map(str,WORDS[v])) for v in chosen],
                                         verified_pairs=len(chosen)*(len(chosen)-1)//2))
    report['status'] = 'candidate_found' if result.get('full_size',0)>=368 else 'bounded_search_complete'
    save()
    print(json.dumps(dict(status=report['status'],solver_status=result['solver_status'],
                          full_size=result.get('full_size'),nodes=result.get('nodes'))),flush=True)


if __name__=='__main__':
    main()
