"""Binary search in a full saved domain with geometric cylinder inequalities."""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np

from cylinder_bounds import HERE, constraints
from search_three_slices import WORDS, solve_hinted, verify


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path, default=HERE/'three-slice-cylinders012-sep21.json')
    p.add_argument('--seconds', type=float, default=20)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    if args.seconds <= 0:
        p.error('Positive limit required')
    if args.output.exists():
        raise FileExistsError(args.output)
    source = json.loads(args.input.read_text())
    pool, fixed = source['pool'], source['fixed']
    seed = {int(w, 7) for w in (HERE/'family-d-seed-words.txt').read_text().split()}
    hint = {i for i, v in enumerate(pool) if v in seed}
    assert set(fixed) | {pool[v] for v in hint} == seed
    assert len(fixed)+len(hint) == 367
    members, desc, matrix = constraints(pool, source['dimensions'])
    capacity = [d['capacity'] for d in desc]
    initial = np.array([i in hint for i in range(len(pool))], dtype=float)
    assert np.all(matrix @ initial <= capacity)
    report = dict(status='running', results=[], candidates=[],
                  input_sha256=hashlib.sha256(args.input.read_bytes()).hexdigest(),
                  hashes={n: hashlib.sha256((HERE/n).read_bytes()).hexdigest() for n in
                          (Path(__file__).name, 'cylinder_bounds.py', 'search_three_slices.py')},
                  scope='Whole saved slab domain. Valid cylinder cuts; timeouts unresolved.')
    for target, banned in [(len(hint)+1, None), (len(hint), 11725), (len(hint), 13885)]:
        if banned is not None and banned not in pool:
            continue
        result = solve_hinted(pool, matrix, hint, target, banned, args.seconds, capacity)
        report['results'].append(result)
        chosen = fixed+result.get('vertices', [])
        if 'vertices' in result:
            result['verified_pairs'] = verify([list(WORDS[v]) for v in chosen])
            result['full_size'] = len(chosen)
        if result['status'] == 'model_found':
            report['candidates'].append(dict(step=len(report['results'])-1,
                                             words=[''.join(map(str, WORDS[v])) for v in chosen],
                                             forbidden=banned, verified_pairs=result['verified_pairs']))
            report['status'] = 'candidate_found'
        tmp = args.output.with_name(args.output.name+'.tmp')
        tmp.write_text(json.dumps(report, indent=2)+'\n');tmp.replace(args.output)
        print(json.dumps({k: v for k, v in result.items() if k != 'vertices'}), flush=True)
        if report['candidates']:
            return
    report['status'] = 'queries_complete'
    args.output.write_text(json.dumps(report, indent=2)+'\n')


if __name__ == '__main__':
    main()
