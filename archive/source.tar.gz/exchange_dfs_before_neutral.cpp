// Exact increasing-index DFS, following the traversal contributed by fabius-cunctator.
// Input: n, blocker-word count, radius; then hex blockers and compatibility rows.
#include <array>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <vector>

using Bits = std::vector<uint64_t>;
using Blockers = std::array<uint64_t, 16>;
struct BlockerHash {
    size_t operator()(const Blockers& b) const {
        size_t h = 0;
        for (auto x : b) h ^= std::hash<uint64_t>{}(x) + size_t(0x9e3779b97f4a7c15ULL) + (h << 6) + (h >> 2);
        return h;
    }
};
struct Search {
    size_t n, bw, cw;
    unsigned radius;
    std::vector<Blockers> blockers;
    std::vector<Bits> compatible;
    std::vector<unsigned> chosen;
    uint64_t started = 0, completed = 0;
    bool subset_index = false;
    uint64_t subset_probes = 0, budget_prunes = 0;
    bool noncore_bound = false;
    unsigned core_prefix = 0, noncore_limit = 0;
    Blockers noncore_mask{};
    uint64_t noncore_prunes = 0;
    std::unordered_map<Blockers, std::vector<unsigned>, BlockerHash> groups;
    bool timed_out = false;
    std::chrono::steady_clock::time_point deadline;

    bool dfs(size_t first, const Blockers& used, const Bits& allowed, unsigned used_count) {
        if (chosen.size() >= radius + 1) return true;
        Bits filtered;
        const Bits* active = &allowed;
        if (subset_index && used_count == radius) {
            // A full budget cannot acquire another blocker. Enumerate every subset,
            // including the empty one; then preserve compatibility and index order.
            std::vector<unsigned> positions;
            for (size_t w = 0; w < bw; ++w) {
                uint64_t bits = used[w];
                while (bits) {
                    positions.push_back(unsigned(w * 64 + __builtin_ctzll(bits)));
                    bits &= bits - 1;
                }
            }
            filtered.assign(cw, 0);
            Blockers sub{};
            unsigned previous_gray = 0, remaining = 0;
            for (unsigned j = 0; j < (1u << positions.size()); ++j) {
                unsigned gray = j ^ (j >> 1);
                if (j) {
                    unsigned p = positions[__builtin_ctz(gray ^ previous_gray)];
                    sub[p / 64] ^= uint64_t(1) << (p % 64);
                }
                previous_gray = gray;
                ++subset_probes;
                auto group = groups.find(sub);
                if (group == groups.end()) continue;
                for (unsigned i : group->second) {
                    uint64_t bit = uint64_t(1) << (i % 64);
                    if (i >= first && (allowed[i / 64] & bit)) {
                        filtered[i / 64] |= bit;
                        ++remaining;
                    }
                }
            }
            if (chosen.size() + remaining < radius + 1) {
                ++budget_prunes;
                return false;
            }
            active = &filtered;
        }
        Bits next(cw);
        for (size_t w = first / 64; w < cw; ++w) {
            uint64_t bits = (*active)[w];
            if (w == first / 64) bits &= (~uint64_t(0) << (first % 64));
            while (bits) {
                unsigned bit = __builtin_ctzll(bits);
                bits &= bits - 1;
                size_t i = w * 64 + bit;
                ++started;
                if ((started & 1023) == 1 && std::chrono::steady_clock::now() >= deadline) {
                    timed_out = true;
                    return false;
                }
                Blockers merged{};
                unsigned count = 0;
                for (size_t j = 0; j < bw; ++j) {
                    merged[j] = used[j] | blockers[i][j];
                    count += __builtin_popcountll(merged[j]);
                    if (count > radius) break;
                }
                if (count <= radius) {
                    // Conditional restriction supplied by a separately checked core bound.
                    unsigned noncore_count = 0;
                    if (noncore_bound) {
                        for (size_t j = core_prefix / 64; j < bw; ++j)
                            noncore_count += __builtin_popcountll(merged[j] & noncore_mask[j]);
                    }
                    if (noncore_bound && noncore_count > noncore_limit) {
                        ++noncore_prunes;
                        ++completed;
                        continue;
                    }
                    for (size_t j = 0; j < cw; ++j) next[j] = (*active)[j] & compatible[i][j];
                    chosen.push_back(unsigned(i));
                    if (dfs(i + 1, merged, next, count)) return true;
                    chosen.pop_back();
                    if (timed_out) return false;
                }
                ++completed;
            }
        }
        return false;
    }
};

int main(int argc, char** argv) {
    try {
        if (argc < 2) throw std::runtime_error("Expected cutoff seconds [--subset] [--noncore-limit CORE_PREFIX LIMIT]");
        double seconds = std::stod(argv[1]);
        if (!(seconds > 0 && seconds <= 600)) throw std::runtime_error("Invalid cutoff");
        Search s;
        for (int a = 2; a < argc; ++a) {
            std::string option = argv[a];
            if (option == "--subset") s.subset_index = true;
            else if (option == "--noncore-limit" && a + 2 < argc) {
                int prefix = std::stoi(argv[++a]), limit = std::stoi(argv[++a]);
                if (prefix < 0 || prefix > 1024 || limit < 0 || limit > 8)
                    throw std::runtime_error("Invalid noncore restriction");
                s.noncore_bound = true;
                s.core_prefix = unsigned(prefix);
                s.noncore_limit = unsigned(limit);
            } else throw std::runtime_error("Unknown or incomplete option");
        }
        if (!(std::cin >> s.n >> s.bw >> s.radius) || !s.n || s.n > 20000 ||
            !s.bw || s.bw > 16 || s.radius > 8) throw std::runtime_error("Invalid dimensions");
        s.cw = (s.n + 63) / 64;
        if (s.noncore_bound) {
            if (s.core_prefix > s.bw * 64 || s.noncore_limit > s.radius)
                throw std::runtime_error("Noncore restriction exceeds dimensions");
            for (size_t j = 0; j < s.bw * 64; ++j)
                if (j >= s.core_prefix) s.noncore_mask[j / 64] |= uint64_t(1) << (j % 64);
        }
        s.blockers.resize(s.n);
        s.compatible.assign(s.n, Bits(s.cw));
        std::cin >> std::hex;
        for (size_t i = 0; i < s.n; ++i) {
            for (size_t j = 0; j < s.bw; ++j)
                if (!(std::cin >> s.blockers[i][j])) throw std::runtime_error("Missing blocker word");
            for (auto& word : s.compatible[i])
                if (!(std::cin >> word)) throw std::runtime_error("Missing compatibility word");
            if (s.n % 64 && (s.compatible[i].back() >> (s.n % 64)))
                throw std::runtime_error("Out of range compatibility bit");
        }
        Bits full(s.cw, ~uint64_t(0));
        if (s.n % 64) full.back() = (uint64_t(1) << (s.n % 64)) - 1;
        if (s.subset_index)
            for (size_t i = 0; i < s.n; ++i) s.groups[s.blockers[i]].push_back(unsigned(i));
        auto began = std::chrono::steady_clock::now();
        s.deadline = began + std::chrono::duration_cast<std::chrono::steady_clock::duration>(
            std::chrono::duration<double>(seconds));
        bool found = s.dfs(0, Blockers{}, full, 0);
        double elapsed = std::chrono::duration<double>(std::chrono::steady_clock::now() - began).count();
        std::cout << "{\"status\":\"" << (found ? "witness" : s.timed_out ? "timeout" : "exhausted")
                  << "\",\"nodes_started\":" << s.started << ",\"nodes_completed\":" << s.completed
                  << ",\"seconds\":" << elapsed << ",\"chosen\":[";
        for (size_t i = 0; i < s.chosen.size(); ++i) std::cout << (i ? "," : "") << s.chosen[i];
        std::cout << "],\"subset_index\":" << (s.subset_index ? "true" : "false")
                  << ",\"subset_probes\":" << s.subset_probes
                  << ",\"budget_prunes\":" << s.budget_prunes
                  << ",\"noncore_bound\":" << (s.noncore_bound ? "true" : "false")
                  << ",\"core_prefix\":" << s.core_prefix << ",\"noncore_limit\":" << s.noncore_limit
                  << ",\"noncore_prunes\":" << s.noncore_prunes << "}\n";
    } catch (const std::exception& e) {
        std::cerr << e.what() << '\n';
        return 1;
    }
}
