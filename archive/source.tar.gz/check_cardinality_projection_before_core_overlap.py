"""Replay saved pump points and witnesses with direct coordinate conflicts.

Checks feasibility, cardinality and the stated L1 distances. Does not replay LP
optimality, native search trees, or infer any exclusion from a bounded search.
"""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
from search_cardinality_projection import load_projection_model


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def conflicts(vertices):
    assert len(vertices)==len(set(vertices)) and all(type(v) is int and 0<=v<16807 for v in vertices)
    coords=np.array([[v//7**j%7 for j in range(5)] for v in vertices])
    if not vertices:return 0
    delta=(coords[:,None,:]-coords[None,:,:])%7
    return int(np.count_nonzero(np.triu(np.all((delta==0)|(delta==1)|(delta==6),axis=2),1)))


def verify(report):
    assert digest(report['input'])==report['input_sha256']
    assert digest(report['base_verification'])==report['base_verification_sha256']
    overlap=report.get('overlap')
    if overlap is not None:
        assert digest(overlap['certificate'])==overlap['certificate_sha256']
    proof,model,matrix,caps,limit=load_projection_model(Path(report['input']),Path(report['base_verification']),
                                                     Path(overlap['certificate']) if overlap else None)
    if overlap is not None:assert limit==overlap['limit']
    pool=model['pool'];fixed=model['fixed'];local={v:i for i,v in enumerate(pool)}
    target=report['target'];assert target+len(fixed)==report['target_size']==368
    n=len(pool);points=0;direct_pairs=0;min_conflicts=None
    for row in report['rows']:
        vs=row['rounded_vertices'];assert len(vs)==target and set(vs)<=set(pool)
        if limit is not None:
            retained=len(set(vs)&{pool[i] for i in model['hint']})
            assert retained==row['retained_hint'] and retained<=limit
        counted=conflicts(vs);assert counted==row['conflicts']
        assert conflicts(fixed+vs)==counted
        direct_pairs+=len(vs)*(len(vs)-1)//2
        min_conflicts=counted if min_conflicts is None else min(counted,min_conflicts)
        if 'primal' not in row:continue
        assert row['lp_status']==0
        assert len(row['primal'])==len({v for v,x in row['primal']})
        x=np.zeros(n)
        for v,value in row['primal']:
            assert np.isfinite(value);x[local[v]]=value
        y=np.zeros(n);y[[local[v] for v in vs]]=1
        assert min(x)>=-1e-6 and max(x)<=1+1e-6 and abs(sum(x)-target)<1e-5
        assert np.all(matrix@x<=caps+1e-5)
        assert abs(sum(abs(x-y))-row['distance'])<1e-5
        points+=1
    assert min_conflicts==report['best_conflicts']
    support_witnesses=[]
    for query in report['support_searches']:
        subset=query['pool'];answer=query['result'];indices=answer['vertices']
        assert len(subset)==len(set(subset)) and set(subset)<=set(pool)
        assert conflicts(subset)==query['edges']
        assert len(indices)==len(set(indices))==answer['best_size']
        assert all(type(i) is int and 0<=i<len(subset) for i in indices)
        full=sorted(fixed+[subset[i] for i in indices]);assert not conflicts(full) and len(full)==query['full_size']
        direct_pairs+=len(full)*(len(full)-1)//2
        assert (answer['status']=='target_found')==(len(full)>=368)
        support_witnesses.append(full)
    for candidate in report['candidates']:
        full=candidate['vertices'];assert len(full)==candidate['size'] and not conflicts(full)
        assert set(fixed)<=set(full) and set(full)-set(fixed)<=set(pool)
        assert candidate['pair_checks']==len(full)*(len(full)-1)//2
        assert full in support_witnesses or any(sorted(fixed+r['rounded_vertices'])==full for r in report['rows'])
    found=any(c['size']>=368 for c in report['candidates'])
    assert (report['status']=='verified_target')==found
    return dict(rows=len(report['rows']),feasible_fractional_points=points,support_queries=len(support_witnesses),
                candidates=len(report['candidates']),best_conflicts=min_conflicts,target_witness_found=found,
                direct_pair_checks=direct_pairs,scope=__doc__)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('inputs',nargs='+',type=Path)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();assert __debug__ and not a.output.exists()
    records=[]
    for path in a.inputs:
        records.append(dict(input=str(path),input_sha256=digest(path),**verify(json.loads(path.read_text()))))
    output=dict(checker_sha256=digest(__file__),results=records)
    a.output.write_text(json.dumps(output,indent=2)+'\n');print(json.dumps(output),flush=True)


if __name__=='__main__':main()
