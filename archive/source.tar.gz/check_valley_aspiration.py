"""Regression through the actual CLI, using a temporary initial tabu fixture.

The nine-set is maximal but admits a one-for-two gain. Every initial vertex is
tabu. The old guard misses the gain on its first move; aspiration must take it.
No production test hook or duplicate implementation of augmentation is used.
"""
import itertools
import json
import subprocess
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SEED = [19, 24, 46, 14, 34, 48, 37, 10, 1]
WORDS = list(itertools.product(range(7), repeat=2))

def conflict(i, j):
    return all((a-b) % 7 in (0, 1, 6) for a,b in zip(WORDS[i], WORDS[j]))

assert all(any(conflict(v,u) for u in SEED) for v in set(range(49))-set(SEED))
source = (ROOT/'search_valleys.cpp').read_text()
anchor = 'reset(); s.check();'
guard = 'respect_tabu && tabu[u] > steps && s.selected.size() + 1 <= best.size()'
assert source.count(anchor) == source.count(guard) == 1
fixture = source.replace(anchor, anchor+' std::fill(tabu.begin(), tabu.end(), 1000000);')
results = {}
with tempfile.TemporaryDirectory(prefix='c7-aspiration-') as directory:
    tmp = Path(directory)
    (tmp/'seed.ids').write_text(' '.join(map(str, SEED)))
    (tmp/'core.ids').write_text('')
    for label, code in [('old', fixture.replace(guard, 'respect_tabu && tabu[u] > steps')),
                        ('fixed', fixture)]:
        source_path, executable = tmp/f'{label}.cpp', tmp/label
        source_path.write_text(code)
        subprocess.run(['clang++','-std=c++20','-O2',str(source_path),'-o',str(executable)],check=True)
        output = tmp/f'{label}.json'
        subprocess.run([str(executable),str(tmp/'seed.ids'),str(tmp/'core.ids'),str(output),
                        '17','1','10','7','1000','2'],check=True,capture_output=True)
        row = json.loads(output.read_text())
        ids = row['best_ids']
        assert len(ids) == len(set(ids))
        assert all(not conflict(a,b) for a,b in itertools.combinations(ids,2))
        results[label] = {k:row[k] for k in ['best_size','one_for_two','kicks','steps']}
assert results['old']['best_size'] == 9
assert results['fixed']['best_size'] == 10
report = {'fixture_seed':SEED, 'method':'One CLI move, all initial vertices tabu in temporary source',
          'results':results}
(ROOT/'valley-aspiration-regression.json').write_text(json.dumps(report,indent=2)+'\n')
print(report)
