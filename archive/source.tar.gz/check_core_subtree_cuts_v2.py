"""Check closed-subtree coverage and every literal-resolution step.

Version 2 requires the v7 branch checker and the v2 derivation source.
This permits a further generation of cuts without weakening model identity checks.

Uses the existing checked integer leaf proofs as premises. Replays subtrees
recursively instead of importing the bottom-up clause derivation routine.
"""
import argparse
import hashlib
import json
from pathlib import Path


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def verify(path):
    data = json.loads(Path(path).read_text())
    assert data['status'] == 'derived' and data['target'] == 368
    assert all(sha(f) == h for f, h in data['dependencies'].items())
    assert data['source_sha256'] == sha(Path(__file__).with_name('derive_core_subtree_cuts_v2.py'))
    checked_proofs, originals = {}, []
    for clause in data['clauses']:
        proof_path = clause['verification']
        if proof_path not in checked_proofs:
            assert data['dependencies'][proof_path] == sha(proof_path)
            proof = json.loads(Path(proof_path).read_text())
            assert proof['passed'] and proof['root_partition_replayed']
            assert proof['checker_sha256'] == sha(Path(__file__).with_name('check_core_branch_certificates_v7.py'))
            assert all(sha(f) == h for f, h in proof['dependencies'].items())
            bundles = []
            for f in proof['dependencies']:
                if Path(f).suffix == '.json':
                    obj = json.loads(Path(f).read_text())
                    if isinstance(obj, dict) and obj.get('status') == 'complete_attempt' and 'tree' in obj:
                        bundles.append(obj)
            assert len(bundles) == 1
            bundle = bundles[0]
            assert all(sha(f) == h for f, h in bundle['dependencies'].items())
            tree = json.loads(Path(bundle['tree']).read_text())
            assert proof['dependencies'][bundle['tree']] == sha(bundle['tree'])
            assert tree['status'] == 'bounded_attempt_complete'
            assert all(sha(f) == h for f, h in tree['dependencies'].items())
            assert all(tree[k] == data[k] for k in ('input', 'radius', 'target_model_sha256'))
            certs = {r['tree_index'] for r in bundle['rows'] if r['certificate'] is not None}
            assert len(certs) == proof['integer_certified_leaves']
            lookup = {(tuple(r['inside']), tuple(r['outside'])): i for i, r in enumerate(tree['rows'])}
            assert len(lookup) == len(tree['rows'])
            checked_proofs[proof_path] = bundle['tree'], tree, lookup, certs
        tree_path, tree, lookup, certs = checked_proofs[proof_path]
        assert clause['tree'] == tree_path
        index = clause['root_index']
        assert type(index) is int and 0 <= index < len(tree['rows'])
        root = tree['rows'][index]
        assert clause['inside'] == sorted(root['inside'])
        assert clause['original_outside'] == sorted(root['outside'])
        def walk(inside, outside):
            assert (inside, outside) in lookup, 'Unvisited child cannot close a subtree'
            i = lookup[(inside, outside)]
            row = tree['rows'][i]
            if 'branch' in row:
                v = row['branch']
                return walk(inside + (v,), outside) + walk(inside, outside + (v,))
            assert i in certs or row['status'] == 'exact_conflict_or_radius', 'Uncertified leaf cannot close a subtree'
            return [i]
        covered = walk(tuple(root['inside']), tuple(root['outside']))
        assert sorted(covered) == clause['checked_leaves'] and len(covered) == len(set(covered))
        originals.append((set(clause['inside']), set(clause['original_outside'])))
    done, active = set(), set()
    def resolve(i):
        if i in done:
            return
        assert i not in active, 'Circular clause derivation'
        assert type(i) is int and 0 <= i < len(data['clauses'])
        active.add(i)
        clause = data['clauses'][i]
        inside, outside = originals[i][0], originals[i][1].copy()
        for step in clause['resolutions']:
            j, word = step['positive_clause'], step['removed']
            resolve(j)
            premise = data['clauses'][j]
            assert not premise['outside']
            premise_inside = set(premise['inside'])
            assert word in outside and word in premise_inside
            assert premise_inside - {word} <= inside, 'Resolution premise lacks required inside assumptions'
            outside.remove(word)
        assert sorted(outside) == clause['outside']
        active.remove(i)
        done.add(i)
    for i in range(len(data['clauses'])):
        resolve(i)
    return data


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    assert __debug__ and not args.output.exists()
    d = verify(args.input)
    out = dict(passed=True, input=str(args.input), clauses=len(d['clauses']),
               positive_clauses=sum(not c['outside'] for c in d['clauses']),
               resolution_steps=sum(len(c['resolutions']) for c in d['clauses']),
               target_model_sha256=d['target_model_sha256'], checker_sha256=sha(__file__),
               dependencies={str(args.input): sha(args.input)},
               scope='Exact recursive subtree coverage and clause-resolution replay, conditional on the specified checked leaf proofs. Same fixed-core/radius/target model only.')
    args.output.write_text(json.dumps(out, indent=2) + '\n')
    print({k: v for k, v in out.items() if k not in ('dependencies', 'scope')})


if __name__ == '__main__':
    main()
