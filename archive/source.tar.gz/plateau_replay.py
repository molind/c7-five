"""Independent finite certificate using five P4s, without the DFS or XOR state.

Enumerate every maximal completion of the 357-word core. Check that the
243 completions are connected and closed under all one/two-word replacements.
Every completion is maximal, so an augmentation removing <=2 words is also
impossible: its first equally many inserted words would stay in this family,
and its next insertion would contradict that family's maximality.
"""
import hashlib
import itertools
import json
import struct
from pathlib import Path

import numpy as np

import sys

def verify(words):
    if len(set(map(tuple, words))) != len(words) or any(len(w) != 5 or any(type(x) is not int or not 0 <= x < 7 for x in w) for w in words):
        raise ValueError("Invalid code")
    for u, v in itertools.combinations(words, 2):
        if all((x-y) % 7 in (0, 1, 6) for x, y in zip(u, v)):
            raise ValueError("Confusable pair")



def main():
    artifacts = json.loads(Path(sys.argv[1]).read_text())
    words = next(a["data"]["words"] for a in artifacts if a["id"] == 2565)
    verify(words)
    variable = {tuple(map(int, w)) for w in "03565 13446 23546 24635 34035 44616 50536 52643 53134 53235 53642 54606 56526 60645 61655 63505 64246 64340 64532 65531".split()}
    source = {"fixed_across_visited_words": [w for w in words if tuple(w) not in variable],
              "component_sha256": "b9bf14dc2037700ac17ec73d5f5dd0424e8f2bd64c42ded9d5c7a8e66fc5b930"}
    core = source["fixed_across_visited_words"]
    verify(core)
    vertices = list(itertools.product(range(7), repeat=5))
    powers = np.array([2401, 343, 49, 7, 1])
    shifts = np.array(list(itertools.product((-1, 0, 1), repeat=5)))
    core_ids = [int(np.array(w) @ powers) for w in core]
    base = [0]*16807
    for i, v in enumerate(core_ids):
        for u in (((np.array(vertices[v])+shifts) % 7) @ powers).tolist():
            base[u] |= 1 << i
    available = [i for i, b in enumerate(base) if not b]
    if len(core) != 357 or len(available) != 20:
        raise ArithmeticError("Wrong core or free-set size")

    def conflict(v, u):
        return all((x-y) % 7 in (0, 1, 6) for x, y in zip(vertices[v], vertices[u]))

    adj = {v: {u for u in available if u != v and conflict(v, u)} for v in available}
    components = []
    seen = set()
    for v in available:
        if v in seen:
            continue
        pending, comp = [v], []
        seen.add(v)
        while pending:
            u = pending.pop()
            comp.append(u)
            for w in adj[u]-seen:
                seen.add(w)
                pending.append(w)
        if len(comp) != 4 or sorted(len(adj[u]) for u in comp) != [1, 1, 2, 2]:
            raise ArithmeticError("Free component is not P4")
        components.append(comp)
    choices = [[pair for pair in itertools.combinations(c, 2) if not conflict(*pair)]
               for c in components]
    if len(choices) != 5 or any(len(c) != 3 for c in choices):
        raise ArithmeticError("Wrong completion factors")
    completions = [tuple(sorted(itertools.chain.from_iterable(parts)))
                   for parts in itertools.product(*choices)]
    states = [frozenset(core_ids) | frozenset(c) for c in completions]
    state_index = {s: i for i, s in enumerate(states)}
    neighbors = {v: (((np.array(vertices[v])+shifts) % 7) @ powers).tolist() for v in available}
    transitions = [set() for _ in states]
    singles = doubles = 0
    for state_id, completion in enumerate(completions):
        selected = core_ids+list(completion)
        selected_set = states[state_id]
        blockers = base.copy()
        for i, v in enumerate(completion, len(core_ids)):
            for u in neighbors[v]:
                blockers[u] |= 1 << i
        if any(b == 0 for b in blockers):
            raise ArithmeticError("A completion is not maximal")
        candidates = [v for v, b in enumerate(blockers) if v not in selected_set and b.bit_count() <= 2]
        for v in candidates:
            if blockers[v].bit_count() == 1:
                removed = selected[blockers[v].bit_length()-1]
                new = (selected_set-{removed}) | {v}
                if new not in state_index:
                    raise ArithmeticError("Single replacement escapes the family")
                transitions[state_id].add(state_index[new])
                singles += 1
        for v, u in itertools.combinations(candidates, 2):
            bs = blockers[v] | blockers[u]
            if bs.bit_count() > 2 or conflict(v, u):
                continue
            if bs.bit_count() < 2:
                raise ArithmeticError("One-for-two augmentation")
            first = bs & -bs
            removed = {selected[first.bit_length()-1], selected[(bs ^ first).bit_length()-1]}
            new = (selected_set-removed) | {v, u}
            if new not in state_index:
                raise ArithmeticError("Double replacement escapes the family")
            transitions[state_id].add(state_index[new])
            doubles += 1
    reached, pending = {0}, [0]
    while pending:
        for u in transitions[pending.pop()]-reached:
            reached.add(u)
            pending.append(u)
    packed = sorted(struct.pack("<367H", *sorted(s)) for s in states)
    digest = hashlib.sha256(b"".join(packed)).hexdigest()
    if len(reached) != 243 or digest != source["component_sha256"]:
        raise ArithmeticError("Constructed component differs from the DFS component")
    report = {"core_size": len(core), "free_vertices": len(available),
              "free_components": [{"words": [vertices[v] for v in c],
                                    "edges": [[vertices[v], vertices[u]] for v, u in itertools.combinations(c, 2) if conflict(v, u)]}
                                   for c in components],
              "complete_maximal_completions": len(states), "connected_completions": len(reached),
              "directed_single_moves": singles, "directed_double_moves": doubles,
              "component_sha256": digest,
              "claim": "Closed nondecreasing component under moves removing at most two words"}
    print(json.dumps({k: v for k, v in report.items() if k != "free_components"}), flush=True)


if __name__ == "__main__":
    main()
