"""Compare all exact minimal compatible-cover unions in Python and C++."""
import gzip
import hashlib
import json
import subprocess
from itertools import product
from pathlib import Path

import numpy as np


def main():
    assert __debug__
    r = Path('research/c7')
    output = r / 'compatible-critical-native-verification-sep22.json'
    assert not output.exists()
    sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
    audit_path = r / 'compatible-critical-union-verification-sep22.json'
    audit = json.loads(audit_path.read_text())
    assert audit['passed'] and all(sha(p) == h for p, h in audit['dependencies'].items())
    assert audit['checker_sha256'] == sha(r / 'check_compatible_critical_profile.py')
    profile = json.loads((r / 'compatible-critical-union-profile-sep22.json').read_text())
    coords = np.array(list(product(range(7), repeat=5)), dtype=np.int16)
    loaded, results = {}, []
    for row in profile['rows']:
        name, index, radius = row['manifest'], row['state'], row['radius']
        assert row['complete']
        if name not in loaded:
            m = json.loads((r / name).read_text())
            with gzip.open(m['source'], 'rt') as f:
                next(f)
                loaded[name] = [set(json.loads(s)) for s in f]
        states = loaded[name]
        state, parents, frozen = states[index], [], set()
        old = sorted(state)
        for other in states[:index]:
            if len(state - other) == len(other - state) == 1:
                parents.append(next(iter(other - state)))
                frozen |= state - other
        def conflicting(a, b):
            delta = (coords[np.asarray(a)[:, None]] - coords[np.asarray(b)[None, :]]) % 7
            return np.all((delta == 0) | (delta == 1) | (delta == 6), axis=2)
        bad = conflicting(list(range(16807)), old)
        deg = bad.sum(axis=1)
        pool = (deg >= 2) & (deg <= radius)
        pool[old] = False
        if frozen:
            pool &= ~np.any(bad[:, [old.index(x) for x in frozen]], axis=1)
        ids = np.flatnonzero(pool)
        flags = conflicting(ids, parents).T
        useful = flags.any(axis=0)
        ids, flags = ids[useful], flags[:, useful]
        assert len(ids) == row['useful_candidates']
        lines = [f'{radius} {len(ids)} {len(parents)}']
        for b in bad[ids]:
            points = np.flatnonzero(b)
            lines.append(str(len(points)) + ' ' + ' '.join(map(str, points)))
        for f in flags:
            lines.append(' '.join(map(str, f.astype(int))))
        for f in ~conflicting(ids, ids):
            lines.append(' '.join(map(str, f.astype(int))))
        body = '\n'.join(lines) + '\n'
        p = subprocess.run([str(r / 'compatible_requirements_harness')], input=body,
                           text=True, capture_output=True, check=True)
        assert not p.stderr
        found = json.loads(p.stdout)
        assert found['complete'], (name, index, found)
        native = {tuple(old[i] for i in b) for b in found['sets']}
        expected = {tuple(s['removed']) for s in row['supports']}
        assert len(native) == len(found['sets']) and native == expected, (name, index)
        results.append(dict(manifest=name, state=index, radius=radius, sets=len(native),
                            nodes=found['nodes'], comparisons=found['comparisons'],
                            input_sha256=hashlib.sha256(body.encode()).hexdigest(),
                            output_sha256=hashlib.sha256(p.stdout.encode()).hexdigest()))
        print(json.dumps(results[-1]), flush=True)
    deps = dict(audit['dependencies'])
    for p in [audit_path, r / 'check_compatible_critical_profile.py', r / 'compatible_requirements_harness.cpp',
              r / 'compatible_requirements_harness', r / 'scan_component_atomic7_incremental_compatible.cpp']:
        deps[str(p)] = sha(p)
    output.write_text(json.dumps(dict(passed=True, checker_sha256=sha(__file__), dependencies=deps,
                                     rows=results, scope=__doc__), indent=2) + '\n')


if __name__ == '__main__':
    main()
