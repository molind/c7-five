"""Restrict the verified U2 cover to words compatible with each possible anchor."""
import contextlib,io,json,runpy,struct
from itertools import product
from pathlib import Path
p=Path(__file__).parent
with contextlib.redirect_stdout(io.StringIO()):cert=runpy.run_path(str(p/'shared_u2_compact_replay.py'))
u2=sorted(cert['U2']);index={w:i for i,w in enumerate(u2)};full=(1<<len(u2))-1
boxes=[]
for origin,units in struct.iter_unpack('<HI',cert['raw']):
    mask=0
    for w in product(*[(x,(x+1)%7) for x in cert['W'][origin]]):
        if w in index:mask|=1<<index[w]
    boxes.append((mask,units))
m=json.loads((p/'core-anchor-family-c-input.json').read_text());rows=[]
for a in m['pool'][:m['anchors']]:
    conflicts=0
    for w in product(*[((x-1)%7,x,(x+1)%7) for x in a]):
        if w in index:conflicts|=1<<index[w]
    allowed=full^conflicts
    bound=sum(units for mask,units in boxes if mask&allowed)
    rows.append(dict(anchor=''.join(map(str,a)),remaining_u2=allowed.bit_count(),cover_units=bound))
r=dict(anchors=len(rows),denominator=1000000,minimum=min(x['cover_units'] for x in rows),maximum=max(x['cover_units'] for x in rows),single_anchor_excluded=sum(x['cover_units']<367000000 for x in rows),rows=rows)
(p/'two-anchor-cover-probe.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:v for k,v in r.items() if k!='rows'}),flush=True)
