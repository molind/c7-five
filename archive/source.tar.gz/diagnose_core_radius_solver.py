"""Compare HiGHS strategies on the exact saved radius/cardinality model.

Records a full solver log and byte-bound model inputs. Strategy options change
only execution, not constraints. Any returned set is directly pair-checked.
"""
import argparse
import hashlib
from itertools import product
import json
from pathlib import Path
import time

import numpy as np
from scipy.sparse import vstack
from scipy.optimize._highspy import _core as high

from search_core_radius_cut import bind_f9, radius_rows
from search_core_regions import box_constraints, independence


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True)
    p.add_argument('--radius',type=int,required=True)
    p.add_argument('--presolve',choices=('choose','off'),default='choose')
    p.add_argument('--seconds',type=float,default=30)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();logfile=args.output.with_suffix('.highs.log')
    assert __debug__ and not args.output.exists() and not logfile.exists() and args.seconds>0
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    data=json.loads(args.input.read_text());assert data['status']=='complete_bounded_queries'
    assert all(sha(f)==h for f,h in data['dependencies'].items())
    assert data['source_sha256']==sha(Path(__file__).with_name('search_core_radius_cut.py'))
    parent=data['parent_words'];assert independence(parent)==67161
    binding=data['radius_binding'];assert bind_f9(Path(binding['proof']),Path(binding['manifest']),set(parent))==binding
    row=next(r for r in data['rows'] if r['radius']==args.radius)
    pool=data['pool'];fixed=data['fixed'];initial=np.array([float(v in parent) for v in pool])
    m=int(initial.sum());assert m+len(fixed)==367 and data['target']==m+1
    coords=np.array(list(product(range(7),repeat=5)),dtype=np.int16)
    corners=np.array(list(product((0,1),repeat=5)));powers=np.array([2401,343,49,7,1])
    boxes=box_constraints(pool,coords,corners,powers).tocsc()
    extra,lo,hi=radius_rows(initial,10,args.radius);assert lo.tolist()==row['extra_lower'] and hi.tolist()==row['extra_upper']
    matrix=vstack((boxes,extra),format='csc');lower=np.r_[np.zeros(boxes.shape[0]),lo];upper=np.r_[np.ones(boxes.shape[0]),hi]
    excluded=set(row['excluded_words']);variable_upper=np.array([float(v not in excluded) for v in pool])
    assert np.all(initial<=variable_upper) and np.all(matrix@initial>=lower) and np.all(matrix@initial<=upper)
    h=hashlib.sha256()
    for array in (np.array(matrix.shape,dtype='<i8'),matrix.indptr.astype('<i8'),matrix.indices.astype('<i8'),matrix.data.astype('<f8'),lower.astype('<f8'),upper.astype('<f8'),variable_upper.astype('<f8')):h.update(array.tobytes())
    model_sha=h.hexdigest();n=len(pool)
    lp=high.HighsLp();lp.num_col_=n;lp.num_row_=matrix.shape[0];lp.col_cost_=-np.ones(n)
    lp.col_lower_=np.zeros(n);lp.col_upper_=variable_upper;lp.row_lower_=lower;lp.row_upper_=upper
    lp.integrality_=[high.HighsVarType.kInteger]*n;lp.a_matrix_.format_=high.MatrixFormat.kColwise
    lp.a_matrix_.start_=matrix.indptr.astype(np.int32);lp.a_matrix_.index_=matrix.indices.astype(np.int32);lp.a_matrix_.value_=matrix.data
    solver=high._Highs()
    options=dict(output_flag=True,log_to_console=False,log_file=str(logfile),presolve=args.presolve,
        time_limit=float(args.seconds),mip_rel_gap=0.0,objective_target=-float(m+1))
    for key,value in options.items():assert solver.setOptionValue(key,value)==high.HighsStatus.kOk
    assert solver.passModel(lp)==high.HighsStatus.kOk
    assert solver.setSolution(n,np.arange(n,dtype=np.int32),initial)==high.HighsStatus.kOk
    dependencies={str(args.input):sha(args.input)}
    for name in ('search_core_radius_cut.py','search_core_regions.py'):
        path=Path(__file__).with_name(name);dependencies[str(path)]=sha(path)
    out=dict(status='running',input=str(args.input),radius=args.radius,options=options,model_sha256=model_sha,
        dependencies=dependencies,source_sha256=sha(__file__),scope='Same radius model, strategy comparison only; timeouts do not exclude368.')
    args.output.write_text(json.dumps(out,indent=2)+'\n');began=time.monotonic()
    run_status=solver.run();info=solver.getInfo();solution=solver.getSolution()
    out.update(status='complete_attempt',run_status=str(run_status),solver_status=solver.modelStatusToString(solver.getModelStatus()),
        seconds=time.monotonic()-began,nodes=info.mip_node_count,objective=info.objective_function_value,
        dual_bound=info.mip_dual_bound,simplex_iterations=info.simplex_iteration_count,highs_version=solver.version())
    if solution.value_valid and info.primal_solution_status==high.kSolutionStatusFeasible:
        values=np.asarray(solution.col_value);rounded=np.rint(values)
        assert np.max(np.abs(values-rounded))<1e-6 and np.all((rounded==0)|(rounded==1)) and np.all(rounded<=variable_upper)
        assert np.all(matrix@rounded>=lower) and np.all(matrix@rounded<=upper)
        words=sorted(fixed+[v for v,x in zip(pool,rounded) if x]);checks=independence(words)
        assert len(words)>=367 and abs(info.objective_function_value+rounded.sum())<1e-5
        out.update(words=words,size=len(words),pair_checks=checks)
        if len(words)==368:assert checks==67528;out['status']='verified_improvement'
    solver.setOptionValue('log_file','')
    out['log_file']=str(logfile);out['log_sha256']=sha(logfile)
    args.output.write_text(json.dumps(out,indent=2)+'\n')
    print({k:v for k,v in out.items() if k not in ('words','options','dependencies','scope')})


if __name__=='__main__':main()
