"""Cover full domains after two omissions from the specified315-word core.

Extend a verified one-omission cover by one box when possible. Otherwise solve
the complete small fractional box-cover LP and round weights upward to integer
millionths. A failed strict cover is an open domain, not evidence of a368 set.
"""
import argparse
from itertools import combinations, product
import hashlib
import json
import math
from pathlib import Path
import time

import numpy as np
from scipy.optimize import linprog
from scipy.sparse import csc_matrix

from check_common314_covers import decode, encode


def containing_box(words):
    origin=[]
    for i in range(5):
        values={decode(v)[i] for v in words}
        choices=[x for x in range(7) if values<={x,(x+1)%7}]
        if not choices:return None
        origin.append(choices[0])
    return encode(origin)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--single-covers',type=Path,required=True)
    p.add_argument('--verification',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();assert __debug__ and not args.output.exists()
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    single=json.loads(args.single_covers.read_text());proof=json.loads(args.verification.read_text())
    assert proof['passed'] and proof['dependencies'][str(args.single_covers)]==sha(args.single_covers)
    assert all(sha(f)==h for f,h in proof['dependencies'].items())
    base=json.loads(Path(single['base_certificate']).read_text());core=sorted(base['fixed'])
    assert len(core)==315 and len(set(core))==315
    blockers=[[] for _ in range(16807)]
    for v in core:
        for w in product(*[((x-1)%7,x,(x+1)%7) for x in decode(v)]):blockers[encode(w)].append(v)
    buckets={}
    for v,bk in enumerate(blockers):
        if len(bk)<=2:buckets.setdefault(tuple(bk),[]).append(v)
    prior={r['omitted']:r for r in single['rows']}
    empty=buckets.get((),[]);D=single['denominator'];assert D==1000000
    for i in core:assert set(prior[i]['pool'])==set(empty+buckets[(i,)])
    coords=np.array(list(product(range(7),repeat=5)),dtype=np.int16)
    powers=np.array([2401,343,49,7,1]);corners=np.array(list(product((0,1),repeat=5)))
    rows=[];opened=[];lp_count=0;began=time.monotonic()
    for i,j in combinations(core,2):
        shared=buckets.get((i,j),[])
        origin=containing_box(buckets[(j,)]+shared);parent=i
        if origin is None:origin=containing_box(buckets[(i,)]+shared);parent=j
        if origin is not None:
            total=prior[parent]['total_units']+D
            assert total<55*D
            rows.append(dict(omitted=[i,j],kind='extension',parent_omission=parent,
                             extra_box_origin=origin,total_units=total))
            continue
        lp_count+=1
        pool=sorted(empty+buckets[(i,)]+buckets[(j,)]+shared);index={v:k for k,v in enumerate(pool)}
        boxes={}
        for v in pool:
            for origin in (((coords[v]-corners)%7)@powers).tolist():
                if origin not in boxes:boxes[origin]=tuple(sorted(index[x] for x in (((coords[origin]+corners)%7)@powers).tolist() if x in index))
        distinct={}
        for origin,members in boxes.items():distinct.setdefault(members,origin)
        items=list(distinct.items());rr=[];cc=[]
        for k,(members,_) in enumerate(items):rr.extend(members);cc.extend([k]*len(members))
        matrix=csc_matrix((np.ones(len(rr)),(rr,cc)),shape=(len(pool),len(items)))
        result=linprog(np.ones(len(items)),A_ub=-matrix,b_ub=-np.ones(len(pool)),bounds=(0,None),method='highs')
        assert result.success
        cover=[];coverage=[0]*len(pool)
        for (members,origin),value in zip(items,result.x):
            units=math.ceil(max(0,float(value))*D)
            if not units:continue
            cover.append(dict(origin=origin,units=units))
            for k in members:coverage[k]+=units
        assert min(coverage)>=D
        total=sum(c['units'] for c in cover)
        row=dict(omitted=[i,j],kind='lp',pool=pool,cover=cover,total_units=total,
                 floating_cover=float(result.fun),certified_no368=total<55*D)
        rows.append(row)
        if total>=55*D:opened.append(dict(omitted=[i,j],pool=pool,total_units=total))
    out=dict(status='complete',denominator=D,rows=rows,open_domains=opened,seconds=time.monotonic()-began,
             single_covers=str(args.single_covers),single_verification=str(args.verification),
             dependencies={str(args.single_covers):sha(args.single_covers),str(args.verification):sha(args.verification)},
             source_sha256=sha(__file__),scope='All completions retaining313of the exact315corewords, when each corresponding cover is below55. Open rows need search or stronger bounds.')
    args.output.write_text(json.dumps(out,indent=2)+'\n')
    print(dict(cases=len(rows),extension_cases=len(rows)-lp_count,lp_cases=lp_count,open_domains=len(opened),
               largest_lp=max(r['floating_cover'] for r in rows if r['kind']=='lp'),seconds=out['seconds']))


if __name__=='__main__':main()
