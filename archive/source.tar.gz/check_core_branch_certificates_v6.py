"""Independent integer verification of a complete binary branch certificate.

Reconstructs C7 conflicts, all box rows, radius constraints, branch partition,
and bound propagation. No LP solver or search/generator imports are used.
"""
import argparse
import hashlib
from itertools import product
import json
import math
from pathlib import Path

import numpy as np


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def decode(v):
    return tuple((v // p) % 7 for p in (2401, 343, 49, 7, 1))


def encode(word):
    return sum(x * p for x, p in zip(word, (2401, 343, 49, 7, 1)))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--certificates', type=Path, required=True)
    p.add_argument('--radius-verification', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--allow-partial', action='store_true')
    p.add_argument('--extra-leaves', type=Path, action='append', default=[])
    args = p.parse_args()
    assert __debug__ and not args.output.exists()
    certificates = json.loads(args.certificates.read_text())
    assert certificates['status'] == 'complete_attempt'
    assert all(sha(f) == h for f, h in certificates['dependencies'].items())
    tree_path = Path(certificates['tree'])
    tree = json.loads(tree_path.read_text())
    assert all(sha(f) == h for f, h in tree['dependencies'].items())
    data_path = Path(tree['input'])
    data = json.loads(data_path.read_text())
    assert all(sha(f) == h for f, h in data['dependencies'].items())
    prior = json.loads(args.radius_verification.read_text())
    assert prior['passed'] and prior['dependencies'][str(data_path)] == sha(data_path)
    assert all(sha(f) == h for f, h in prior['dependencies'].items())
    assert prior['checker_sha256'] == sha(Path(__file__).with_name('check_core_radius_cut.py'))
    radius = tree['radius']
    assert any(r['file'] == str(data_path) and r['radius'] == radius for r in prior['rows'])
    # The earlier independent radius verifier binds q=10 to the exact parent and
    # its completed F9 certificate. Validate every dependency in that proof chain.
    visited = set()
    def links(path):
        path = Path(path)
        if path in visited or path.suffix != '.json':
            return
        visited.add(path)
        d = json.loads(path.read_text())
        dep = d.get('dependencies', {}) if isinstance(d, dict) else {}
        pairs = dep.items() if isinstance(dep, dict) else [(v['path'], v['sha256']) for v in dep]
        for file, digest in pairs:
            assert sha(file) == digest
            links(file)
    links(data['radius_binding']['proof'])
    binding = data['radius_binding']
    assert binding['proof_sha256'] == sha(binding['proof']) and binding['minimum_improving_deletions'] == 10
    pool, fixed, parent = data['pool'], set(data['fixed']), set(data['parent_words'])
    assert pool == sorted(set(pool)) and fixed <= parent and len(parent) == 367
    coords = np.array(list(product(range(7), repeat=5)), dtype=np.int16)
    eligible = np.ones(16807, dtype=bool)
    for v in fixed:
        delta = (coords - coords[v]) % 7
        eligible &= ~np.all((delta == 0) | (delta == 1) | (delta == 6), axis=1)
    assert np.flatnonzero(eligible).tolist() == pool
    pos, pool_set = {v: i for i, v in enumerate(pool)}, set(pool)
    old, m = parent - fixed, 367 - len(fixed)
    assert old <= pool_set and m == len(old)
    neighborhoods = {}
    for v in pool:
        delta = (coords[pool] - coords[v]) % 7
        bad = np.all((delta == 0) | (delta == 1) | (delta == 6), axis=1)
        neighborhoods[v] = set(np.array(pool)[bad].tolist())
    origins = set()
    for v in pool:
        origins.update(encode(w) for w in product(*[((x-1) % 7, x) for x in decode(v)]))
    memberships = set()
    for origin in origins:
        # Keep corner enumeration order, including modulo wrap, before sorting
        # the distinct row tuples: this reproduces the recorded row numbering.
        words = [encode(w) for w in product(*[(x, (x+1) % 7) for x in decode(origin)])]
        memberships.add(tuple(pos[v] for v in words if v in pos))
    box_rows = sorted(memberships)
    assert all(box_rows)
    rows = [[(j, 1) for j in row] for row in box_rows]
    rows += [[(j, 1) for j in range(len(pool))], [(pos[v], 1) for v in sorted(old)],
             [(j, 10 + int(v in old)) for j, v in enumerate(pool)]]
    lower = [0] * len(box_rows) + [m+1, m-radius, 0]
    upper = [1] * len(box_rows) + [m+1, m, 11*m]
    domain_exclusion_path = tree.get('domain_exclusion')
    assert not tree.get('condition_proof'), 'General learned-clause models require their own reconstruction'
    if domain_exclusion_path:
        assert tree['dependencies'][domain_exclusion_path] == sha(domain_exclusion_path)
        exclusion = json.loads(Path(domain_exclusion_path).read_text())
        assert exclusion['passed'] and exclusion['target'] == 368
        assert exclusion['input'] == str(data_path) and exclusion['deletion_radius'] == radius
        assert exclusion['fixed'] == data['fixed'] and exclusion['exact_parent'] == data['parent_words']
        assert exclusion['checker_sha256'] == sha(Path(__file__).with_name('derive_core_domain_exclusion.py'))
        links(domain_exclusion_path)
        premises = []
        for file in exclusion['dependencies']:
            if Path(file).suffix == '.json':
                value = json.loads(Path(file).read_text())
                if isinstance(value, dict) and value.get('no368_in_this_fixed_domain_through_radius'):
                    premises.append((file, value))
        assert len(premises) == 1
        premise_path, premise = premises[0]
        assert premise['passed'] and premise['complete_branch_partition']
        assert premise['target'] == 368 and premise['deletion_radius'] == radius
        assert premise['checker_sha256'] == sha(Path(__file__).with_name('check_core_branch_certificates_v4.py'))
        assert premise['exact_parent'] == data['parent_words']
        extra = set(exclusion['inside'])
        assert extra and len(extra) == len(exclusion['inside']) and exclusion['outside'] == []
        assert extra <= old and exclusion['inequality_upper'] == len(extra)-1
        assert set(premise['fixed']) == fixed | extra
        # Reconstruct the restricted wide pool and bind it to the complete
        # narrow exclusion. Keeping every extra word preserves parent deletions.
        narrow_inputs = []
        for file in premise['dependencies']:
            if Path(file).suffix == '.json':
                value = json.loads(Path(file).read_text())
                if isinstance(value, dict) and 'pool' in value and 'parent_words' in value:
                    narrow_inputs.append(value)
        assert len(narrow_inputs) == 1
        narrow = narrow_inputs[0]
        assert narrow['fixed'] == premise['fixed'] and narrow['parent_words'] == data['parent_words']
        eligible_narrow = pool_set - set().union(*(neighborhoods[v] for v in extra))
        assert eligible_narrow == set(narrow['pool'])
        assert (parent - set(narrow['fixed'])) | extra == old
        assert data['target'] == narrow['target'] + len(extra)
        rows.insert(len(box_rows), [(pos[v], 1) for v in sorted(extra)])
        lower.insert(len(box_rows), 0)
        upper.insert(len(box_rows), len(extra)-1)
    common_core_path = tree.get('common_core_proof')
    if common_core_path:
        common_base_path = tree['common_core_base']
        assert tree['dependencies'][common_core_path] == sha(common_core_path)
        assert tree['dependencies'][common_base_path] == sha(common_base_path)
        core_proof = json.loads(Path(common_core_path).read_text())
        core_base = json.loads(Path(common_base_path).read_text())
        assert core_proof['passed'] and not core_proof['open_domains']
        core_checker = Path(__file__).with_name('check_common312_covers.py')
        assert core_proof['checker_sha256'] == sha(core_checker)
        links(common_core_path)
        assert core_proof['dependencies'][common_base_path] == sha(common_base_path)
        parent_path = core_base['input']
        assert core_proof['dependencies'][parent_path] == sha(parent_path) == core_base['input_sha256']
        parents = json.loads(Path(parent_path).read_text())['bases']
        core = set(parents[0]['words']) & set(parents[1]['words'])
        assert core == set(core_base['fixed']) and len(core) == 315
        assert core_proof['cases'] == math.comb(315, 3)
        assert core_proof['implicit'] + core_proof['explicit_extensions'] + core_proof['lp_covers'] == core_proof['cases']
        assert core_proof['minimum_core_omissions_for368'] == 4
        assert core_proof['any368_retains_at_most_core_words'] == 311
        assert 0 < core_proof['denominator'] and core_proof['maximum_total_units'] < 56*core_proof['denominator']
        assert fixed <= core and parent in [set(p['words']) for p in parents]
        assert data['target'] + len(fixed) == 368
        remaining_core, bound = sorted(core-fixed), 311-len(fixed)
        assert set(remaining_core) <= pool_set and 0 <= bound < len(remaining_core)
        assert tree['common_core_cut_words'] == remaining_core
        assert tree['common_core_cut_upper'] == bound
        # Keeping >=312 words from this exact315core cannot attain368:
        # every312-word subset has a checked free cover of weight strictly<56.
        # Insert after any earlier cuts, before the three final radius rows.
        rows.insert(len(rows)-3, [(pos[v], 1) for v in remaining_core])
        lower.insert(len(lower)-3, 0)
        upper.insert(len(upper)-3, bound)
    base_forbidden = {v for v in pool if len((neighborhoods[v] & old) - {v}) > radius}
    recorded = next(r for r in data['rows'] if r['radius'] == radius)
    assert sorted(base_forbidden) == recorded['excluded_words']
    records = {r['tree_index']: r for r in certificates['rows']}
    assert len(records) == len(certificates['rows'])
    assert all(type(i) is int and 0 <= i < len(tree['rows']) for i in records)
    proofs = {i: r['certificate'] for i, r in records.items() if r['certificate'] is not None}
    pending, used, gaps, observed_unknown = [((), ())], set(), [], []
    unknown = [(tuple(r['inside']), tuple(r['outside'])) for r in tree['unknown_nodes']]
    unresolved_unknown, certified_unknown = [], []
    for index, node in enumerate(tree['rows']):
        inside, outside = pending.pop()
        assert node['inside'] == list(inside) and node['outside'] == list(outside)
        assert set(inside) <= pool_set and set(outside) <= pool_set
        forbidden = set(outside) | base_forbidden
        for v in inside:
            forbidden |= neighborhoods[v] - {v}
        deleted = forbidden & old
        contradiction = bool(set(inside) & forbidden) or len(deleted) > radius
        for v in pool_set - old - set(inside) - forbidden:
            if len(deleted | (neighborhoods[v] & old)) > radius:
                forbidden.add(v)
        if 'branch' in node:
            assert not contradiction
            branch = node['branch']
            assert type(branch) is int and branch in pool_set - set(inside) - forbidden
            pending.append((inside, outside + (branch,)))
            pending.append((inside + (branch,), outside))
            continue
        if node['status'] == 'exact_conflict_or_radius':
            assert contradiction
            continue
        if (inside, outside) in unknown:
            assert node['status'] not in ('Infeasible', 'exact_integer_contradiction')
            observed_unknown.append((inside, outside))
            if index not in proofs:
                unresolved_unknown.append((inside, outside))
                continue
            certified_unknown.append(index)
        assert not contradiction and index in proofs
        proof = proofs[index]
        weights = proof['multipliers']
        assert len({r for r, _ in weights}) == len(weights)
        coefficients = [0] * len(pool)
        rhs = 0
        for row, weight in weights:
            assert type(row) is int and 0 <= row < len(rows)
            assert type(weight) is int and weight != 0
            rhs += weight * (upper[row] if weight > 0 else lower[row])
            for column, coefficient in rows[row]:
                coefficients[column] += weight * coefficient
        minimum = sum(c * (int(v in inside) if c > 0 else int(v not in forbidden)) for v, c in zip(pool, coefficients))
        assert minimum == proof['minimum_lhs'] and rhs == proof['rhs']
        assert minimum - rhs == proof['positive_gap'] > 0
        gaps.append(minimum-rhs)
        used.add(index)
    assert pending == [(tuple(r['inside']), tuple(r['outside'])) for r in tree['pending_nodes']]
    assert observed_unknown == unknown and used == set(proofs)
    complete = not pending and not unresolved_unknown
    assert args.allow_partial or complete
    out = dict(passed=True, complete_branch_partition=complete, root_partition_replayed=True,
               pending_nodes=len(pending), unknown_nodes=len(unresolved_unknown), recorded_unknown_nodes=len(unknown),
               certified_unknown_indices=certified_unknown, nodes=len(tree['rows']),
               integer_certified_leaves=len(used), minimum_positive_gap=min(gaps) if gaps else None,
               fixed_words=len(fixed), free_pool=len(pool), target=368,
               deletion_radius=radius, exact_parent=data['parent_words'], fixed=data['fixed'],
               no368_in_this_fixed_domain_through_radius=complete,
               checker_sha256=sha(__file__),
               dependencies={str(args.certificates): sha(args.certificates), str(tree_path): sha(tree_path),
                             str(data_path): sha(data_path), str(args.radius_verification): sha(args.radius_verification)},
               scope=f'This fixed{len(fixed)} core region and deletion radius<={radius} only. Integer leaf contradictions and branch partition, conditional on the previously verified F9 computational certificate. Whole-domain exclusion requires complete_branch_partition; no global C7 bound.')
    # Extra certificates may forbid broader conditions than any tree leaf.
    # Check them against the same independently reconstructed domain, without
    # using them to claim additional branch coverage.
    extra_checked = []
    for extra_path in args.extra_leaves:
        extra = json.loads(extra_path.read_text())
        assert extra['status'] == 'complete_attempt'
        assert extra['input'] == tree['input'] and extra['radius'] == radius
        assert extra['target_model_sha256'] == tree['target_model_sha256']
        assert all(sha(f) == h for f, h in extra['dependencies'].items())
        for index, record in enumerate(extra['rows']):
            proof = record['certificate']
            if proof is None:
                continue
            inside, outside = set(record['inside']), set(record['outside'])
            assert len(inside) == len(record['inside']) and len(outside) == len(record['outside'])
            assert inside <= pool_set and outside <= pool_set and not inside & outside
            forbidden = outside | base_forbidden
            for v in inside:
                forbidden |= neighborhoods[v] - {v}
            deleted = forbidden & old
            assert not inside & forbidden and len(deleted) <= radius
            for v in pool_set - old - inside - forbidden:
                if len(deleted | (neighborhoods[v] & old)) > radius:
                    forbidden.add(v)
            coefficients, rhs, seen = [0] * len(pool), 0, set()
            for row, weight in proof['multipliers']:
                assert type(row) is int and 0 <= row < len(rows) and row not in seen
                assert type(weight) is int and weight != 0
                seen.add(row)
                rhs += weight * (upper[row] if weight > 0 else lower[row])
                for column, coefficient in rows[row]:
                    coefficients[column] += weight * coefficient
            minimum = sum(c * (int(v in inside) if c > 0 else int(v not in forbidden))
                          for v, c in zip(pool, coefficients))
            assert minimum == proof['minimum_lhs'] and rhs == proof['rhs']
            assert minimum - rhs == proof['positive_gap'] > 0
            extra_checked.append(dict(file=str(extra_path), index=index, inside=sorted(inside),
                                      outside=sorted(outside), positive_gap=minimum-rhs))
        out['dependencies'][str(extra_path)] = sha(extra_path)
    if domain_exclusion_path:
        out['dependencies'][domain_exclusion_path] = sha(domain_exclusion_path)
        out['applied_domain_exclusion'] = domain_exclusion_path
        out['scope'] += ' Includes the independently reconstructed nested-domain omission constraint, conditional on its completed narrow proof.'
    if common_core_path:
        out['dependencies'][common_core_path] = sha(common_core_path)
        out['dependencies'][common_base_path] = sha(common_base_path)
        out['dependencies'][str(core_checker)] = sha(core_checker)
        out['applied_common_core_omission'] = dict(proof=common_core_path, base=common_base_path,
                                                 core_words=315, minimum_omissions=4,
                                                 free_core_words=len(remaining_core), upper=bound)
        out['scope'] += ' Includes the exact315core omission bound, conditional on its checked all-triples cover proof.'
    out['additional_certified_conditions'] = extra_checked
    args.output.write_text(json.dumps(out, indent=2) + '\n')
    print({k: v for k, v in out.items() if k not in ('dependencies', 'exact_parent', 'fixed')})


if __name__ == '__main__':
    main()
