"""Direct-coordinate census of the small pinned two-omission component."""
from collections import deque
import hashlib
from itertools import product
import json
from pathlib import Path
import struct
import time
import numpy as np

HERE=Path(__file__).resolve().parent


def main():
    if not __debug__:raise RuntimeError('Run without -O')
    source=json.loads((HERE/'a-missing-01013-search.json').read_text())
    start=tuple(sorted(int(w,7) for w in source['final_words']))
    forbidden={int(w,7) for w in ('00063','01013')}
    assert len(start)==368 and not forbidden.intersection(start)
    words=np.array(list(product(range(7),repeat=5)),dtype=np.int16)
    seen={start};todo=deque([start]);directed=0;began=time.monotonic()
    while todo:
        if len(seen)>100 or time.monotonic()-began>30:
            raise RuntimeError('INCOMPLETE direct control')
        state=todo.popleft();selected=words[list(state)]
        diff=(selected[:,None,:]-selected[None,:,:])%7
        graph=np.all((diff==0)|(diff==1)|(diff==6),axis=2)
        degree=graph.sum(axis=1)-1;energy=int(degree.sum())//2
        assert energy==3
        for lo in range(0,len(words),256):
            diff=(words[lo:lo+256,None,:]-selected[None,:,:])%7
            touches=np.all((diff==0)|(diff==1)|(diff==6),axis=2)
            counts=touches.sum(axis=1)
            # Every possible removed word is represented by a column. No
            # degree/pool pruning from search_low_conflict is reused here.
            energies=energy+counts[:,None]-degree[None,:]-touches.astype(np.int16)
            for row,column in zip(*np.nonzero(energies<=3)):
                added=lo+int(row)
                if added in state or added in forbidden:continue
                removed=state[int(column)]
                target=tuple(sorted(set(state)-{removed}|{added}))
                directed+=1
                if target not in seen:seen.add(target);todo.append(target)
    digest=hashlib.sha256(b''.join(sorted(struct.pack('<368H',*state) for state in seen))).hexdigest()
    expected=json.loads((HERE/'a-missing-00063-01013-search.json').read_text())
    assert expected['status']=='exhausted' and len(seen)==expected['states']==6
    assert directed==expected['allowed_directed']==12 and digest==expected['states_sha256']
    result=dict(status='exhausted',states=len(seen),directed_edges=directed,states_sha256=digest,
                seconds=time.monotonic()-began,
                scope='All add/remove pairs evaluated from direct coordinates, with00063 and01013 forbidden. Separate local implementation, not an external replay or global cap3 census.')
    (HERE/'two-missing-direct-verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))


if __name__=='__main__':main()
