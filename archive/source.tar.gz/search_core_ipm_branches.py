"""Bounded IPM-guided branching for an exact368 core-domain construction.

Branch bounds are binary restrictions on new words. Conflict propagation and
the deletion cap prune impossible insertions. LP infeasibility is numerical;
this exploratory search deliberately makes no certificate/exclusion claim.
"""
import argparse
import json
from pathlib import Path
import time

import numpy as np
from scipy.optimize._highspy import _core as high

from check_two_slice_covers import closed
from search_core_radius_cut import sha
from search_core_regions import independence
from solve_core_radius_ipm import build_model, load_radius_model, model_digest


def propagate(pool, old, neighborhoods, inside, outside, radius):
    """Return implied zero variables, or None for an exact conflict/cap failure."""
    inside, outside = set(inside), set(outside)
    if inside & outside:
        return None
    forbidden = set(outside)
    for v in inside:
        forbidden.update(neighborhoods[v] - {v})
    if inside & forbidden:
        return None
    deleted = old & forbidden
    if len(deleted) > radius:
        return None
    for v in pool - old - inside - forbidden:
        if len(deleted | (neighborhoods[v] & old)) > radius:
            forbidden.add(v)
    return forbidden


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path, required=True)
    p.add_argument('--radius', type=int, required=True)
    p.add_argument('--nodes', type=int, default=64)
    p.add_argument('--seconds', type=float, default=120)
    p.add_argument('--lp-seconds', type=float, default=5)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    assert __debug__ and not args.output.exists()
    assert args.nodes > 0 and args.seconds > 0 and args.lp_seconds > 0
    data, matrix, lower, upper, variable_upper, initial = load_radius_model(args.input, args.radius)
    model_sha = model_digest(matrix, lower, upper, variable_upper)
    target = data['target']
    assert upper[-3] == target and lower[-3] == 0
    lower[-3] = target  # Search only the requested368, not neutral367 optima.
    pool, old = set(data['pool']), set(data['parent_words']) - set(data['fixed'])
    positions = {v: i for i, v in enumerate(data['pool'])}
    neighborhoods = {v: closed(v) & pool for v in pool}
    out = dict(status='running', input=str(args.input), radius=args.radius,
               original_model_sha256=model_sha, target_model_sha256=model_digest(matrix, lower, upper, variable_upper),
               source_sha256=sha(__file__), dependencies={str(args.input): sha(args.input)},
               parameters=dict(nodes=args.nodes, seconds=args.seconds, lp_seconds=args.lp_seconds),
               rows=[], unknown_nodes=[], scope=__doc__)
    for name in ('solve_core_radius_ipm.py', 'check_two_slice_covers.py', 'search_core_regions.py'):
        path = Path(__file__).with_name(name)
        out['dependencies'][str(path)] = sha(path)
    stack = [((), ())]
    began = time.monotonic()
    def save():
        out['seconds'] = time.monotonic() - began
        out['pending_nodes'] = [dict(inside=list(a), outside=list(b)) for a, b in stack]
        args.output.write_text(json.dumps(out, indent=2) + '\n')
    save()
    while stack and len(out['rows']) < args.nodes and time.monotonic() - began < args.seconds:
        inside, outside = stack.pop()
        row = dict(inside=list(inside), outside=list(outside))
        forbidden = propagate(pool, old, neighborhoods, inside, outside, args.radius)
        if forbidden is None:
            row['status'] = 'exact_conflict_or_radius'
        else:
            variable_lo = np.zeros(len(pool))
            variable_hi = variable_upper.copy()
            for v in inside:
                variable_lo[positions[v]] = 1
            for v in forbidden:
                variable_hi[positions[v]] = 0
            solver = high._Highs()
            for key, value in dict(output_flag=False, solver='ipm', run_crossover='on',
                                   time_limit=float(min(args.lp_seconds, args.seconds - (time.monotonic() - began)))).items():
                assert solver.setOptionValue(key, value) == high.HighsStatus.kOk
            model = build_model(matrix, lower, upper, variable_hi, False)
            model.col_lower_ = variable_lo
            assert solver.passModel(model) == high.HighsStatus.kOk
            start = time.monotonic()
            solver.run()
            info, solution = solver.getInfo(), solver.getSolution()
            row.update(status=solver.modelStatusToString(solver.getModelStatus()), seconds=time.monotonic() - start,
                       ipm_iterations=info.ipm_iteration_count, objective=info.objective_function_value,
                       forced_zero=len(forbidden), forced_old_deletions=len(forbidden & old))
            if solution.value_valid and info.primal_solution_status == high.kSolutionStatusFeasible:
                x = np.asarray(solution.col_value)
                assert np.all(x >= variable_lo - 1e-6) and np.all(x <= variable_hi + 1e-6)
                assert np.all(matrix @ x >= lower - 1e-6) and np.all(matrix @ x <= upper + 1e-6)
                fractional = np.abs(x - np.rint(x)) > 1e-6
                row['fractional'] = int(fractional.sum())
                if not np.any(fractional):
                    words = sorted(data['fixed'] + [v for v, value in zip(data['pool'], np.rint(x)) if value])
                    assert len(words) == 368 and independence(words) == 67528
                    out.update(status='verified_improvement', verified368=words, pair_checks=67528)
                else:
                    available = [v for v in pool - old - set(inside) - forbidden if fractional[positions[v]]]
                    assert available, 'An independent old set cannot supply a fractional-only residual with integral new words'
                    deleted = forbidden & old
                    branch = max(available, key=lambda v: (x[positions[v]] / max(1, len(neighborhoods[v] & old - deleted)), -v))
                    row.update(branch=branch, branch_value=float(x[positions[branch]]))
                    stack.append((inside, outside + (branch,)))
                    stack.append((inside + (branch,), outside))
            elif solver.getModelStatus() != high.HighsModelStatus.kInfeasible:
                out['unknown_nodes'].append(dict(inside=list(inside), outside=list(outside)))
        out['rows'].append(row)
        save()
        print(dict(node=len(out['rows']), **{k: v for k, v in row.items() if k not in ('inside', 'outside')}), flush=True)
        if out['status'] == 'verified_improvement':
            break
    if out['status'] == 'running':
        out['status'] = 'bounded_attempt_complete'
    save()


if __name__ == '__main__':
    main()
