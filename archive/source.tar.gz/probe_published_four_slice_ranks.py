"""Strengthen a verified four-slice root using a cited published cubic rank.

The published alpha(C7^3)=33 is an explicit external theorem dependency.
Adjacent-layer counting gives alpha(C7^4)<=floor(7*33/2)=115.
The resulting integer cover is replayable conditional on that theorem.
"""
import argparse
import hashlib
from itertools import combinations
import json
from pathlib import Path
import time

import numpy as np
from scipy.optimize import linprog
from scipy.sparse import csc_matrix

from check_two_slice_covers import HERE,WORDS,conflict
from check_cylinder_covers import check_entries
from cylinder_bounds import constraints,certify,CAPACITY,PUBLISHED_CAPACITY,PUBLISHED_SOURCE


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True)
    p.add_argument('--verification',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--seconds',type=float,default=30)
    args=p.parse_args()
    if args.output.exists():raise FileExistsError(args.output)
    if args.seconds<=0:p.error('Positive time limit required')
    source=json.loads(args.input.read_text());checked=json.loads(args.verification.read_text())
    assert checked['input_sha256']==hashlib.sha256(args.input.read_bytes()).hexdigest()
    pool,fixed=source['pool'],source['fixed']
    check_entries(source['root']['certificate'],pool,CAPACITY)
    began=time.monotonic()
    members,desc,_=constraints(pool,[0,3,4],PUBLISHED_CAPACITY)
    rows=dict(zip(members,desc));local={v:i for i,v in enumerate(pool)}
    for c in source['root']['certificate']['cover']:
        key=tuple(sorted(local[v]for v in c['vertices']))
        if c['capacity']<rows.get(key,{'capacity':len(key)+1})['capacity']:
            rows[key]={k:v for k,v in c.items()if k not in ('vertices','units')}
    members=sorted(rows);desc=[rows[row]for row in members]
    rr=[i for i,row in enumerate(members)for _ in row];cc=[v for row in members for v in row]
    matrix=csc_matrix((np.ones(len(rr)),(rr,cc)),shape=(len(members),len(pool)))
    seed={int(w,7)for w in (HERE/'family-d-seed-words.txt').read_text().split()}
    hint=np.array([v in seed for v in pool],dtype=float)
    caps=[d['capacity']for d in desc]
    assert len(fixed)+int(sum(hint))==367 and np.all(matrix@hint<=caps)
    built=time.monotonic()
    solved=linprog(-np.ones(len(pool)),A_ub=matrix,b_ub=caps,bounds=(0,None),method='highs-ipm',options={'time_limit':args.seconds})
    report={k:source[k]for k in ('axis','start','width','pool','fixed')}
    report.update(status=int(solved.status),message=solved.message,target=367-len(fixed),capacity_sequence=PUBLISHED_CAPACITY,
                  published_cube_dependency=dict(url=PUBLISHED_SOURCE,theorem=4,printed_pages=[102],local_computation_replayed=False,
                      pdf_sha256=hashlib.sha256((HERE/'sources/baumert-packing-1971.pdf').read_bytes()).hexdigest()),
                  input_sha256=checked['input_sha256'],source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  constraints=len(members),nonzeros=int(matrix.nnz),build_seconds=built-began,solve_seconds=time.monotonic()-built,candidates=[],
                  scope='One four-slice exterior; cover arithmetic is checked, published cubic theorem is not re-proved here.')
    if solved.success:
        report['floating_bound']=float(-solved.fun)
        report['certificate']=certify(pool,members,desc,-solved.ineqlin.marginals)
        total,den=check_entries(report['certificate'],pool,PUBLISHED_CAPACITY)
        report['full_upper']=len(fixed)+total//den
        report['primal']=[[v,float(x)]for v,x in zip(pool,solved.x)if x>1e-8]
        if np.max(np.abs(solved.x-np.rint(solved.x)))<1e-7:
            chosen=sorted(fixed+[v for v,x in zip(pool,solved.x)if x>.5])
            assert len(chosen)==len(set(chosen)) and all(not conflict(a,b)for a,b in combinations(chosen,2))
            if len(chosen)>=367:
                report['candidates'].append(dict(step=0,size=len(chosen),words=[''.join(map(str,WORDS[v]))for v in chosen],verified_pairs=len(chosen)*(len(chosen)-1)//2))
    args.output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items()if k not in ('pool','fixed','certificate','primal','candidates')}),flush=True)


if __name__=='__main__':main()
