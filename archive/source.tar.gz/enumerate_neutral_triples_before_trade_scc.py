"""Enumerate three-word exchanges from maximal366 sets with the existing kernel.

Keep neutral exchanges with no independent mixed triple in their six-word union.
This is local indecomposability only, not separation of global width2 components.
Status complete means the bounded batch finished; row statuses retain time/output
limits. The native kernel itself is unchanged.
"""
import argparse
import hashlib
from itertools import combinations,product
import json
from pathlib import Path
import subprocess
import time

from check_exchange_dfs import graph_text
from run_seed_exchanges import coordinate_masks,nearby,conflict
from search_exchanges import verify

HERE=Path(__file__).resolve().parent


def mixed_independent(removed,added,compatible):
    r=set(removed);a=set(added)
    for triple in combinations(sorted(r|a),3):
        if set(triple) in (r,a):continue
        if all(compatible(u,v) for u,v in combinations(triple,2)):return list(triple)
    return None


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--indices',type=int,nargs='+',required=True)
    p.add_argument('--seconds',type=float,default=5)
    a=p.parse_args();assert __debug__ and not a.output.exists() and 0<a.seconds<=600
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    source=json.loads(a.input.read_text());assert source['status']=='complete'
    assert len(a.indices)==len(set(a.indices)) and all(0<=i<len(source['bases']) for i in a.indices)
    universe=list(product(range(7),repeat=5));ident={w:i for i,w in enumerate(universe)}
    report=dict(input=str(a.input),input_sha256=sha(a.input),source_sha256=sha(__file__),
                kernel_sha256=sha(HERE/'exchange_dfs'),kernel_source_sha256=sha(HERE/'exchange_dfs.cpp'),
                mask_source_sha256=sha(HERE/'run_seed_exchanges.py'),seconds_per_query=a.seconds,
                indices=a.indices,rows=[],bases=[],candidates=[],status='running',scope=__doc__)
    seen=set();seen_candidates=set();began=time.monotonic()
    def save():
        report['seconds']=time.monotonic()-began
        temp=a.output.with_suffix('.tmp');temp.write_text(json.dumps(report,separators=(',',':'))+'\n');temp.replace(a.output)
    save()
    for bi in a.indices:
        ids=source['bases'][bi]['words'];assert len(ids)==len(set(ids))==366 and ids==sorted(ids)
        words=[universe[v] for v in ids];verify(words);masks=coordinate_masks(words);occupied=set(ids)
        outside=[(v,nearby(w,masks,366)) for v,w in enumerate(universe) if v not in occupied]
        assert all(b for v,b in outside),'Immediate extensions need separate handling'
        pool=sorted(((v,b) for v,b in outside if b.bit_count()<=3),key=lambda row:row[1].bit_count())
        points=[universe[v] for v,b in pool];pm=coordinate_masks(points);full=(1<<len(pool))-1
        blockers=[b for v,b in pool];comp=[full^nearby(w,pm,len(pool)) for w in points]
        encoded=graph_text(blockers,comp,3,6)
        proc=subprocess.run([str(HERE/'exchange_dfs'),str(a.seconds),'--subset','--neutral'],input=encoded,text=True,capture_output=True,check=True,timeout=a.seconds+15)
        result=json.loads(proc.stdout);assert result['status'] in ('exhausted','timeout','output_limit')
        if result['status']=='exhausted':assert result['nodes_started']==result['nodes_completed']
        row=dict(base=bi,pool_ids=[v for v,b in pool],graph_sha256=hashlib.sha256(encoded.encode()).hexdigest(),
                 result=result,locally_indecomposable=[],decomposable=0)
        report['rows'].append(row)
        for kind in ('neutral','improving'):
            for index,chosen in enumerate(result[kind]):
                assert len(chosen)==len(set(chosen))==3 and all(type(i) is int and 0<=i<len(pool) for i in chosen)
                used=0
                for i in chosen:used|=blockers[i]
                assert used.bit_count()<=3 and (used.bit_count()==3)==(kind=='neutral')
                assert all(comp[i]>>j&1 for i,j in combinations(chosen,2))
                removed=[v for i,v in enumerate(ids) if used>>i&1];added=[pool[i][0] for i in chosen]
                new=tuple(sorted((occupied-set(removed))|set(added)))
                if kind=='neutral':
                    witness=mixed_independent(removed,added,lambda u,v:not conflict(universe[u],universe[v]))
                    if witness is not None:row['decomposable']+=1;continue
                    row['locally_indecomposable'].append(index)
                    if new in seen:continue
                    checks=verify([universe[v] for v in new]);assert len(new)==366;seen.add(new)
                    report['bases'].append(dict(words=list(new),source_base=bi,native_index=index,removed=removed,added=added,pair_checks=checks))
                else:
                    checks=verify([universe[v] for v in new]);assert len(new)>=367
                    if new in seen_candidates:continue
                    seen_candidates.add(new)
                    report['candidates'].append(dict(step=len(report['candidates']),source_base=bi,native_index=index,
                        words=[''.join(map(str,universe[v])) for v in new],size=len(new),pair_checks=checks))
                    if len(new)>=368:report['status']='verified_target';save();return
        save();print(json.dumps(dict(base=bi,status=result['status'],neutral=len(result['neutral']),improving=len(result['improving']),locally_indecomposable=len(row['locally_indecomposable']))),flush=True)
    report['status']='complete';report['enumeration_complete']=all(row['result']['status']=='exhausted' for row in report['rows']);save()


if __name__=='__main__':main()
