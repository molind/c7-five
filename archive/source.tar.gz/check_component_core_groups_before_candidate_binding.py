"""Separately rebuild core-omission domains and solve their small residual graphs.

Blockers and adjacency use closed coordinate neighborhoods, independently of
the searcher's NumPy difference arrays. The MIS replay always branches on the
lowest numbered vertex, rather than the searcher's maximum-degree choice.
"""
import argparse
from functools import lru_cache
import gzip
import hashlib
from itertools import combinations, islice, product
import json
import math
from pathlib import Path


def load(path):
    with (gzip.open if Path(path).suffix == '.gz' else open)(path, 'rt') as f:
        return json.load(f)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def bits(mask):
    while mask:
        low = mask & -mask
        yield low.bit_length()-1
        mask ^= low


def closed(v):
    word = [v//7**i % 7 for i in range(4, -1, -1)]
    for point in product(*[((x-1) % 7, x, (x+1) % 7) for x in word]):
        yield sum(x*7**(4-i) for i, x in enumerate(point))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('inputs', nargs='+', type=Path)
    p.add_argument('--output', required=True, type=Path)
    args = p.parse_args()
    if not __debug__:
        raise RuntimeError('Run without -O')
    if args.output.exists():
        raise FileExistsError(args.output)
    results = []
    for path in args.inputs:
        data = load(path)
        certificate = load(data['verification'])
        assert sha(data['verification']) == data['verification_sha256']
        assert sha(data['component']) == data['component_file_sha256'] == certificate['component_file_sha256']
        core = data['core']
        assert core == certificate['core_words'] and len(core) == len(set(core))
        assert all(type(v) is int and 0 <= v < 16807 for v in core)
        assert certificate['closed_under_all_one_for_one_exchanges'] and certificate['connected']
        r = data['release_size']
        assert type(r) is int and 1 <= r <= 8
        owners = [0]*16807
        for i, v in enumerate(core):
            for w in closed(v):
                owners[w] |= 1 << i
        occupied = set(core)
        pool = [v for v in range(16807) if v not in occupied and owners[v].bit_count() <= r]
        assert pool == data['pool'] and [owners[v] for v in pool] == data['blockers']
        index = {v:i for i, v in enumerate(pool)}
        adj = []
        for i, v in enumerate(pool):
            adj.append(sum(1 << index[w] for w in closed(v) if w != v and w in index))
        assert all(not (adj[i] >> i & 1) for i in range(len(pool)))
        assert all(adj[j] >> i & 1 for i, row in enumerate(adj) for j in bits(row))
        @lru_cache(maxsize=500000)
        def alpha(mask):
            if not mask:
                return 0
            bit = mask & -mask
            i = bit.bit_length()-1
            rest = mask ^ bit
            return max(alpha(rest), 1+alpha(rest & ~adj[i]))
        selected_groups = None
        if data.get('selection', 'all') == 'explicit':
            assert sha(data['groups_file']) == data['groups_file_sha256']
            selected_groups = sorted(tuple(sorted(g)) for g in load(data['groups_file']))
            assert selected_groups and len(set(selected_groups)) == len(selected_groups)
            assert all(len(g) == len(set(g)) == r and all(type(v) is int and v in occupied for v in g) for g in selected_groups)
        total = len(selected_groups) if selected_groups is not None else math.comb(len(core), r)
        assert data['total_groups'] == total
        assert 0 <= data['start'] < data['end'] <= total
        assert data['next_index'] == data['start']+len(data['rows']) <= data['end']
        assert [row['index'] for row in data['rows']] == list(range(data['start'], data['next_index']))
        expected_groups = islice(combinations(core, r) if selected_groups is None else selected_groups,
                                data['start'], data['next_index'])
        core_index = {v:i for i, v in enumerate(core)}
        largest = 0
        distinct_domains = set()
        for row, expected in zip(data['rows'], expected_groups):
            assert row['omitted'] == list(expected)
            omission = sum(1 << core_index[v] for v in expected)
            # Scan every eligible word for each group; do not reuse the
            # searcher's subset-index construction of the active domain.
            domain = sum(1 << i for i, v in enumerate(pool) if owners[v] & ~omission == 0)
            assert domain.bit_count() == row['domain_size']
            actual = alpha(domain)
            assert actual == row['alpha']
            residual = row['residual']
            assert len(residual) == len(set(residual)) == actual
            assert all(v in index and domain >> index[v] & 1 for v in residual)
            chosen = sum(1 << index[v] for v in residual)
            assert all(not (adj[i] & chosen) for i in bits(chosen))
            largest = max(largest, len(core)-r+actual)
            distinct_domains.add(domain)
        assert largest == data['best_full_size']
        complete = data['status'] in ('exhausted', 'selection_complete', 'range_complete')
        if complete:
            assert data['next_index'] == data['end']
        assert (data['status'] == 'exhausted') == (selected_groups is None and complete and data['start'] == 0 and data['end'] == total)
        assert (data['status'] == 'selection_complete') == (selected_groups is not None and complete and data['start'] == 0 and data['end'] == total)
        results.append(dict(input=str(path), input_sha256=sha(path), release_size=r,
            complete_group_range=complete, all_groups_complete=data['status'] == 'exhausted',
            groups_checked=len(data['rows']), pool=len(pool), distinct_domains=len(distinct_domains),
            best_full_size=largest, separate_recursion_states=alpha.cache_info().currsize))
        print(json.dumps(results[-1]), flush=True)
    args.output.write_text(json.dumps(dict(results=results, checker_sha256=sha(__file__),
        scope='Every saved group and its entire compatible noncore domain rebuilt; all saved optima replayed by a distinct branch order. Local bounds only; unprocessed groups remain open.'), indent=2)+'\n')


if __name__ == '__main__':
    main()
