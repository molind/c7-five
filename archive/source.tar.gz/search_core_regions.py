"""Probe larger shared-core omissions, then solve open domains constructively.

Only the listed sampled domains are searched. Exact integer covers exclude
368 locally; a MILP timeout does not exclude it. Every returned word set is
verified directly. No candidate is called a new family without classification.
"""
import argparse
import hashlib
from itertools import combinations, product
import json
from pathlib import Path
import random
import time

import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import csc_matrix

from cover_three_core_omissions import fractional_cover
from cover_two_core_omissions import containing_box
from check_common314_covers import decode, encode


def independence(words):
    assert len(words)==len(set(words)) and all(type(v) is int and 0<=v<16807 for v in words)
    count=0
    for a,b in combinations(words,2):
        assert any((x-y)%7 in (2,3,4,5) for x,y in zip(decode(a),decode(b)))
        count+=1
    return count


def box_constraints(pool,coords,corners,powers):
    index={v:i for i,v in enumerate(pool)};origins=set()
    for v in pool:origins.update((((coords[v]-corners)%7)@powers).tolist())
    rows=set()
    for origin in sorted(origins):
        rows.add(tuple(index[v] for v in (((coords[origin]+corners)%7)@powers).tolist() if v in index))
    rr=[];cc=[]
    for i,row in enumerate(sorted(rows)):
        rr.extend([i]*len(row));cc.extend(row)
    return csc_matrix((np.ones(len(rr)),(rr,cc)),shape=(len(rows),len(pool)))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--base',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--max-cases',type=int,default=64)
    p.add_argument('--milp-seconds',type=float,default=10)
    args=p.parse_args();assert __debug__ and not args.output.exists()
    assert args.max_cases>0 and args.milp_seconds>0
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    base=json.loads(args.base.read_text());assert sha(base['input'])==base['input_sha256']
    core=sorted(base['fixed']);assert len(core)==len(set(core))==315
    assert independence(base['witness'])==67161 and set(core)<=set(base['witness'])
    coords=np.array(list(product(range(7),repeat=5)),dtype=np.int16)
    powers=np.array([2401,343,49,7,1]);corners=np.array(list(product((0,1),repeat=5)))
    blockers=[set() for _ in range(16807)]
    for v in core:
        for w in product(*[((x-1)%7,x,(x+1)%7) for x in decode(v)]):blockers[encode(w)].add(v)
    buckets={}
    for v,bk in enumerate(blockers):buckets.setdefault(tuple(sorted(bk)),[]).append(v)
    bad=[v for v in core if containing_box(buckets[(v,)]) is None]
    recipes=[];seen=set()
    def add(label,omitted):
        key=tuple(sorted(omitted))
        if len(key)>=4 and key not in seen:
            assert set(key)<=set(core)
            seen.add(key);recipes.append((label,key))
    add('all non-box singleton buckets',bad)
    neighbors={v:set() for v in core}
    for key in buckets:
        if len(key)==2:
            a,b=key;neighbors[a].add(b);neighbors[b].add(a)
    add('bad singleton vertices plus their pair-bucket neighbors',set(bad)|set().union(*(neighbors[v] for v in bad)))
    for axis in range(5):
        for value in range(7):add(f'coordinate {axis} value {value}',[v for v in core if decode(v)[axis]==value])
    rng=random.Random(2026092255)
    for size in (4,6,8,12,16,20):
        add(f'bad singleton sample size {size}',rng.sample(bad,size))
    for v in bad:
        add(f'pair-bucket neighborhood of {v}',{v}|neighbors[v])
    # Prefer blocker sets releasing many jointly eligible words per omitted word.
    scores=[]
    for key in buckets:
        if 4<=len(key)<=12:
            omit=set(key);eligible=sum(len(values) for bk,values in buckets.items() if set(bk)<=omit)
            scores.append((eligible/len(key),key))
    for _,key in sorted(scores,reverse=True)[:64]:add('high eligible density blocker set',key)
    rows=[];began=time.monotonic();improvement=None
    dependencies={str(args.base):sha(args.base),base['input']:sha(base['input'])}
    for name in ('cover_three_core_omissions.py','cover_two_core_omissions.py','check_common314_covers.py'):
        path=Path(__file__).with_name(name);dependencies[str(path)]=sha(path)
    for ordinal,(label,key) in enumerate(recipes[:args.max_cases]):
        omitted=set(key);fixed=sorted(set(core)-omitted)
        pool=[v for v,bk in enumerate(blockers) if bk<=omitted]
        assert not set(fixed)&set(pool)
        target=368-len(fixed);D=1000000
        row=dict(ordinal=ordinal,label=label,omitted=list(key),fixed_size=len(fixed),target=target,
                 **fractional_cover(pool,D,coords,corners,powers))
        row['denominator']=D
        row['cover_excludes368']=row['total_units']<target*D
        if not row['cover_excludes368']:
            matrix=box_constraints(pool,coords,corners,powers)
            result=milp(-np.ones(len(pool)),integrality=np.ones(len(pool)),bounds=Bounds(0,1),
                constraints=LinearConstraint(matrix,0,1),options={'time_limit':args.milp_seconds,'mip_rel_gap':0})
            row['milp']=dict(status=int(result.status),message=result.message,
                seconds_limit=args.milp_seconds,box_constraints=matrix.shape[0],
                reported_dual_bound=float(result.mip_dual_bound) if getattr(result,'mip_dual_bound',None) is not None else None)
            if result.x is not None:
                assert np.max(np.abs(result.x-np.rint(result.x)))<1e-6
                chosen=[v for v,x in zip(pool,result.x) if x>.5]
                witness=sorted(fixed+chosen);checks=independence(witness)
                row['milp'].update(witness=witness,size=len(witness),pair_checks=checks)
                if len(witness)>=368:
                    improvement=witness[:368];assert independence(improvement)==67528
        rows.append(row)
        out=dict(status='verified_improvement' if improvement else 'running',rows=rows,
            improved_words=improvement,source_sha256=sha(__file__),dependencies=dependencies,
            recipes_available=len(recipes),requested_cases=args.max_cases,seconds=time.monotonic()-began,
            scope='Listed sampled core-omission domains only; timeout is unknown; no global bound.')
        args.output.write_text(json.dumps(out,indent=2)+'\n')
        print(dict(case=ordinal,omitted=len(key),pool=len(pool),cover=row['total_units']/D,target=target,
            milp=row.get('milp',{}).get('status'),size=row.get('milp',{}).get('size')),flush=True)
        if improvement:break
    if not improvement:out['status']='complete_sample'
    args.output.write_text(json.dumps(out,indent=2)+'\n')


if __name__=='__main__':main()
