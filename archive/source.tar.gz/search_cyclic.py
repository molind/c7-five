"""Search cyclic lattice constructions that round directly to C7^5.

For a modulus n, choose at most five multipliers a. For each nonzero t,
at least one circular distance |t*a|_n must be >= ceil(2*n/7).
Rounding each coordinate x to floor(7*x/n) then preserves separation.
This extends the geometric multiplier ansatz in Polak--Schrijver; a
negative answer here concerns only these cyclic constructions.
"""

import argparse
import hashlib
import json
import time
from pathlib import Path

import z3

from search_exchanges import verify


def is_prime(n):
    return n >= 2 and all(n % d for d in range(2, int(n**0.5) + 1))


def search(n, timeout_ms):
    threshold = (2 * n + 6) // 7
    variables = {a: z3.Bool(f"a_{a}") for a in range(1, n // 2 + 1)}
    solver = z3.SolverFor("QF_FD")
    solver.set(timeout=timeout_ms, random_seed=20260915)
    solver.add(z3.PbLe([(v, 1) for v in variables.values()], 5))
    for t in range(1, n // 2 + 1):
        covering = [var for a, var in variables.items()
                    if threshold <= (t * a) % n <= n - threshold]
        solver.add(z3.Or(*covering))
    # For prime n, multiplying all multipliers by any nonzero inverse
    # merely permutes t. One selected multiplier can therefore be 1.
    if is_prime(n):
        solver.add(variables[1])
    start = time.monotonic()
    status = solver.check()
    result = {"n": n, "threshold": threshold, "status": str(status),
              "seconds": time.monotonic() - start, "timeout_ms": timeout_ms,
              "prime_normalization": is_prime(n)}
    solution = None
    if status == z3.sat:
        model = solver.model()
        aa = [a for a, v in variables.items() if z3.is_true(model.eval(v))]
        aa += [0] * (5 - len(aa))
        assert all(max(min((t*a) % n, n - (t*a) % n) for a in aa) >= threshold
                   for t in range(1, n))
        words = [[7 * ((t*a) % n) // n for a in aa] for t in range(n)]
        verify(words)
        result["multipliers"] = aa
        solution = {"words": words}
    elif status == z3.unknown:
        result["reason"] = solver.reason_unknown()
    return result, solution


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--moduli", type=int, nargs="+", default=list(range(368, 402)))
    parser.add_argument("--timeout", type=int, default=3, help="seconds per modulus")
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("cyclic-results.json"))
    args = parser.parse_args()
    report = {"z3_version": z3.get_version_string(), "results": []}
    for n in args.moduli:
        result, solution = search(n, args.timeout * 1000)
        print(json.dumps(result), flush=True)
        report["results"].append(result)
        args.output.write_text(json.dumps(report, indent=2) + "\n")
        if solution is not None:
            args.output.with_suffix(".solution.json").write_text(json.dumps(solution, indent=2)+"\n")
            break


if __name__ == "__main__":
    main()
