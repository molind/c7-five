"""Rebuild the reported greedy covers, then test reverse order on residual cases.

The trimming idea and forward-order results are curious-reader-4c82e374's
Inputs are our pinned U2 certificate and the contributed saved rows.
No search for independent sets is performed here.
"""
import contextlib
import hashlib
import io
import json
from itertools import product
from pathlib import Path
import runpy
import struct

if not __debug__:
    raise RuntimeError('Run without -O')
ROOT = Path(__file__).parent
with contextlib.redirect_stdout(io.StringIO()):
    cert = runpy.run_path(str(ROOT / 'shared_u2_compact_replay.py'))
universe = list(product(range(7), repeat=5))
u2 = sorted(cert['U2'])
index = {word: i for i, word in enumerate(u2)}
records = list(struct.iter_unpack('<HI', cert['raw']))
boxes = []
for origin, weight in records:
    vertices = product(*[(x, (x + 1) % 7) for x in universe[origin]])
    boxes.append(([index[v] for v in vertices if v in index], weight))
coverage = [0] * len(u2)
for vertices, weight in boxes:
    for i in vertices:
        coverage[i] += weight
assert min(coverage) == 1000001

def trim(token, reverse=False):
    anchor = tuple(map(int, token))
    assert anchor not in index
    # Explicit coordinate differences; use our certificate, not the other checker.
    allowed = {i for i, w in enumerate(u2)
               if any((x-y) % 7 in (2, 3, 4, 5) for x, y in zip(w, anchor))}
    live = [set(vertices) & allowed for vertices, _ in boxes]
    excess = {i: coverage[i] - 1000000 for i in allowed}
    weights = [w for _, w in boxes]
    order = range(len(boxes)-1, -1, -1) if reverse else range(len(boxes))
    for j in order:
        reduction = min([weights[j]] + [excess[i] for i in live[j]])
        weights[j] -= reduction
        for i in live[j]:
            excess[i] -= reduction
    # Reconstruct coverage from the final weights, ignoring the maintained slack.
    rebuilt = {i: 0 for i in allowed}
    for vertices, weight in zip(live, weights):
        assert isinstance(weight, int) and weight >= 0
        for i in vertices:
            rebuilt[i] += weight
    assert all(rebuilt[i] >= 1000000 for i in allowed)
    assert all(rebuilt[i] == excess[i] + 1000000 for i in allowed)
    return sum(weights), weights, len(allowed), min(rebuilt.values())

rows = json.loads((ROOT / 'sources/curious-reader-sep18/trim-all-results.json').read_text())
assert len(rows) == len({r['anchor'] for r in rows}) == 3790
canonical = ''.join(f"{r['anchor']},{r['before']},{r['after']}\n"
                    for r in sorted(rows, key=lambda r: r['anchor'])).encode()
assert hashlib.sha256(canonical).hexdigest() == '2c50d98979f1f8db4743f3b606f35f6b46ecb42ee24311ab83abbddc80da7bd8'
reversed_rows = []
for r in rows:
    total, weights, size, minimum = trim(r['anchor'])
    assert total == r['after']
    if r['anchor'] == '21633':
        saved = json.loads((ROOT / 'sources/curious-reader-sep18/trimmed-21633.json').read_text())
        assert weights == saved['weights'] and total == saved['total_units']
        assert size == 2194 and minimum == 1000000
    if total >= 367000000:
        rev, weights, size, minimum = trim(r['anchor'], reverse=True)
        reversed_rows.append(dict(anchor=r['anchor'],forward=total,reverse=rev))
assert len(reversed_rows) == 1353
report = dict(forward_reproduced=len(rows), forward_new_exclusions=2437,
              reverse_tested=len(reversed_rows),
              reverse_new_exclusions=sum(r['reverse'] < 367000000 for r in reversed_rows),
              reverse_rows=reversed_rows,
              scope='Exact covers of V(a); sole-outside-word exclusions, not global alpha.')
(ROOT / 'greedy-anchor-order-results.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({k: v for k, v in report.items() if k != 'reverse_rows'}), flush=True)
