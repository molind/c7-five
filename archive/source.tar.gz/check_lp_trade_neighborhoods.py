"""Replay frozen bounds and LP-point feasibility without importing the search.

The companion geometric-domain verifier checks blockers, cuts and full output
sets from coordinates. This checker binds that evidence and verifies sampling,
hint preservation and bounds. Numerical solver optimality is not certified.
"""
import argparse
import copy
import hashlib
import json
import math
from pathlib import Path
import random


def check(report, domain, old, hint):
    pool=domain['pool_ids'];active=domain['active_old_indices'];n=len(pool)
    blocked=domain.get('blocker_sets',domain.get('blocker_pairs'))
    full=sorted(int(w,7) for w in hint['words'])
    assert full==report['hint_words'] and len(full)==len(set(full))==367
    assert set(full)<=set(old+pool)
    mandatory=[i for i,v in enumerate(old) if v not in full]
    assert mandatory==report['mandatory_removals'] and set(mandatory)<=set(active)
    hint_x=[int(v in full) for v in pool]
    hint_y={j:int(j in mandatory) for j in range(len(old))}
    assert sum(hint_x)-sum(hint_y.values())==1
    point=report['root_lp']['values'];assert len(point)==n+len(active)
    assert all(math.isfinite(v) and -1e-7<=v<=1+1e-7 for v in point)
    yy=dict.fromkeys(range(len(old)),0.0);yy.update(zip(active,point[n:]))

    def feasible(xx, y):
        for i,group in enumerate(blocked):
            for j in group:assert xx[i]<=y[j]+1e-6
        for i,j in domain['conflict_edges']:assert xx[i]+xx[j]<=1+1e-6
        for box in domain.get('box_cliques',[]):
            bound=y[box['old_index']] if box['old_index']>=0 else 1
            assert sum(xx[i] for i in box['candidates'])<=bound+1e-6
        for cycle in domain.get('odd_cycles',[]):
            assert sum(xx[i] for i in cycle['candidates'])+sum(1-y[j] for j in cycle['old_indices'])<=len(cycle['vertices'])//2+1e-6
        for cut in domain.get('projection_cuts',[]):
            assert sum(xx[i] for i in cut['candidates'])+sum(1-y[j] for j in cut['old_indices'])<=cut['capacity']+1e-6

    feasible(point[:n],yy);feasible(hint_x,hint_y)
    assert abs(sum(point[:n])-sum(point[n:])-report['root_lp']['gain_bound'])<1e-6
    assert report['root_lp']['status']==0
    expected=[(budget,trial) for budget in report['budgets'] for trial in range(report['trials'])]
    actual=[(row['budget'],row['trial']) for row in report['rows']]
    assert report['status'] in ('complete','verified_target')
    assert actual==expected if report['status']=='complete' else actual==expected[:len(actual)]
    rows=[]
    for row in report['rows']:
        assert row['base']==report['base']==domain['base'] and row['mode']=='improve'
        budget=row['budget'];trial=row['trial'];seed=report['seed']+100*budget+trial
        assert row['sampling_seed']==seed and len(mandatory)<=budget<=len(active)
        ranked=[j for j in active if j not in mandatory]
        if trial==0:ranked.sort(key=lambda j:(-yy[j],j))
        else:
            rng=random.Random(seed)
            keys={j:-math.log(1-rng.random())/(max(0.0,yy[j])+0.05) for j in ranked}
            ranked.sort(key=lambda j:(keys[j],j))
        permitted=sorted(mandatory+ranked[:budget-len(mandatory)])
        assert permitted==row['permitted_removals'] and len(set(permitted))==budget
        enabled=[i for i,group in enumerate(blocked) if set(group)<=set(permitted)]
        assert enabled==row['enabled_candidates']
        upper=enabled+[n+k for k,j in enumerate(active) if j in permitted]
        assert upper==row['upper_one_indices']
        assert {i for i,v in enumerate(hint_x) if v}<=set(enabled)
        assert row['initial_size']==367 and row['lexicographic_weight']==n+1
        assert row['initial_objective']==-(n+1)-sum(hint_x)
        assert row['objective_target']==-2*(n+1)
        if 'chosen_indices' in row:
            assert set(row['chosen_indices'])<=set(enabled)
            assert set(row['removed_indices'])<=set(permitted)
            reconstructed_cost=-(n+1)*(row['size']-366)-len(row['chosen_indices'])
            # Returned sets may restore auxiliary removals unused by insertions.
            assert reconstructed_cost<=row['objective']+1e-5<=row['initial_objective']+2e-5
        rows.append(dict(budget=budget,trial=trial,enabled_candidates=len(enabled),hint_preserved=True))
    return rows


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--result',required=True,type=Path)
    p.add_argument('--geometry-proof',required=True,type=Path)
    p.add_argument('--output',required=True,type=Path)
    a=p.parse_args();assert __debug__ and not a.output.exists()
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    r=json.loads(a.result.read_text());model_path=Path(r['input'])
    assert sha(model_path)==r['input_sha256'];model=json.loads(model_path.read_text())
    source=Path(model['input']);assert sha(source)==model['input_sha256']
    hint_path=Path(r['initial_solutions']['file']);assert sha(hint_path)==r['initial_solutions']['sha256']
    proof=json.loads(a.geometry_proof.read_text())
    assert proof['model_sha256']==sha(model_path)
    assert any(q['file']==str(a.result) and q['sha256']==sha(a.result) for q in proof['results'])
    domain=next(d for d in model['rows'] if d['base']==r['base'])
    old=json.loads(source.read_text())['bases'][r['base']]['words']
    hint=next(c for c in json.loads(hint_path.read_text())['candidates'] if c['source_base']==r['base'] and c['size']==367)
    rows=check(r,domain,old,hint)
    mutations=[]
    for kind in ('lp_point','permission','bound','hint'):
        broken=copy.deepcopy(r)
        if kind=='lp_point':broken['root_lp']['values'][0]=1.25
        elif kind=='permission':broken['rows'][0]['permitted_removals'].pop()
        elif kind=='bound':broken['rows'][0]['upper_one_indices'].pop()
        else:broken['hint_words'].pop()
        try:check(broken,domain,old,hint)
        except AssertionError:mutations.append(kind)
        else:raise AssertionError('Damaged certificate accepted: '+kind)
    out=dict(result=str(a.result),result_sha256=sha(a.result),checker_sha256=sha(__file__),
             geometry_proof=str(a.geometry_proof),geometry_proof_sha256=sha(a.geometry_proof),
             root_lp_point_feasible=True,rows=rows,negative_controls_rejected=mutations,
             independent_optimality_certificate=False,scope=__doc__)
    a.output.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))


if __name__=='__main__':main()
