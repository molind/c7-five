"""Exhaustively test transfer of target-specific exterior exclusions on small graphs."""
import argparse
from itertools import combinations
import json
from pathlib import Path


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    edges = list(combinations(range(5),2))
    subsets = [{v for v in range(5) if mask>>v&1} for mask in range(32)]
    result = dict(graphs=0,proved_cuts=0,feasible_target_checks=0,closed_new_exteriors=0,
                  unchecked_cuts_that_would_remove_a_target=0)
    for mask in range(1<<len(edges)):
        graph = [edge for i,edge in enumerate(edges) if mask>>i&1]
        independent = [s for s in subsets if all(not {a,b}<=s for a,b in graph)]
        targets = [s for s in independent if len(s)>=3]
        for seed in (s for s in independent if len(s)==2):
            old_exteriors = [e for e in subsets if e<=seed]
            for old in old_exteriors:
                certified = not any(old<=s for s in targets)
                for fixed in old_exteriors:
                    feasible = [s for s in targets if fixed<=s]
                    cut = old-fixed
                    if not certified:
                        result['unchecked_cuts_that_would_remove_a_target'] += any(cut<=s for s in feasible)
                        continue
                    if not cut:
                        assert not feasible
                        result['closed_new_exteriors'] += 1
                        continue
                    result['proved_cuts'] += 1
                    for witness in feasible:
                        assert len(cut&witness)<=len(cut)-1
                        result['feasible_target_checks'] += 1
        result['graphs'] += 1
    assert result['graphs']==1024 and result['feasible_target_checks']>0
    assert result['unchecked_cuts_that_would_remove_a_target']>0
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result),flush=True)


if __name__=='__main__':
    main()
