"""Check the first finite slice-path closure experiment, including all walks.

All six-slice walks in the small source graph are enumerated independently of
the search DP. Boundary domains use vectorized coordinate differences. Exact
extension maxima are re-run with target best+1 using the recorded graph kernel.
"""
import argparse
from collections import Counter
import hashlib
from itertools import combinations, product
import json
from pathlib import Path
import subprocess

import numpy as np

from search_slice_library import HERE


def main():
    if not __debug__:raise RuntimeError('Run without -O')
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    args=p.parse_args()
    if args.output.exists():raise FileExistsError(args.output)
    r=json.loads(args.input.read_text());sp=Path(r['input']);vp=Path(r['verification'])
    assert hashlib.sha256(sp.read_bytes()).hexdigest()==r['input_sha256']
    assert hashlib.sha256(vp.read_bytes()).hexdigest()==r['verification_sha256']
    assert json.loads(vp.read_text())['input_sha256']==r['input_sha256']
    assert hashlib.sha256((HERE/'slice_clique').read_bytes()).hexdigest()==r['kernel_sha256']
    s=json.loads(sp.read_text());adj=s['adjacency'];weights=s['weights'];slices=s['slices']
    # This intentionally bounded checker must not accidentally enumerate a
    # much denser component library with exponentially many walks.
    assert len(slices)<=175 and max(map(len,adj))<=3
    best={};walks=0
    for start in range(len(slices)):
        stack=[([start],weights[start])]
        while stack:
            path,score=stack.pop()
            if len(path)==6:
                pair=tuple(sorted((start,path[-1])));best[pair]=max(score,best.get(pair,-1));walks+=1
            else:
                stack.extend((path+[v],score+weights[v])for v in adj[path[-1]])
    assert len(r['jobs'])==len(best)
    vertices=np.array(list(product(range(7),repeat=4)),dtype=np.int16)
    blocked=[]
    for sl in slices:
        diff=(vertices[:,None,:]-np.array(sl,dtype=np.int16)[None,:,:])%7
        blocked.append(np.any(np.all((diff==0)|(diff==1)|(diff==6),axis=2),axis=1))
    seen=set()
    for job in r['jobs']:
        a,b=job['endpoints'];pair=(a,b);assert pair in best and pair not in seen;seen.add(pair)
        path=job['path'];assert len(path)==6 and path[0]==a and path[-1]==b
        assert all(v in adj[u]for u,v in zip(path,path[1:]))
        assert job['path_size']==sum(weights[i]for i in path)==best[pair]
        assert job['target']==368-best[pair]>0
        assert job['pool']==np.flatnonzero(~blocked[a]&~blocked[b]).tolist()
    assert [q['index']for q in r['results']]==list(range(len(r['results'])))
    assert r['status']=='complete' and len(r['results'])==len(r['jobs'])and not r['candidates']
    maxima=[];replayed=0;verified_pairs=0
    for q in r['results']:
        job=r['jobs'][q['index']];pool=job['pool']
        if q['status']=='cardinality_closed':
            assert len(pool)<job['target'];continue
        assert q['status']=='exhausted'
        points=vertices[pool];diff=(points[:,None,:]-points[None,:,:])%7
        edges=np.argwhere(np.triu(np.all((diff==0)|(diff==1)|(diff==6),axis=2),k=1)).tolist()
        selected=q['vertices'];assert len(selected)==len(set(selected))==q['best_size']<job['target']
        assert all(type(i)is int and 0<=i<len(pool)for i in selected)
        edge_set=set(map(tuple,edges));assert all(e not in edge_set for e in combinations(sorted(selected),2))
        data=f'{len(pool)} {len(edges)} {q["best_size"]+1} {r["milliseconds"]} {len(selected)}\n'+' '.join(map(str,selected))+'\n'+''.join(f'{u} {v}\n'for u,v in edges)
        rerun=subprocess.run([str(HERE/'slice_clique')],input=data,text=True,capture_output=True,check=True,timeout=r['milliseconds']/1000+5)
        exact=json.loads(rerun.stdout);assert exact['status']=='exhausted' and exact['best_size']==q['best_size']
        full=np.array([(layer,*w)for layer,i in enumerate(job['path'])for w in slices[i]]+[(6,*vertices[pool[i]].tolist())for i in selected],dtype=np.int16)
        delta=(full[:,None,:]-full[None,:,:])%7
        assert not np.any(np.triu(np.all((delta==0)|(delta==1)|(delta==6),axis=2),k=1))
        assert q['full_size']==len(full)==job['path_size']+q['best_size']<368
        assert q['verified_pairs']==len(full)*(len(full)-1)//2
        maxima.append(len(full));verified_pairs+=q['verified_pairs'];replayed+=1
    assert max(maxima)==367
    assert r['statistics']==dict(Counter(q['status']for q in r['results']))
    result=dict(input_sha256=hashlib.sha256(args.input.read_bytes()).hexdigest(),
        checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),kernel_sha256=r['kernel_sha256'],
        enumerated_six_slice_walks=walks,endpoint_domains=len(best),cardinality_closed=r['statistics']['cardinality_closed'],
        exact_extension_searches_replayed=replayed,full_witness_pairs=verified_pairs,optimum367=True,target_witness_found=False,
        scope='Any six consecutive slices from this 175-slice library plus any seventh slice; kernel-dependent finite proof, no global bound.')
    args.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)


if __name__=='__main__':main()
