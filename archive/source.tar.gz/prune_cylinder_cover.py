"""Iterate exact reduced-cost exclusions for a fixed target cardinality.

If cover total is T, denominator D, and vertex v has coverage c(v), any
target-size independent set containing v needs at least target*D+c(v)-D
cover units. Thus c(v)-D > T-target*D excludes v for that target only.
Every round is archived and can be replayed without a numerical solver.
"""
import argparse
import hashlib
from itertools import combinations
import json
from pathlib import Path
import time

from check_two_slice_covers import HERE, WORDS, closed, conflict
from check_cylinder_covers import check_entries


def exclusions(certificate, pool, target):
    den, total = certificate['denominator'], certificate['total_units']
    coverage = dict.fromkeys(pool, 0)
    for row in certificate['cover']:
        for v in row['vertices']:
            coverage[v] += row['units']
    assert all(c >= den for c in coverage.values())
    return [dict(vertex=v, excess_units=c-den) for v, c in coverage.items()
            if c-den > total-target*den]


def replay(report):
    seed = {int(w, 7) for w in (HERE/'family-d-seed-words.txt').read_text().split()}
    assert len(seed) == 367 and all(not conflict(a, b) for a, b in combinations(seed, 2))
    axis, start, width = (report[k] for k in ('axis', 'start', 'width'))
    assert axis in range(5) and start in range(7) and width == 3
    fixed = {v for v in seed if (WORDS[v][axis]-start) % 7 >= width}
    assert sorted(fixed) == report['fixed']
    pool = sorted(set(range(7**5))-set.union(*(set(closed(v)) for v in fixed)))
    assert pool == report['initial_pool']
    capacities = [1]
    for _ in range(5):
        capacities.append(7*capacities[-1]//2)
    target = report['residual_target']
    assert target > 0 and report['full_target'] == len(fixed)+target
    excluded = False
    for row in report['rounds']:
        assert not excluded and row['pool'] == pool
        total, den = check_entries(row['certificate'], pool, capacities)
        if total < target*den:
            assert row['removed'] == [] and row['excludes_target']
            excluded = True
        else:
            assert not row['excludes_target']
            # Explicit per-vertex sums independently check each recorded decision.
            expected = []
            for v in pool:
                weight = sum(c['units'] for c in row['certificate']['cover'] if v in c['vertices'])
                if weight-den > total-target*den:
                    expected.append(dict(vertex=v, excess_units=weight-den))
            assert expected == row['removed']
            pool = sorted(set(pool)-{v['vertex'] for v in expected})
    assert report['final_pool'] == pool
    assert report['excludes_target'] == excluded
    return dict(rounds=len(report['rounds']), original_pool=len(report['initial_pool']),
                remaining_pool=len(pool), removed=len(report['initial_pool'])-len(pool),
                full_target=report['full_target'], excludes_target=excluded,
                scope='Eliminations apply only to independent sets reaching the stated target.')


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--verify', action='store_true')
    p.add_argument('--rounds', type=int, default=6)
    p.add_argument('--seconds', type=float, default=15)
    p.add_argument('--target', type=int, default=368)
    args = p.parse_args()
    if args.rounds < 1 or args.seconds <= 0 or args.target < 1:
        p.error('Positive limits required')
    if args.output.exists():
        raise FileExistsError(args.output)
    source = json.loads(args.input.read_text())
    if args.verify:
        result = replay(source)
        result['input_sha256'] = hashlib.sha256(args.input.read_bytes()).hexdigest()
        args.output.write_text(json.dumps(result, indent=2)+'\n')
        print(json.dumps(result), flush=True)
        return
    import numpy as np
    from scipy.optimize import linprog
    from cylinder_bounds import certify
    from refine_cylinder_ranks import refined_constraints
    assert source['status'] == 0 and not source.get('published_cube_dependency')
    report = {k: source[k] for k in ('axis', 'start', 'width', 'fixed')}
    report.update(initial_pool=source['pool'], rounds=[], excludes_target=False,
                  full_target=args.target, residual_target=args.target-len(source['fixed']),
                  input_sha256=hashlib.sha256(args.input.read_bytes()).hexdigest(),
                  source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    assert report['residual_target'] > 0
    pool = list(source['pool'])
    certificate = source['certificate']
    for i in range(args.rounds):
        row = dict(index=i, pool=pool, certificate=certificate, removed=[], excludes_target=False)
        check_entries(certificate, pool, source['capacity_sequence'])
        report['rounds'].append(row)
        if certificate['total_units'] < report['residual_target']*certificate['denominator']:
            row['excludes_target'] = report['excludes_target'] = True
        else:
            row['removed'] = exclusions(certificate, pool, report['residual_target'])
            pool = sorted(set(pool)-{v['vertex'] for v in row['removed']})
        report['final_pool'] = pool
        args.output.write_text(json.dumps(report, indent=2)+'\n')
        print(json.dumps(dict(round=i, vertices=len(row['pool']), removed=len(row['removed']),
                              total_units=certificate['total_units'], excludes_target=row['excludes_target'])), flush=True)
        if row['excludes_target'] or not row['removed'] or i+1 == args.rounds:
            break
        began = time.monotonic()
        members, desc, matrix, stats = refined_constraints(pool)
        solved = linprog(-np.ones(len(pool)), A_ub=matrix, b_ub=[c['capacity'] for c in desc],
                         bounds=(0, None), method='highs-ipm', options={'time_limit': args.seconds})
        row['next_lp'] = dict(status=int(solved.status), seconds=time.monotonic()-began,
                              message=solved.message, stats=stats)
        args.output.write_text(json.dumps(report, indent=2)+'\n')
        if not solved.success:
            break
        certificate = certify(pool, members, desc, -solved.ineqlin.marginals)
    report['verification'] = replay(report)
    args.output.write_text(json.dumps(report, indent=2)+'\n')


if __name__ == '__main__':
    main()
