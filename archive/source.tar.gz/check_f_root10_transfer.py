"""Bind the selected-root10 restrictions for radius9 at its one-word neighbors."""
import gzip,hashlib,json,random
from pathlib import Path
from itertools import product
import numpy as np
from check_radius10_tail import audit


def main():
    assert __debug__
    r=Path('research/c7');out=r/'component-F-root10-transfer-verification-sep22.json';assert not out.exists();deps={}
    def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
    def read(p):
        deps[str(p)]=sha(p)
        return json.loads(Path(p).read_text())
    root9=read(r/'component-F-selected-root9-verification-sep22.json')
    assert root9['checker_sha256']==sha(r/'check_f_root9.py')
    assert all(sha(p)==h for p,h in root9['dependencies'].items());deps.update(root9['dependencies'])
    assert root9['passed'] and root9['neutral_radius9_stays_in_component'] and root9['no_augmentation_through_radius9']
    m=read(r/'component-F-rooted8-sep22-input.json')
    assert sha(m['source'])==m['source_sha256']
    with gzip.open(m['source'],'rt') as f:next(f);states=[json.loads(x) for x in f]
    assert states[0]==root9['root_words'] and m['component_sha256']==root9['component_sha256']
    gain=read(r/'reference367-full-radius10-final-verification-sep21.json')
    assert gain['checker_sha256']==sha(r/'check_radius10_tail.py')
    replay=json.loads(json.dumps(audit(**gain['inputs'])))
    assert all(gain[k]==v for k,v in replay.items());deps.update(gain['dependencies'])
    for row in gain['rows']:
        for seg in row['segments']:assert sha(seg['file'])==seg['sha256'];deps[seg['file']]=seg['sha256']
    gr=next(x for x in gain['rows'] if x['base']==1)
    assert gr['complete_radius10'] and gr['minimum_removed_for_any_368_set']==11
    prefix_path=gain['inputs']['prefix'];prefix=read(prefix_path)
    high=read(r/'reference367-F-neutral10-transfer-recheck-sep22.json')
    assert high['checker_sha256']==sha(r/'check_reference_neutral_results.py')
    assert high['graph_proofs']=={prefix_path:sha(prefix_path)}
    assert len(high['rows'])==1
    hr=high['rows'][0]
    assert hr['base']==1 and hr['radius']==10 and hr['minimum_blocker_degree']==5 and hr['restricted_prefix_exhausted']
    model=read(hr['model']);starts=read(model['input'])
    assert model['input_sha256']==sha(model['input']) and starts['bases'][1]['words']==states[0]
    assert model['min_blockers']==1 and model['max_blockers']==10
    assert all(sha(p)==h for p,h in prefix['dependencies'].items());deps.update(prefix['dependencies'])
    for rec in high['results']:
        assert rec['sets']==rec['pair_checks']==0 and sha(rec['file'])==rec['sha256']
        row=read(rec['file']);assert row['base']==1 and row['input']==hr['model']
        assert row['input_sha256']==sha(hr['model'])
        assert row['graph_sha256']==sha(row['graph'])==prefix['graphs']['1']['sha256']
        assert row['kernel_sha256']==sha(row['kernel']) and row['kernel_source_sha256']==sha(Path(row['kernel']).with_suffix('.cpp'))
        deps[row['graph']]=sha(row['graph'])
    # Finite constructional checks: retaining x makes neutral r from S
    # exactly neutral r+1 from P. Root/child blocker counts differ only at x,y.
    rng=random.Random(2026092402);toy=dict(parent_edges=0,neutral_transfers=0,positive_transfers=0,blocker_counts=0)
    n=8;k=3
    for case in range(100):
        adj=[1<<i for i in range(n)]
        for i in range(n):
            for j in range(i):
                if rng.random()<(0.2,0.35,0.5)[case%3]:adj[i]|=1<<j;adj[j]|=1<<i
        def independent(s):return all((s&adj[i])==1<<i for i in range(n) if s>>i&1)
        bases=[s for s in range(1<<n) if s.bit_count()==k and independent(s)]
        targets=[s for s in range(1<<n) if s.bit_count() in (k,k+1) and independent(s)]
        for p in bases:
            for s in bases:
                x,y=s&~p,p&~s
                if x.bit_count()!=1 or y.bit_count()!=1 or not adj[x.bit_length()-1]&y:continue
                toy['parent_edges']+=1
                for t in targets:
                    d=(s&~t).bit_count()
                    if t.bit_count()>k:
                        assert (p&~t).bit_count()<=d+1;toy['positive_transfers']+=1
                    elif t&x:
                        assert not t&y and (p&~t).bit_count()==d+1
                        assert t&~p==(t&~s)|x;toy['neutral_transfers']+=1
                        for v in range(n):
                            if (t&~s)>>v&1:
                                assert (adj[v]&p).bit_count()==(adj[v]&s).bit_count()+bool(adj[v]&y)
                                toy['blocker_counts']+=1
    assert all(v>0 for v in toy.values())
    coords=np.array(list(product(range(7),repeat=5)),dtype=np.int16)
    delta=(coords[:,None,:]-coords[np.array(states[0])[None,:],:])%7
    root_count=np.all((delta==0)|(delta==1)|(delta==6),axis=2).sum(axis=1)
    def conflicts(v):
        delta=(coords-coords[v])%7;return np.all((delta==0)|(delta==1)|(delta==6),axis=1)
    rows=[];root=set(states[0])
    for i,state in enumerate(states):
        x=set(state)-root;y=root-set(state)
        if len(x)!=1 or len(y)!=1:continue
        x=x.pop();y=y.pop();bad_x=conflicts(x);bad_y=conflicts(y)
        child_count=root_count-bad_y.astype(int)+bad_x.astype(int)
        occupied=np.zeros(16807,dtype=bool);occupied[state]=True
        pool=(child_count>=2)&(child_count<=9)&~occupied&~bad_x
        retained=pool&(root_count<5)
        assert np.all(child_count[retained&bad_y]<=3) and np.all(child_count[retained]<=4)
        rows.append(dict(state=i,inserted=x,deleted=y,pool_before=int(pool.sum()),pool_after=int(retained.sum()),critical_before=int((pool&bad_y).sum()),critical_after=int((retained&bad_y).sum())))
    assert [x['state'] for x in rows]==[1,2,3,4,5]
    for name in ['check_f_root9.py','check_radius10_tail.py','check_complete_radius10_intervals.py','check_reference_neutral_results.py','check_blocker_radius.py']:deps[str(r/name)]=sha(r/name)
    result=dict(passed=True,checker_sha256=sha(__file__),dependencies=deps,component_sha256=m['component_sha256'],root_words=states[0],root_sha256=root9['root_sha256'],radius=9,parent_radius=10,forbidden_root_blocker_degree=5,affected_states=rows,toy_controls=toy,
                scope='Only one-word neighbors of exact forest state0. Parent radius9 coverage permits retaining x. Any new neutral9 target then is a neutral10 target from root; completed >=5-blocker parent neutral10 search forces all its new words to have <=4 root blockers. Full parent gain10 excludes all child gains9. No exclusion for other states and no new construction.')
    out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ('dependencies','root_words')}))


if __name__=='__main__':main()
