// Test-only access to the exact native helper, independent of group generation.
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wreturn-type"
#define main c7_compatible_scanner_main
#include "scan_component_atomic7_incremental_compatible.cpp"
#undef main
#pragma clang diagnostic pop
int main() {
    unsigned radius,n,k;if(!(std::cin>>radius>>n>>k))return 1;
    std::vector<Candidate> pool;
    for(unsigned i=0;i<n;++i) {
        unsigned size;if(!(std::cin>>size))return 1;Choice b(size);
        for(int& x:b)if(!(std::cin>>x) || x<0 || x>=512)return 1;
        if(!std::is_sorted(b.begin(),b.end()) || std::adjacent_find(b.begin(),b.end())!=b.end())return 1;
        pool.push_back({static_cast<int>(i),std::move(b)});
    }
    std::vector<std::vector<bool>> flags(k,std::vector<bool>(n)),comp(n,std::vector<bool>(n));
    std::vector<const std::vector<bool>*> conditions;
    for(auto& f:flags) {
        for(unsigned i=0;i<n;++i){int b;if(!(std::cin>>b) || b<0 || b>1)return 1;f[i]=b;}
        conditions.push_back(&f);
    }
    for(auto& row:comp)for(unsigned j=0;j<n;++j){int b;if(!(std::cin>>b) || b<0 || b>1)return 1;row[j]=b;}
    std::string extra;if(std::cin>>extra)return 1;
    auto answer=compatible_requirements(pool,conditions,[&](int i,int j){return comp[i][j];},radius);
    std::cout<<"{\"complete\":"<<(answer.complete?"true":"false")<<",\"nodes\":"<<answer.nodes
             <<",\"comparisons\":"<<answer.comparisons<<",\"sets\":[";
    for(std::size_t i=0;i<answer.sets.size();++i){if(i)std::cout<<',';print_words(answer.sets[i]);}
    std::cout<<"]}\n";
}
