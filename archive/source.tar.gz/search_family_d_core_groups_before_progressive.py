"""Exact MIS after omitting small groups of the356-word Family-D core.
Noncore choices are unrestricted. Shared subproblem cache reuses the23-word base.
"""
import argparse
from functools import lru_cache
import gzip
import hashlib
from itertools import combinations, product, islice
from collections import Counter
import math
import json
from pathlib import Path
import random
import struct
import time

HERE=Path(__file__).resolve().parent

def bits(mask):
    while mask:
        bit=mask&-mask;yield bit.bit_length()-1;mask^=bit

def make_solver(adj, deadline):
    calls=0
    @lru_cache(maxsize=250000)
    def solve(mask):
        nonlocal calls
        calls+=1
        if calls%1024==0 and time.monotonic()>deadline:raise TimeoutError
        if not mask:return 0,0
        v=max(bits(mask),key=lambda i:(adj[i]&mask).bit_count())
        rest=mask^(1<<v)
        a,aa=solve(rest);b,bb=solve(rest&~adj[v]);b+=1
        return (a,aa) if a>=b else (b,bb|(1<<v))
    return solve

def controls():
    rng=random.Random(20260921);cases=0
    for n in range(1,11):
        for trial in range(10):
            adj=[0]*n
            for a,b in combinations(range(n),2):
                if rng.random()<trial/10:adj[a]|=1<<b;adj[b]|=1<<a
            solve=make_solver(adj,float('inf'));alpha,chosen=solve((1<<n)-1)
            expected=max(m.bit_count() for m in range(1<<n) if all(not(adj[v]&m) for v in bits(m)))
            assert alpha==expected==chosen.bit_count() and all(not(adj[v]&chosen) for v in bits(chosen))
            cases+=1
    alpha,chosen=make_solver([0]*13,float('inf'))((1<<13)-1)
    assert alpha==chosen.bit_count()==13
    return dict(exhaustive_small_graphs=cases,positive_size13_control=True)

def main():
    if not __debug__:raise RuntimeError('Run without -O')
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--seconds',type=float,default=65)
    parser.add_argument('--start-index',type=int,default=0)
    parser.add_argument('--limit',type=int)
    parser.add_argument('--release-size',type=int,choices=(2,3,4,5),default=3)
    parser.add_argument('--selection',choices=('all','blocker-sets'),default='all')
    parser.add_argument('--groups-file',type=Path,help='Explicit groups of omitted original word IDs; all noncore choices remain unrestricted')
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    if args.seconds<=0 or args.start_index<0 or (args.limit is not None and args.limit<1):parser.error('Invalid budget/range')
    if args.output.exists():raise FileExistsError(args.output)
    if args.groups_file and args.selection!='all':parser.error('--groups-file cannot be combined with --selection')
    checked=controls()
    cache=HERE/'breakout-perturb64-sep20-2049-component-0.jsonl.gz'
    with gzip.open(cache,'rt') as f:
        metadata=json.loads(next(f));states=[set(json.loads(line)) for line in f]
    packed=sorted(struct.pack('<367H',*sorted(s)) for s in states)
    assert len(set(packed))==384 and hashlib.sha256(b''.join(packed)).hexdigest()==metadata['component_sha256']
    core=sorted(set.intersection(*states));assert len(core)==356
    core_set=set(core);words=list(product(range(7),repeat=5));word_ids={w:i for i,w in enumerate(words)}
    coords=[[0]*7 for _ in range(5)]
    for i,v in enumerate(core):
        for k,x in enumerate(words[v]):coords[k][x]|=1<<i
    spread=[0]*len(words)
    for i,v in enumerate(core):
        for w in product(*[[(x-1)%7,x,(x+1)%7] for x in words[v]]):spread[word_ids[w]]|=1<<i
    all_blockers={}
    for v,w in enumerate(words):
        if v in core_set:continue
        mask=(1<<len(core))-1
        for k,x in enumerate(w):mask&=coords[k][(x-1)%7]|coords[k][x]|coords[k][(x+1)%7]
        assert mask==spread[v]
        all_blockers[v]=mask
    explicit=None;released_masks=None
    if args.groups_file:
        raw=json.loads(args.groups_file.read_text());core_index={v:i for i,v in enumerate(core)}
        assert isinstance(raw,list) and raw
        assert all(isinstance(g,list) and len(g)==len(set(g))==args.release_size and all(type(v) is int and v in core_set for v in g) for g in raw)
        explicit=sorted(tuple(sorted(core_index[v] for v in g)) for g in raw)
        assert len(set(explicit))==len(explicit), 'Duplicate selected group'
        released_masks=[sum(1<<i for i in g) for g in explicit]
    pool=[v for v,mask in all_blockers.items() if mask.bit_count()<=args.release_size
          and (released_masks is None or any(mask&~r==0 for r in released_masks))]
    local={v:i for i,v in enumerate(pool)};groups={}
    for v in pool:
        m=all_blockers[v];groups[m]=groups.get(m,0)|(1<<local[v])
    adj=[]
    conflict=lambda a,b:all((x-y)%7 in (0,1,6) for x,y in zip(words[a],words[b]))
    for i,v in enumerate(pool):
        mask=0
        for w in product(*[[(x-1)%7,x,(x+1)%7] for x in words[v]]):
            j=local.get(word_ids[w])
            if j is not None and j!=i:mask|=1<<j
        # Full direct-coordinate check of the indexed pool graph.
        assert mask==sum(1<<j for j,u in enumerate(pool) if j!=i and conflict(v,u))
        adj.append(mask)
    report=dict(status='running',core_size=356,pool=len(pool),baseline=groups[0].bit_count(),
                component_sha256=metadata['component_sha256'],input_domain_verified=True,
                graph_verified=True,controls=checked,candidates=[],start_index=args.start_index,release_size=args.release_size,
                source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                scope='Each case keeps all but the specified core group and forbids every omitted word; all noncore choices unrestricted.')
    began=time.monotonic();deadline=began+args.seconds;solve=make_solver(adj,deadline)
    report['selection']=args.selection
    report['total_possible_groups']=math.comb(len(core),args.release_size)
    if explicit is not None:
        selected=explicit;total=len(selected);group_iterator=iter(selected)
        report['selection']='explicit'
        report['groups_file']=str(args.groups_file)
        report['groups_file_sha256']=hashlib.sha256(args.groups_file.read_bytes()).hexdigest()
        report['selected_omitted_words']=[[core[i] for i in group] for group in selected]
    elif args.selection=='blocker-sets':
        selected=sorted(tuple(bits(m)) for m in groups if m.bit_count()==args.release_size)
        total=len(selected);group_iterator=iter(selected)
        report['selected_omitted_words']=[[core[i] for i in group] for group in selected]
    else:
        total=report['total_possible_groups'];group_iterator=combinations(range(len(core)),args.release_size)
    report['total_groups']=total
    end=min(args.start_index+(args.limit if args.limit is not None else total),total)
    if args.start_index>total:raise ValueError('Start index beyond the group space')
    alpha_counts=Counter();domain_counts=Counter();completed=0;digest=hashlib.sha256()
    max_alpha=-1;best=None
    assert groups[0].bit_count()==23
    for index,indices in enumerate(islice(group_iterator,args.start_index,end),args.start_index):
        omitted=[core[i] for i in indices];omask=sum(1<<i for i in indices)
        domain=groups[0];sub=omask
        while sub:
            domain|=groups.get(sub,0);sub=(sub-1)&omask
        try:
            if time.monotonic()>deadline:raise TimeoutError
            alpha,chosen=solve(domain)
        except TimeoutError:
            report['status']='timeout';report['next_index']=index;break
        assert chosen&~domain==0 and chosen.bit_count()==alpha and all(not(adj[v]&chosen) for v in bits(chosen))
        completed+=1;alpha_counts[alpha]+=1;domain_counts[domain.bit_count()]+=1
        digest.update(struct.pack('<'+str(args.release_size+2)+'H',*omitted,domain.bit_count(),alpha))
        if alpha>max_alpha:
            max_alpha=alpha;best=dict(index=index,omitted=omitted,domain=domain.bit_count(),alpha=alpha,
                                      residual_words=[''.join(map(str,words[pool[v]])) for v in bits(chosen)])
        if alpha>=11+args.release_size:
            target=sorted((core_set-set(omitted))|{pool[v] for v in bits(chosen)})
            assert len(target)==356-args.release_size+alpha and not any(conflict(a,b) for a,b in combinations(target,2))
            report['candidates'].append(dict(step=index,words=[''.join(map(str,words[v])) for v in target],omitted=omitted))
            report['status']='new_target';report['next_index']=index+1;break
    else:
        report['status']=('exhausted' if report['selection']=='all' else 'selection_complete') if end==total else 'range_complete';report['next_index']=end
    report.update(completed=completed,alpha_counts=dict(sorted(alpha_counts.items())),
                  domain_counts=dict(sorted(domain_counts.items())),record_sha256=digest.hexdigest(),
                  record_encoding='Lexicographic core-group order; little-endian u16 omitted word IDs,domain size,alpha',
                  best=best)
    report['seconds']=time.monotonic()-began;report['cache_info']=solve.cache_info()._asdict()
    tmp=args.output.with_name(args.output.name+'.tmp')
    opener=gzip.open if args.output.suffix=='.gz' else open
    with opener(tmp,'wt') as f:json.dump(report,f,separators=(',',':'))
    tmp.replace(args.output)
    print(json.dumps({k:v for k,v in report.items() if k not in ('rows','candidates','selected_omitted_words')}|dict(candidates=len(report['candidates']))))

if __name__=='__main__':main()
