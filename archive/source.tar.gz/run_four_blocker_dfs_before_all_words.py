"""Run the existing exact exchange kernel on verified bounded-blocker models.

Words at the model's maximum blocker degree come first. A checked radius
certificate for the pool with one fewer blocker justifies requiring one of them.
Exported bitsets are read back against the
independently verified model before searching. Timeouts exclude nothing.
An optional checked count certificate raises the required four-blocker count.
The kernel seeks exactly radius+1 insertions and at most radius removals;
smaller insertion counts need separate exclusions before claiming a full radius.
"""
import argparse
import hashlib
from itertools import combinations, product
import json
from pathlib import Path
import subprocess
import time

from run_seed_exchanges import coordinate_masks, nearby
from check_blocker_radius import check as check_radius
from check_four_radius_chain import check_chain


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',required=True,type=Path);p.add_argument('--geometry-proof',required=True,type=Path)
    p.add_argument('--prefix-proof',required=True,type=Path);p.add_argument('--output',required=True,type=Path)
    p.add_argument('--count-proof',type=Path)
    p.add_argument('--budget-bitsets',action='store_true')
    p.add_argument('--radius',type=int,default=7);p.add_argument('--seconds',type=float,default=30)
    a=p.parse_args();assert __debug__ and not a.output.exists() and 1<=a.radius<=9 and 0<a.seconds<=600
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();here=Path(__file__).resolve().parent
    data=json.loads(a.input.read_text());assert data['status']=='complete' and data['min_blockers']==1 and data['max_blockers'] in (4,5)
    degree=data['max_blockers']
    geom=json.loads(a.geometry_proof.read_text());assert geom['model_sha256']==sha(a.input)
    assert geom['checker_sha256']==sha(here/'check_blocker_trade_results.py')
    bp=Path(data['input']);assert sha(bp)==data['input_sha256'];bases=json.loads(bp.read_text())['bases']
    proof=json.loads(a.prefix_proof.read_text());cert=None
    if proof.get('kind')=='exhaustive_radius_chain':
        assert proof['checker_sha256']==sha(here/'check_four_radius_chain.py')
        assert proof['radius_checker_sha256']==sha(here/'check_blocker_radius.py')
        checked_chain=check_chain(**proof['inputs'])
        assert all(proof[k]==v for k,v in checked_chain.items())
        mp=Path(proof['inputs']['model']);lower=json.loads(mp.read_text())
    else:
        cp=Path(proof['input']);assert sha(cp)==proof['input_sha256']
        assert proof['checker_sha256']==sha(here/'check_blocker_radius.py')
        cert=json.loads(cp.read_text());mp=Path(cert['input']);assert sha(mp)==cert['input_sha256'];lower=json.loads(mp.read_text())
        assert cert['status']=='complete'
    assert lower['status']=='complete'
    assert lower['min_blockers']==1 and lower['max_blockers']==degree-1 and lower['input_sha256']==data['input_sha256']
    count_cert=None
    if a.count_proof:
        assert degree==4, 'The count-proof option currently certifies four-blocker counts only.'
        checked=json.loads(a.count_proof.read_text())
        assert checked['checker_sha256']==sha(here/'check_blocker_radius.py')
        path=Path(checked['input']);assert checked['input_sha256']==sha(path)
        count_cert=json.loads(path.read_text());assert count_cert['status']=='complete'
        assert count_cert['input_sha256']==sha(a.input)
    coords=list(product(range(7),repeat=5));binary=here/'exchange_dfs'
    out=dict(input=str(a.input),input_sha256=sha(a.input),source_sha256=sha(__file__),
             geometry_proof=str(a.geometry_proof),geometry_proof_sha256=sha(a.geometry_proof),
             prefix_proof=str(a.prefix_proof),prefix_proof_sha256=sha(a.prefix_proof),
             kernel_sha256=sha(binary),kernel_source_sha256=sha(here/'exchange_dfs.cpp'),
             max_removals=a.radius,target_insertions=a.radius+1,prefix_blocker_degree=degree,budget_bitsets=a.budget_bitsets,rows=[],candidates=[],status='running',scope=__doc__)
    if a.count_proof:
        out.update(count_proof=str(a.count_proof),count_proof_sha256=sha(a.count_proof))
    def save():
        temp=a.output.with_suffix('.tmp');temp.write_text(json.dumps(out,indent=2)+'\n');temp.replace(a.output)
    save()
    for d in data['rows']:
        bi=d['base'];old=bases[bi]['words'];assert len(old)==367
        td=next(r for r in lower['rows'] if r['base']==bi)
        pc=(check_radius(next(r for r in cert['rows'] if r['base']==bi),td) if cert
            else next(r for r in checked_chain['rows'] if r['base']==bi))
        assert pc==next(r for r in proof['rows'] if r['base']==bi)
        assert pc['max_removals']>=a.radius and pc['integer_gain_upper']==0
        blocked=d['blocker_sets'];pool=d['pool_ids']
        assert list(zip(td['pool_ids'],td['blocker_sets']))==[(v,b) for v,b in zip(pool,blocked) if len(b)<degree]
        # A count-conditional proof cannot justify the unconditional prefix rule.
        assert 'max_four_insertions' not in pc
        required_prefix=1
        if count_cert:
            cr=check_radius(next(r for r in count_cert['rows'] if r['base']==bi),d)
            assert cr==next(r for r in checked['rows'] if r['base']==bi)
            assert cr['max_removals']>=a.radius and cr['integer_gain_upper']==0
            required_prefix=cr['minimum_four_insertions_for_gain']
        order=sorted(range(len(pool)),key=lambda i:(len(blocked[i])!=degree,pool[i]));ids=[pool[i] for i in order]
        prefix=sum(len(b)==degree for b in blocked);assert prefix>0
        n=len(ids);full=(1<<n)-1;mask=(1<<64)-1;cw=(n+63)//64
        om=coordinate_masks([coords[v] for v in old]);pm=coordinate_masks([coords[v] for v in ids])
        graph=a.output.with_name(a.output.stem+'-base'+str(bi)+'.txt');assert not graph.exists()
        with graph.open('x') as f:
            f.write(f'{n} 6 {a.radius}\n')
            for v in ids:
                b=nearby(coords[v],om,367);compatible=full^nearby(coords[v],pm,n)
                values=[(b>>(64*j))&mask for j in range(6)]+[(compatible>>(64*j))&mask for j in range(cw)]
                f.write(' '.join(f'{v:x}' for v in values)+'\n')
            if count_cert:f.write(' '.join([str(required_prefix)]*n)+'\n')
        # Reconstruct from the checked edge list rather than the exporter's
        # coordinate-mask algorithm, including diagonal and padding bits.
        inverse={i:j for j,i in enumerate(order)};conflicts=[1<<i for i in range(n)]
        for u,v in d['conflict_edges']:
            i,j=inverse[u],inverse[v];conflicts[i]|=1<<j;conflicts[j]|=1<<i
        with graph.open() as f:
            assert list(map(int,next(f).split()))==[n,6,a.radius]
            for j,index in enumerate(order):
                words=[int(t,16) for t in next(f).split()];assert len(words)==6+cw
                assert sum(v<<(64*k) for k,v in enumerate(words[:6]))==sum(1<<i for i in blocked[index])
                assert sum(v<<(64*k) for k,v in enumerate(words[6:]))==full^conflicts[j]
            if count_cert:assert list(map(int,next(f).split()))==[required_prefix]*n
            assert not f.read().strip()
        start=time.monotonic()
        with graph.open() as f:
            try:
                command=[str(binary),str(a.seconds),'--subset','--root-prefix',str(prefix)]
                if count_cert:command+=['--anchor-bounds',str(prefix)]
                if a.budget_bitsets:command+=['--budget-bitsets']
                run=subprocess.run(command,stdin=f,capture_output=True,text=True,check=True,timeout=a.seconds+15)
                result=json.loads(run.stdout)
            except subprocess.TimeoutExpired:result=dict(status='parent_timeout')
        row=dict(base=bi,mode='improve',graph=str(graph),graph_sha256=sha(graph),kernel_order=order,
                 prefix=prefix,minimum_prefix_insertions=required_prefix,rows_replayed=n,wall_seconds=time.monotonic()-start,kernel_result=result)
        if degree==4:row['minimum_four_insertions']=required_prefix
        if result['status']=='exhausted':assert result['nodes_started']==result['nodes_completed']
        if result['status']=='witness':
            chosen=result['chosen'];assert len(chosen)==len(set(chosen))==a.radius+1 and min(chosen)<prefix
            assert all(type(i) is int and 0<=i<n for i in chosen)
            assert sum(i<prefix for i in chosen)>=required_prefix
            chosen=sorted(order[i] for i in chosen);removed=sorted({j for i in chosen for j in blocked[i]})
            words=sorted((set(old)-{old[j] for j in removed})|{pool[i] for i in chosen})
            assert len(removed)<=a.radius and len(words)==len(set(words))>=368
            assert all(any((x-y)%7 in (2,3,4,5) for x,y in zip(coords[u],coords[v])) for u,v in combinations(words,2))
            row.update(chosen_indices=chosen,removed_indices=removed,size=len(words),pair_checks=len(words)*(len(words)-1)//2)
            out['candidates'].append(dict(step=len(out['candidates']),source_base=bi,size=len(words),words=[''.join(map(str,coords[v])) for v in words]))
            out['status']='verified_target'
        out['rows'].append(row);save();print(json.dumps({k:v for k,v in row.items() if k!='kernel_order'}),flush=True)
        if out['status']=='verified_target':return
    out['status']='complete';save()


if __name__=='__main__':main()
