"""Replay every saved replacement using direct coordinate counts.

Validates domain, fixed exterior, overlap cap, cardinality and true conflict
energy. Does not re-execute the heuristic's weighted proposal selection.
"""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
from check_cardinality_projection import conflicts,verify
from search_cardinality_projection import load_projection_model


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();assert __debug__ and not a.output.exists()
    report=json.loads(a.input.read_text());source=Path(report['input'])
    assert hashlib.sha256(source.read_bytes()).hexdigest()==report['input_sha256']
    trajectory=json.loads(source.read_text());verify(trajectory)
    _,model,_,_,cap,bounded=load_projection_model(Path(trajectory['input']),Path(trajectory['base_verification']),Path(trajectory['overlap']['certificate']))
    fixed=set(model['fixed']);pool=set(model['pool']);limited={model['pool'][i] for i in bounded}
    assert report['fixed']==model['fixed'] and report['pool']==model['pool']
    assert set(report['limited'])==limited and report['cap']==cap
    words=np.array([[v//7**j%7 for j in range(5)] for v in range(16807)])
    def adjacent_count(v,others):
        delta=(words[list(others)]-words[v])%7
        return int(sum(np.all((delta==0)|(delta==1)|(delta==6),axis=1)))
    verified=[];one_edge_states=set();checks=0
    for ri,run in enumerate(report['runs']):
        selected=set(run['start']);assert len(selected)==len(run['start'])==368
        assert fixed<=selected and selected-fixed<=pool and len(selected&limited)<=cap
        assert any(sorted(model['fixed']+row['rounded_vertices'])==run['start'] for row in trajectory['rows'])
        energy=conflicts(run['start']);best=energy;best_words=sorted(selected)
        assert run['steps']==len(run['moves'])
        for old,new,saved_energy in run['moves']:
            assert old in selected-fixed and new in pool-selected
            selected.remove(old);energy-=adjacent_count(old,selected)
            energy+=adjacent_count(new,selected);selected.add(new)
            assert energy==saved_energy and len(selected&limited)<=cap
            checks+=2*367
            if energy<best:best=energy;best_words=sorted(selected)
            if energy==1:one_edge_states.add(tuple(sorted(selected)))
        assert sorted(selected)==run['final_words']
        assert best==run['best_conflicts'] and best_words==run['best_words']
        assert conflicts(run['final_words'])==energy and conflicts(best_words)==best
        assert (run['status']=='independent')==(best==0)
        period=run['penalty_period']
        expected=(run['steps']-int(best==0))//period if period else 0
        assert expected==run['penalty_updates']
        verified.append(dict(run=ri,moves=run['steps'],best_conflicts=best,final_conflicts=energy))
    if report['candidates']:
        for candidate in report['candidates']:
            assert len(candidate['vertices'])==candidate['size']==368 and not conflicts(candidate['vertices'])
            assert candidate['pair_checks']==67528
            assert any(run['best_words']==candidate['vertices'] for run in report['runs'])
    found=any(row['best_conflicts']==0 for row in report['runs'])
    assert (report['status']=='verified_target')==found
    result=dict(input=str(a.input),input_sha256=hashlib.sha256(a.input.read_bytes()).hexdigest(),
                checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),runs=verified,
                moves=sum(r['moves'] for r in verified),coordinate_pair_tests=checks,
                one_edge_states=[list(s) for s in sorted(one_edge_states)],target_witness_found=found,scope=__doc__)
    a.output.write_text(json.dumps(result,separators=(',',':'))+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='one_edge_states'}|{'one_edge_states':len(one_edge_states)}),flush=True)


if __name__=='__main__':main()
