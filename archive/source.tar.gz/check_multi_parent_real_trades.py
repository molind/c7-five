"""Check all-earlier-neighbor reduction against twelve recorded C+B trades."""
import gzip
import hashlib
import json
from itertools import product
from pathlib import Path
import numpy as np


def main():
    assert __debug__
    r=Path('research/c7');deps={}
    def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
    def read(p):
        deps[str(p)]=sha(p)
        return json.loads(Path(p).read_text())
    baseline=read(r/'component-CB-atomic6-C-joined-verification-sep22.json')
    assert all(sha(p)==h for p,h in baseline['dependencies'].items())
    deps.update(baseline['dependencies'])
    manifest_path=r/'component-CB-incremental-sep22-input.json'
    m=read(manifest_path)
    assert sha(m['source'])==m['source_sha256']
    ref=read(m['reference_manifest'])
    assert sha(m['reference_manifest'])==m['reference_manifest_sha256']
    assert baseline['dependencies'][ref['source']]==ref['source_sha256']
    deps[m['source']]=sha(m['source'])
    with gzip.open(m['source'],'rt') as f:
        next(f);states=[tuple(json.loads(line)) for line in f]
    inv={old:new for new,old in enumerate(m['source_indices'])}
    masks=[sum(1<<v for v in state) for state in states];known=set(states)
    coords=np.array(list(product(range(7),repeat=5)),dtype=np.int16)
    checked=[];pairs=0
    for interval in baseline['intervals']:
        for row in read(interval['file'])['rows']:
            if row.get('event')!='trade':continue
            i=inv[row['state']];old=set(states[i]);target=tuple(sorted((old-set(row['removed']))|set(row['added'])))
            assert target in known
            branches=[]
            for j in range(i):
                if (masks[i]^masks[j]).bit_count()!=2:continue
                parent=set(states[j]);x,=old-parent;y,=parent-old
                if x not in target:
                    assert len(parent-set(target))<=6
                    branch='parent_covers_target'
                else:
                    diff=(coords[row['added']]-coords[y])%7
                    critical=np.any(np.all((diff==0)|(diff==1)|(diff==6),axis=1))
                    if critical:
                        branch='retained_critical'
                    else:
                        t=tuple(sorted((set(target)-{x})|{y}))
                        assert len(t)==367 and t in known and len(parent-set(t))<=6
                        delta=(coords[list(t),None,:]-coords[np.array(t)[None,:],:])%7
                        conflicts=np.all((delta==0)|(delta==1)|(delta==6),axis=2)
                        assert np.array_equal(conflicts,np.eye(367,dtype=bool))
                        pairs+=67161;branch='commuting_internal_target'
                branches.append(dict(parent=j,branch=branch))
            assert any(p['parent']==m['parents'][i] for p in branches)
            retained=all(p['branch']=='retained_critical' for p in branches)
            checked.append(dict(state=i,original_state=row['state'],all_parent_conditions_hold=retained,branches=branches))
    assert len(checked)==12
    result=dict(checker_sha256=sha(__file__),dependencies=deps,passed=True,recorded_trades=len(checked),
                prior_parent_edges=sum(len(x['branches']) for x in checked),
                surviving_all_parent_conditions=sum(x['all_parent_conditions_hold'] for x in checked),
                commuting_pair_checks=pairs,rows=checked,
                scope='Tests reduction on twelve actual six-removal internal trades. Does not rerun a radius-six multi-parent scanner or establish any new exclusion.')
    out=r/'component-incremental7-multi-real-controls-sep22.json';assert not out.exists()
    out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ('dependencies','rows')}))


if __name__=='__main__':main()
