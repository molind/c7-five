"""Check saved compatible-cover witnesses directly against C7 coordinates.

Witness validity and relaxation comparisons are checked here. Completeness of
the cover enumeration still relies on its tested search, not this witness audit.
"""
import gzip
import hashlib
import json
from itertools import combinations, product
from pathlib import Path

import numpy as np
from profile_joint_critical_unions import minimal


def main():
    assert __debug__
    r = Path('research/c7')
    source = r / 'compatible-critical-union-profile-sep22.json'
    output = r / 'compatible-critical-union-verification-sep22.json'
    assert not output.exists()
    sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
    profile = json.loads(source.read_text())
    assert profile['status'] == 'complete'
    assert sha(r / 'profile_compatible_critical_unions.py') == profile['source_sha256']
    assert all(sha(p) == h for p, h in profile['dependencies'].items())
    coords = np.array(list(product(range(7), repeat=5)), dtype=np.int16)
    loaded, results = {}, []
    checked = pairs = 0
    for row in profile['rows']:
        assert row['complete']
        name, index, radius = row['manifest'], row['state'], row['radius']
        if name not in loaded:
            m = json.loads((r / name).read_text())
            with gzip.open(m['source'], 'rt') as f:
                next(f)
                loaded[name] = [set(json.loads(line)) for line in f]
        states = loaded[name]
        state, parents, frozen = states[index], [], set()
        old = sorted(state)
        for other in states[:index]:
            if len(state - other) == len(other - state) == 1:
                parents.append(next(iter(other - state)))
                frozen |= state - other
        def conflicting(a, b):
            d = (coords[np.asarray(a)[:, None]] - coords[np.asarray(b)[None, :]]) % 7
            return np.all((d == 0) | (d == 1) | (d == 6), axis=2)
        bad = conflicting(list(range(16807)), old)
        deg = bad.sum(axis=1)
        pool = (deg >= 2) & (deg <= radius)
        pool[old] = False
        if frozen:
            pool &= ~np.any(bad[:, [old.index(x) for x in frozen]], axis=1)
        ids = np.flatnonzero(pool)
        masks = [int.from_bytes(b.tobytes(), 'little') for b in np.packbits(bad[ids], axis=1, bitorder='little')]
        conditions = []
        for y in parents:
            flags = conflicting(ids, [y])[:, 0]
            conditions.append(minimal([b for b, flag in zip(masks, flags) if flag]))
        relaxed = [0]
        for condition in sorted(conditions, key=len):
            relaxed = minimal({a | b for a in relaxed for b in condition if (a | b).bit_count() <= radius})
        assert len(relaxed) == row['relaxed_minimal']
        unions = []
        for support in row['supports']:
            removed, added = support['removed'], support['inserted']
            assert len(removed) == len(set(removed)) <= radius and set(removed) <= state
            assert len(added) == len(set(added)) and not set(added) & state
            assert not set(removed) & frozen
            blockers = [set(old[i] for i in np.flatnonzero(b)) for b in conflicting(added, old)]
            assert set.union(*blockers) == set(removed)
            assert all(2 <= len(b) <= radius for b in blockers)
            assert all(np.any(conflicting(added, [y])) for y in parents)
            assert np.array_equal(conflicting(added, added), np.eye(len(added), dtype=bool))
            pairs += len(added) * (len(added) - 1) // 2
            for size in range(1, min(radius, len(added) + 1)):
                for subset in combinations(blockers, size):
                    assert len(set.union(*subset)) > size
            mask = sum(1 << old.index(x) for x in removed)
            assert any(a & mask == a for a in relaxed)
            unions.append(mask)
            checked += 1
        assert len(unions) == len(set(unions)) == row['compatible_minimal']
        assert set(minimal(unions)) == set(unions)
        # Compare upward closures, rather than raw antichain cardinalities.
        rejected = sum(not any(b & a == b for b in unions) for a in relaxed)
        results.append(dict(manifest=name, state=index, radius=radius, relaxed_minimal=len(relaxed),
                            compatible_minimal=len(unions), relaxed_minimal_rejected=rejected))
    dependencies = dict(profile['dependencies'])
    for p in [source, r / 'profile_compatible_critical_unions.py', r / 'profile_joint_critical_unions.py']:
        dependencies[str(p)] = sha(p)
    out = dict(passed=True, checker_sha256=sha(__file__), dependencies=dependencies,
               supports_checked=checked, inserted_pair_checks=pairs, rows=results, scope=__doc__)
    output.write_text(json.dumps(out, indent=2) + '\n')
    print(json.dumps({k: v for k, v in out.items() if k not in ('dependencies', 'scope')}))


if __name__ == '__main__':
    main()
