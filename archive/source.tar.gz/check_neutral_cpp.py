"""Cross-language complete-list controls for the C++ neutral enumeration mode."""
from itertools import combinations
import json
from pathlib import Path
import random
import subprocess
import sys

from check_exchange_dfs import graph_text, controls
from neutral_exchanges import enumerate_exchanges

HERE = Path(__file__).parent
binary = Path(sys.argv[1]).resolve()
rng = random.Random(2026091810)
cases = []
for _ in range(300):
    n, d = rng.randrange(1, 12), rng.randrange(1, 7)
    positions = [0, 1, 63, 64, 127, 128, 307, 366, 511]
    cb = [sum(1 << p for p in rng.sample(positions, rng.randrange(5))) for _ in range(n)]
    comp = [0]*n
    for i, j in combinations(range(n), 2):
        if rng.randrange(4):
            comp[i] |= 1 << j
            comp[j] |= 1 << i
    cases.append((cb, comp, d))
for n in [63, 64, 65, 127, 128, 129]:
    cases.append(([1]*n, [((1 << n)-1) ^ (1 << i) for i in range(n)], 2))
positive_neutral = positive_improving = 0
for cb, comp, d in cases:
    wanted = {'neutral': [], 'improving': []}
    for chosen in combinations(range(len(cb)), d):
        mask = 0
        for i in chosen:
            mask |= cb[i]
        if mask.bit_count() <= d and all(comp[i] >> j & 1 for i, j in combinations(chosen, 2)):
            wanted['neutral' if mask.bit_count() == d else 'improving'].append(list(chosen))
    reference = enumerate_exchanges(cb, comp, d)
    assert reference['status'] == 'exhausted'
    for kind in wanted:
        assert list(map(list, reference[kind])) == wanted[kind]
    for mode in [[], ['--subset']]:
        run = subprocess.run([str(binary), '5', '--neutral', *mode],
            input=graph_text(cb, comp, d, 8), text=True, capture_output=True, check=True, timeout=7)
        actual = json.loads(run.stdout)
        assert actual['status'] == 'exhausted'
        assert actual['nodes_started'] == actual['nodes_completed']
        assert all(actual[k] == wanted[k] for k in wanted)
    positive_neutral += bool(wanted['neutral'])
    positive_improving += bool(wanted['improving'])
# Output cap, timeout, and rejection of an improvement-only pruning option.
large = graph_text([0]*24, [((1 << 24)-1) ^ (1 << i) for i in range(24)], 6, 1)
for seconds, expected in [('5', 'output_limit'), ('0.000000001', 'timeout')]:
    run = subprocess.run([str(binary), seconds, '--neutral', '--subset'], input=large,
                         text=True, capture_output=True, check=True, timeout=7)
    actual = json.loads(run.stdout)
    assert actual['status'] == expected
    if expected == 'output_limit':
        assert len(actual['neutral'])+len(actual['improving']) == 100000
bad = subprocess.run([str(binary), '5', '--neutral', '--noncore-limit', '0', '0'],
                     input=large, text=True, capture_output=True, timeout=7)
assert bad.returncode != 0
report = dict(binary=str(binary), cases=len(cases), modes=2,
              positive_neutral=positive_neutral, positive_improving=positive_improving,
              special_controls=3, seed=2026091810,
              method='Full ordered lists against Python and exhaustive combinations')
(HERE/(binary.name+'-neutral-controls.json')).write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report))
controls(binary)
controls(binary, ['--subset'])
