"""Add every three-location Boolean triangle inequality to the global pair LP.

For a,b in Z7^n, x0*xa+x0*xb-xa*xb <= x0 holds for all binary occupancies.
Translation and automorphism averaging gives f(a)+f(b)-f(a-b)<=1. Enumerating
multisets of the25 one-coordinate distance triples covers every pair(a,b)
up to coordinate permutations; all three side profiles are retained.
"""
import argparse
import hashlib
from itertools import product, combinations_with_replacement
import json
from pathlib import Path
import time

import numpy as np
from scipy.optimize import linprog
from scipy.sparse import csc_matrix, vstack
from probe_global_pair_lp import model, cylinder_rows


def triangle_keys(n, profiles):
    distance=lambda v:min(v%7,(-v)%7)
    types=sorted({(distance(a),distance(b),distance(a-b)) for a,b in product(range(7),repeat=2)})
    pos={p:i for i,p in enumerate(profiles)}
    keys=set()
    for choice in combinations_with_replacement(types,n):
        counts=[[0]*4 for _ in range(3)]
        for distances in choice:
            for j,v in enumerate(distances):counts[j][v]+=1
        i,j,k=[pos[tuple(c)] for c in counts]
        keys.add((min(i,j),max(i,j),k))
    return sorted(keys)


def triangle_matrix(n, profiles):
    keys=triangle_keys(n,profiles)
    rows=[];cols=[];vals=[]
    for r,(i,j,k) in enumerate(keys):
        for c,v in [(i,1),(j,1),(k,-1)]:rows.append(r);cols.append(c);vals.append(v)
    return csc_matrix((vals,(rows,cols)),shape=(len(keys),len(profiles))),keys


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--dimensions',type=int,nargs='+',default=[1,2,3,4,5])
    args=p.parse_args();assert __debug__ and not args.output.exists()
    helper=Path(__file__).with_name('probe_global_pair_lp.py')
    out=dict(status='running',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
             dependencies={str(helper):hashlib.sha256(helper.read_bytes()).hexdigest()},rows=[],scope=__doc__,
             warning='Numerical LP results are exploratory, not exact upper-bound certificates.')
    for n in args.dimensions:
        began=time.monotonic();coords,profiles,index,weights,fourier,bounds=model(n)
        cyl,cup,labels=cylinder_rows(n,coords,index,len(profiles));tri,keys=triangle_matrix(n,profiles)
        a=vstack((-csc_matrix(fourier),csc_matrix(cyl),tri),format='csc');b=np.r_[np.zeros(len(fourier)),cup,np.ones(len(keys))]
        res=linprog(-weights,A_ub=a,b_ub=b,bounds=bounds,method='highs',options={'time_limit':120})
        row=dict(dimension=n,profiles=len(profiles),triangle_rows=len(keys),constraints=len(b),status=int(res.status),message=res.message,seconds=time.monotonic()-began)
        if res.success:
            x=res.x;violation=max(0,float(np.max(a@x-b)),max(lo-v for v,(lo,hi) in zip(x,bounds)),max(v-hi for v,(lo,hi) in zip(x,bounds)))
            assert violation<1e-6
            row.update(numerical_upper=float(weights@x),maximum_violation=violation,profiles_order=[list(v) for v in profiles],values=x.tolist(),dual_inequalities=res.ineqlin.marginals.tolist(),dual_lower=res.lower.marginals.tolist(),dual_upper=res.upper.marginals.tolist())
        out['rows'].append(row);args.output.write_text(json.dumps(out,indent=2)+'\n');print({k:v for k,v in row.items() if k not in ['profiles_order','values','dual_inequalities','dual_lower','dual_upper']},flush=True)
    out['status']='complete_attempt';args.output.write_text(json.dumps(out,indent=2)+'\n')


if __name__=='__main__':main()
