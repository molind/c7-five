"""Check five-removal scan intervals, trades and the exact width-four premise.

A compatible proper insertion subset with at most four words and no more
blockers either gives a previously excluded augmentation or a neutral move
inside the checked width-four component. Making the latter move first leaves
at most four old removals. Thus only irreducible five/six-insertion sets remain.
Exhaustion relies on the tested native enumerator; this is not a proof-tree replay.
"""
import argparse
import gzip
import hashlib
from itertools import combinations, product
import json
from pathlib import Path
import random
import struct

import numpy as np


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--runs', required=True, nargs='+', type=Path)
    p.add_argument('--width-four-proof', required=True, type=Path)
    p.add_argument('--output', required=True, type=Path)
    args = p.parse_args()
    assert __debug__ and not args.output.exists()
    here = Path(__file__).resolve().parent
    sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
    dependencies = {}

    def read(path):
        dependencies[str(path)] = sha(path)
        return json.loads(Path(path).read_text())

    records = [(path, read(path)) for path in args.runs]
    first = records[0][1]
    manifest = read(first['input_manifest'])
    assert manifest['source_sha256'] == sha(manifest['source'])
    assert manifest['input_sha256'] == sha(manifest['input'])
    with gzip.open(manifest['source'], 'rt') as f:
        meta = json.loads(next(f))
        states = [json.loads(line) for line in f]
    assert all(len(s) == 367 and s == sorted(set(s)) and all(type(v) is int and 0 <= v < 16807 for v in s) for s in states)
    keys = [struct.pack('<367H', *s) for s in states]
    assert len(keys) == len(set(keys)) == manifest['states'] == meta['states']
    assert hashlib.sha256(b''.join(sorted(keys))).hexdigest() == manifest['component_sha256'] == meta['component_sha256']
    expected = f'{len(states)} 367\n' + '\n'.join(' '.join(map(str, s)) for s in states) + '\n'
    assert Path(manifest['input']).read_text() == expected
    known = set(keys)
    previous = read(args.width_four_proof)
    assert previous['checker_sha256'] == sha(here/'check_component_atomic4.py')
    assert all(sha(p) == h for p, h in previous['dependencies'].items())
    assert previous['dependencies'][manifest['source']] == manifest['source_sha256']
    assert previous['states'] == len(states) and not previous['outside']
    assert previous['complete_atomic4'] and previous['width4_component_equals_width3'] and previous['four_removal_augmentations_excluded']
    coords = np.array(list(product(range(7), repeat=5)), dtype=np.int16)
    neutral = internal = improving = pairs = 0
    seen = set()
    outside = []
    cursor = 0
    intervals = []
    for path, run in records:
        assert not outside, 'Do not silently continue after a reported escape or improvement'
        assert run['status'] == 'complete'
        assert run['kernel_sha256'] == sha(run['kernel']) == sha(here/'scan_component_atomic5')
        assert run['kernel_source_sha256'] == sha(here/'scan_component_atomic5.cpp')
        assert run['manifest_sha256'] == sha(first['input_manifest']) == sha(run['input_manifest'])
        assert run['input_sha256'] == manifest['input_sha256']
        assert run['native_sha256'] == sha(run['native_file'])
        dependencies[run['native_file']] = sha(run['native_file'])
        rows = [json.loads(line) for line in Path(run['native_file']).read_text().splitlines()]
        assert rows == run['rows']
        footer = rows[-1]
        assert footer['status'] in ('timeout', 'exhausted', 'escape', 'witness')
        assert all(type(footer[k]) is int for k in ('start_state', 'next_state', 'total_states'))
        assert footer['start_state'] == cursor and cursor <= footer['next_state'] <= len(states) == footer['total_states']
        assert int(run['command'][2]) == cursor
        if footer['status'] == 'exhausted':
            assert footer['next_state'] == len(states)
        count = dict(neutral=0, internal_neutral=0, improving=0)
        emitted = []
        for row in rows[:-1]:
            index = row['state']
            assert type(index) is int and cursor <= index < footer['next_state']
            if row['event'] == 'candidate':
                emitted.append(row)
                continue
            assert row['event'] == 'trade'
            old = states[index]
            removed, added = row['removed'], row['added']
            assert len(removed) == len(set(removed)) == 5 and set(removed) <= set(old)
            assert len(added) == len(set(added)) in (5, 6) and not set(added) & set(old)
            assert all(type(v) is int and 0 <= v < 16807 for v in added)
            identity = index, tuple(sorted(added))
            assert identity not in seen
            seen.add(identity)
            delta = (coords[added, None, :] - coords[np.array(old)[None, :], :]) % 7
            bad = np.all((delta == 0) | (delta == 1) | (delta == 6), axis=2)
            blockers = [set(old[i] for i in np.flatnonzero(r)) for r in bad]
            assert all(2 <= len(b) <= 5 for b in blockers)
            assert set.union(*blockers) == set(removed)
            for size in range(2, 5):
                assert all(len(set.union(*subset)) > size for subset in combinations(blockers, size))
            words = sorted((set(old) - set(removed)) | set(added))
            points = coords[words]
            diff = (points[:, None, :] - points[None, :, :]) % 7
            conflicts = np.all((diff == 0) | (diff == 1) | (diff == 6), axis=2)
            assert np.array_equal(conflicts, np.eye(len(words), dtype=bool))
            pairs += len(words)*(len(words)-1)//2
            if len(words) == 367:
                count['neutral'] += 1
                if struct.pack('<367H', *words) in known:
                    count['internal_neutral'] += 1
                else:
                    outside.append(dict(state=index, words=words))
            else:
                assert len(words) == 368
                count['improving'] += 1
                outside.append(dict(state=index, words=words))
        assert all(count[k] == footer[k] for k in count)
        assert bool(outside) == bool(emitted)
        for row in emitted:
            assert row['size'] == len(row['words'])
            assert dict(state=row['state'], words=row['words']) in outside
        if footer['status'] in ('escape', 'witness'):
            assert outside and (footer['status'] == 'witness') == bool(count['improving'])
        else:
            assert not outside
        neutral += count['neutral']
        internal += count['internal_neutral']
        improving += count['improving']
        intervals.append(dict(file=str(path), start=cursor, end=footer['next_state'], status=footer['status']))
        cursor = footer['next_state']

    # A sampled finite control of the general reduction; native enumeration is
    # compared with exhaustive subset search separately in its C++ self-tests.
    rng = random.Random(2026092205)
    checked = reduced = retained = 0
    for _ in range(10000):
        masks = [rng.randrange(1, 32) for _ in range(rng.choice((5, 6)))]
        union = 0
        for b in masks:
            union |= b
        if union != 31:
            continue
        checked += 1
        short = None
        for size in range(1, 5):
            for indices in combinations(range(len(masks)), size):
                blocked = 0
                for i in indices:
                    blocked |= masks[i]
                if blocked.bit_count() <= size:
                    short = indices, blocked
                    break
            if short:
                break
        if short is None:
            retained += 1
        else:
            indices, blocked = short
            if blocked.bit_count() < len(indices):
                assert blocked.bit_count() <= 3  # An earlier-radius augmentation.
            else:
                assert 5 - blocked.bit_count() <= 4
            assert all(masks[i] & ~blocked == 0 for i in indices)
            reduced += 1
    for file in [manifest['source'], manifest['input'], here/'scan_component_atomic5', here/'scan_component_atomic5.cpp', here/'check_component_atomic4.py']:
        dependencies[str(file)] = sha(file)
    complete = cursor == len(states) and intervals[-1]['status'] == 'exhausted' and not outside
    out = dict(checker_sha256=sha(__file__), scope=__doc__, dependencies=dependencies,
               states=len(states), intervals=intervals, next_state=cursor, checked_trades=len(seen),
               pair_checks=pairs, neutral=neutral, internal_neutral=internal, improving=improving, outside=outside,
               complete_atomic5=complete, width5_component_equals_width4=complete,
               five_removal_augmentations_excluded=complete,
               sampled_reduction_controls=dict(checked=checked, reduced=reduced, retained=retained))
    args.output.write_text(json.dumps(out, indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k not in ('scope','dependencies','outside','intervals')}))


if __name__ == '__main__':
    main()
