"""Can 59 fixed free boxes + one box per core word cover low-blocker vertices?

This tests a specific stronger certificate template. Failure says nothing
against the already verified per-triple covers or an alternative free cover.
"""
import itertools
import json
import time
from pathlib import Path
import z3
import one_core_cover_replay as p

ROOT = Path(__file__).resolve().parent


def main():
    free = json.loads((ROOT/'cover-structure-optima.json').read_text())['cases'][0]
    assert free['name'] == 'free' and len(free['cover']) == 59
    assert all(c['weight'] == '1' for c in free['cover'])
    free_boxes = [tuple(c['origin']) for c in free['cover']]
    covered = set()
    for origin in free_boxes:
        covered.update(p.ID(w) for w in itertools.product(*[(x, (x+1) % 7) for x in origin]))
    assert all(v in covered for v, m in enumerate(p.blocked) if not m)
    side = [[z3.Bool(f'b{i}_{k}') for k in range(5)] for i in range(308)]
    solver = z3.Solver()
    solver.set(timeout=20000)
    cases = []
    for radius in (1, 2, 3):
        for v, blockers in enumerate(p.blocked):
            if blockers.bit_count() != radius or v in covered:
                continue
            options = []
            for i in range(308):
                if not blockers >> i & 1:
                    continue
                conditions = []
                for k, (x, c) in enumerate(zip(p.W[v], p.W[p.core[i]])):
                    difference = (x-c) % 7
                    assert difference in (0, 1, 6)
                    if difference == 1:
                        conditions.append(z3.Not(side[i][k]))
                    elif difference == 6:
                        conditions.append(side[i][k])
                options.append(z3.And(conditions))
            solver.add(z3.Or(options))
        started = time.monotonic()
        status = solver.check()
        row = {'radius': radius, 'status': str(status), 'seconds': time.monotonic()-started,
               'candidate_count': sum(m.bit_count() <= radius for m in p.blocked)}
        if status == z3.sat:
            model = solver.model()
            boxes = free_boxes + [tuple((x-int(z3.is_true(model.eval(side[i][k], model_completion=True)))) % 7
                                       for k, x in enumerate(p.W[v])) for i, v in enumerate(p.core)]
            union = set()
            for origin in boxes:
                union.update(p.ID(w) for w in itertools.product(*[(x, (x+1) % 7) for x in origin]))
            assert all(v in union for v, m in enumerate(p.blocked) if m.bit_count() <= radius)
            row['certificate'] = boxes
            row['box_count'] = len(boxes)
        cases.append(row)
        print(json.dumps({k: v for k, v in row.items() if k != 'certificate'}), flush=True)
        if status != z3.sat:
            break
    (ROOT/'shared-core-cover-probe.json').write_text(json.dumps({
        'protocol': 'Fix the 59 free boxes from the exact optimum probe; choose one adjacent box containing each of 308 core words; add all vertices by blocker count, radii1,2,3,20s per query. SAT certificates checked by full corner expansion. UNSAT is a solver result for this restricted template only, no proof exported.',
        'cases': cases}, indent=2)+'\n')


if __name__ == '__main__':
    main()
