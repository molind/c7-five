"""Global translation-averaged pair LP for independent sets in C7 strong powers.

For a nonempty independent S, f(d)=|S intersect(S-d)|/|S|, averaged over
coordinate permutations and reflections. Then f(0)=1, f is nonnegative, its
Fourier transform is nonnegative, and sum_d f(d)=|S|. Edge differences have f=0.
For every induced subgraph H with independence upper bound r, averaging
1_S(t)*sum_{h in H}1_S(t+h) <= r*1_S(t) gives sum_{h in H} f(h)<=r.
Cylinders use k adjacent coordinate pairs and n-k complete cyclic coordinates;
projection bounds their independence by alpha(C7^(n-k)). Numerical LP only.
"""
import argparse
from itertools import product, combinations_with_replacement
import json
import math
from pathlib import Path
import time
import hashlib

import numpy as np
from scipy.optimize import linprog


def model(n):
    coords = np.array(list(product(range(7), repeat=n)), dtype=np.int16)
    distances = np.minimum(coords, 7-coords)
    keys = [tuple(np.bincount(row, minlength=4).tolist()) for row in distances]
    profiles = sorted(set(keys))
    pos = {key:i for i,key in enumerate(profiles)}
    index = np.array([pos[key] for key in keys])
    weights = np.bincount(index, minlength=len(profiles))
    fourier = []
    for counts in profiles:
        freq = np.repeat(np.arange(4), counts)
        phase = (coords @ freq) % 7
        fourier.append(np.bincount(index, weights=np.cos(2*np.pi*phase/7), minlength=len(profiles)))
    bounds = [(1,1) if key[0]==n else ((0,0) if key[2]+key[3]==0 else (0,1)) for key in profiles]
    return coords, profiles, index, weights, np.array(fourier), bounds


def cylinder_rows(n, coords, index, count):
    # Published exact values in dimensions0,1,2,3; 115 follows from
    # alpha(C7^4)<=floor(7*alpha(C7^3)/2). Premises are explicit, not newly proved.
    ranks = [1,3,10,33,115]
    pairs = [(0,1),(1,2),(2,3),(3,4)]
    rows, upper, labels = [], [], []
    for k in range(1,n+1):
        for pattern in combinations_with_replacement(range(4),k):
            mask = np.ones(len(coords),dtype=bool)
            for j,p in enumerate(pattern):
                mask &= np.isin(coords[:,j],pairs[p])
            rows.append(np.bincount(index[mask],minlength=count))
            upper.append(ranks[n-k])
            labels.append(dict(adjacent_coordinates=k,pair_types=list(pattern),rank_upper=ranks[n-k]))
    return np.array(rows),np.array(upper),labels


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--dimensions',type=int,nargs='+',default=[1,2,3,4,5])
    args=p.parse_args(); assert __debug__ and not args.output.exists()
    out=dict(status='running',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
             rank_premises={'0':1,'1':3,'2':10,'3':33,'4':115},
             rank_reference='https://arxiv.org/html/1808.07438',rows=[],scope=__doc__)
    for n in args.dimensions:
        assert 1<=n<=5
        coords,profiles,index,weights,fourier,bounds=model(n)
        cyl,cup,labels=cylinder_rows(n,coords,index,len(profiles))
        for method in ['fourier','conditional_cylinders']:
            a=-fourier;b=np.zeros(len(fourier))
            if method=='conditional_cylinders':
                a=np.vstack((a,cyl));b=np.r_[b,cup]
            began=time.monotonic()
            res=linprog(-weights,A_ub=a,b_ub=b,bounds=bounds,method='highs',options={'time_limit':60})
            row=dict(dimension=n,method=method,profiles=len(profiles),constraints=len(b),status=int(res.status),message=res.message,seconds=time.monotonic()-began)
            if res.success:
                x=res.x
                violation=max(0,float(np.max(a@x-b)),max(lo-v for v,(lo,hi) in zip(x,bounds)),max(v-hi for v,(lo,hi) in zip(x,bounds)))
                assert violation<1e-6
                row.update(numerical_upper=float(weights@x),maximum_violation=violation,
                           profiles_order=[list(v) for v in profiles],values=x.tolist(),
                           dual_inequalities=res.ineqlin.marginals.tolist(),
                           dual_lower=res.lower.marginals.tolist(),dual_upper=res.upper.marginals.tolist())
                if method=='conditional_cylinders':row['cylinders']=labels
            out['rows'].append(row)
            args.output.write_text(json.dumps(out,indent=2)+'\n')
            print({k:v for k,v in row.items() if k not in ['profiles_order','values','dual_inequalities','dual_lower','dual_upper','cylinders']},flush=True)
    out['status']='complete_attempt';args.output.write_text(json.dumps(out,indent=2)+'\n')


if __name__=='__main__':main()
