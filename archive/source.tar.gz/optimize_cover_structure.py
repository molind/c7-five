"""Bounded structural probe: exact primal/dual optimum of selected box covers.

A primal cover bounds independent sets. A matching dual fractional packing
proves that no smaller cover of adjacent boxes exists; it need not be an
integer independent set. All certificates are verified without trusting the
optimizer's optimality status.
"""
import hashlib
import itertools
import json
import time
from fractions import Fraction
from pathlib import Path
import z3
import one_core_cover_replay as p
from check_one_core_covers import check

ROOT = Path(__file__).resolve().parent


def rational(value):
    return Fraction(value.numerator_as_long(), value.denominator_as_long())


def optimize(words):
    boxes = {}
    for i, word in enumerate(words):
        for d in itertools.product((0, 1), repeat=5):
            origin = tuple((x-y) % 7 for x, y in zip(word, d))
            boxes[origin] = boxes.get(origin, 0) | (1 << i)
    representatives = {mask: origin for origin, mask in sorted(boxes.items())}
    maximal = []
    for mask in sorted(representatives, key=lambda m: (-m.bit_count(), m)):
        if not any(mask & other == mask for other in maximal):
            maximal.append(mask)
    weights = [z3.Real('w'+str(i)) for i in range(len(maximal))]
    solver = z3.Optimize()
    solver.set(timeout=20000)
    solver.add(*[w >= 0 for w in weights])
    for i in range(len(words)):
        solver.add(z3.Sum([w for w, mask in zip(weights, maximal) if mask >> i & 1]) >= 1)
    solver.minimize(z3.Sum(weights))
    started = time.monotonic()
    status = solver.check()
    result = {'candidate_count': len(words), 'maximal_box_masks': len(maximal),
              'primal_status': str(status), 'primal_seconds': time.monotonic()-started}
    if status != z3.sat:
        return result
    model = solver.model()
    cover = [{'origin': representatives[mask], 'weight': str(rational(model.eval(var)))}
             for var, mask in zip(weights, maximal) if rational(model.eval(var))]
    total = sum((Fraction(c['weight']) for c in cover), Fraction(0))
    assert check(cover, set(words), total+1) == total

    # Seek an exact dual witness at the returned primal value. If unavailable,
    # retain only the valid upper bound and do not claim an optimum.
    packing = [z3.Real('x'+str(i)) for i in range(len(words))]
    dual = z3.SolverFor('QF_LRA')
    dual.set(timeout=20000)
    dual.add(*[x >= 0 for x in packing])
    dual.add(z3.Sum(packing) == z3.RealVal(str(total)))
    for mask in maximal:
        dual.add(z3.Sum([x for i, x in enumerate(packing) if mask >> i & 1]) <= 1)
    began = time.monotonic()
    dual_status = dual.check()
    result.update(cover=cover, primal_total=str(total), dual_status=str(dual_status),
                  dual_seconds=time.monotonic()-began, optimum_proved=False)
    if dual_status == z3.sat:
        model = dual.model()
        witness = {w: rational(model.eval(x)) for w, x in zip(words, packing)}
        assert all(x >= 0 for x in witness.values())
        assert sum(witness.values(), Fraction(0)) == total
        # Independently test every one of the 7^5 boxes by corner expansion.
        for origin in itertools.product(range(7), repeat=5):
            load = sum((witness.get(w, Fraction(0))
                        for w in itertools.product(*[(x, (x+1) % 7) for x in origin])), Fraction(0))
            assert load <= 1
        result.update(optimum_proved=True,
                      dual=[{'word': w, 'weight': str(q)} for w, q in witness.items() if q])
    return result


def main():
    # First the free pool; then the triple with the largest returned weight in
    # the completed sweep. This selection is deterministic, not a random sample.
    rows = json.loads((ROOT/'three-core-probe-results.json').read_text())['cases']
    for line in (ROOT/'three-core-continuation.jsonl').read_text().splitlines():
        rows.append(json.loads(line)['case'])
    worst = max(rows, key=lambda r: Fraction(r['cover']['total']))
    selections = [('free', []), ('largest_returned_triple_weight', worst['triple'])]
    cases = []
    full = (1 << len(p.core)) - 1
    for name, deleted in selections:
        kept = full ^ sum(1 << i for i in deleted)
        words = [w for w, mask in zip(p.W, p.blocked) if not mask & kept]
        result = optimize(words)
        result.update(name=name, deleted_core_indices=deleted,
                      words=[list(w) for w in words])
        cases.append(result)
        print(json.dumps({k: v for k, v in result.items() if k not in ('cover', 'dual', 'words')}), flush=True)
    report = {'protocol': 'Free pool and largest returned triple-cover weight; 20s per primal and dual solver query; exact independent cover and all-box dual checks.',
              'continuation_sha256': hashlib.sha256((ROOT/'three-core-continuation.jsonl').read_bytes()).hexdigest(),
              'cases': cases}
    (ROOT/'cover-structure-optima.json').write_text(json.dumps(report, indent=2)+'\n')


if __name__ == '__main__':
    main()
