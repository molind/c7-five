"""Count nonredundant distance-two constraints in exact saved forest orders."""
import gzip,hashlib,json
from pathlib import Path


def main():
    r=Path('research/c7');records=[];deps={}
    for name in ['component-CB-incremental-sep22-input.json','component-F-rooted8-sep22-input.json']:
        p=r/name;m=json.loads(p.read_text());deps[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
        assert hashlib.sha256(Path(m['source']).read_bytes()).hexdigest()==m['source_sha256']
        deps[m['source']]=m['source_sha256']
        with gzip.open(m['source'],'rt') as f:next(f);states=[json.loads(x) for x in f]
        masks=[sum(1<<v for v in s) for s in states]
        sample=list(range(len(states))) if len(states)<100 else sorted(set([0,1,547,548,1000,2000,3000,4000,5000,6000,len(states)-1]+list(range(550,590))))
        for i in sample:
            near=[];one=[];s=masks[i];frozen=deleted=0
            for j,t in enumerate(masks[:i]):
                distance=(s^t).bit_count()//2
                if distance==1:
                    x,y=s&~t,t&~s;one.append((j,x,y));frozen|=x;deleted|=y
                elif distance==2:near.append((j,s&~t,t&~s))
            retention=[(j,x,y) for j,x,y in near if not x&frozen]
            critical=[(j,x,y) for j,x,y in near if not y&deleted]
            both=[(j,x,y) for j,x,y in near if not x&frozen and not y&deleted]
            records.append(dict(manifest=name,state=i,prior_one=len(one),prior_two=len(near),new_retention=len(retention),new_critical=len(critical),both=len(both)))
    out=r/'distant-parent-profile-sep22.json';assert not out.exists()
    d=dict(source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),dependencies=deps,records=records,scope='Necessary constraints only; subset tests remove implications of existing distance-one constraints. No group reduction or search speed is measured.')
    out.write_text(json.dumps(d,indent=2)+'\n')
    for name in sorted(set(x['manifest'] for x in records)):
        xs=[x for x in records if x['manifest']==name]
        print(json.dumps(dict(manifest=name,sampled=len(xs),totals={k:sum(x[k] for x in xs) for k in ['prior_one','prior_two','new_retention','new_critical','both']},states_with_new=sum(bool(x['new_retention'] or x['new_critical']) for x in xs))))


if __name__=='__main__':main()
