"""Exhaustive small-input checks of width-two augmentation and move reduction."""
from itertools import combinations,permutations
import hashlib
import json
from pathlib import Path
import random
import struct

from search_plateau import inspect_known_augmentations


def check(selected,n,edges,known_fraction,rng):
    def compatible(u,v):return u!=v and tuple(sorted((u,v))) not in edges
    def independent(vs):return all(compatible(u,v) for u,v in combinations(vs,2))
    outside=[v for v in range(n) if v not in selected];free=[];grouped={};doubles={}
    for v in outside:
        bs=tuple(u for u in selected if not compatible(u,v))
        if not bs:free.append(v)
        elif len(bs)==1:grouped.setdefault(bs[0],[]).append(v)
        elif len(bs)==2:doubles.setdefault(bs,[]).append(v)
    aug={1:set(),2:set()};all_moves={};single_gain_two=set()
    for size in range(3):
        for removed in combinations(selected,size):
            kept=set(selected)-set(removed)
            for gain in (1,2):
                for added in combinations(outside,size+gain):
                    full=tuple(sorted(kept|set(added)))
                    if independent(full):
                        aug[gain].add(full)
                        if gain==2 and size<=1:single_gain_two.add(full)
            if size:
                for added in combinations(outside,size):
                    if independent(kept|set(added)):all_moves[removed,added]=tuple(sorted(kept|set(added)))
    known_sets={s for s in aug[1] if rng.random()<known_fraction}
    encode=lambda s:struct.pack('<'+str(len(s))+'H',*s)
    known={encode(s) for s in known_sets}
    solution,moves,ignored=inspect_known_augmentations(selected,free,grouped,compatible,known,doubles)
    assert all(k in known for k in ignored)
    stats=dict(gain_two=0,two_deletion_only=0,unseen_gain_one=0,continued=0,two_word_moves=0,omitted_decomposable=0,free_in_double_moves=0)
    if aug[2]:
        assert tuple(solution) in aug[2] and not moves;stats['gain_two']=1
        stats['two_deletion_only']=int(not single_gain_two)
    elif aug[1]-known_sets:
        assert tuple(solution) in aug[1]-known_sets and not moves;stats['unseen_gain_one']=1
    else:
        assert solution is None and set(ignored)==known;stats['continued']=1
        actual={(tuple(sorted(r)),tuple(sorted(a))) for r,a in moves}
        assert len(actual)==len(moves) and actual<=set(all_moves)
        assert {m for m in all_moves if len(m[0])==1}<=actual
        for m in set(all_moves)-actual:
            removed,added=m;assert len(removed)==len(added)==2
            # Each omitted direct edge has an explicit two-single-move path.
            decomposable=False
            for rs in permutations(removed):
                for vs in permutations(added):
                    middle=(set(selected)-{rs[0]})|{vs[0]}
                    if independent(middle) and independent((middle-{rs[1]})|{vs[1]}):decomposable=True
            assert decomposable;stats['omitted_decomposable']+=1
        stats['two_word_moves']=sum(len(r)==2 for r,a in actual)
        stats['free_in_double_moves']=sum(len(r)==2 and bool(set(a)&set(free)) for r,a in actual)
    return stats


def main():
    rng=random.Random(2026100100);totals={};cases=0
    for trial in range(1600):
        n=rng.randrange(6,12);selected=list(range(rng.randrange(2,5)))
        edges={p for p in combinations(range(n),2) if not set(p)<=set(selected) and rng.random()<(.25+.5*(trial%4)/3)}
        result=check(selected,n,edges,(1,.5,0)[trial%3],rng)
        for k,v in result.items():totals[k]=totals.get(k,0)+v
        cases+=1
    # Gain two may require two sole-blocker groups, without any double blockers.
    crafted=[([0,1],6,{(0,2),(0,3),(1,4),(1,5)}),
             ([0,1],6,{(u,v) for u in (0,1) for v in (2,3,4,5)})]
    for selected,n,edges in crafted:
        result=check(selected,n,edges,1,rng);assert result['gain_two'] and result['two_deletion_only']
        for k,v in result.items():totals[k]=totals.get(k,0)+v
        cases+=1
    assert all(totals[k]>0 for k in totals)
    report=dict(cases=cases,totals=totals,search_sha256=hashlib.sha256(Path(__file__).with_name('search_plateau.py').read_bytes()).hexdigest(),checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope=__doc__)
    p=Path(__file__).with_name('filtered-width-two-controls-reviewed-sep21.json');assert not p.exists();p.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))


if __name__=='__main__':main()
