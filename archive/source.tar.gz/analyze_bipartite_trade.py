"""Analyze an equal-size replacement using its bipartite conflict graph.

Old and new words are separately independent. A matching of size m bounds the
independent-set size by 2r-m; the returned cover-complement attains that bound.
With a perfect matching, every size-r independent set chooses exactly one end
of each matched edge. Dependencies between those choices form a directed graph.
Each strongly connected component must switch as a unit; sink-first component
switches give a path whose maximum replacement size is the largest component.
All claims refer only to the supplied union of old/new words.
"""


def analyze_trade(old,new,compatible):
    old=tuple(old);new=tuple(new);r=len(old)
    assert 0<r==len(new) and len(set(old+new))==2*r
    assert all(compatible(group[i],group[j]) for group in (old,new) for i in range(r) for j in range(i))
    edges=[[j for j in range(r) if not compatible(new[i],old[j])] for i in range(r)]
    owner=[-1]*r
    def augment(i,seen):
        for j in edges[i]:
            if j in seen:continue
            seen.add(j)
            if owner[j]<0 or augment(owner[j],seen):owner[j]=i;return True
        return False
    for i in range(r):augment(i,set())
    matched_new={i for i in owner if i>=0};m=len(matched_new)
    matching=[[new[i],old[j]] for j,i in enumerate(owner) if i>=0]
    # Alternating reachability from unmatched new vertices constructs a cover:
    # new vertices outside reachability, and old vertices inside reachability.
    left=set(range(r))-matched_new;right=set();queue=list(left)
    for i in queue:
        for j in edges[i]:
            if owner[j]==i or j in right:continue
            right.add(j)
            if owner[j]>=0 and owner[j] not in left:left.add(owner[j]);queue.append(owner[j])
    cover=[new[i] for i in range(r) if i not in left]+[old[j] for j in sorted(right)]
    maximum=[new[i] for i in sorted(left)]+[old[j] for j in range(r) if j not in right]
    assert len(cover)==m and len(maximum)==2*r-m
    assert all(compatible(u,v) for i,u in enumerate(maximum) for v in maximum[i+1:])
    out=dict(matching=matching,cover=cover,maximum=maximum,matching_size=m)
    if m<r:return out
    paired_old={i:j for j,i in enumerate(owner)}
    reach=[(1<<i)|sum(1<<owner[j] for j in edges[i]) for i in range(r)]
    for k in range(r):
        for i in range(r):
            if reach[i]>>k&1:reach[i]|=reach[k]
    remaining=set(range(r));components=[]
    while remaining:
        i=min(remaining);component={j for j in remaining if reach[i]>>j&1 and reach[j]>>i&1}
        assert component;remaining-=component;components.append(component)
    pending=list(components);steps=[];state=set(old)
    while pending:
        unswitched=set().union(*pending)
        component=next(c for c in pending if all(owner[j] in c or owner[j] not in unswitched for i in c for j in edges[i]))
        removed=[old[paired_old[i]] for i in sorted(component)];added=[new[i] for i in sorted(component)]
        state.difference_update(removed);state.update(added)
        assert len(state)==r and all(compatible(u,v) for u in state for v in state if u!=v)
        steps.append(dict(removed=removed,added=added));pending.remove(component)
    assert state==set(new)
    out.update(component_sizes=sorted(map(len,components)),minimum_step_width=max(map(len,components)),steps=steps)
    return out
