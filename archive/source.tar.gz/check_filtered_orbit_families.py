"""Map every classified cached state to a previously verified canonical family."""
import gzip
import hashlib
import json
from pathlib import Path
import struct

import numpy as np

ROOT=Path(__file__).resolve().parent


def load(path):
    with gzip.open(path,'rt') as f:meta=json.loads(next(f));states=[json.loads(line) for line in f]
    assert all(s==sorted(s) and len(s)==len(set(s))==367 and all(type(v) is int and 0<=v<16807 for v in s) for s in states)
    keys={struct.pack('<367H',*s) for s in states}
    assert len(keys)==meta['states'] and hashlib.sha256(b''.join(sorted(keys))).hexdigest()==meta['component_sha256']
    return meta,states,keys


def images(states,mapping):
    perm,sign,shift=(mapping[k] for k in ('permutation','signs','shift'))
    assert sorted(perm)==list(range(5)) and len(sign)==len(shift)==5
    assert all(s in (-1,1) for s in sign) and all(type(t) is int and 0<=t<7 for t in shift)
    ids=np.array(states,dtype=np.int32);out=np.zeros(ids.shape,dtype=np.int32);powers=[2401,343,49,7,1]
    for i in range(5):out+=((sign[i]*(ids//powers[perm[i]]%7)+shift[i])%7)*powers[i]
    return {row.tobytes() for row in np.sort(out,axis=1).astype('<u2')}


def main():
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    references={
        'C':('family-f-c-frontier-classified-sep21-component-0.jsonl.gz','family-f-c-frontier-classification-verification-sep21.json'),
        'B':('family-f-frontier-forced-omit-classified-sep21-component-0.jsonl.gz','family-f-frontier-forced-omit-classification-verification-sep21.json'),
        'E':('family-e-classifier-control-sep21-component-0.jsonl.gz','family-e-component-verification-sep21.json')}
    canonical={};refs=[]
    for label,(cache,verification) in references.items():
        path=ROOT/cache;vp=ROOT/verification;meta,states,keys=load(path);v=json.loads(vp.read_text())
        if label=='E':assert v['component_sha256']==meta['component_sha256']
        else:assert v['cache_sha256']==sha(path)
        m=meta['classification'];assert m['family']==label
        canonical[label]=images(states,m)
        assert hashlib.sha256(b''.join(sorted(canonical[label]))).hexdigest()==m['reference_component_sha256']
        refs.append(dict(family=label,file=str(path),sha256=sha(path),verification=str(vp),verification_sha256=sha(vp)))
    path=ROOT/'filtered366-orbit-classified-sep21-classification.json';classification=json.loads(path.read_text());rows=[];keys_by_component={}
    for ci,comp in enumerate(classification['components']):
        m=comp['classification'];assert m is not None and m['family'] in canonical
        cache=Path(comp['cache']);meta,states,keys=load(cache);assert meta['classification']==m
        mapped=images(states,m);assert mapped==canonical[m['family']]
        keys_by_component[ci]=keys;rows.append(dict(component=ci,family=m['family'],states=len(states),cache_sha256=sha(cache),mapping=m))
    candidates=[];sources={}
    for r in classification['candidates']:
        if r['file'] not in sources:sources[r['file']]=json.loads(Path(r['file']).read_text())
        c=sources[r['file']]['candidates'][r['candidate']];ids=sorted(int(w,7) for w in c['words'])
        assert len(ids)==len(set(ids))==367 and struct.pack('<367H',*ids) in keys_by_component[r['component']]
        candidates.append(dict(file=r['file'],candidate=r['candidate'],family=rows[r['component']]['family'],component=r['component']))
    out=dict(classification_sha256=sha(path),checker_sha256=sha(__file__),references=refs,components=rows,candidates=candidates,
             source_hashes={p:sha(p) for p in sources},mapped_states=sum(r['states'] for r in rows),mapped_words=sum(r['states'] for r in rows)*367,
             scope='Every classified state maps by a checked graph automorphism onto the complete previously verified canonicalB,C,orE component. Every candidate checked by full-state membership. Candidate pair checks are supplied by the separate witness/extension audits.')
    target=ROOT/'filtered366-orbit-family-verification-sep21.json';assert not target.exists();target.write_text(json.dumps(out,indent=2)+'\n')
    from collections import Counter
    print(json.dumps(dict(components=len(rows),candidates=len(candidates),families=dict(Counter(r['family'] for r in candidates)),mapped_states=out['mapped_states'],mapped_words=out['mapped_words'])))


if __name__=='__main__':main()
