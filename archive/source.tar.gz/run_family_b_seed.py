"""Bounded checks for the public Family-B seed or its farthest component member."""
import argparse
import ast
import base64
import hashlib
import itertools
import json
from pathlib import Path
import struct
import subprocess
import sys
import time
import zlib

from family_a_component import component, TOKENS, WORDS

HERE = Path(__file__).resolve().parent
if not __debug__:
    raise RuntimeError('Run without -O')
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('variant', nargs='?', choices=('seed', 'farthest'), default='seed')
variant = parser.parse_args().variant
prefix = f'family-b-{variant}'
data = next(ast.literal_eval(n.value) for n in ast.parse((HERE/'valley_replay.py').read_text()).body
            if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name)
            and n.targets[0].id == 'DATA')[1]
raw = zlib.decompress(base64.b85decode(data[2]))
assert len(raw) == 780
seed = tuple(itertools.accumulate(struct.unpack('<367H', raw[:734])))
assert len(seed) == len(set(seed)) == 367 and seed == tuple(sorted(seed))
assert all(0 <= i < 7**5 for i in seed)
assert all(any((x-y) % 7 in (2, 3, 4, 5) for x, y in zip(WORDS[a], WORDS[b]))
           for a, b in itertools.combinations(seed, 2))
states, _, edges = component(seed)
digest = hashlib.sha256(b''.join(sorted(struct.pack('<367H', *s) for s in states))).hexdigest()
assert (len(states), digest) == (data[0], data[1])
known = set(states)
if variant == 'farthest':
    distances = [len(set(seed)-set(s)) for s in states]
    assert max(distances) == 8 and distances.count(8) == 1
    seed = states[distances.index(8)]
words = ' '.join(TOKENS[i] for i in seed)
seed_hash = hashlib.sha256(words.encode()).hexdigest()
assert seed_hash == {'seed': 'ab9029e1f7074e0c40d3468b2a02d11717498386474194126b2362eb1d1d85ea',
                     'farthest': '0964b6078b5132368ecf183f9eb72e8222043721747b3a9766055033bae80d81'}[variant]
word_file = HERE/f'{prefix}-words.txt'
word_file.write_text(words+'\n')
source = HERE/'exchange_dfs_before_pair_counts.cpp'
source_hash = hashlib.sha256(source.read_bytes()).hexdigest()
assert source_hash == 'c0eb2f1b798c0aaab2d14086d23bd9dd011a133dd3325900b4fdf37b37d8232e'
binary = HERE/'exchange_dfs_family_b'
subprocess.run(['clang++', '-std=c++17', '-O3', str(source), '-o', str(binary)], check=True, timeout=30)
report = dict(variant=variant, seed_sha256=seed_hash, source_sha256=source_hash,
              component_sha256=digest, component_states=len(states), directed_edges=len(edges),
              internal_limit_seconds=60, parent_limit_seconds=75, rows=[], outside={})
result_file = HERE/f'{prefix}-exchanges.json'
occupied = set(seed)
for radius in range(1, 7):
    graph_file = HERE/f'{prefix}-d{radius}.txt'
    with graph_file.open('w') as out:
        subprocess.run([sys.executable, str(HERE/'export_exchange_graph.py'), str(word_file),
                        seed_hash, str(radius)], stdout=out, check=True, timeout=40)
    # Reconstruct ordering and blocker sets by direct coordinate comparison.
    pool = []
    for i, w in enumerate(WORDS):
        if i in occupied:
            continue
        blockers = {s for s in seed if all((x-y) % 7 in (0, 1, 6) for x, y in zip(w, WORDS[s]))}
        if len(blockers) <= radius:
            pool.append((i, blockers))
    pool.sort(key=lambda x: len(x[1]))
    graph = graph_file.read_bytes()
    assert int(graph.split(b'\n', 1)[0].split()[0]) == len(pool)
    for neutral in (False, True):
        began = time.monotonic()
        with graph_file.open() as inp:
            try:
                run = subprocess.run([str(binary), '60', '--subset', *(['--neutral'] if neutral else [])],
                                     stdin=inp, text=True, capture_output=True, check=True, timeout=75)
                result = json.loads(run.stdout)
            except subprocess.TimeoutExpired:
                result = dict(status='parent_timeout')
        row = dict(radius=radius, neutral=neutral, candidates=len(pool), search=result,
                   wall_seconds=time.monotonic()-began, graph_sha256=hashlib.sha256(graph).hexdigest())
        if result['status'] == 'exhausted':
            assert result['nodes_started'] == result['nodes_completed']
        selections = result.get('neutral', []) + result.get('improving', [])
        if result['status'] == 'witness' and result.get('chosen'):
            selections.append(result['chosen'])
        targets = set()
        for selected in selections:
            removed = set().union(*(pool[i][1] for i in selected))
            target = tuple(sorted((occupied-removed) | {pool[i][0] for i in selected}))
            assert len(removed) <= radius and len(target) >= 367
            assert all(any((x-y) % 7 in (2, 3, 4, 5) for x, y in zip(WORDS[a], WORDS[b]))
                       for a, b in itertools.combinations(target, 2))
            targets.add(target)
            if target not in known:
                text = ' '.join(TOKENS[i] for i in target)
                h = hashlib.sha256(text.encode()).hexdigest()
                report['outside'][h] = dict(words=text, size=len(target), radius=radius)
        row['distinct_targets'] = len(targets)
        row['outside_targets'] = sum(t not in known for t in targets)
        report['rows'].append(row)
        result_file.write_text(json.dumps(report, indent=2)+'\n')
        print(json.dumps({k:v for k,v in row.items() if k != 'search'} | {
            'status':result['status'], 'nodes':result.get('nodes_started'),
            'seconds':result.get('seconds')}), flush=True)
        if report['outside']:
            raise SystemExit('New target saved; stop for verification before further searches')
