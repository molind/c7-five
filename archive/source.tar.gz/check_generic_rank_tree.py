"""Check a generic-exterior tree, including its coordinate branch partitions."""
import argparse
import copy
import hashlib
import json
from pathlib import Path

import numpy as np

from check_two_slice_covers import WORDS
from search_rank_tree import replay, pruning_domain


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    assert __debug__ and not args.output.exists()
    tree = json.loads(args.input.read_text())
    checked = replay(tree)
    source = json.loads(Path(tree['input']).read_text())
    domain = pruning_domain(source, tree['domain_index'])
    coords = np.asarray(WORDS)
    partitions = 0
    for node in tree['nodes']:
        if node['status'] != 'split':
            continue
        vertex = node['split_vertex']
        pool = node['remaining_pool']
        delta = (coords[pool]-coords[vertex]) % 7
        allowed = np.any((delta >= 2) & (delta <= 5), axis=1)
        include = [v for v, ok in zip(pool, allowed) if ok]
        exclude = [v for v in pool if v != vertex]
        assert tree['nodes'][node['children']['include']]['pool'] == include
        assert tree['nodes'][node['children']['exclude']]['pool'] == exclude
        partitions += 1

    rejected = []
    bad = copy.deepcopy(tree)
    bad['domain_index'] = max(source['requested_indices'])+1
    cases = [('wrong source domain', bad)]
    bad = copy.deepcopy(tree)
    bad['nodes'][0]['pool'] = bad['nodes'][0]['pool'][1:]
    cases.append(('unjustified root restriction', bad))
    bad = copy.deepcopy(tree)
    bad['full_target'] -= 1
    cases.append(('weakened target', bad))
    for label, bad in cases:
        try:
            replay(bad)
        except AssertionError:
            rejected.append(label)
        else:
            raise AssertionError(f'Accepted {label}')
    result = dict(input_sha256=hashlib.sha256(args.input.read_bytes()).hexdigest(),
                  checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  tree_source_sha256=hashlib.sha256(Path(__file__).with_name('search_rank_tree.py').read_bytes()).hexdigest(),
                  verification=checked, coordinate_partitions=partitions,
                  fixed=len(domain['fixed']), root_pool=len(domain['final_pool']),
                  negative_controls=rejected,
                  scope='Local proof replay and separate coordinate branch partitions; not an external replay.')
    args.output.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
