"""Test exact blocker-subset lookup when a six-deletion budget is full.

This is a profiling/control experiment, not an exhaustive C7 search.
"""
import collections
import contextlib
import io
import json
from pathlib import Path
import random
import statistics
import sys
import time

HERE = Path(__file__).parent


def prepare(name, pin):
    source = (HERE / 'export_exchange_graph.py').read_text().split('print(n, 6, radius)')[0]
    saved = sys.argv
    sys.argv = ['export', str(HERE / f'exchange-dfs-{name}-words.txt'), pin, '6']
    try:
        ns = {}
        with contextlib.redirect_stdout(io.StringIO()):
            exec(compile(source, '<reviewed graph preparation>', 'exec'), ns)
        return [ns['blockers'][v] for v in ns['pool']]
    finally:
        sys.argv = saved


def profile(name, pin):
    blockers = prepare(name, pin)
    groups = collections.defaultdict(list)
    for i, b in enumerate(blockers):
        groups[b].append(i)
    rng = random.Random(20260917)
    # Include unions of two smaller blocker sets, not just one-word masks.
    small = [b for b in blockers if b.bit_count() <= 3]
    single = list(dict.fromkeys(b for b in blockers if b.bit_count() == 6))
    rng.shuffle(single)
    unions = set(single[:500])
    attempts = 0
    while len(unions) < 1000 and attempts < 100000:
        u = rng.choice(small) | rng.choice(small)
        if u.bit_count() == 6:
            unions.add(u)
        attempts += 1
    cases = sorted(unions)
    began = time.perf_counter()
    direct = [[i for i, b in enumerate(blockers) if b & u == b] for u in cases]
    scan_seconds = time.perf_counter() - began
    began = time.perf_counter()
    indexed = []
    for u in cases:
        found = []
        sub = u
        while True:
            found.extend(groups.get(sub, ()))
            if sub == 0:
                break
            sub = (sub - 1) & u
        indexed.append(sorted(found))
    lookup_seconds = time.perf_counter() - began
    assert indexed == direct
    counts = [len(x) for x in direct]
    return dict(incumbent=name, pool=len(blockers), exact_blocker_groups=len(groups),
                tested_six_word_budgets=len(cases), subset_probes_per_budget=64,
                min_eligible=min(counts), median_eligible=statistics.median(counts),
                max_eligible=max(counts), fewer_than_seven=sum(c < 7 for c in counts),
                full_scan_seconds=scan_seconds, indexed_lookup_seconds=lookup_seconds,
                seed=20260917, scope='Eligibility before pairwise compatibility; sampled budgets only. No C7 exclusion or whole-search speedup claimed.')


if __name__ == '__main__':
    results = [profile('original', 'd520ab2a9b74b927b00d1ca851a20c5f7ed8194dba42cb74486e1be016a7069a'),
               profile('family-c', '7fed46596bf35cb433d9e81c7a13f3b1fb3d6cfe31f1d8905f286556b87cb21c')]
    (HERE / 'blocker-subset-profile.json').write_text(json.dumps(results, indent=2)+'\n')
    print(json.dumps(results, indent=2))
