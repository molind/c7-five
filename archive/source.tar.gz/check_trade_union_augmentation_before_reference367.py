"""Verify a recovered gain using only coordinates, matching edges and a cover."""
import argparse
import hashlib
from itertools import combinations, product
import json
from pathlib import Path


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--input',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();assert __debug__ and not a.output.exists()
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    data=json.loads(a.input.read_text());sp=Path(data['input']);assert sha(sp)==data['input_sha256'];source=json.loads(sp.read_text())
    mp=Path(source['input']);assert sha(mp)==source['input_sha256'];model=json.loads(mp.read_text())
    bp=Path(model['input']);assert sha(bp)==model['input_sha256'];bases=json.loads(bp.read_text())['bases']
    coords=list(product(range(7),repeat=5))
    def conflict(u,v):return all((x-y)%7 in (0,1,6) for x,y in zip(coords[u],coords[v]))
    def independent(vs):
        assert len(vs)==len(set(vs)) and all(type(v) is int and 0<=v<16807 for v in vs)
        assert all(not conflict(u,v) for u,v in combinations(vs,2))
        return len(vs)*(len(vs)-1)//2
    checks=0;rows=[];expected=[]
    for row in data['rows']:
        candidate=source['candidates'][row['candidate']];assert row['base']==candidate['source_base']
        initial=bases[row['base']]['words'];changed=sorted(int(w,7) for w in candidate['words'])
        checks+=independent(initial)+independent(changed)
        old=sorted(set(initial)-set(changed));new=sorted(set(changed)-set(initial));assert old==row['removed'] and new==row['added'] and len(old)==len(new)
        certificate=row['analysis'];matching=certificate['matching'];cover=certificate['cover'];maximum=certificate['maximum'];union=set(old+new)
        assert len(matching)==certificate['matching_size']==len(cover)==len(set(cover))
        endpoints=[v for edge in matching for v in edge];assert len(endpoints)==len(set(endpoints))==2*len(matching)
        assert all(u in new and v in old and conflict(u,v) for u,v in matching)
        assert set(cover)<=union and all(u in cover or v in cover for u in old for v in new if conflict(u,v))
        assert set(maximum)<=union and len(maximum)==len(union)-len(matching);checks+=independent(maximum)
        if len(maximum)>len(old):
            full=sorted((set(initial)-set(old))|set(maximum));checks+=independent(full)
            assert len(full)==row['recovered_size'];expected.append((row['candidate'],row['base'],full))
        rows.append(dict(candidate=row['candidate'],union_size=len(union),matching=len(matching),maximum=len(maximum)))
    assert len(expected)==len(data['candidates'])
    for index,((origin,bi,full),c) in enumerate(zip(expected,data['candidates'])):
        assert c['step']==index and c['source_candidate']==origin and c['source_base']==bi
        assert full==[int(w,7) for w in c['words']] and c['size']==len(full) and c['pair_checks']==len(full)*(len(full)-1)//2
    assert (data['status']=='verified_target')==any(len(full)>=368 for _,_,full in expected)
    out=dict(input=str(a.input),input_sha256=sha(a.input),checker_sha256=sha(__file__),rows=rows,pair_checks=checks,
        recovered_sizes=[len(full) for _,_,full in expected],scope=__doc__)
    a.output.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))


if __name__=='__main__':main()
