"""Probe and search the exact target368 model with verified subtree clauses.

LP results are diagnostics. MIP infeasibility is not an exclusion certificate.
Only a distinct368-word construction with every C7 pair checked is a solution.
"""
import argparse
import json
from pathlib import Path
import time

import numpy as np
from scipy.sparse import csc_matrix, vstack
from scipy.optimize._highspy import _core as high

from check_core_subtree_cuts import verify, sha
from solve_core_radius_ipm import load_radius_model, model_digest, build_model
from search_core_regions import independence


def append_before_radius(matrix, lower, upper, entries, lows, highs):
    rows, cols, vals = [], [], []
    for i, terms in enumerate(entries):
        for j, value in terms:
            rows.append(i); cols.append(j); vals.append(value)
    extra = csc_matrix((vals, (rows, cols)), shape=(len(entries), matrix.shape[1]))
    return (vstack((matrix[:-3], extra, matrix[-3:]), format='csc'),
            np.r_[lower[:-3], lows, lower[-3:]], np.r_[upper[:-3], highs, upper[-3:]])


def solve(matrix, lower, upper, variable_upper, seconds, integer, cost=None):
    solver = high._Highs()
    options = dict(output_flag=False, time_limit=float(seconds))
    if not integer:
        options.update(solver='ipm', run_crossover='off')
    else:
        options.update(mip_rel_gap=0.0)
    for k, v in options.items():
        assert solver.setOptionValue(k, v) == high.HighsStatus.kOk
    model = build_model(matrix, lower, upper, variable_upper, integer)
    if cost is not None:
        model.col_cost_ = cost
    assert solver.passModel(model) == high.HighsStatus.kOk
    began = time.monotonic()
    run_status = solver.run()
    info, solution = solver.getInfo(), solver.getSolution()
    result = dict(status=solver.modelStatusToString(solver.getModelStatus()),
                  run_status=str(run_status), seconds=time.monotonic()-began,
                  objective=info.objective_function_value, nodes=info.mip_node_count,
                  primal_solution_status=int(info.primal_solution_status))
    values = None
    if solution.value_valid and info.primal_solution_status == high.kSolutionStatusFeasible:
        candidate = np.asarray(solution.col_value)
        activity = matrix @ candidate
        if np.all(np.isfinite(candidate)) and np.all(np.isfinite(activity)):
            violation = float(max(0, np.max(-candidate), np.max(candidate-variable_upper),
                                  np.max(lower-activity), np.max(activity-upper)))
            result['maximum_violation'] = violation
            if violation <= 1e-6:
                values = candidate
            else:
                result['point_rejected'] = True
    return result, values


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--cuts', type=Path, required=True)
    p.add_argument('--lp-seconds', type=float, default=15)
    p.add_argument('--mip-seconds', type=float, default=120)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    assert __debug__ and not args.output.exists() and min(args.lp_seconds, args.mip_seconds) > 0
    cuts = verify(args.cuts)
    data, matrix, lower, upper, variable_upper, _ = load_radius_model(Path(cuts['input']), cuts['radius'])
    tree_path = Path(cuts['clauses'][0]['tree'])
    tree = json.loads(tree_path.read_text())
    pos = {v: i for i, v in enumerate(data['pool'])}
    exclusion = json.loads(Path(tree['domain_exclusion']).read_text())
    entries = [[(pos[v], 1) for v in exclusion['inside']],
               [(pos[v], 1) for v in tree['common_core_cut_words']]]
    matrix, lower, upper = append_before_radius(matrix, lower, upper, entries, [0, 0],
        [exclusion['inequality_upper'], tree['common_core_cut_upper']])
    lower[-3] = data['target']
    assert model_digest(matrix, lower, upper, variable_upper) == cuts['target_model_sha256']
    entries, lows, highs = [], [], []
    for c in cuts['clauses']:
        assert not set(c['inside']) & set(c['outside'])
        entries.append([(pos[v], 1) for v in c['inside']] + [(pos[v], -1) for v in c['outside']])
        lows.append(-len(c['outside']))
        highs.append(len(c['inside'])-1)
    strengthened, slo, shi = append_before_radius(matrix, lower, upper, entries, lows, highs)
    out = dict(status='running', input=cuts['input'], radius=cuts['radius'],
               original_model_sha256=cuts['target_model_sha256'],
               strengthened_model_sha256=model_digest(strengthened, slo, shi, variable_upper),
               added_clauses=len(entries), source_sha256=sha(__file__),
               dependencies={str(args.cuts): sha(args.cuts), str(tree_path): sha(tree_path)},
               scope=__doc__)
    for name in ('check_core_subtree_cuts.py', 'derive_core_subtree_cuts.py', 'solve_core_radius_ipm.py', 'search_core_regions.py'):
        path = Path(__file__).with_name(name)
        out['dependencies'][str(path)] = sha(path)
    def save():
        args.output.write_text(json.dumps(out, indent=2) + '\n')
    save()
    cost = np.zeros(len(pos))
    for j, value in entries[0]:
        cost[j] = -value
    for label, a, lo, hi in [('before', matrix, lower, upper), ('after', strengthened, slo, shi)]:
        result, values = solve(a, lo, hi, variable_upper, args.lp_seconds, False, cost)
        if values is not None:
            result['values'] = values.tolist()
            result['first_clause_lhs'] = float(-cost @ values)
            result['first_clause_violation'] = float(-cost @ values - highs[0])
        out[label] = result
        save()
        print(label, {k: v for k, v in result.items() if k != 'values'}, flush=True)
    mip, values = solve(strengthened, slo, shi, variable_upper, args.mip_seconds, True)
    out['mip'] = mip
    out['status'] = 'complete_attempt'
    if values is not None:
        rounded = np.rint(values)
        assert np.all(np.abs(values-rounded) <= 1e-6)
        assert np.all(rounded >= 0) and np.all(rounded <= variable_upper)
        assert np.all(strengthened @ rounded >= slo) and np.all(strengthened @ rounded <= shi)
        words = sorted(data['fixed'] + [v for v, x in zip(data['pool'], rounded) if x])
        assert len(words) == len(set(words)) == 368
        assert len(set(data['parent_words'])-set(words)) <= cuts['radius']
        assert independence(words) == 67528
        out.update(status='verified_improvement', verified368=words, pair_checks=67528)
    save()
    print(dict(status=out['status'], mip=mip), flush=True)


if __name__ == '__main__':
    main()
