"""Bound a conditional cover face using a signed integer dual certificate.

Upper rows have coefficient +1; derived lower rows have coefficient -1.
Rounded dual weights are repaired with valid Boolean bounds x[v] <= 1.
The target cardinality lower row is omitted during optimization, so a bound
strictly below the target can certify that no target-size set exists.
"""
import argparse
import hashlib
import json
from pathlib import Path
import time

from search_rank_cover_face import derive, propagate
from check_cylinder_covers import check_entries
from check_two_slice_covers import HERE, WORDS, closed, conflict
from itertools import combinations


def signed_rows(face, propagation):
    states = propagation['states']
    unknown = [i for i, s in enumerate(states) if s == -1]
    selected = sum(s == 1 for s in states)
    rows = []
    for row in face['rows']:
        variables = [i for i in row['vertices'] if states[i] == -1]
        fixed = sum(states[i] == 1 for i in row['vertices'])
        upper = row['upper']-fixed
        if variables and upper < len(variables):
            rows.append(dict(vertices=variables, sign=1, rhs=upper))
        # The global target lower bound is the implication premise, not a cut.
        if len(row['vertices']) != len(states) and row['lower'] > fixed:
            rows.append(dict(vertices=variables, sign=-1, rhs=fixed-row['lower']))
    rows += [dict(vertices=[i], sign=1, rhs=1) for i in unknown]
    return unknown, selected, rows


def verify(certificate, unknown, selected, rows):
    den = certificate['denominator']
    assert type(den) is int and den > 0
    coverage = dict.fromkeys(unknown, 0)
    total = selected*den
    for entry in certificate['weights']:
        index, units = entry['row'], entry['units']
        assert type(index) is int and 0 <= index < len(rows)
        assert type(units) is int and units > 0
        r = rows[index]
        total += r['rhs']*units
        for v in r['vertices']:
            coverage[v] += r['sign']*units
    for r in certificate['repairs']:
        assert r['vertex'] in coverage and type(r['units']) is int and r['units'] > 0
        coverage[r['vertex']] += r['units']
        total += r['units']
    assert all(value >= den for value in coverage.values())
    assert certificate['total_units'] == total
    assert certificate['integer_upper_bound'] == total//den
    return total, den


def load_face(path):
    source = json.loads(path.read_text())
    model_path = Path(source['model_file'])
    assert hashlib.sha256(model_path.read_bytes()).hexdigest() == source['model_sha256']
    model_source = json.loads(model_path.read_text())
    cover_path = Path(model_source['input'])
    assert hashlib.sha256(cover_path.read_bytes()).hexdigest() == model_source['input_sha256']
    cover = json.loads(cover_path.read_text())
    model = model_source['model']
    assert model['pool'] == cover['pool'] and sorted(model['fixed']) == sorted(cover['fixed'])
    check_entries(cover['certificate'], model['pool'], cover['capacity_sequence'])
    seed = {int(w, 7) for w in (HERE/'family-d-seed-words.txt').read_text().split()}
    fixed = sorted(v for v in seed if (WORDS[v][cover['axis']]-cover['start']) % 7 >= cover['width'])
    assert fixed == sorted(model['fixed']) and all(not conflict(a, b) for a, b in combinations(fixed, 2))
    assert sorted(set(range(7**5))-set.union(*(set(closed(v)) for v in fixed))) == model['pool']
    valid_ranks = {}
    for c in cover['certificate']['cover']:
        key = tuple(sorted(c['vertices']))
        valid_ranks[key] = min(valid_ranks.get(key, c['capacity']), c['capacity'])
    assert len(model['members']) == len(model['capacities'])
    for row, capacity in zip(model['members'], model['capacities']):
        assert len(row) == len(set(row)) and all(type(v) is int and 0 <= v < len(model['pool']) for v in row)
        assert type(capacity) is int and capacity >= 1
        vertices = tuple(sorted(model['pool'][v] for v in row))
        if valid_ranks.get(vertices, capacity+1) > capacity:
            assert all(conflict(a, b) for a, b in combinations(vertices, 2))
    assert source['full_target'] == len(fixed)+source['residual_target']
    expected = derive(model, cover['certificate'], source['residual_target'])
    assert source['face'] == expected
    propagation = propagate(expected)
    assert source['propagation'] == propagation and propagation['status'] == 'fixed_point'
    return source, signed_rows(expected, propagation)


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--seconds', type=float, default=20)
    p.add_argument('--verify', action='store_true')
    args = p.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    if args.verify:
        report = json.loads(args.input.read_text())
        source_path = Path(report['input'])
        assert hashlib.sha256(source_path.read_bytes()).hexdigest() == report['input_sha256']
        source, (unknown, selected, rows) = load_face(source_path)
        total, den = verify(report['certificate'], unknown, selected, rows)
        result = dict(total_units=total, denominator=den, residual_upper=total//den,
                      target=source['residual_target'], excludes_target=total < source['residual_target']*den,
                      input_sha256=hashlib.sha256(args.input.read_bytes()).hexdigest())
        args.output.write_text(json.dumps(result, indent=2)+'\n')
        print(json.dumps(result), flush=True)
        return
    if args.seconds <= 0:
        p.error('Positive limit required')
    import numpy as np
    from scipy.optimize import linprog
    from scipy.sparse import csc_matrix
    source, (unknown, selected, rows) = load_face(args.input)
    local = {v: i for i, v in enumerate(unknown)}
    rr = [i for i, r in enumerate(rows) for _ in r['vertices']]
    cc = [local[v] for r in rows for v in r['vertices']]
    data = [r['sign'] for r in rows for _ in r['vertices']]
    matrix = csc_matrix((data, (rr, cc)), shape=(len(rows), len(unknown)))
    began = time.monotonic()
    solved = linprog(-np.ones(len(unknown)), A_ub=matrix, b_ub=[r['rhs'] for r in rows],
                     bounds=(0, None), method='highs-ipm', options={'time_limit':args.seconds})
    report = dict(input=str(args.input), input_sha256=hashlib.sha256(args.input.read_bytes()).hexdigest(),
                  source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  status=int(solved.status), message=solved.message, seconds=time.monotonic()-began,
                  target=source['residual_target'], variables=len(unknown), rows=len(rows),
                  scope='All derived constraints are conditional on reaching the stated cardinality. Infeasible numerical LPs alone are not certificates.')
    if solved.success:
        den = 1000000
        units = [int(x) for x in np.ceil(np.maximum(0, -solved.ineqlin.marginals)*den)]
        coverage = dict.fromkeys(unknown, 0)
        for row, weight in zip(rows, units):
            for v in row['vertices']:
                coverage[v] += row['sign']*weight
        repairs = [dict(vertex=v, units=den-c) for v, c in coverage.items() if c < den]
        total = selected*den+sum(r['rhs']*w for r, w in zip(rows, units))+sum(r['units'] for r in repairs)
        certificate = dict(denominator=den, total_units=total, integer_upper_bound=total//den,
                           weights=[dict(row=i, units=w) for i, w in enumerate(units) if w], repairs=repairs)
        verify(certificate, unknown, selected, rows)
        report.update(floating_bound=selected-float(solved.fun), certificate=certificate,
                      excludes_target=total < source['residual_target']*den)
    args.output.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='certificate'} |
                     {'total_units':report.get('certificate',{}).get('total_units')}), flush=True)


if __name__ == '__main__':
    main()
