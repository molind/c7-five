"""Replay saved two-slice escape queries using Z3 cardinality/clique constraints.

The encoding is checked against direct conflict pairs. SAT models are checked
as complete C7^5 sets; unknown is unresolved. No formal UNSAT proof is exported.
"""
import argparse
from collections import Counter
import hashlib
from itertools import combinations
import json
from pathlib import Path
import time

import z3

from search_two_slice_escape import load_input
from search_exchanges import graph_data, verify
from search_slices import HERE, build_pool


def make_solver(pool, adj, hint, cliques, target):
    local = {v: i for i, v in enumerate(pool)}
    constraints = {tuple(sorted(local[v] for v in c if v in local)) for c in cliques.tolist()}
    constraints = sorted(c for c in constraints if len(c) > 1)
    covered = {e for c in constraints for e in combinations(c, 2)}
    actual = {(u, v) for u, ns in enumerate(adj) for v in ns if u < v}
    assert covered == actual
    var = [z3.Bool(f'v_{v}') for v in pool]
    solver = z3.SolverFor('QF_FD')
    solver.set(random_seed=20260921)
    solver.add(z3.PbGe([(v, 1) for v in var], target))
    solver.add([z3.AtMost(*(var[v] for v in c), 1) for c in constraints])
    for v in range(len(pool)):
        solver.set_initial_value(var[v], v in hint)
    return solver, var, len(constraints)


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--seconds', type=float, default=1)
    parser.add_argument('--limit', type=int, default=35)
    args = parser.parse_args()
    if args.seconds <= 0 or args.limit < 1:
        parser.error('Positive limits required')
    if args.output.exists():
        raise FileExistsError(args.output)
    source = json.loads(args.input.read_text())
    words, vertices, ids, blockers, core, digest = load_input()
    assert source['core_component_sha256'] == digest
    cliques = graph_data(words)[3]
    loaded = {}
    report = dict(status='running', results=[], candidates=[],
                  input_sha256=hashlib.sha256(args.input.read_bytes()).hexdigest(),
                  source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  shared_hashes={n: hashlib.sha256((HERE/n).read_bytes()).hexdigest()
                                 for n in ('search_two_slice_escape.py', 'search_slices.py',
                                           'search_exchanges.py', 'family-d-seed-words.txt')},
                  z3_version=z3.get_version_string(), seconds_per_query=args.seconds,
                  scope='Exactly the saved finite pools; unknown is unresolved, no global bound.')
    began = time.monotonic()

    def save():
        report['elapsed_seconds'] = time.monotonic()-began
        report['statuses'] = dict(Counter(r['status'] for r in report['results']))
        tmp = args.output.with_name(args.output.name+'.tmp')
        tmp.write_text(json.dumps(report, indent=2)+'\n')
        tmp.replace(args.output)

    for job in source['results'][:args.limit]:
        key = job['pool_key']
        if key not in loaded:
            fixed, pool, adj, hint = build_pool(words, vertices, ids, blockers,
                                               job['axis'], job['start'], 2)
            saved = source['pools'][key]
            assert saved['pool'] == pool and saved['hint'] == sorted(hint) and saved['fixed'] == fixed
            solver, var, count = make_solver(pool, adj, hint, cliques, len(hint))
            loaded[key] = fixed, pool, hint, solver, var, count
        fixed, pool, hint, solver, var, count = loaded[key]
        assert job['forbidden'] in core and job['target'] == len(hint)
        banned = pool.index(job['forbidden'])
        solver.set(timeout=max(1, int(args.seconds*1000)))
        start = time.monotonic()
        status = solver.check(z3.Not(var[banned]))
        row = dict(index=job['index'], pool_key=key, forbidden=job['forbidden'],
                   status=str(status), clique_constraints=count,
                   solve_seconds=time.monotonic()-start,
                   prior_status=job['result']['status'])
        if status == z3.sat:
            model = solver.model()
            selected = [v for v, x in zip(pool, var) if z3.is_true(model.eval(x))]
            solution = fixed+[vertices[v].tolist() for v in selected]
            pairs = verify(solution)
            assert len(solution) >= 367 and job['forbidden'] not in selected
            omitted = sorted(core-set(selected)-{int(''.join(map(str, w)), 7) for w in fixed})
            assert job['forbidden'] in omitted
            report['candidates'].append(dict(step=job['index'], words=[''.join(map(str, w)) for w in solution],
                                             omitted_core=omitted, verified_pairs=pairs))
            row['size'] = len(solution)
            report['status'] = 'candidate_found'
        elif status == z3.unknown:
            row['reason'] = solver.reason_unknown()
        report['results'].append(row)
        save()
        print(json.dumps(row), flush=True)
        if status == z3.sat:
            break
    else:
        report['status'] = 'queries_complete'
    save()


if __name__ == '__main__':
    main()
