"""Continue residual triples with a bounded run and append-only checkpoints.

The initial 256 certificates remain frozen in the earlier probe artifact.
Each later result is stored as one JSON line. Unsuccessful queries are kept
as unresolved; they never count as exclusions and are not retried implicitly.
"""
import hashlib
import json
import time
from pathlib import Path
from collections import Counter
from fractions import Fraction
import one_core_cover_replay as old
from one_core_fractional_cover import find_cover
from check_one_core_covers import check

ROOT = Path(__file__).resolve().parent


def main():
    source = ROOT / 'three-core-screen-results.json'
    digest = hashlib.sha256(source.read_bytes()).hexdigest()
    screen = json.loads(source.read_text())
    probe = json.loads((ROOT / 'three-core-probe-results.json').read_text())
    assert screen['core_ids'] == old.core and probe['screen_sha256'] == digest
    residual = screen['residual']
    initial = probe['cases']
    assert [c['triple'] for c in initial] == residual[:len(initial)]
    checkpoint = ROOT / 'three-core-continuation.jsonl'
    cases = list(initial)
    if checkpoint.exists():
        for line in checkpoint.read_text().splitlines():
            item = json.loads(line)
            assert item['screen_sha256'] == digest
            cases.append(item['case'])
    assert [c['triple'] for c in cases] == residual[:len(cases)]
    assert len(cases) <= len(residual)
    start_count = len(cases)
    began = time.monotonic()
    all_core = (1 << len(old.core)) - 1
    with checkpoint.open('a') as output:
        for triple in residual[start_count:]:
            if time.monotonic() - began >= 320:
                break
            kept = all_core ^ sum(1 << i for i in triple)
            words = [old.W[v] for v, mask in enumerate(old.blocked) if not mask & kept]
            assert all(old.W[old.core[i]] in words for i in triple)
            cover = find_cover(words, 63)
            if cover['excluded']:
                assert check(cover['certificate'], set(words), 63) == Fraction(cover['total'])
            case = {'triple': triple, 'cover': cover}
            output.write(json.dumps({'screen_sha256': digest, 'case': case}, separators=(',', ':')) + '\n')
            output.flush()
            cases.append(case)
            if (len(cases) - start_count) % 500 == 0:
                print('Checked', len(cases), 'of', len(residual), 'residual triples;',
                      round(time.monotonic() - began, 2), 'seconds this run', flush=True)
    excluded = sum(c['cover']['excluded'] for c in cases)
    result = {
        'protocol': 'Residual triples in lexicographic order; append-only continuation after frozen probe; 320-second budget between calls, two-second solver timeout per query.',
        'screen_sha256': digest,
        'cases_before_run': start_count,
        'cases_after_run': len(cases),
        'excluded': excluded,
        'queried_without_certificate': len(cases) - excluded,
        'unqueried': len(residual) - len(cases),
        'counts': dict(Counter(c['cover']['solver_status'] for c in cases)),
        'seconds_this_run': time.monotonic() - began,
        'all_residuals_have_certificates': excluded == len(residual),
    }
    (ROOT / 'three-core-continuation-summary.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2), flush=True)


if __name__ == '__main__':
    main()
