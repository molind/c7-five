"""Lift odd-cycle cuts with a common conflicting hub.

If a hub conflicts with every vertex of an odd cycle of length 2k+1,
sum(cycle variables) + k*hub <= k is valid for every independent set.
"""
import argparse
import hashlib
import json
from pathlib import Path
import random
import time

import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix
from check_two_slice_covers import closed, conflict
from probe_odd_cycle_cuts import separate


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--model', type=Path, required=True)
    p.add_argument('--hubs', type=int, default=64)
    p.add_argument('--roots', type=int, default=32)
    p.add_argument('--max-cuts', type=int, default=512)
    p.add_argument('--seconds', type=float, default=10)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    assert __debug__ and min(args.hubs,args.roots,args.max_cuts,args.seconds) > 0 and not args.output.exists()
    report = json.loads(args.model.read_text());model = report['model']
    source_path = Path(report['input'])
    assert hashlib.sha256(source_path.read_bytes()).hexdigest() == report['input_sha256']
    source = json.loads(source_path.read_text())
    pool = model['pool'];local = {v:i for i,v in enumerate(pool)}
    assert pool == source['pool']
    values = np.zeros(len(pool))
    for v,x in source['primal']:
        values[local[v]] = x
    adjacency = [{local[w] for w in closed(v) if w != v and w in local} for v in pool]
    hubs = [i for i,x in enumerate(values) if 1e-6 < x < 1-1e-6]
    rng = random.Random(20260921);rng.shuffle(hubs)
    hubs.sort(key=lambda i:-values[i])
    hubs = hubs[:args.hubs]
    cuts, seen, visited = [], set(), []
    started = time.monotonic()
    for hub in hubs:
        neighbors = sorted(adjacency[hub]);indices = {v:i for i,v in enumerate(neighbors)}
        edges = [(i,indices[v]) for i,u in enumerate(neighbors) for v in adjacency[u] if v in indices and i < indices[v]]
        if not edges:
            continue
        normalized = values[neighbors]/(1-values[hub])
        roots = [i for i,x in enumerate(normalized) if 1e-6 < x < 1-1e-6]
        rng.shuffle(roots);roots = roots[:args.roots]
        if not roots:
            continue
        visited.append(dict(hub=pool[hub], roots=[pool[neighbors[i]] for i in roots]))
        for cut in separate(len(neighbors),edges,normalized,roots):
            cycle = [neighbors[i] for i in cut['cycle']];k = cut['capacity']
            key = hub,tuple(sorted(cycle))
            violation = float(sum(values[i] for i in cycle)+k*values[hub]-k)
            if key in seen or violation <= 1e-6:
                continue
            seen.add(key)
            words = [pool[i] for i in cycle]
            assert len(words) == len(set(words)) == 2*k+1 and pool[hub] not in words
            assert all(conflict(a,b) for a,b in zip(words,words[1:]+words[:1]))
            assert all(conflict(pool[hub],v) for v in words)
            cuts.append(dict(hub=pool[hub],cycle=words,capacity=k,hub_coefficient=k,violation=violation))
            if len(cuts) >= args.max_cuts:
                break
        if len(cuts) >= args.max_cuts:
            break
    rows = [i for i,c in enumerate(model['members']) for _ in c]
    cols = [v for c in model['members'] for v in c]
    coefficients = [1]*len(cols)
    capacities = list(model['capacities'])
    results = []
    for label in ('base','with_wheels'):
        if label == 'with_wheels':
            for c in cuts:
                row = len(capacities)
                for v in c['cycle']:
                    rows.append(row);cols.append(local[v]);coefficients.append(1)
                rows.append(row);cols.append(local[c['hub']]);coefficients.append(c['hub_coefficient'])
                capacities.append(c['capacity'])
        matrix = coo_matrix((coefficients,(rows,cols)),shape=(len(capacities),len(pool))).tocsr()
        hint = np.zeros(len(pool));hint[model['hint']] = 1
        assert np.all(matrix@hint <= capacities)
        if label == 'base':
            assert np.all(matrix@values <= np.asarray(capacities)+1e-6)
        lp = linprog(-np.ones(len(pool)),A_ub=matrix,b_ub=capacities,bounds=(0,1),
                     method='highs-ipm',options={'time_limit':args.seconds})
        results.append(dict(label=label,status=int(lp.status),message=lp.message,
                            floating_full_bound=len(model['fixed'])-float(lp.fun) if lp.success else None))
    output = dict(input=str(args.model),input_sha256=hashlib.sha256(args.model.read_bytes()).hexdigest(),
                  source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  visited=visited,cuts=cuts,results=results,seconds=time.monotonic()-started,
                  scope='Sampled lifted odd-cycle cuts. Every cycle and hub is geometrically checked; floating LP results are not integer certificates.')
    args.output.write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps(dict(hubs=len(visited),cuts=len(cuts),results=results,seconds=output['seconds'])),flush=True)


if __name__ == '__main__':
    main()
