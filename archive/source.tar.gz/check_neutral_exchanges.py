"""Compare complete neutral and improving tuple lists with brute force."""
from itertools import combinations
import json
from pathlib import Path
import random

from neutral_exchanges import enumerate_exchanges

rng = random.Random(2026091808)
cases = 0
positive_neutral = positive_improving = 0
for _ in range(300):
    n, d = rng.randrange(1, 13), rng.randrange(1, 5)
    cb = [sum(1 << p for p in rng.sample([0, 1, 63, 64, 127, 307, 366], rng.randrange(4)))
          for _ in range(n)]
    comp = [0]*n
    for i, j in combinations(range(n), 2):
        if rng.randrange(4):
            comp[i] |= 1 << j
            comp[j] |= 1 << i
    wanted = {'neutral': [], 'improving': []}
    for indices in combinations(range(n), d):
        mask = 0
        for i in indices:
            mask |= cb[i]
        if mask.bit_count() <= d and all(comp[i] >> j & 1 for i, j in combinations(indices, 2)):
            wanted['neutral' if mask.bit_count() == d else 'improving'].append(indices)
    actual = enumerate_exchanges(cb, comp, d)
    assert actual['status'] == 'exhausted'
    assert actual['neutral'] == wanted['neutral'] and actual['improving'] == wanted['improving']
    cases += 1
    positive_neutral += bool(wanted['neutral'])
    positive_improving += bool(wanted['improving'])
# Explicit positive fixtures and incomplete-result statuses.
positive = enumerate_exchanges([7, 7, 7], [6, 5, 3], 3)
assert positive['neutral'] == [(0, 1, 2)] and not positive['improving']
improvement = enumerate_exchanges([3, 3, 3], [6, 5, 3], 3)
assert improvement['improving'] == [(0, 1, 2)] and not improvement['neutral']
assert enumerate_exchanges([7, 7, 7], [6, 5, 3], 3, seconds=0)['status'] == 'timeout'
assert enumerate_exchanges([7, 7, 7], [6, 5, 3], 3, max_results=1)['status'] == 'output_limit'
report = dict(brute_cases=cases, positive_neutral_cases=positive_neutral,
              positive_improving_cases=positive_improving, explicit_controls=4,
              seed=2026091808, comparison='Full ordered tuple lists, not existence alone')
Path(__file__).with_name('neutral-exchanges-controls.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report))
