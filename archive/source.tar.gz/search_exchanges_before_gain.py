"""Search exact r-for-(r+1) exchanges in a supplied independent set of C7^5.

Input construction: Polak--Schrijver, Information Processing Letters 143 (2019).
Downloaded from EinsteinArena solution 2565 on 2026-09-15.
The graph and search encoding here are implemented independently.
"""

import argparse
import hashlib
import itertools
import json
import time
from pathlib import Path

import numpy as np
import z3


def verify(words):
    """Check the mathematical definition directly, without the search graph."""
    if not words or any(len(w) != 5 for w in words):
        raise ValueError("Expected nonempty list of five-coordinate words")
    if any(type(x) is not int or not 0 <= x < 7 for w in words for x in w):
        raise ValueError("Coordinates must be integers from 0 to 6")
    if len(set(map(tuple, words))) != len(words):
        raise ValueError("Duplicate word")
    for i, left in enumerate(words):
        for right in words[i + 1:]:
            if all((a - b) % 7 in (0, 1, 6) for a, b in zip(left, right)):
                raise ValueError(f"Confusable pair: {left}, {right}")
    return len(words) * (len(words) - 1) // 2


def graph_data(words):
    vertices = np.array(list(itertools.product(range(7), repeat=5)), dtype=np.int16)
    powers = np.array([7**i for i in range(4, -1, -1)], dtype=np.int32)
    ids = [int(np.array(w) @ powers) for w in words]
    blockers = [[] for _ in vertices]
    shifts = np.array(list(itertools.product((-1, 0, 1), repeat=5)))
    for j, word in enumerate(words):
        neighbors = (((np.array(word) + shifts) % 7) @ powers).tolist()
        for v in neighbors:
            blockers[v].append(j)
    # Maximal cliques: Cartesian products of five adjacent pairs on C7.
    corners = np.array(list(itertools.product((0, 1), repeat=5)))
    cliques = np.zeros((len(vertices), len(corners)), dtype=np.int32)
    for i in range(5):
        cliques += ((vertices[:, i, None] + corners[None, :, i]) % 7) * powers[i]
    return vertices, ids, blockers, cliques


def solve_radius(words, vertices, ids, blockers, cliques, radius, timeout_ms, seed):
    start = time.monotonic()
    original = set(ids)
    candidates = [v for v in range(len(vertices))
                  if v not in original and len(blockers[v]) <= radius]
    remove = [z3.Bool(f"remove_{i}") for i in range(len(words))]
    add = {v: z3.Bool(f"add_{v}") for v in candidates}
    solver = z3.SolverFor("QF_FD")
    solver.set(timeout=timeout_ms, random_seed=seed)
    solver.add(z3.PbLe([(x, 1) for x in remove], radius))
    solver.add(z3.PbGe([(x, 1) for x in add.values()], radius + 1))
    for v, var in add.items():
        for b in blockers[v]:
            solver.add(z3.Or(z3.Not(var), remove[b]))
    # Every conflicting candidate pair belongs to at least one such clique.
    unique_cliques = set()
    for clique in cliques:
        key = tuple(sorted(v for v in clique.tolist() if v in add))
        if len(key) > 1:
            unique_cliques.add(key)
    for clique in sorted(unique_cliques):
        solver.add(z3.AtMost(*(add[v] for v in clique), 1))
    build_seconds = time.monotonic() - start
    print(json.dumps({"radius": radius, "candidates": len(candidates),
                      "cliques": len(unique_cliques), "build_seconds": build_seconds}), flush=True)
    start = time.monotonic()
    status = solver.check()
    result = {"radius": radius, "seed": seed, "status": str(status),
              "candidate_count": len(candidates), "clique_count": len(unique_cliques),
              "build_seconds": build_seconds, "solve_seconds": time.monotonic() - start,
              "timeout_ms": timeout_ms}
    solution = None
    if status == z3.sat:
        model = solver.model()
        removed = [i for i, x in enumerate(remove) if z3.is_true(model.eval(x))]
        inserted = [v for v, x in add.items() if z3.is_true(model.eval(x))]
        solution = [w for i, w in enumerate(words) if i not in set(removed)]
        solution += [vertices[v].tolist() for v in inserted]
        verify(solution)
        assert len(solution) > len(words)
        result.update(removed=removed, inserted=inserted, size=len(solution))
    elif status == z3.unknown:
        result["reason"] = solver.reason_unknown()
    return result, solution


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, default=Path(__file__).with_name("baseline.json"))
    parser.add_argument("--radii", type=int, nargs="+", default=[1, 2, 3, 4])
    parser.add_argument("--timeout", type=int, default=60, help="seconds per radius")
    parser.add_argument("--seed", type=int, default=20260915)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("exchange-results.json"))
    args = parser.parse_args()
    words = json.loads(args.input.read_text())["words"]
    pairs = verify(words)
    vertices, ids, blockers, cliques = graph_data(words)
    report = {"input_sha256": hashlib.sha256(args.input.read_bytes()).hexdigest(),
              "input_size": len(words), "input_pair_checks": pairs,
              "z3_version": z3.get_version_string(), "results": []}
    for radius in args.radii:
        result, solution = solve_radius(words, vertices, ids, blockers, cliques,
                                        radius, args.timeout * 1000, args.seed)
        report["results"].append(result)
        args.output.write_text(json.dumps(report, indent=2) + "\n")
        print(json.dumps(result), flush=True)
        if solution is not None:
            args.output.with_suffix(".solution.json").write_text(
                json.dumps({"words": solution}, indent=2) + "\n")
            break


if __name__ == "__main__":
    main()
