"""Brute-force small-graph controls for known-result-aware inspection."""
from itertools import combinations
import hashlib
import json
from pathlib import Path
import random
import struct

from search_plateau import inspect_known_augmentations


def main():
    rng=random.Random(2026093100);stats={'graphs':0,'gain_two':0,'unseen_gain_one':0,'continued':0,'free_neutral_moves':0}
    for trial in range(800):
        n=rng.randrange(4,11);selected=list(range(rng.randrange(1,min(4,n-1))))
        edges=set()
        for u,v in combinations(range(n),2):
            if u in selected and v in selected:continue
            if rng.randrange(3)==0:edges.add((u,v))
        def independent(vs):return all(tuple(sorted((u,v))) not in edges for u,v in combinations(vs,2))
        def compatible(u,v):return u!=v and tuple(sorted((u,v))) not in edges
        outside=list(range(len(selected),n));free=[];grouped={}
        for v in outside:
            blockers=[u for u in selected if not compatible(u,v)]
            if not blockers:free.append(v)
            if len(blockers)==1:grouped.setdefault(blockers[0],[]).append(v)
        aug1=set();aug2=set();neutral=set()
        for removed in [()]+[(u,) for u in selected]:
            kept=set(selected)-set(removed)
            for gain,targets in [(1,aug1),(2,aug2)]:
                for added in combinations(outside,len(removed)+gain):
                    full=tuple(sorted(kept|set(added)))
                    if independent(full):targets.add(full)
        for u in selected:
            for v in outside:
                if independent((set(selected)-{u})|{v}):neutral.add((u,v))
        known_sets={vs for vs in aug1 if trial%3==0 or (trial%3==1 and rng.randrange(2))}
        known={struct.pack('<'+str(len(vs))+'H',*vs) for vs in known_sets}
        result,moves,ignored=inspect_known_augmentations(selected,free,grouped,compatible,known)
        assert all(k in known for k in ignored)
        if aug2:
            assert tuple(result) in aug2 and not moves;stats['gain_two']+=1
        elif aug1-known_sets:
            assert tuple(result) in aug1-known_sets and not moves;stats['unseen_gain_one']+=1
        else:
            assert result is None and {(r[0],a[0]) for r,a in moves}==neutral
            assert len(moves)==len(neutral);stats['continued']+=1
            stats['free_neutral_moves']+=len(free)*len(selected)
            assert set(ignored)==known
        stats['graphs']+=1
    assert min(stats['gain_two'],stats['unseen_gain_one'],stats['continued'],stats['free_neutral_moves'])>0
    out=dict(stats=stats,source_sha256=hashlib.sha256(Path(__file__).with_name('search_plateau.py').read_bytes()).hexdigest(),checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope=__doc__)
    path=Path(__file__).with_name('filtered-inspection-controls-sep21.json');assert not path.exists();path.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))


if __name__=='__main__':main()
