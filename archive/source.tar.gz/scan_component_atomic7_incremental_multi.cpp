// Scan atomic seven-removal trades at every state in a supplied finite cache.
// A neutral trade returns 7 insertions; an improvement returns 8.
// Candidates have 2..7 blockers; reducible proper insertion subsets up to size six are excluded.
// This file does not prove width-six closure or previous-parent coverage.
// Nonroot searches retain the newly inserted parent-edge word and require
// an insertion conflicting with the deleted parent-edge word; see report.
#include <algorithm>
#include <array>
#include <cassert>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <iterator>
#include <map>
#include <random>
#include <set>
#include <stdexcept>
#include <string>
#include <vector>

struct Candidate { int word; std::vector<int> blockers; };
using Choice = std::vector<int>;
using Clock = std::chrono::steady_clock;

static int pair_key(int a, int b) { return (a << 9) | b; }
static int triple_key(int a, int b, int c) { return (a << 18) | (b << 9) | c; }

template<class Compatible, class Emit>
static std::uint64_t enumerate(int old_count, const std::vector<Candidate>& pool,
                               Compatible compatible, Emit emit,
                               const std::vector<bool>* critical = nullptr,
                               const std::vector<std::vector<bool>>* extra_critical = nullptr) {
    assert(old_count > 0 && old_count < 512);
    struct CriticalIndex {
        std::vector<std::vector<int>> at;
        unsigned minimum_degree=8;
    };
    std::vector<const std::vector<bool>*> conditions;
    if(critical)conditions.push_back(critical);
    if(extra_critical)for(const auto& c:*extra_critical)conditions.push_back(&c);
    std::vector<CriticalIndex> indices;
    for(const auto* c:conditions) {
        assert(c->size()==pool.size());
        CriticalIndex index;index.at.resize(old_count);
        for(int i=0;i<static_cast<int>(pool.size());++i)if((*c)[i]) {
            for(int b:pool[i].blockers)index.at[b].push_back(i);
            index.minimum_degree=std::min(index.minimum_degree,static_cast<unsigned>(pool[i].blockers.size()));
        }
        if(index.minimum_degree==8)return 0; // An unmet critical condition.
        indices.push_back(std::move(index));
    }
    // Every prior one-word neighbor supplies a necessary condition. A surviving
    // union must contain a critical blocker list for EACH neighbor, not just
    // one arbitrarily chosen parent. Keep only prefixes satisfying all of them.
    auto keep_partial=[&](const auto& q) {
        unsigned remaining=7-static_cast<unsigned>(q.size());
        for(const auto& index:indices) {
            if(index.minimum_degree<=remaining)continue;
            bool found=false;
            for(int b:q) {
                for(int i:index.at[b]) {
                    unsigned missing=0;
                    for(int a:pool[i].blockers)if(std::find(q.begin(),q.end(),a)==q.end()) {
                        if(++missing>remaining)break;
                    }
                    if(missing<=remaining){found=true;break;}
                }
                if(found)break;
            }
            if(!found)return false;
        }
        return true;
    };
    auto keep=[&](const std::array<int,7>& q) { return keep_partial(q); };
    std::map<int, std::vector<int>> pairs, triples;
    std::map<int, std::set<int>> third_by_pair;
    std::map<std::array<int,4>, std::vector<int>> groups;
    std::map<std::array<int,5>, std::vector<int>> fives;
    std::map<std::array<int,6>, std::vector<int>> sixes;
    std::map<std::array<int,7>, std::vector<int>> sevens;
    std::map<std::array<int,5>, std::set<int>> sixth_by_five;
    std::map<int,std::set<std::array<int,5>>> fives_by_triple;
    std::vector<std::set<std::array<int,4>>> quads_at(old_count);
    std::map<std::array<int,4>, std::set<int>> fifth_by_quad;
    std::map<int, std::set<std::array<int,4>>> quads_by_pair;
    std::map<int,std::set<int>> fourth_by_triple;
    std::vector<std::set<int>> triples_at(old_count);
    std::vector<std::set<int>> adjacent(old_count);
    for(int i=0;i<static_cast<int>(pool.size());++i) {
        const auto& b=pool[i].blockers;
        assert(b.size()>=2 && b.size()<=7 && std::is_sorted(b.begin(),b.end()));
        assert(b.front()>=0 && b.back()<old_count && std::adjacent_find(b.begin(),b.end())==b.end());
        if(b.size()==2) {
            pairs[pair_key(b[0],b[1])].push_back(i);
            adjacent[b[0]].insert(b[1]);adjacent[b[1]].insert(b[0]);
        } else if(b.size()==3) {
            triples[triple_key(b[0],b[1],b[2])].push_back(i);
            for(int x:b)triples_at[x].insert(triple_key(b[0],b[1],b[2]));
            third_by_pair[pair_key(b[0],b[1])].insert(b[2]);
            third_by_pair[pair_key(b[0],b[2])].insert(b[1]);
            third_by_pair[pair_key(b[1],b[2])].insert(b[0]);
        } else if(b.size()==4) {
            std::array<int,4> q4={b[0],b[1],b[2],b[3]};
            for(int a:b)quads_at[a].insert(q4);
            if(keep_partial(q4))groups[q4].push_back(i);
            for(int j=0;j<4;++j)for(int k=j+1;k<4;++k)
                quads_by_pair[pair_key(b[j],b[k])].insert({b[0],b[1],b[2],b[3]});
            for(int j=0;j<4;++j)for(int k=j+1;k<4;++k)for(int l=k+1;l<4;++l)
                for(int x:b)if(x!=b[j] && x!=b[k] && x!=b[l])
                    fourth_by_triple[triple_key(b[j],b[k],b[l])].insert(x);
        } else if(b.size()==5) {
            std::array<int,5> q5={b[0],b[1],b[2],b[3],b[4]};
            if(keep_partial(q5))fives[q5].push_back(i);
            for(int j=0;j<5;++j)for(int k=j+1;k<5;++k)for(int l=k+1;l<5;++l)
                fives_by_triple[triple_key(b[j],b[k],b[l])].insert(q5);
            for(int skip=0;skip<5;++skip) {
                std::array<int,4> key;int at=0;
                for(int j=0;j<5;++j)if(j!=skip)key[at++]=b[j];
                fifth_by_quad[key].insert(b[skip]);
            }
        } else if(b.size()==6) {
            std::array<int,6> q={b[0],b[1],b[2],b[3],b[4],b[5]};
            if(keep_partial(q))sixes[q].push_back(i);
            for(int skip=0;skip<6;++skip) {
                std::array<int,5> key;int at=0;
                for(int j=0;j<6;++j)if(j!=skip)key[at++]=b[j];
                sixth_by_five[key].insert(b[skip]);
            }
        } else {
            std::array<int,7> q={b[0],b[1],b[2],b[3],b[4],b[5],b[6]};
            if(keep(q))sevens[q].push_back(i);
        }
    }
    // A selected triple-blocker set can only grow to four through an edge
    // leaving it, a triple overlapping in two places, or a four-blocker word.
    for(const auto& entry:triples) {
        int key=entry.first;
        std::array<int,3> t={key>>18,(key>>9)&511,key&511};
        auto extend=[&](int x) {
            if(std::find(t.begin(),t.end(),x)!=t.end())return;
            std::array<int,4> q={t[0],t[1],t[2],x};std::sort(q.begin(),q.end());
            if(keep_partial(q))groups.try_emplace(q);
        };
        for(int a:t)for(int x:adjacent[a])extend(x);
        for(int i=0;i<3;++i)for(int j=i+1;j<3;++j) {
            auto it=third_by_pair.find(pair_key(t[i],t[j]));
            if(it!=third_by_pair.end())for(int x:it->second)extend(x);
        }
    }
    // Every connected non-pair-only union of five either starts with a
    // five-blocker word, joins two triples in one place, or extends a generated
    // four-word union by one old word. Irreducibility implies connectivity.
    for(const auto& entry:groups) {
        const auto& q=entry.first;
        auto extend=[&](int x) {
            if(std::find(q.begin(),q.end(),x)!=q.end())return;
            std::array<int,5> u={q[0],q[1],q[2],q[3],x};std::sort(u.begin(),u.end());if(keep_partial(u))fives.try_emplace(u);
        };
        for(int a:q)for(int x:adjacent[a])extend(x);
        for(int i=0;i<4;++i)for(int j=i+1;j<4;++j) {
            auto t=third_by_pair.find(pair_key(q[i],q[j]));
            if(t!=third_by_pair.end())for(int x:t->second)extend(x);
            for(int k=j+1;k<4;++k) {
                auto f=fourth_by_triple.find(triple_key(q[i],q[j],q[k]));
                if(f!=fourth_by_triple.end())for(int x:f->second)extend(x);
            }
        }
    }
    for(const auto& keys:triples_at) {
        std::vector<int> ts(keys.begin(),keys.end());
        for(std::size_t i=0;i<ts.size();++i)for(std::size_t j=i+1;j<ts.size();++j) {
            std::vector<int> u={ts[i]>>18,(ts[i]>>9)&511,ts[i]&511,ts[j]>>18,(ts[j]>>9)&511,ts[j]&511};
            std::sort(u.begin(),u.end());u.erase(std::unique(u.begin(),u.end()),u.end());
            if(u.size()==5) {
                std::array<int,5> q5={u[0],u[1],u[2],u[3],u[4]};
                if(keep_partial(q5))fives.try_emplace(q5);
            }
        }
    }
    // A connected selected hypergraph with a non-pair edge starts at an
    // edge of maximum size. Before reaching six vertices its unions of size
    // four/five occur in groups/fives above. It then grows either 5->6 or
    // 4->6 (by a triple or quadruple). A six-blocker edge is already seeded.
    // Pair-only cycles are generated only at the final size seven.
    for(const auto& entry:fives) {
        const auto& q=entry.first;
        auto extend=[&](int x) {
            if(std::find(q.begin(),q.end(),x)!=q.end())return;
            std::array<int,6> u={q[0],q[1],q[2],q[3],q[4],x};
            std::sort(u.begin(),u.end());if(keep_partial(u))sixes.try_emplace(u);
        };
        for(int a:q)for(int x:adjacent[a])extend(x);
        for(int i=0;i<5;++i)for(int j=i+1;j<5;++j) {
            auto t=third_by_pair.find(pair_key(q[i],q[j]));
            if(t!=third_by_pair.end())for(int x:t->second)extend(x);
            for(int k=j+1;k<5;++k) {
                auto f=fourth_by_triple.find(triple_key(q[i],q[j],q[k]));
                if(f!=fourth_by_triple.end())for(int x:f->second)extend(x);
                for(int l=k+1;l<5;++l) {
                    auto h=fifth_by_quad.find({q[i],q[j],q[k],q[l]});
                    if(h!=fifth_by_quad.end())for(int x:h->second)extend(x);
                }
            }
        }
    }
    for(const auto& entry:groups) {
        const auto& q=entry.first;
        auto combine=[&](const std::vector<int>& b) {
            std::vector<int> u(q.begin(),q.end());u.insert(u.end(),b.begin(),b.end());
            std::sort(u.begin(),u.end());u.erase(std::unique(u.begin(),u.end()),u.end());
            if(u.size()==6) {
                std::array<int,6> q6={u[0],u[1],u[2],u[3],u[4],u[5]};
                if(keep_partial(q6))sixes.try_emplace(q6);
            }
        };
        for(int a:q)for(int t:triples_at[a])combine({t>>18,(t>>9)&511,t&511});
        for(int i=0;i<4;++i)for(int j=i+1;j<4;++j) {
            auto it=quads_by_pair.find(pair_key(q[i],q[j]));
            if(it!=quads_by_pair.end())for(const auto& b:it->second)combine({b.begin(),b.end()});
        }
    }
    // Start from a largest selected blocker edge. Connected growth to seven
    // is direct7,6->7,5->7 (degree3/4/5), or4->7 (degree4). Smaller connected
    // non-pair prefixes were generated above. Pair-only survivors are7-cycles.
    for(const auto& entry:sixes) {
        const auto& q=entry.first;
        auto extend=[&](int x) {
            if(std::find(q.begin(),q.end(),x)!=q.end())return;
            std::array<int,7> u={q[0],q[1],q[2],q[3],q[4],q[5],x};
            std::sort(u.begin(),u.end());if(keep(u))sevens.try_emplace(u);
        };
        for(int a:q)for(int x:adjacent[a])extend(x);
        for(int i=0;i<6;++i)for(int j=i+1;j<6;++j) {
            auto t=third_by_pair.find(pair_key(q[i],q[j]));
            if(t!=third_by_pair.end())for(int x:t->second)extend(x);
            for(int k=j+1;k<6;++k) {
                auto f=fourth_by_triple.find(triple_key(q[i],q[j],q[k]));
                if(f!=fourth_by_triple.end())for(int x:f->second)extend(x);
                for(int l=k+1;l<6;++l) {
                    auto h=fifth_by_quad.find({q[i],q[j],q[k],q[l]});
                    if(h!=fifth_by_quad.end())for(int x:h->second)extend(x);
                    for(int m=l+1;m<6;++m) {
                        auto z=sixth_by_five.find({q[i],q[j],q[k],q[l],q[m]});
                        if(z!=sixth_by_five.end())for(int x:z->second)extend(x);
                    }
                }
            }
        }
    }
    for(const auto& entry:fives) {
        const auto& q=entry.first;
        auto combine=[&](const auto& b) {
            std::vector<int> u(q.begin(),q.end());u.insert(u.end(),b.begin(),b.end());
            std::sort(u.begin(),u.end());u.erase(std::unique(u.begin(),u.end()),u.end());
            if(u.size()==7) {
                std::array<int,7> q7={u[0],u[1],u[2],u[3],u[4],u[5],u[6]};
                if(keep(q7))sevens.try_emplace(q7);
            }
        };
        for(int a:q)for(int t:triples_at[a])combine(std::array<int,3>{t>>18,(t>>9)&511,t&511});
        for(int i=0;i<5;++i)for(int j=i+1;j<5;++j) {
            auto t=quads_by_pair.find(pair_key(q[i],q[j]));
            if(t!=quads_by_pair.end())for(const auto& b:t->second)combine(b);
            for(int k=j+1;k<5;++k) {
                auto f=fives_by_triple.find(triple_key(q[i],q[j],q[k]));
                if(f!=fives_by_triple.end())for(const auto& b:f->second)combine(b);
            }
        }
    }
    for(const auto& entry:groups) {
        const auto& q=entry.first;
        for(int a:q)for(const auto& b:quads_at[a]) {
            std::vector<int> u(q.begin(),q.end());u.insert(u.end(),b.begin(),b.end());
            std::sort(u.begin(),u.end());u.erase(std::unique(u.begin(),u.end()),u.end());
            if(u.size()==7) {
                std::array<int,7> q7={u[0],u[1],u[2],u[3],u[4],u[5],u[6]};
                if(keep(q7))sevens.try_emplace(q7);
            }
        }
    }
    for(int a=0;a<old_count;++a)for(int b:adjacent[a])if(b>a)
    for(int c:adjacent[b])if(c>a && c!=b)
    for(int d:adjacent[c])if(d>a && d!=b && d!=c)
    for(int e:adjacent[d])if(e>a && e!=b && e!=c && e!=d)
    for(int f:adjacent[e])if(f>a && f!=b && f!=c && f!=d && f!=e)
    for(int g:adjacent[f])if(g>a && g>b && g!=c && g!=d && g!=e && g!=f && adjacent[g].count(a)) {
        std::array<int,7> q={a,b,c,d,e,f,g};std::sort(q.begin(),q.end());if(keep(q))sevens.try_emplace(q);
    }
    for(const auto& entry:sevens) {
        const auto& q=entry.first;
        Choice eligible=entry.second;
        for(unsigned mask=0;mask<128;++mask) {
            unsigned n=__builtin_popcount(mask);if(n<2 || n>6)continue;
            std::array<int,6> b;int at=0;for(int i=0;i<7;++i)if(mask>>i&1)b[at++]=q[i];
            if(n==2) {
                auto p=pairs.find(pair_key(b[0],b[1]));
                if(p!=pairs.end())eligible.insert(eligible.end(),p->second.begin(),p->second.end());
            } else if(n==3) {
                auto p=triples.find(triple_key(b[0],b[1],b[2]));
                if(p!=triples.end())eligible.insert(eligible.end(),p->second.begin(),p->second.end());
            } else if(n==4) {
                auto p=groups.find({b[0],b[1],b[2],b[3]});
                if(p!=groups.end())eligible.insert(eligible.end(),p->second.begin(),p->second.end());
            } else if(n==5) {
                auto p=fives.find({b[0],b[1],b[2],b[3],b[4]});
                if(p!=fives.end())eligible.insert(eligible.end(),p->second.begin(),p->second.end());
            } else {
                auto p=sixes.find({b[0],b[1],b[2],b[3],b[4],b[5]});
                if(p!=sixes.end())eligible.insert(eligible.end(),p->second.begin(),p->second.end());
            }
        }
        if(eligible.size()<7)continue;
        std::sort(eligible.begin(),eligible.end());
        assert(std::adjacent_find(eligible.begin(),eligible.end())==eligible.end());
        std::vector<unsigned> masks;
        for(int c:eligible) {
            unsigned mask=0;
            for(int b:pool[c].blockers) {
                auto it=std::find(q.begin(),q.end(),b);assert(it!=q.end());mask|=1u<<static_cast<unsigned>(it-q.begin());
            }
            masks.push_back(mask);
        }
        std::vector<std::size_t> selected;
        auto visit=[&](auto&& self,std::size_t start)->void {
            if(selected.size()>=7) {
                Choice chosen;bool has_critical=!critical;
                for(auto i:selected) {chosen.push_back(eligible[i]);if(critical && (*critical)[eligible[i]])has_critical=true;}
                if(has_critical && extra_critical)for(const auto& c:*extra_critical)
                    if(!std::any_of(chosen.begin(),chosen.end(),[&](int i){return c[i];})){has_critical=false;break;}
                if(has_critical)emit(chosen);
                if(selected.size()==8)return;
            }
            for(std::size_t i=start;i<eligible.size();++i) {
                if(selected.size()+eligible.size()-i<7)break;
                bool ok=true;
                for(auto j:selected)if(!compatible(eligible[i],eligible[j])){ok=false;break;}
                if(!ok)continue;
                for(unsigned subset=0;subset<(1u<<selected.size());++subset) {
                    unsigned n=__builtin_popcount(subset)+1;if(n>6)continue;
                    unsigned blocked=masks[i];
                    for(unsigned j=0;j<selected.size();++j)if(subset>>j&1)blocked|=masks[selected[j]];
                    if(static_cast<unsigned>(__builtin_popcount(blocked))<=n){ok=false;break;}
                }
                if(!ok)continue;
                selected.push_back(i);self(self,i+1);selected.pop_back();
            }
        };
        visit(visit,0);
    }
    return sevens.size();
}

static void self_test() {
    std::mt19937 rng(2026092209), filter_rng(2026092210);
    std::uint64_t tested=0,emitted=0,improvements=0,filtered_trades=0,filtered_improvements=0,multi_trades=0,multi_gains=0;
    for(int test=0;test<300;++test) {
        int old=7+test%4,n=8+test%7;std::vector<Candidate> pool;
        if(test==1) {
            old=7;n=7;pool={{0,{0,1}},{1,{1,2}},{2,{2,3}},{3,{3,4}},{4,{4,5}},{5,{5,6}},{6,{0,6}}};
        } else if(test==2) {
            old=7;n=7;pool={{0,{0,1,2,3,4,5}},{1,{0,6}},{2,{1,6}},{3,{2,6}},{4,{3,6}},{5,{4,6}},{6,{5,6}}};
        } else if(test==3) {
            old=7;n=7;pool={{0,{0,1,2,3,4}},{1,{0,5,6}},{2,{1,5}},{3,{2,5}},{4,{3,6}},{5,{4,6}},{6,{1,6}}};
        } else if(test==4) {
            old=7;n=7;pool={{0,{0,1,2,3}},{1,{0,4,5,6}},{2,{1,4}},{3,{2,4}},{4,{2,5}},{5,{3,5}},{6,{3,6}}};
        } else if(test==5) {
            old=7;n=7;pool={{0,{0,1,2}},{1,{0,3,4}},{2,{0,5,6}},{3,{1,3}},{4,{2,5}},{5,{4,6}},{6,{1,6}}};
        } else if(test==6) {
            old=7;n=7;pool={{0,{0,1,2,3,4}},{1,{0,1,2,5,6}},{2,{1,4}},{3,{2,4}},{4,{2,5}},{5,{3,5}},{6,{3,6}}};
        } else if(test==7) {
            old=7;n=7;pool={{0,{0,1,2,3}},{1,{0,4,5}},{2,{5,6}},{3,{1,4}},{4,{2,5}},{5,{3,6}},{6,{1,6}}};
        } else if(test==8) {
            old=7;n=7;pool={{0,{0,1,2}},{1,{0,1,3}},{2,{2,4,5}},{3,{5,6}},{4,{4,6}},{5,{3,6}},{6,{1,4}}};
        } else for(int i=0;i<n;++i) {
            int degree=test==0?7:2+rng()%6;std::set<int> b;
            while(static_cast<int>(b.size())<degree)b.insert(rng()%old);
            pool.push_back({i,{b.begin(),b.end()}});
        }
        std::vector<std::vector<bool>> comp(n,std::vector<bool>(n));
        for(int i=0;i<n;++i)for(int j=i+1;j<n;++j)
            comp[i][j]=comp[j][i]=(test<9 || rng()%4!=0);
        std::set<Choice> actual,expected;
        enumerate(old,pool,[&](int i,int j){return comp[i][j];},[&](const Choice& c){
            if(!actual.insert(c).second)throw std::runtime_error("Duplicate emitted trade");
        });
        for(unsigned mask=0;mask<(1u<<n);++mask) {
            int count=__builtin_popcount(mask);if(count!=7 && count!=8)continue;
            ++tested;Choice c;std::set<int> all;bool ok=true;
            for(int i=0;i<n;++i)if(mask>>i&1) {
                c.push_back(i);all.insert(pool[i].blockers.begin(),pool[i].blockers.end());
                for(int j=0;j<i;++j)if(mask>>j&1)ok &= comp[i][j];
            }
            for(unsigned sub=1;sub<(1u<<c.size()) && ok;++sub) {
                unsigned count=__builtin_popcount(sub);if(count>6)continue;
                std::set<int> b;
                for(unsigned j=0;j<c.size();++j)if(sub>>j&1)b.insert(pool[c[j]].blockers.begin(),pool[c[j]].blockers.end());
                ok &= b.size()>count;
            }
            if(ok && all.size()<=7)expected.insert(c);
        }
        if(actual!=expected)throw std::runtime_error("Disagreement with exhaustive subset control");
        std::vector<bool> critical(n);
        for(int i=0;i<n;++i)critical[i]=(test%10!=9 && filter_rng()%4==0);
        if(test<9)critical[0]=true;
        std::set<Choice> restricted, restricted_expected;
        enumerate(old,pool,[&](int i,int j){return comp[i][j];},[&](const Choice& c){
            if(!restricted.insert(c).second)throw std::runtime_error("Duplicate filtered trade");
        },&critical);
        for(const auto& c:expected)
            if(std::any_of(c.begin(),c.end(),[&](int i){return critical[i];}))restricted_expected.insert(c);
        if(restricted!=restricted_expected)throw std::runtime_error("Critical filter differs from exhaustive control");
        std::vector<std::vector<bool>> extras(1+test%3,std::vector<bool>(n));
        std::mt19937 multi_rng(2026092300+test);
        for(auto& flags:extras)for(int i=0;i<n;++i)flags[i]=(test%11!=10 && multi_rng()%3==0);
        if(test<9)for(auto& flags:extras)flags[0]=true;
        std::set<Choice> multi,multi_expected;
        enumerate(old,pool,[&](int i,int j){return comp[i][j];},[&](const Choice& c){
            if(!multi.insert(c).second)throw std::runtime_error("Duplicate multi-parent trade");
        },&critical,&extras);
        for(const auto& c:restricted_expected) {
            bool ok=true;
            for(const auto& flags:extras)if(!std::any_of(c.begin(),c.end(),[&](int i){return flags[i];}))ok=false;
            if(ok)multi_expected.insert(c);
        }
        if(multi!=multi_expected)throw std::runtime_error("Multi-parent filter differs from exhaustive control");
        if(test<9 && multi.empty())throw std::runtime_error("Multi-parent positive control failed");
        multi_trades+=multi.size();for(const auto& c:multi)multi_gains+=c.size()==8;
        filtered_trades+=restricted.size();
        for(const auto& c:restricted)filtered_improvements+=c.size()==8;
        if(test<9 && restricted.empty())throw std::runtime_error("Filtered positive control failed");
        if(test<9 && actual.empty())throw std::runtime_error("Explicit group-generator positive control failed");
        emitted+=actual.size();for(const auto& c:actual)improvements+=c.size()==8;
    }
    assert(improvements>0);
    std::cout<<"{\"status\":\"passed\",\"cases\":300,\"subsets\":"<<tested
             <<",\"trades\":"<<emitted<<",\"improvements\":"<<improvements<<",\"filtered_trades\":"<<filtered_trades
             <<",\"filtered_improvements\":"<<filtered_improvements
             <<",\"multi_trades\":"<<multi_trades<<",\"multi_gains\":"<<multi_gains<<"}\n";
}

static void print_words(const std::vector<int>& words) {
    std::cout << '[';
    for(std::size_t i=0;i<words.size();++i) { if(i)std::cout<<',';std::cout<<words[i]; }
    std::cout << ']';
}

int main(int argc,char** argv) {
    try {
        if(argc==2 && std::string(argv[1])=="--self-test") { self_test(); return 0; }
        if(argc!=3) throw std::runtime_error("Usage: scan_component_atomic7_incremental_multi SECONDS START_STATE < cache.txt");
        double seconds=std::stod(argv[1]); int start=std::stoi(argv[2]);
        int nstates, size; if(!(std::cin>>nstates>>size)) throw std::runtime_error("Missing header");
        if(size!=367 || nstates<=0 || start<0 || start>nstates || !(seconds>0)) throw std::runtime_error("Invalid input limits");
        std::vector<std::vector<int>> states(nstates,std::vector<int>(size));
        std::set<std::vector<int>> known;
        for(auto& state:states) {
            for(int& v:state) if(!(std::cin>>v) || v<0 || v>=16807) throw std::runtime_error("Bad word");
            if(!std::is_sorted(state.begin(),state.end()) || std::adjacent_find(state.begin(),state.end())!=state.end()
               || !known.insert(state).second) throw std::runtime_error("Unsorted/duplicate state");
        }
        std::map<std::vector<int>,int> state_positions;
        for(int i=0;i<nstates;++i)state_positions.emplace(states[i],i);
        std::string label;if(!(std::cin>>label) || label!="parents")throw std::runtime_error("Missing parents");
        std::vector<int> parents(nstates), inserted(nstates,-1), deleted(nstates,-1);
        for(int i=0;i<nstates;++i) {
            if(!(std::cin>>parents[i]) || parents[i]<-1 || parents[i]>=i)throw std::runtime_error("Invalid parent order");
            if(parents[i]>=0) {
                std::vector<int> add,drop;const auto& p=states[parents[i]];
                std::set_difference(states[i].begin(),states[i].end(),p.begin(),p.end(),std::back_inserter(add));
                std::set_difference(p.begin(),p.end(),states[i].begin(),states[i].end(),std::back_inserter(drop));
                if(add.size()!=1 || drop.size()!=1)throw std::runtime_error("Parent edge is not a one-word move");
                inserted[i]=add[0];deleted[i]=drop[0];
            }
        }
        std::string extra; if(std::cin>>extra) throw std::runtime_error("Unexpected trailer");
        std::array<std::array<int,5>,16807> coords;
        for(int v=0;v<16807;++v) {int x=v;for(int k=4;k>=0;--k){coords[v][k]=x%7;x/=7;}}
        auto compatible = [&](int u,int v) {
            for(int k=0;k<5;++k) {int d=(coords[u][k]-coords[v][k]+7)%7;if(d>=2 && d<=5)return true;}
            return false;
        };
        std::vector<std::array<int,243>> neighbors(16807);
        for(int v=0;v<16807;++v) for(int s=0;s<243;++s) {
            int bits=s, word=0;
            for(int k=0;k<5;++k) {int delta=bits%3-1;bits/=3;word=7*word+(coords[v][k]+delta+7)%7;}
            neighbors[v][s]=word;
        }
        auto began=Clock::now(); auto elapsed=[&]{return std::chrono::duration<double>(Clock::now()-began).count();};
        std::array<int,16807> count;
        std::array<std::array<int,7>,16807> blocked;
        std::array<bool,16807> chosen;
        std::uint64_t total_groups=0,total_neutral=0,total_internal=0,total_improving=0;
        std::uint64_t full_states=0,anchored_states=0,total_pool=0,total_critical=0,prior_edges=0,frozen_count=0;
        int state_index=start; std::string status="exhausted";
        for(;state_index<nstates;++state_index) {
            if(elapsed()>=seconds) {status="timeout";break;}
            const auto& ref=states[state_index];count.fill(0);chosen.fill(false);
            for(int i=0;i<size;++i) {
                chosen[ref[i]]=true;
                for(int v:neighbors[ref[i]]) {if(count[v]<7)blocked[v][count[v]]=i;++count[v];}
            }
            for(int v:ref) if(count[v]!=1) throw std::runtime_error("Reference is not independent");
            std::vector<Candidate> pool;std::vector<bool> critical;
            bool anchored=parents[state_index]>=0;
            if(anchored)++anchored_states;else ++full_states;
            std::vector<bool> frozen(size,false);
            std::vector<int> extra_deleted;
            for(int v=0;v<16807;++v)if(!chosen[v] && count[v]==1) {
                std::vector<int> neighbor=ref;
                int old_index=blocked[v][0];neighbor[old_index]=v;std::sort(neighbor.begin(),neighbor.end());
                auto it=state_positions.find(neighbor);
                if(it==state_positions.end())throw std::runtime_error("Cache lacks a width-one neighbor");
                if(it->second<state_index) {
                    ++prior_edges;frozen[old_index]=true;
                    if(v!=deleted[state_index])extra_deleted.push_back(v);
                }
            }
            if(anchored)assert(std::count(frozen.begin(),frozen.end(),true)>0);
            else assert(extra_deleted.empty());
            frozen_count+=std::count(frozen.begin(),frozen.end(),true);
            std::vector<std::vector<bool>> extra_critical(extra_deleted.size());
            for(int v=0;v<16807;++v) {
                if(count[v]==0) throw std::runtime_error("Reference admits immediate insertion");
                if(!chosen[v] && (count[v]>=2 && count[v]<=7)) {
                    bool hits_frozen=false;
                    for(int j=0;j<count[v];++j)if(frozen[blocked[v][j]]){hits_frozen=true;break;}
                    if(hits_frozen)continue;
                    if(anchored)assert(compatible(v,inserted[state_index]));
                    pool.push_back({v,{blocked[v].begin(),blocked[v].begin()+count[v]}});
                    critical.push_back(anchored && !compatible(v,deleted[state_index]));
                    for(std::size_t j=0;j<extra_deleted.size();++j)extra_critical[j].push_back(!compatible(v,extra_deleted[j]));
                    ++total_pool;if(critical.back())++total_critical;
                }
            }
            std::vector<int> escape, improvement;
            auto make_words=[&](const Choice& c) {
                std::set<int> removed;
                for(int i:c) removed.insert(pool[i].blockers.begin(),pool[i].blockers.end());
                assert(removed.size()==7);
                std::vector<int> words;
                for(int i=0;i<size;++i) if(!removed.count(i))words.push_back(ref[i]);
                for(int i:c)words.push_back(pool[i].word);
                std::sort(words.begin(),words.end());return words;
            };
            total_groups+=enumerate(size,pool,[&](int i,int j){return compatible(pool[i].word,pool[j].word);},[&](const Choice& c){
                std::set<int> removed;
                std::vector<int> inserted;
                for(int i:c) {removed.insert(pool[i].blockers.begin(),pool[i].blockers.end());inserted.push_back(pool[i].word);}
                std::vector<int> deleted;
                for(int i:removed)deleted.push_back(ref[i]);
                std::cout<<"{\"event\":\"trade\",\"state\":"<<state_index<<",\"removed\":";
                print_words(deleted);std::cout<<",\"added\":";print_words(inserted);std::cout<<"}\n";
                if(c.size()==8) {
                    ++total_improving;
                    if(improvement.empty()){improvement=make_words(c);}
                } else {
                    ++total_neutral;auto words=make_words(c);
                    if(known.count(words))++total_internal;
                    else if(escape.empty()){escape=std::move(words);}
                }
            },anchored?&critical:nullptr,&extra_critical);
            if(!improvement.empty() || !escape.empty()) {
                const auto& result=improvement.empty()?escape:improvement;
                for(std::size_t i=0;i<result.size();++i) for(std::size_t j=0;j<i;++j)
                    if(!compatible(result[i],result[j]))throw std::runtime_error("Returned construction conflicts");
                std::cout<<"{\"event\":\"candidate\",\"state\":"<<state_index<<",\"size\":"<<result.size()<<",\"words\":";
                print_words(result);std::cout<<"}\n";
                ++state_index;status=improvement.empty()?"escape":"witness";break;
            }
        }
        std::cout<<"{\"status\":\""<<status<<"\",\"start_state\":"<<start<<",\"next_state\":"<<state_index
                 <<",\"total_states\":"<<nstates<<",\"groups\":"<<total_groups<<",\"neutral\":"<<total_neutral
                 <<",\"internal_neutral\":"<<total_internal<<",\"improving\":"<<total_improving
                 <<",\"full_states\":"<<full_states<<",\"anchored_states\":"<<anchored_states
                 <<",\"prior_edges\":"<<prior_edges<<",\"frozen_words\":"<<frozen_count
                 <<",\"candidate_pool\":"<<total_pool<<",\"critical_candidates\":"<<total_critical
                 <<",\"seconds\":"<<elapsed()<<"}\n";
    } catch(const std::exception& e) {std::cerr<<e.what()<<'\n';return 1;}
}
