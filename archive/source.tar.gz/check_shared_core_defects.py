"""Replay all shared-core two-defect cases using direct geometry and BFS."""
import argparse
import hashlib
from itertools import product, combinations
import json
from pathlib import Path
import struct

import numpy as np


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True)
    p.add_argument('--translations',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();assert __debug__ and not args.output.exists()
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    d=json.loads(args.input.read_text());t=json.loads(args.translations.read_text())
    assert d['status']=='exhausted' and all(sha(f)==h for f,h in d['dependencies'].items())
    assert sha(t['parents_file'])==t['parents_sha256'] and sha(t['matching_file'])==t['matching_sha256']
    a,b=[sorted(x['words']) for x in json.loads(Path(t['parents_file']).read_text())['bases']]
    mate=struct.unpack('<367H',Path(t['matching_file']).read_bytes()[:734]);b=[b[j] for j in mate]
    coords=np.array(list(product(range(7),repeat=5)),dtype=np.int16)
    common={i for i in range(367) if a[i]==b[i]};noncommon=[i for i in range(367) if i not in common]
    assert len(common)==315 and len(noncommon)==52
    delta=(coords[a,None,:]-coords[b][None,:,:])%7
    graph=[np.flatnonzero(x).tolist() for x in np.all((delta==0)|(delta==1)|(delta==6),axis=2)]
    union=set(a)|set(b);exterior=[v for v in range(16807) if v not in union]
    base=[];private={i:[] for i in common};blockers={}
    for start in range(0,len(exterior),512):
        chunk=exterior[start:start+512]
        da=(coords[chunk,None,:]-coords[a][None,:,:])%7
        db=(coords[chunk,None,:]-coords[b][None,:,:])%7
        ca=np.all((da==0)|(da==1)|(da==6),axis=2);cb=np.all((db==0)|(db==1)|(db==6),axis=2)
        for v,x,y in zip(chunk,ca,cb):
            la,lb=set(np.flatnonzero(x).tolist()),set(np.flatnonzero(y).tolist())
            touched=common&la;assert touched==common&lb
            if len(touched)>1:continue
            if touched:private[next(iter(touched))].append(v)
            else:base.append(v)
            blockers[v]=(la,lb)
    assert len(base)==d['common_free_exterior'] and sum(map(len,private.values()))==d['private_common_exterior']
    rows=[];triangles=0
    for cut in noncommon:
        kept=set(noncommon)-{cut};closure={}
        for i in kept:
            reached={i};todo=[i]
            while todo:
                v=todo.pop()
                for w in graph[v]:
                    if w in kept and w not in reached:reached.add(w);todo.append(w)
            closure[i]=reached
        feasible={}
        for v,(la,lb) in blockers.items():
            forced=set().union(*(closure[i] for i in lb&kept))
            forbidden=la&kept
            if forced.isdisjoint(forbidden):feasible[v]=(forced,forbidden)
        row=dict(cut=cut,common_cuts=0,feasible_word_cases=0,compatible_pairs=0)
        for core in sorted(common):
            choices=[v for v in base+private[core] if v in feasible]
            row['common_cuts']+=1;row['feasible_word_cases']+=len(choices)
            edges=set()
            for i,j in combinations(range(len(choices)),2):
                v,w=choices[i],choices[j];rv,fv=feasible[v];rw,fw=feasible[w]
                independent=any(int(x-y)%7 in (2,3,4,5) for x,y in zip(coords[v],coords[w]))
                if independent and (rv|rw).isdisjoint(fv|fw):edges.add((i,j))
            row['compatible_pairs']+=len(edges)
            for i,j,k in combinations(range(len(choices)),3):
                if {(i,j),(i,k),(j,k)}<=edges:triangles+=1
        rows.append(row)
    assert rows==d['rows'] and triangles==0
    out=dict(passed=True,cut_pairs=sum(r['common_cuts'] for r in rows),
             feasible_word_cases=sum(r['feasible_word_cases'] for r in rows),
             compatible_pairs=sum(r['compatible_pairs'] for r in rows),triangles=triangles,
             dependencies={str(args.input):sha(args.input),str(args.translations):sha(args.translations)},
             checker_sha256=sha(__file__),scope='All16380 specified shared/noncommon pair deletions, all feasible exterior triples; no SCC code reused.')
    args.output.write_text(json.dumps(out,indent=2)+'\n');print(out)


if __name__=='__main__':main()
