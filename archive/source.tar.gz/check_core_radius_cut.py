"""Independent replay of F9-bound radius/cardinality models and witnesses.

Rebuilds complete domains, old-word blockers, all clique rows and the three
extra inequalities. Solver optimality is still a computational report, without
an independently replayable search proof log.
"""
import argparse
import gzip
import hashlib
from itertools import combinations, product
import json
from pathlib import Path
import struct

import numpy as np

from check_common314_covers import decode, encode


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--runs',type=Path,nargs='+',required=True)
    p.add_argument('--domains',type=Path,required=True)
    p.add_argument('--base',type=Path,required=True)
    p.add_argument('--known-caches',type=Path,nargs='+',required=True)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();assert __debug__ and not args.output.exists()
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    base=json.loads(args.base.read_text());assert sha(base['input'])==base['input_sha256']
    parents=json.loads(Path(base['input']).read_text())['bases']
    core=set(parents[0]['words'])&set(parents[1]['words']);assert len(core)==315 and core==set(base['fixed'])
    domains=json.loads(args.domains.read_text());assert all(sha(f)==h for f,h in domains['dependencies'].items())
    deps={str(args.base):sha(args.base),base['input']:sha(base['input']),str(args.domains):sha(args.domains)}
    coords=np.array(list(product(range(7),repeat=5)),dtype=np.int16);known={}
    for path in args.known_caches:
        with gzip.open(path,'rt') as f:
            header=json.loads(next(f));states=[tuple(json.loads(line)) for line in f]
        assert len(states)==len(set(states))==header['states']
        for i,s in enumerate(states):known.setdefault(s,[]).append(dict(file=str(path),index=i))
        deps[str(path)]=sha(path)
    rows=[];checked_pairs=0;visited_proofs=set()
    def check_links(path):
        path=Path(path)
        if path in visited_proofs:return
        visited_proofs.add(path)
        if path.suffix!='.json':return
        value=json.loads(path.read_text());links=value.get('dependencies',{}) if isinstance(value,dict) else {}
        links=list(links.items()) if isinstance(links,dict) else [(x['path'],x['sha256']) for x in links]
        for file,h in links:
            assert sha(file)==h;check_links(file)
    def direct(words):
        nonlocal checked_pairs
        assert words==sorted(set(words)) and all(type(v) is int and 0<=v<16807 for v in words)
        for a,b in combinations(words,2):
            assert any((x-y)%7 in (2,3,4,5) for x,y in zip(decode(a),decode(b)))
            checked_pairs+=1
    for path in args.runs:
        d=json.loads(path.read_text());assert d['status'] in ('complete_bounded_queries','verified_improvement')
        assert all(sha(f)==h for f,h in d['dependencies'].items());deps[str(path)]=sha(path)
        assert d['dependencies'][str(args.domains)]==sha(args.domains)
        assert d['source_sha256']==sha(Path(__file__).with_name('search_core_radius_cut.py'))
        old=d['parent_words'];direct(old);assert old==sorted(parents[1]['words']) and len(old)==367
        binding=d['radius_binding'];proof_path=Path(binding['proof']);check_links(proof_path)
        assert binding['proof_sha256']==sha(proof_path)
        proof=json.loads(proof_path.read_text());assert proof['complete_atomic9'] and proof['nine_removal_augmentations_excluded']
        assert proof['width9_component_equals_width8'] and not proof['outside'] and proof['improving']==0
        assert proof['next_state']==proof['states']==36 and binding['minimum_improving_deletions']==10
        assert any(sha(p)==proof['checker_sha256'] for p in Path(__file__).parent.glob('check_component_atomic9_incremental*.py'))
        manifest=json.loads(Path(binding['manifest']).read_text())
        assert proof['dependencies'][binding['manifest']]==binding['manifest_sha256']==sha(binding['manifest'])
        assert manifest['source']==binding['cache'] and proof['dependencies'][binding['cache']]==binding['cache_sha256']==sha(binding['cache'])
        with gzip.open(binding['cache'],'rt') as f:
            header=json.loads(next(f));states=[tuple(json.loads(line)) for line in f]
        assert len(states)==len(set(states))==36
        assert all(s==tuple(sorted(set(s))) and len(s)==367 for s in states)
        digest=hashlib.sha256(b''.join(sorted(struct.pack('<367H',*s) for s in states))).hexdigest()
        assert digest==binding['component_sha256']==manifest['component_sha256']==header['component_sha256']
        assert states[binding['parent_component_index']]==tuple(old)
        region=domains['rows'][d['case']];fixed=core-set(region['omitted'])
        assert fixed==set(d['fixed']) and len(fixed)==len(d['fixed'])
        eligible=np.ones(16807,dtype=bool)
        for v in fixed:
            delta=(coords-coords[v])%7;eligible &= ~np.all((delta==0)|(delta==1)|(delta==6),axis=1)
        pool=np.flatnonzero(eligible).tolist();assert pool==d['pool']==region['pool']
        m=len(set(old)-fixed);assert d['target']==m+1 and m+len(fixed)==367
        assert fixed<=set(old)<=fixed|set(pool)
        counts=np.zeros(len(pool),dtype=np.int16)
        for v in old:
            delta=(coords[pool]-coords[v])%7;counts+=np.all((delta==0)|(delta==1)|(delta==6),axis=1)
        for i,v in enumerate(pool):counts[i]-=v in old
        origins=set();pool_set=set(pool)
        for v in pool:origins.update(encode(w) for w in product(*[((x-1)%7,x) for x in decode(v)]))
        memberships={tuple(sorted(set(encode(w) for w in product(*[(x,(x+1)%7) for x in decode(o)]))&pool_set)) for o in origins}
        assert all(memberships)
        radii=[row['radius'] for row in d['rows']]
        assert radii==d['requested_radii'][:len(radii)]
        if d['status']=='complete_bounded_queries':assert radii==d['requested_radii']
        for row in d['rows']:
            radius=row['radius'];assert type(radius) is int and 10<=radius<=m
            assert row['extra_lower']==[0,m-radius,0] and row['extra_upper']==[m+1,m,11*m]
            assert row['excluded_words']==[v for v,c in zip(pool,counts) if c>radius]
            solver=row['solver'];assert solver['variables']==len(pool) and solver['constraints']==len(memberships)+3
            assert solver['initial_objective']==-m and solver['objective_target']==-(m+1)
            record=dict(file=str(path),radius=radius,solver_status=solver['solver_status'],size=None,
                primary_optimum_reported=None,exact_cache_matches=[])
            if 'words' in row:
                words=row['words'];direct(words);assert len(words)==row['size'] in (367,368)
                assert row['pair_checks']==len(words)*(len(words)-1)//2
                assert fixed<=set(words)<=fixed|set(pool) and not set(words)&set(row['excluded_words'])
                X=len(words)-len(fixed);O=len(set(words)&set(old)-fixed)
                assert X<=m+1 and m-radius<=O<=m and O+10*X<=11*m
                assert row['removed']==sorted(set(old)-set(words)) and len(row['removed'])<=radius
                assert row['added']==sorted(set(words)-set(old))
                assert abs(solver['objective']+X)<1e-4
                if solver['solver_status']=='Optimal':
                    assert abs(solver['dual_bound']+X)<1e-4;record['primary_optimum_reported']=len(words)
                record.update(size=len(words),removed=len(row['removed']),exact_cache_matches=known.get(tuple(words),[]),
                    classification_pending=len(words)==367 and tuple(words) not in known)
            rows.append(record)
        if d['status']=='verified_improvement':
            assert len(d['verified368'])==368 and d['verified368']==d['rows'][-1]['words'];direct(d['verified368'])
    out=dict(passed=True,rows=rows,direct_pair_checks=checked_pairs,checker_sha256=sha(__file__),dependencies=deps,
        scope='Complete recorded domains and all bounds/pruning rebuilt. F9-bound row is valid for the exact F parent. Native optimality is not a proof log; timeouts remain unknown.')
    args.output.write_text(json.dumps(out,indent=2)+'\n');print(out)


if __name__=='__main__':main()
