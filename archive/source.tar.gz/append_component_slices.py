"""Append all five coordinate decompositions of a verified367 component.

Keeps existing slice indices stable for prior certificates. Produces an input
library for shape classification; it does not claim compatibility or optimality.
"""
import argparse
import gzip
import hashlib
import json
from pathlib import Path


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--library', type=Path, required=True)
    p.add_argument('--component', type=Path, required=True)
    p.add_argument('--verification', type=Path, required=True)
    p.add_argument('--label', required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    if not __debug__:
        raise RuntimeError('Run without -O')
    if args.output.exists():
        raise FileExistsError(args.output)
    verified = json.loads(args.verification.read_text())
    assert verified['component_file_sha256'] == sha(args.component)
    assert verified['connected'] and verified['closed_under_all_one_for_one_exchanges']
    prior = json.loads(args.library.read_text())
    slices = [tuple(sorted(map(tuple, sl))) for sl in prior['slices']]
    lookup = {sl: i for i, sl in enumerate(slices)}
    assert len(lookup) == len(slices)
    original_count = len(slices)
    parents = list(prior['parents'])
    with gzip.open(args.component, 'rt') as f:
        metadata = json.loads(next(f))
        states = [json.loads(line) for line in f]
    assert len(states) == verified['states'] and metadata['component_sha256'] == verified['component_sha256']
    for index, state in enumerate(states):
        words = [tuple(v//7**i % 7 for i in range(4, -1, -1)) for v in state]
        for axis in range(5):
            layers = []
            for value in range(7):
                sl = tuple(sorted(w[:axis]+w[axis+1:] for w in words if w[axis] == value))
                assert sl
                if sl not in lookup:
                    lookup[sl] = len(slices)
                    slices.append(sl)
                layers.append(lookup[sl])
            assert sum(len(slices[i]) for i in layers) == 367
            parents.append(dict(parent=args.label, state=index, axis=axis, slices=layers))
    result = dict(status='prepared', slices=slices, weights=list(map(len, slices)), parents=parents,
                  original_count=original_count, added_slices=len(slices)-original_count,
                  source_library=str(args.library), source_library_sha256=sha(args.library),
                  component=str(args.component), component_sha256=sha(args.component),
                  verification=str(args.verification), verification_sha256=sha(args.verification),
                  generator_sha256=sha(__file__),
                  scope='All coordinate slices of every verified component state appended to the supplied library. Compatibility and search bounds must be recomputed.')
    args.output.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(dict(original_slices=original_count, added_slices=result['added_slices'],
                         total_slices=len(slices), added_parents=5*len(states))), flush=True)


if __name__ == '__main__':
    main()
