"""Direct coordinate audit of selected replacement cavities and their witnesses.

Rebuilds the full allowed universe independently of cached neighborhoods. Tries
explicit clique partitions to certify local target exclusions. An unsupported
native exhausted label is reported as such, never promoted to a global bound.
"""
import argparse
from collections import Counter
import hashlib
from itertools import combinations, product
import json
from pathlib import Path
import random

import numpy as np


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();assert __debug__ and not a.output.exists()
    report=json.loads(a.input.read_text());source=Path(report['input'])
    assert hashlib.sha256(source.read_bytes()).hexdigest()==report['input_sha256']
    assert report['status'] in ('bounded_cavity_search_complete','verified_target')
    coords=np.array(list(product(range(7),repeat=5)),dtype=np.int16)
    def forbidden(left,right):
        delta=(coords[left]-coords[right])%7
        return np.all((delta==0)|(delta==1)|(delta==6),axis=-1)
    def independent(vs):
        assert len(vs)==len(set(vs)) and all(type(v) is int and 0<=v<16807 for v in vs)
        for i,v in enumerate(vs):assert not forbidden(v,vs[i+1:]).any()
    originals=json.loads(source.read_text());derived={}
    for run in originals['runs']:
        vs=run['best_words'];assert len(vs)==len(set(vs))==368
        edges=[(i,j) for i in range(368) for j in range(i+1,368) if forbidden(vs[i],vs[j])]
        assert len(edges)==run['best_conflicts']
        if len(edges)!=2 or set(edges[0])&set(edges[1]):continue
        for i,j in product(*edges):
            base=tuple(v for t,v in enumerate(vs) if t not in (i,j))
            derived.setdefault(base,sorted([vs[i],vs[j]]))
    assert [r['words'] for r in report['bases']]==[list(vs) for vs in sorted(derived)][:len(report['bases'])]
    expected=[];seen=set()
    for bi,b in enumerate(report['bases']):
        base=b['words'];independent(base);assert len(base)==366
        assert b['centers']==derived[tuple(base)]
        dist=np.minimum((coords[base,None,:]-coords[b['centers']])%7,(coords[b['centers']]-coords[base,None,:])%7)
        scores=(dist*dist).sum(axis=2)
        for mode,s in [('nearest',scores.min(axis=1)),('bridge',scores.sum(axis=1))]:
            order=sorted(range(366),key=lambda i:(int(s[i]),base[i]))
            for k in report['cavity_sizes']:
                omitted=sorted(base[i] for i in order[:k]);retained=tuple(v for v in base if v not in set(omitted))
                if retained in seen:continue
                seen.add(retained);expected.append((bi,mode,omitted,list(retained)))
    if report['status']=='bounded_cavity_search_complete':
        assert len(report['bases'])==len(derived) and len(report['queries'])==len(expected)
    results=[];rng=random.Random(2026092900);pair_checks=0
    for qi,r in enumerate(report['queries']):
        bi,mode,omitted,retained=expected[qi]
        assert (r['base'],r['mode'],r['omitted'])==(bi,mode,omitted)
        assert r['target']==368-len(retained)
        allowed=np.ones(16807,dtype=bool)
        for v in retained:allowed &= ~forbidden(np.arange(16807),v)
        pool=np.flatnonzero(allowed).tolist();assert pool==r['pool']
        delta=(coords[pool,None,:]-coords[pool])%7
        edges=np.all((delta==0)|(delta==1)|(delta==6),axis=2);np.fill_diagonal(edges,False)
        assert int(edges.sum())//2==r['edges']
        result=r['result'];indices=result['vertices']
        assert len(indices)==len(set(indices))==result['best_size'] and all(type(i) is int and 0<=i<len(pool) for i in indices)
        full=sorted(retained+[pool[i] for i in indices]);assert full==r['full_words'];independent(full)
        assert len(full)>=366;pair_checks+=len(full)*(len(full)-1)//2
        assert result['status'] in ('target_found','exhausted','timeout')
        assert (result['status']=='target_found')==(len(full)>=368)
        # Each class is a clique in the conflict graph, so any independent set
        # uses at most one member per class. Full partition is an exact bound.
        partition=None
        for trial in range(24):
            order=list(range(len(pool)))
            if trial:rng.shuffle(order)
            classes=[]
            for v in order:
                for c in classes:
                    if edges[v,c].all():c.append(v);break
                else:classes.append([v])
            if len(classes)<r['target']:
                partition=[[pool[i] for i in c] for c in classes];break
        if partition:
            assert sorted(v for c in partition for v in c)==pool
            for c in partition:
                for i,v in enumerate(c):assert forbidden(v,c[i+1:]).all()
        results.append(dict(query=qi,pool=len(pool),full_size=len(full),native_status=result['status'],
                            independently_certified_no368=partition is not None,clique_partition=partition))
    candidates={tuple(r['full_words']) for r in report['queries'] if len(r['full_words'])>=367}
    assert {tuple(c['vertices']) for c in report['candidates']}==candidates
    for c in report['candidates']:
        assert c['size']==len(c['vertices']) and c['vertices']==report['queries'][c['query']]['full_words']
    assert (report['status']=='verified_target')==any(len(vs)>=368 for vs in candidates)
    out=dict(input=str(a.input),input_sha256=hashlib.sha256(a.input.read_bytes()).hexdigest(),
             checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),queries=len(results),
             witness_pair_checks=pair_checks,explicit_partition_bounds=sum(r['independently_certified_no368'] for r in results),
             statuses=dict(Counter(r['native_status'] for r in results)),rows=results,scope=__doc__)
    a.output.write_text(json.dumps(out,separators=(',',':'))+'\n')
    print(json.dumps({k:v for k,v in out.items() if k!='rows'}),flush=True)


if __name__=='__main__':main()
