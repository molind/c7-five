"""Compare the conditional noncore restriction with exhaustive compatible subsets."""
import itertools
import json
from pathlib import Path
import random
import subprocess
import sys

from check_exchange_dfs import graph_text, controls

HERE = Path(__file__).parent
binary = Path(sys.argv[1]).resolve()
rng = random.Random(2026091804)
cases = []
for _ in range(160):
    n, d = rng.randrange(1, 12), rng.randrange(0, 6)
    prefix = rng.choice([0, 1, 63, 64, 65, 127, 128, 191, 192, 308, 512])
    limit = rng.randrange(d+1)
    positions = [0, 1, 63, 64, 127, 128, 191, 192, 307, 308, 366, 511]
    cb = [sum(1 << p for p in rng.sample(positions, rng.randrange(4))) for _ in range(n)]
    comp = [0]*n
    for i, j in itertools.combinations(range(n), 2):
        if rng.randrange(4):
            comp[i] |= 1 << j
            comp[j] |= 1 << i
    cases.append((cb, comp, d, prefix, limit))
# Shared blockers count once, and the last permitted noncore bit must remain legal.
for prefix in [0, 63, 64, 127, 128, 191, 192, 308, 511]:
    for limit in [0, 1]:
        cases.append(([1 << prefix]*3, [6, 5, 3], 2, prefix, limit))
records = []
for cb, comp, d, prefix, limit in cases:
    expected = []
    for sub in itertools.combinations(range(len(cb)), d+1):
        union = 0
        for i in sub:
            union |= cb[i]
        if (union.bit_count() <= d and (union >> prefix).bit_count() <= limit
                and all(comp[i] & (1 << j) for i, j in itertools.combinations(sub, 2))):
            expected = list(sub)
            break
    for mode in [[], ['--subset']]:
        run = subprocess.run([str(binary), '5', *mode, '--noncore-limit', str(prefix), str(limit)],
                             input=graph_text(cb, comp, d, 8), text=True,
                             capture_output=True, timeout=7, check=True)
        actual = json.loads(run.stdout)
        assert actual['status'] == ('witness' if expected else 'exhausted'), (cb, d, prefix, limit, actual)
        assert actual['chosen'] == expected
    records.append(bool(expected))
report = dict(binary=str(binary), cases=len(cases), modes=2, runs=2*len(cases),
              witness_cases=sum(records), exhausted_cases=len(records)-sum(records),
              seed=2026091804, comparison='Exact lexicographic witness and existence versus exhaustive subsets')
(HERE / (binary.name+'-noncore-controls.json')).write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report))
controls(binary)
controls(binary, ['--subset'])
