// Scan atomic six-removal trades at every state in a supplied finite cache.
// A neutral trade returns 6 insertions; an improvement returns 7.
// Candidates have 2..6 blockers; reducible proper insertion subsets up to size five are excluded.
// This file does not prove width-five closure or previous-parent coverage.
// Nonroot searches retain the newly inserted parent-edge word and require
// an insertion conflicting with the deleted parent-edge word; see report.
#include <algorithm>
#include <array>
#include <cassert>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <iterator>
#include <map>
#include <random>
#include <set>
#include <stdexcept>
#include <string>
#include <vector>

struct Candidate { int word; std::vector<int> blockers; };
using Choice = std::vector<int>;
using Clock = std::chrono::steady_clock;

static int pair_key(int a, int b) { return (a << 9) | b; }
static int triple_key(int a, int b, int c) { return (a << 18) | (b << 9) | c; }

template<class Compatible, class Emit>
static std::uint64_t enumerate(int old_count, const std::vector<Candidate>& pool,
                               Compatible compatible, Emit emit,
                               const std::vector<bool>* critical = nullptr) {
    assert(old_count > 0 && old_count < 512);
    std::vector<std::vector<int>> critical_by_min(old_count), critical_at(old_count);
    unsigned minimum_critical_degree=7;
    if(critical) {
        assert(critical->size()==pool.size());
        for(int i=0;i<static_cast<int>(pool.size());++i)if((*critical)[i]) {
            critical_by_min[pool[i].blockers.front()].push_back(i);
            for(int b:pool[i].blockers)critical_at[b].push_back(i);
            minimum_critical_degree=std::min(minimum_critical_degree,static_cast<unsigned>(pool[i].blockers.size()));
        }
    }
    // A prefix Q contained in a final six-set containing a critical blocker
    // list B must satisfy |B - Q| <= 6 - |Q|. Keep every such prefix.
    auto keep_partial=[&](const auto& q) {
        if(!critical)return true;
        unsigned remaining=6-static_cast<unsigned>(q.size());
        if(minimum_critical_degree<=remaining)return true;
        for(int b:q)for(int i:critical_at[b]) {
            unsigned missing=0;
            for(int a:pool[i].blockers)if(std::find(q.begin(),q.end(),a)==q.end()) {
                if(++missing>remaining)break;
            }
            if(missing<=remaining)return true;
        }
        return false;
    };
    auto keep=[&](const std::array<int,6>& q) {
        if(!critical)return true;
        for(int b:q)for(int i:critical_by_min[b])
            if(std::includes(q.begin(),q.end(),pool[i].blockers.begin(),pool[i].blockers.end()))return true;
        return false;
    };
    std::map<int, std::vector<int>> pairs, triples;
    std::map<int, std::set<int>> third_by_pair;
    std::map<std::array<int,4>, std::vector<int>> groups;
    std::map<std::array<int,5>, std::vector<int>> fives;
    std::map<std::array<int,6>, std::vector<int>> sixes;
    std::map<std::array<int,4>, std::set<int>> fifth_by_quad;
    std::map<int, std::set<std::array<int,4>>> quads_by_pair;
    std::map<int,std::set<int>> fourth_by_triple;
    std::vector<std::set<int>> triples_at(old_count);
    std::vector<std::set<int>> adjacent(old_count);
    for(int i=0;i<static_cast<int>(pool.size());++i) {
        const auto& b=pool[i].blockers;
        assert(b.size()>=2 && b.size()<=6 && std::is_sorted(b.begin(),b.end()));
        assert(b.front()>=0 && b.back()<old_count && std::adjacent_find(b.begin(),b.end())==b.end());
        if(b.size()==2) {
            pairs[pair_key(b[0],b[1])].push_back(i);
            adjacent[b[0]].insert(b[1]);adjacent[b[1]].insert(b[0]);
        } else if(b.size()==3) {
            triples[triple_key(b[0],b[1],b[2])].push_back(i);
            for(int x:b)triples_at[x].insert(triple_key(b[0],b[1],b[2]));
            third_by_pair[pair_key(b[0],b[1])].insert(b[2]);
            third_by_pair[pair_key(b[0],b[2])].insert(b[1]);
            third_by_pair[pair_key(b[1],b[2])].insert(b[0]);
        } else if(b.size()==4) {
            std::array<int,4> q4={b[0],b[1],b[2],b[3]};
            if(keep_partial(q4))groups[q4].push_back(i);
            for(int j=0;j<4;++j)for(int k=j+1;k<4;++k)
                quads_by_pair[pair_key(b[j],b[k])].insert({b[0],b[1],b[2],b[3]});
            for(int j=0;j<4;++j)for(int k=j+1;k<4;++k)for(int l=k+1;l<4;++l)
                for(int x:b)if(x!=b[j] && x!=b[k] && x!=b[l])
                    fourth_by_triple[triple_key(b[j],b[k],b[l])].insert(x);
        } else if(b.size()==5) {
            std::array<int,5> q5={b[0],b[1],b[2],b[3],b[4]};
            if(keep_partial(q5))fives[q5].push_back(i);
            for(int skip=0;skip<5;++skip) {
                std::array<int,4> key;int at=0;
                for(int j=0;j<5;++j)if(j!=skip)key[at++]=b[j];
                fifth_by_quad[key].insert(b[skip]);
            }
        } else {
            std::array<int,6> q={b[0],b[1],b[2],b[3],b[4],b[5]};
            if(keep(q))sixes[q].push_back(i);
        }
    }
    // A selected triple-blocker set can only grow to four through an edge
    // leaving it, a triple overlapping in two places, or a four-blocker word.
    for(const auto& entry:triples) {
        int key=entry.first;
        std::array<int,3> t={key>>18,(key>>9)&511,key&511};
        auto extend=[&](int x) {
            if(std::find(t.begin(),t.end(),x)!=t.end())return;
            std::array<int,4> q={t[0],t[1],t[2],x};std::sort(q.begin(),q.end());
            if(keep_partial(q))groups.try_emplace(q);
        };
        for(int a:t)for(int x:adjacent[a])extend(x);
        for(int i=0;i<3;++i)for(int j=i+1;j<3;++j) {
            auto it=third_by_pair.find(pair_key(t[i],t[j]));
            if(it!=third_by_pair.end())for(int x:it->second)extend(x);
        }
    }
    // Without degree-three/four words, four distinct blocker edges cannot
    // contain a triangle (a reducible triple), so they form a four-cycle.
    for(int a=0;a<old_count;++a) {
        std::vector<int> ns(adjacent[a].begin(),adjacent[a].end());
        for(std::size_t i=0;i<ns.size();++i)for(std::size_t j=i+1;j<ns.size();++j)
            for(int c:adjacent[ns[i]])if(c>a && c!=ns[j] && adjacent[ns[j]].count(c)) {
                std::array<int,4> q={a,ns[i],c,ns[j]};std::sort(q.begin(),q.end());
                if(keep_partial(q))groups.try_emplace(q);
            }
    }
    // Every connected non-pair-only union of five either starts with a
    // five-blocker word, joins two triples in one place, or extends a generated
    // four-word union by one old word. Irreducibility implies connectivity.
    for(const auto& entry:groups) {
        const auto& q=entry.first;
        auto extend=[&](int x) {
            if(std::find(q.begin(),q.end(),x)!=q.end())return;
            std::array<int,5> u={q[0],q[1],q[2],q[3],x};std::sort(u.begin(),u.end());if(keep_partial(u))fives.try_emplace(u);
        };
        for(int a:q)for(int x:adjacent[a])extend(x);
        for(int i=0;i<4;++i)for(int j=i+1;j<4;++j) {
            auto t=third_by_pair.find(pair_key(q[i],q[j]));
            if(t!=third_by_pair.end())for(int x:t->second)extend(x);
            for(int k=j+1;k<4;++k) {
                auto f=fourth_by_triple.find(triple_key(q[i],q[j],q[k]));
                if(f!=fourth_by_triple.end())for(int x:f->second)extend(x);
            }
        }
    }
    for(const auto& keys:triples_at) {
        std::vector<int> ts(keys.begin(),keys.end());
        for(std::size_t i=0;i<ts.size();++i)for(std::size_t j=i+1;j<ts.size();++j) {
            std::vector<int> u={ts[i]>>18,(ts[i]>>9)&511,ts[i]&511,ts[j]>>18,(ts[j]>>9)&511,ts[j]&511};
            std::sort(u.begin(),u.end());u.erase(std::unique(u.begin(),u.end()),u.end());
            if(u.size()==5) {
                std::array<int,5> q5={u[0],u[1],u[2],u[3],u[4]};
                if(keep_partial(q5))fives.try_emplace(q5);
            }
        }
    }
    // In the pair-only case, a surviving five-edge graph has no cycle of
    // length three/four and therefore must be a simple five-cycle.
    for(int a=0;a<old_count;++a)for(int b:adjacent[a])if(b>a)
    for(int c:adjacent[b])if(c>a && c!=b)
    for(int d:adjacent[c])if(d>a && d!=b && d!=c)
    for(int e:adjacent[d])if(e>a && e>b && e!=c && e!=d && adjacent[e].count(a)) {
        std::array<int,5> q={a,b,c,d,e};std::sort(q.begin(),q.end());if(keep_partial(q))fives.try_emplace(q);
    }
    // A connected selected hypergraph with a non-pair edge starts at an
    // edge of maximum size. Before reaching six vertices its unions of size
    // four/five occur in groups/fives above. It then grows either 5->6 or
    // 4->6 (by a triple or quadruple). A six-blocker edge is already seeded.
    // All-pair irreducible six-edge graphs must be six-cycles.
    for(const auto& entry:fives) {
        const auto& q=entry.first;
        auto extend=[&](int x) {
            if(std::find(q.begin(),q.end(),x)!=q.end())return;
            std::array<int,6> u={q[0],q[1],q[2],q[3],q[4],x};
            std::sort(u.begin(),u.end());if(keep(u))sixes.try_emplace(u);
        };
        for(int a:q)for(int x:adjacent[a])extend(x);
        for(int i=0;i<5;++i)for(int j=i+1;j<5;++j) {
            auto t=third_by_pair.find(pair_key(q[i],q[j]));
            if(t!=third_by_pair.end())for(int x:t->second)extend(x);
            for(int k=j+1;k<5;++k) {
                auto f=fourth_by_triple.find(triple_key(q[i],q[j],q[k]));
                if(f!=fourth_by_triple.end())for(int x:f->second)extend(x);
                for(int l=k+1;l<5;++l) {
                    auto h=fifth_by_quad.find({q[i],q[j],q[k],q[l]});
                    if(h!=fifth_by_quad.end())for(int x:h->second)extend(x);
                }
            }
        }
    }
    for(const auto& entry:groups) {
        const auto& q=entry.first;
        auto combine=[&](const std::vector<int>& b) {
            std::vector<int> u(q.begin(),q.end());u.insert(u.end(),b.begin(),b.end());
            std::sort(u.begin(),u.end());u.erase(std::unique(u.begin(),u.end()),u.end());
            if(u.size()==6) {
                std::array<int,6> q6={u[0],u[1],u[2],u[3],u[4],u[5]};
                if(keep(q6))sixes.try_emplace(q6);
            }
        };
        for(int a:q)for(int t:triples_at[a])combine({t>>18,(t>>9)&511,t&511});
        for(int i=0;i<4;++i)for(int j=i+1;j<4;++j) {
            auto it=quads_by_pair.find(pair_key(q[i],q[j]));
            if(it!=quads_by_pair.end())for(const auto& b:it->second)combine({b.begin(),b.end()});
        }
    }
    for(int a=0;a<old_count;++a)for(int b:adjacent[a])if(b>a)
    for(int c:adjacent[b])if(c>a && c!=b)
    for(int d:adjacent[c])if(d>a && d!=b && d!=c)
    for(int e:adjacent[d])if(e>a && e!=b && e!=c && e!=d)
    for(int f:adjacent[e])if(f>a && f>b && f!=c && f!=d && f!=e && adjacent[f].count(a)) {
        std::array<int,6> q={a,b,c,d,e,f};std::sort(q.begin(),q.end());if(keep(q))sixes.try_emplace(q);
    }
    for(const auto& [q,degree_six]:sixes) {
        Choice eligible=degree_six;
        for(int i=0;i<6;++i)for(int j=i+1;j<6;++j) {
            auto p=pairs.find(pair_key(q[i],q[j]));
            if(p!=pairs.end())eligible.insert(eligible.end(),p->second.begin(),p->second.end());
            for(int k=j+1;k<6;++k) {
                auto t=triples.find(triple_key(q[i],q[j],q[k]));
                if(t!=triples.end())eligible.insert(eligible.end(),t->second.begin(),t->second.end());
                for(int l=k+1;l<6;++l) {
                    auto f=groups.find({q[i],q[j],q[k],q[l]});
                    if(f!=groups.end())eligible.insert(eligible.end(),f->second.begin(),f->second.end());
                    for(int m=l+1;m<6;++m) {
                        auto h=fives.find({q[i],q[j],q[k],q[l],q[m]});
                        if(h!=fives.end())eligible.insert(eligible.end(),h->second.begin(),h->second.end());
                    }
                }
            }
        }
        if(eligible.size()<6)continue;
        std::sort(eligible.begin(),eligible.end());
        assert(std::adjacent_find(eligible.begin(),eligible.end())==eligible.end());
        std::vector<unsigned> masks;
        for(int c:eligible) {
            unsigned mask=0;
            for(int b:pool[c].blockers) {
                auto it=std::find(q.begin(),q.end(),b);assert(it!=q.end());mask|=1u<<static_cast<unsigned>(it-q.begin());
            }
            masks.push_back(mask);
        }
        std::vector<std::size_t> selected;
        auto visit=[&](auto&& self,std::size_t start)->void {
            if(selected.size()>=6) {
                Choice chosen;bool has_critical=!critical;
                for(auto i:selected) {chosen.push_back(eligible[i]);if(critical && (*critical)[eligible[i]])has_critical=true;}
                if(has_critical)emit(chosen);
                if(selected.size()==7)return;
            }
            for(std::size_t i=start;i<eligible.size();++i) {
                if(selected.size()+eligible.size()-i<6)break;
                bool ok=true;
                for(auto j:selected)if(!compatible(eligible[i],eligible[j])){ok=false;break;}
                if(!ok)continue;
                for(unsigned subset=0;subset<(1u<<selected.size());++subset) {
                    unsigned n=__builtin_popcount(subset)+1;if(n>5)continue;
                    unsigned blocked=masks[i];
                    for(unsigned j=0;j<selected.size();++j)if(subset>>j&1)blocked|=masks[selected[j]];
                    if(static_cast<unsigned>(__builtin_popcount(blocked))<=n){ok=false;break;}
                }
                if(!ok)continue;
                selected.push_back(i);self(self,i+1);selected.pop_back();
            }
        };
        visit(visit,0);
    }
    return sixes.size();
}

static void self_test() {
    std::mt19937 rng(2026092206), filter_rng(2026092207);
    std::uint64_t tested=0,emitted=0,improvements=0,filtered_trades=0,filtered_improvements=0;
    for(int test=0;test<300;++test) {
        int old=6+test%4,n=7+test%7;std::vector<Candidate> pool;
        if(test==1) {
            old=6;n=6;pool={{0,{0,1}},{1,{1,2}},{2,{2,3}},{3,{3,4}},{4,{4,5}},{5,{0,5}}};
        } else if(test==2) {
            old=6;n=6;pool={{0,{0,1,2,3,4}},{1,{0,5}},{2,{1,5}},{3,{2,5}},{4,{3,5}},{5,{4,5}}};
        } else if(test==3) {
            old=6;n=6;pool={{0,{0,1,2,3}},{1,{0,4,5}},{2,{1,4}},{3,{2,5}},{4,{3,4}},{5,{3,5}}};
        } else if(test==4) {
            old=6;n=6;pool={{0,{0,1,2}},{1,{0,3,4}},{2,{1,2,5}},{3,{2,3}},{4,{4,5}},{5,{1,4}}};
        } else if(test==5) {
            old=6;n=6;pool={{0,{0,1,2,3}},{1,{0,1,4,5}},{2,{2,4}},{3,{2,5}},{4,{3,4}},{5,{0,5}}};
        } else for(int i=0;i<n;++i) {
            int degree=test==0?6:2+rng()%5;std::set<int> b;
            while(static_cast<int>(b.size())<degree)b.insert(rng()%old);
            pool.push_back({i,{b.begin(),b.end()}});
        }
        std::vector<std::vector<bool>> comp(n,std::vector<bool>(n));
        for(int i=0;i<n;++i)for(int j=i+1;j<n;++j)
            comp[i][j]=comp[j][i]=(test<6 || rng()%4!=0);
        std::set<Choice> actual,expected;
        enumerate(old,pool,[&](int i,int j){return comp[i][j];},[&](const Choice& c){
            if(!actual.insert(c).second)throw std::runtime_error("Duplicate emitted trade");
        });
        for(unsigned mask=0;mask<(1u<<n);++mask) {
            int count=__builtin_popcount(mask);if(count!=6 && count!=7)continue;
            ++tested;Choice c;std::set<int> all;bool ok=true;
            for(int i=0;i<n;++i)if(mask>>i&1) {
                c.push_back(i);all.insert(pool[i].blockers.begin(),pool[i].blockers.end());
                for(int j=0;j<i;++j)if(mask>>j&1)ok &= comp[i][j];
            }
            for(unsigned sub=1;sub<(1u<<c.size()) && ok;++sub) {
                unsigned count=__builtin_popcount(sub);if(count>5)continue;
                std::set<int> b;
                for(unsigned j=0;j<c.size();++j)if(sub>>j&1)b.insert(pool[c[j]].blockers.begin(),pool[c[j]].blockers.end());
                ok &= b.size()>count;
            }
            if(ok && all.size()<=6)expected.insert(c);
        }
        if(actual!=expected)throw std::runtime_error("Disagreement with exhaustive subset control");
        std::vector<bool> critical(n);
        for(int i=0;i<n;++i)critical[i]=(test%10!=9 && filter_rng()%4==0);
        if(test<6)critical[0]=true;
        std::set<Choice> restricted, restricted_expected;
        enumerate(old,pool,[&](int i,int j){return comp[i][j];},[&](const Choice& c){
            if(!restricted.insert(c).second)throw std::runtime_error("Duplicate filtered trade");
        },&critical);
        for(const auto& c:expected)
            if(std::any_of(c.begin(),c.end(),[&](int i){return critical[i];}))restricted_expected.insert(c);
        if(restricted!=restricted_expected)throw std::runtime_error("Critical filter differs from exhaustive control");
        filtered_trades+=restricted.size();
        for(const auto& c:restricted)filtered_improvements+=c.size()==7;
        if(test<6 && restricted.empty())throw std::runtime_error("Filtered positive control failed");
        if(test<6 && actual.empty())throw std::runtime_error("Explicit group-generator positive control failed");
        emitted+=actual.size();for(const auto& c:actual)improvements+=c.size()==7;
    }
    assert(improvements>0);
    std::cout<<"{\"status\":\"passed\",\"cases\":300,\"subsets\":"<<tested
             <<",\"trades\":"<<emitted<<",\"improvements\":"<<improvements<<",\"filtered_trades\":"<<filtered_trades
             <<",\"filtered_improvements\":"<<filtered_improvements<<"}\n";
}

static void print_words(const std::vector<int>& words) {
    std::cout << '[';
    for(std::size_t i=0;i<words.size();++i) { if(i)std::cout<<',';std::cout<<words[i]; }
    std::cout << ']';
}

int main(int argc,char** argv) {
    try {
        if(argc==2 && std::string(argv[1])=="--self-test") { self_test(); return 0; }
        if(argc!=3) throw std::runtime_error("Usage: scan_component_atomic6_incremental_filtered SECONDS START_STATE < cache.txt");
        double seconds=std::stod(argv[1]); int start=std::stoi(argv[2]);
        int nstates, size; if(!(std::cin>>nstates>>size)) throw std::runtime_error("Missing header");
        if(size!=367 || nstates<=0 || start<0 || start>nstates || !(seconds>0)) throw std::runtime_error("Invalid input limits");
        std::vector<std::vector<int>> states(nstates,std::vector<int>(size));
        std::set<std::vector<int>> known;
        for(auto& state:states) {
            for(int& v:state) if(!(std::cin>>v) || v<0 || v>=16807) throw std::runtime_error("Bad word");
            if(!std::is_sorted(state.begin(),state.end()) || std::adjacent_find(state.begin(),state.end())!=state.end()
               || !known.insert(state).second) throw std::runtime_error("Unsorted/duplicate state");
        }
        std::string label;if(!(std::cin>>label) || label!="parents")throw std::runtime_error("Missing parents");
        std::vector<int> parents(nstates), inserted(nstates,-1), deleted(nstates,-1);
        for(int i=0;i<nstates;++i) {
            if(!(std::cin>>parents[i]) || parents[i]<-1 || parents[i]>=i)throw std::runtime_error("Invalid parent order");
            if(parents[i]>=0) {
                std::vector<int> add,drop;const auto& p=states[parents[i]];
                std::set_difference(states[i].begin(),states[i].end(),p.begin(),p.end(),std::back_inserter(add));
                std::set_difference(p.begin(),p.end(),states[i].begin(),states[i].end(),std::back_inserter(drop));
                if(add.size()!=1 || drop.size()!=1)throw std::runtime_error("Parent edge is not a one-word move");
                inserted[i]=add[0];deleted[i]=drop[0];
            }
        }
        std::string extra; if(std::cin>>extra) throw std::runtime_error("Unexpected trailer");
        std::array<std::array<int,5>,16807> coords;
        for(int v=0;v<16807;++v) {int x=v;for(int k=4;k>=0;--k){coords[v][k]=x%7;x/=7;}}
        auto compatible = [&](int u,int v) {
            for(int k=0;k<5;++k) {int d=(coords[u][k]-coords[v][k]+7)%7;if(d>=2 && d<=5)return true;}
            return false;
        };
        std::vector<std::array<int,243>> neighbors(16807);
        for(int v=0;v<16807;++v) for(int s=0;s<243;++s) {
            int bits=s, word=0;
            for(int k=0;k<5;++k) {int delta=bits%3-1;bits/=3;word=7*word+(coords[v][k]+delta+7)%7;}
            neighbors[v][s]=word;
        }
        auto began=Clock::now(); auto elapsed=[&]{return std::chrono::duration<double>(Clock::now()-began).count();};
        std::array<int,16807> count;
        std::array<std::array<int,6>,16807> blocked;
        std::array<bool,16807> chosen;
        std::uint64_t total_groups=0,total_neutral=0,total_internal=0,total_improving=0;
        std::uint64_t full_states=0,anchored_states=0,total_pool=0,total_critical=0;
        int state_index=start; std::string status="exhausted";
        for(;state_index<nstates;++state_index) {
            if(elapsed()>=seconds) {status="timeout";break;}
            const auto& ref=states[state_index];count.fill(0);chosen.fill(false);
            for(int i=0;i<size;++i) {
                chosen[ref[i]]=true;
                for(int v:neighbors[ref[i]]) {if(count[v]<6)blocked[v][count[v]]=i;++count[v];}
            }
            for(int v:ref) if(count[v]!=1) throw std::runtime_error("Reference is not independent");
            std::vector<Candidate> pool;std::vector<bool> critical;
            bool anchored=parents[state_index]>=0;
            if(anchored)++anchored_states;else ++full_states;
            for(int v=0;v<16807;++v) {
                if(count[v]==0) throw std::runtime_error("Reference admits immediate insertion");
                if(!chosen[v] && (count[v]>=2 && count[v]<=6)) {
                    if(anchored && !compatible(v,inserted[state_index]))continue;
                    pool.push_back({v,{blocked[v].begin(),blocked[v].begin()+count[v]}});
                    critical.push_back(anchored && !compatible(v,deleted[state_index]));
                    ++total_pool;if(critical.back())++total_critical;
                }
            }
            std::vector<int> escape, improvement;
            auto make_words=[&](const Choice& c) {
                std::set<int> removed;
                for(int i:c) removed.insert(pool[i].blockers.begin(),pool[i].blockers.end());
                assert(removed.size()==6);
                std::vector<int> words;
                for(int i=0;i<size;++i) if(!removed.count(i))words.push_back(ref[i]);
                for(int i:c)words.push_back(pool[i].word);
                std::sort(words.begin(),words.end());return words;
            };
            total_groups+=enumerate(size,pool,[&](int i,int j){return compatible(pool[i].word,pool[j].word);},[&](const Choice& c){
                std::set<int> removed;
                std::vector<int> inserted;
                for(int i:c) {removed.insert(pool[i].blockers.begin(),pool[i].blockers.end());inserted.push_back(pool[i].word);}
                std::vector<int> deleted;
                for(int i:removed)deleted.push_back(ref[i]);
                std::cout<<"{\"event\":\"trade\",\"state\":"<<state_index<<",\"removed\":";
                print_words(deleted);std::cout<<",\"added\":";print_words(inserted);std::cout<<"}\n";
                if(c.size()==7) {
                    ++total_improving;
                    if(improvement.empty()){improvement=make_words(c);}
                } else {
                    ++total_neutral;auto words=make_words(c);
                    if(known.count(words))++total_internal;
                    else if(escape.empty()){escape=std::move(words);}
                }
            },anchored?&critical:nullptr);
            if(!improvement.empty() || !escape.empty()) {
                const auto& result=improvement.empty()?escape:improvement;
                for(std::size_t i=0;i<result.size();++i) for(std::size_t j=0;j<i;++j)
                    if(!compatible(result[i],result[j]))throw std::runtime_error("Returned construction conflicts");
                std::cout<<"{\"event\":\"candidate\",\"state\":"<<state_index<<",\"size\":"<<result.size()<<",\"words\":";
                print_words(result);std::cout<<"}\n";
                ++state_index;status=improvement.empty()?"escape":"witness";break;
            }
        }
        std::cout<<"{\"status\":\""<<status<<"\",\"start_state\":"<<start<<",\"next_state\":"<<state_index
                 <<",\"total_states\":"<<nstates<<",\"groups\":"<<total_groups<<",\"neutral\":"<<total_neutral
                 <<",\"internal_neutral\":"<<total_internal<<",\"improving\":"<<total_improving
                 <<",\"full_states\":"<<full_states<<",\"anchored_states\":"<<anchored_states
                 <<",\"candidate_pool\":"<<total_pool<<",\"critical_candidates\":"<<total_critical
                 <<",\"seconds\":"<<elapsed()<<"}\n";
    } catch(const std::exception& e) {std::cerr<<e.what()<<'\n';return 1;}
}
