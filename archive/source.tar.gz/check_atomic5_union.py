"""Join the checked C prefix with the C+B tail, without rerunning the prefix."""
import gzip
import hashlib
from itertools import combinations, product
import json
from pathlib import Path
import struct

import numpy as np


def main():
    assert __debug__
    root = Path('research/c7')
    output = root / 'component-CB-atomic5-verification-sep22.json'
    assert not output.exists()
    dependencies = {}

    def sha(p):
        return hashlib.sha256(Path(p).read_bytes()).hexdigest()

    def read(p):
        dependencies[str(p)] = sha(p)
        return json.loads(Path(p).read_text())

    def proof(p, checker):
        data = read(p)
        assert data['checker_sha256'] == sha(root / checker)
        for path, digest in data['dependencies'].items():
            assert sha(path) == digest
            dependencies[path] = digest
        return data

    def cache(p):
        dependencies[str(p)] = sha(p)
        with gzip.open(p, 'rt') as f:
            meta = json.loads(next(f))
            states = [tuple(json.loads(line)) for line in f]
        assert len(states) == len(set(states)) == meta['states']
        assert all(len(s) == 367 and tuple(sorted(set(s))) == s for s in states)
        digest = hashlib.sha256(b''.join(sorted(struct.pack('<367H', *s) for s in states))).hexdigest()
        assert digest == meta['component_sha256']
        return states

    prefix = proof(root / 'component-C-atomic5-escape-verification-sep22.json', 'check_component_atomic5.py')
    c4 = proof(root / 'component-C-atomic4-verification-sep22.json', 'check_component_atomic4.py')
    b4 = proof(root / 'component-B78-atomic4-verification-sep22.json', 'check_component_atomic4.py')
    for p in (c4, b4):
        assert p['complete_atomic4'] and p['width4_component_equals_width3'] and p['four_removal_augmentations_excluded']
        assert not p['outside']
    run = read(root / 'component-CB-atomic5-sep22-tail-run.json')
    manifest = read(run['input_manifest'])
    assert run['manifest_sha256'] == sha(run['input_manifest'])
    assert manifest['source_sha256'] == sha(manifest['source'])
    states = cache(manifest['source'])
    parts = []
    for part, p in zip(manifest['parts'], (c4, b4), strict=True):
        assert part['sha256'] == sha(part['source']) == p['dependencies'][part['source']]
        s = cache(part['source'])
        assert len(s) == p['states']
        parts.append(s)
    assert states == parts[0] + parts[1] and len(states) == manifest['states']
    assert hashlib.sha256(b''.join(sorted(struct.pack('<367H', *s) for s in states))).hexdigest() == manifest['component_sha256']
    assert prefix['dependencies'][manifest['parts'][0]['source']] == manifest['parts'][0]['sha256']
    assert prefix['states'] == len(parts[0]) and not prefix['improving']
    assert prefix['next_state'] == 5862
    assert all(tuple(row['words']) in states for row in prefix['outside'])
    expected = f'{len(states)} 367\n' + '\n'.join(' '.join(map(str, s)) for s in states) + '\n'
    assert Path(manifest['input']).read_text() == expected
    assert sha(manifest['input']) == manifest['input_sha256'] == run['input_sha256']
    dependencies[manifest['input']] = sha(manifest['input'])
    assert run['status'] == 'complete'
    assert sha(run['kernel']) == run['kernel_sha256'] == sha(root / 'scan_component_atomic5')
    assert sha(root / 'scan_component_atomic5.cpp') == run['kernel_source_sha256']
    assert sha(run['native_file']) == run['native_sha256']
    dependencies[run['native_file']] = sha(run['native_file'])
    rows = [json.loads(line) for line in Path(run['native_file']).read_text().splitlines()]
    assert rows == run['rows']
    footer = rows[-1]
    assert footer['status'] == 'exhausted'
    assert footer['start_state'] == prefix['next_state'] == int(run['command'][2])
    assert footer['next_state'] == footer['total_states'] == len(states)
    coords = np.array(list(product(range(7), repeat=5)), dtype=np.int16)
    known, seen = set(states), set()
    pair_checks = 0
    for row in rows[:-1]:
        assert row['event'] == 'trade'
        index = row['state']
        assert type(index) is int and footer['start_state'] <= index < footer['next_state']
        old, removed, added = states[index], row['removed'], row['added']
        assert len(removed) == len(set(removed)) == len(added) == len(set(added)) == 5
        assert set(removed) <= set(old) and not set(added) & set(old)
        assert all(type(v) is int and 0 <= v < 16807 for v in added)
        identity = index, tuple(sorted(added))
        assert identity not in seen
        seen.add(identity)
        delta = (coords[added, None, :] - coords[np.array(old)[None, :], :]) % 7
        bad = np.all((delta == 0) | (delta == 1) | (delta == 6), axis=2)
        blockers = [set(old[i] for i in np.flatnonzero(r)) for r in bad]
        assert set.union(*blockers) == set(removed)
        for n in range(1, 5):
            assert all(len(set.union(*sub)) > n for sub in combinations(blockers, n))
        words = tuple(sorted((set(old) - set(removed)) | set(added)))
        assert words in known
        points = coords[list(words)]
        delta = (points[:, None, :] - points[None, :, :]) % 7
        conflicts = np.all((delta == 0) | (delta == 1) | (delta == 6), axis=2)
        assert np.array_equal(conflicts, np.eye(367, dtype=bool))
        pair_checks += 367 * 366 // 2
    assert len(seen) == footer['neutral'] == footer['internal_neutral']
    assert footer['improving'] == 0
    result = dict(checker_sha256=sha(__file__), dependencies=dependencies,
                  states=len(states), parts=[len(s) for s in parts],
                  prefix_states=prefix['next_state'], tail_states=footer['next_state'] - footer['start_state'],
                  checked_trades=prefix['checked_trades'] + len(seen),
                  replayed_tail_pairs=pair_checks, total_replayed_pairs=prefix['pair_checks'] + pair_checks,
                  complete_atomic5=True, width5_component_equals_union=True,
                  five_removal_augmentations_excluded=True, outside=[], improving=0,
                  scope='Exact union of the C5971 and reached B78 components. Prefix is separately replayed and hash-bound; all tail trades replayed here. Each part is closed through width four; their union is closed through width five and has no augmentation with at most five removals. Native exhaustion depends on the tested enumerator, not a formal proof-tree replay. No global bound or 368 construction.')
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('dependencies', 'scope')}))


if __name__ == '__main__':
    main()
