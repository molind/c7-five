"""Use the existing exchange kernel for gain two with one shared dummy blocker.

For every outside candidate, add a fictitious blocker bit366. A kernel query
with removal budget r+1 and insertion target r+2 then means at most r real
removals and at least r+2 insertions. The dummy is not a graph word. This is
exactly the Z3 gain-two query, without modifying the native search engine.
"""
import argparse
from collections import Counter
import hashlib
from itertools import combinations,product
import json
from pathlib import Path
import subprocess
import time

from check_exchange_dfs import graph_text
from run_seed_exchanges import coordinate_masks,nearby,conflict

HERE=Path(__file__).resolve().parent


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--radii',type=int,nargs='+',default=[1,2,3,4,5])
    p.add_argument('--seconds',type=float,default=5)
    p.add_argument('--count',type=int,default=12)
    a=p.parse_args();assert __debug__ and not a.output.exists()
    assert 0<a.seconds<=600 and a.count>0 and all(1<=r<=7 for r in a.radii)
    source=json.loads(a.input.read_text());assert source['status']=='complete'
    bases=source['bases'][:a.count];assert len(bases)==a.count
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    report=dict(input=str(a.input),input_sha256=sha(a.input),source_sha256=sha(__file__),
                kernel_sha256=sha(HERE/'exchange_dfs'),kernel_source_sha256=sha(HERE/'exchange_dfs.cpp'),
                mask_source_sha256=sha(HERE/'run_seed_exchanges.py'),dummy_blocker_bit=366,radii=a.radii,
                seconds_per_query=a.seconds,status='running',rows=[],candidates=[],scope=__doc__)
    began=time.monotonic()
    def save():
        report['seconds']=time.monotonic()-began
        tmp=a.output.with_suffix('.tmp');tmp.write_text(json.dumps(report,separators=(',',':'))+'\n');tmp.replace(a.output)
    save()
    for bi,b in enumerate(bases):
        ids=b['words'];assert len(ids)==len(set(ids))==366
        words=[tuple(v//7**j%7 for j in range(4,-1,-1)) for v in ids]
        assert all(not conflict(x,y) for x,y in combinations(words,2))
        masks=coordinate_masks(words);occupied=set(words)
        outside=[(w,nearby(w,masks,366)) for w in product(range(7),repeat=5) if w not in occupied]
        assert all(mask for _,mask in outside), 'An immediate extension requires separate handling'
        for r in a.radii:
            pool=sorted(((w,b) for w,b in outside if b.bit_count()<=r),key=lambda row:row[1].bit_count())
            points=[w for w,_ in pool];pm=coordinate_masks(points);full=(1<<len(pool))-1
            cb=[b|(1<<366) for _,b in pool];comp=[full^nearby(w,pm,len(pool)) for w in points]
            text=graph_text(cb,comp,r+1,6)
            proc=subprocess.run([str(HERE/'exchange_dfs'),str(a.seconds),'--subset'],input=text,text=True,capture_output=True,check=True,timeout=a.seconds+15)
            result=json.loads(proc.stdout)
            if result['status']=='exhausted':assert result['nodes_started']==result['nodes_completed']
            assert result['status'] in ('witness','exhausted','timeout')
            row=dict(base=bi,real_radius=r,pool=len(pool),kernel_radius=r+1,target=r+2,
                     graph_sha256=hashlib.sha256(text.encode()).hexdigest(),result=result)
            report['rows'].append(row)
            if result['status']=='witness':
                chosen=result['chosen'];assert len(chosen)==len(set(chosen))==r+2
                assert all(type(i) is int and 0<=i<len(pool) for i in chosen)
                removed=0
                for i in chosen:removed|=pool[i][1]
                assert removed.bit_count()<=r
                witness=[w for i,w in enumerate(words) if not removed>>i&1]+[points[i] for i in chosen]
                assert len(witness)==len(set(witness))>=368 and all(not conflict(x,y) for x,y in combinations(witness,2))
                report['candidates'].append(dict(base=bi,radius=r,words=witness,pair_checks=len(witness)*(len(witness)-1)//2))
                report['status']='verified_target';save();return
            save();print(json.dumps(dict(base=bi,radius=r,pool=len(pool),status=result['status'],seconds=result['seconds'])),flush=True)
    report['status']='bounded_exchange_search_complete';save()
    print(json.dumps(dict(queries=len(report['rows']),statuses=dict(Counter(r['result']['status'] for r in report['rows'])))),flush=True)


if __name__=='__main__':main()
