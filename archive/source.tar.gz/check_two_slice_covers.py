"""Check two-slice certificates with integer arithmetic, Python standard library.

Rebuilds the complete domains, checks each clique and every vertex's coverage,
then checks which forbidden-core decisions follow. Also re-enumerates all
maximum independent extensions of the full D core. Imports no search/LP code.
"""
from collections import Counter
import argparse
from functools import lru_cache
import gzip
import hashlib
from itertools import combinations, product
import json
from pathlib import Path
import struct
import time

HERE = Path(__file__).resolve().parent
WORDS = list(product(range(7), repeat=5))


def conflict(a, b):
    return all((x-y) % 7 in (0, 1, 6) for x, y in zip(WORDS[a], WORDS[b]))


def vertex(w):
    value = 0
    for x in w:
        value = 7*value+x
    return value


@lru_cache(None)
def closed(v):
    return frozenset(vertex(w) for w in product(*[((x-1) % 7, x, (x+1) % 7) for x in WORDS[v]]))


def check_cover(row, domain, demands):
    den = row['denominator']
    assert type(den) is int and den > 0 and set(demands) == domain
    cover = {v: 0 for v in domain}
    total = 0
    for entry in row['cover']:
        vs, n = entry['vertices'], entry['units']
        assert type(n) is int and n > 0 and vs and len(vs) == len(set(vs))
        assert set(vs) <= domain and all(conflict(a, b) for a, b in combinations(vs, 2))
        for v in vs:
            cover[v] += n
        total += n
    assert all(cover[v] >= demands[v]*den for v in domain)
    assert total == row['total_units']
    return total, den


def check_core_extensions(core, states):
    pool = sorted(set(range(7**5))-set.union(*(set(closed(v)) for v in core)))
    adj = [sum(1 << j for j, u in enumerate(pool) if j != i and conflict(v, u))
           for i, v in enumerate(pool)]

    @lru_cache(None)
    def optimum(mask):
        if not mask:
            return 0
        v = (mask & -mask).bit_length()-1
        rest = mask ^ (1 << v)
        return max(optimum(rest), 1+optimum(rest & ~adj[v]))

    def enumerate_maxima(mask, needed, chosen):
        if needed == 0:
            yield frozenset(chosen)
            return
        if optimum(mask) < needed:
            return
        v = (mask & -mask).bit_length()-1
        rest = mask ^ (1 << v)
        yield from enumerate_maxima(rest, needed, chosen)
        yield from enumerate_maxima(rest & ~adj[v], needed-1, chosen+[pool[v]])

    full = (1 << len(pool))-1
    size = optimum(full)
    maxima = set(enumerate_maxima(full, size, []))
    assert len(pool) == 23 and size == 11 and len(maxima) == 384
    assert maxima == {frozenset(s-core) for s in states}
    for m in maxima:
        assert len(m | core) == 367 and all(not conflict(a, b) for a, b in combinations(m | core, 2))
    return dict(pool_size=len(pool), residual_alpha=size, maxima=len(maxima),
                all_maxima_are_cached_D=True, all_maxima_direct_pair_checks=384*67161)


def replay_tree(clauses, tree, variable_count):
    """Check a supplied tree by assignment-based unit propagation, no search."""
    counts = Counter()

    def walk(node, assignments):
        counts['nodes'] += 1
        changed = True
        contradiction = False
        while changed and not contradiction:
            changed = False
            for clause in clauses:
                if any(assignments.get(abs(lit)) == (lit > 0) for lit in clause):
                    continue
                remaining = [lit for lit in clause if abs(lit) not in assignments]
                if not remaining:
                    contradiction = True
                    break
                if len(remaining) == 1:
                    lit = remaining[0]
                    assignments[abs(lit)] = lit > 0
                    changed = True
        if contradiction:
            assert node is None
            counts['leaves'] += 1
            return
        assert isinstance(node, dict) and set(node) == {'variable', 'true', 'false'}
        v = node['variable']
        assert type(v) is int and 1 <= v <= variable_count and v not in assignments
        walk(node['true'], assignments | {v: True})
        walk(node['false'], assignments | {v: False})

    walk(tree, {})
    return dict(counts)


def check_faces(domains, lp_report):
    names = ['two-slice-cover-face-sep21.json', 'two-slice-cover-face-rebound-sep21.json',
             'two-slice-face-proofs-sep21.json']
    face_report, rebound_report, proof_report = [json.loads((HERE/n).read_text()) for n in names]
    originals = {r['index']: r for r in lp_report['results']}
    rebounds = {r['index']: r for r in rebound_report['results']}
    proofs = {r['index']: r for r in proof_report['results']}
    closed_cases = set()
    details = []
    for face in face_report['results']:
        row = originals[face['index']]
        pool, target, local_core = domains[row['pool_key']]
        assert face['forbidden'] == row['forbidden'] in local_core
        assert face['pool_key'] == row['pool_key'] and face['target'] == row['target'] == target
        domain = pool-{row['forbidden']}
        total, den = check_cover(row, domain, {v: 1 for v in domain})
        gap = total-target*den
        assert gap >= 0 and face['gap_units'] == gap
        coverage = {v: 0 for v in domain}
        for entry in row['cover']:
            for v in entry['vertices']:
                coverage[v] += entry['units']
        permitted = sorted(v for v in domain if coverage[v]-den <= gap)
        assert face['face'] == permitted
        # Reconstruct deletion neighborhoods directly from actual C7 coordinates.
        adj = [{j for j, u in enumerate(permitted) if i != j and conflict(v, u)}
               for i, v in enumerate(permitted)]
        active = set(range(len(permitted)))
        for v, u in face['domination_steps']:
            assert v in active and u in active and u in adj[v]
            assert (({u} | adj[u]) & active) <= (({v} | adj[v]) & active)
            active.remove(v)
        assert face['kept_face_indices'] == sorted(active)
        reduced = [permitted[v] for v in sorted(active)]
        rebound = rebounds[face['index']]
        assert rebound['pool'] == reduced and rebound['target'] == target
        total, den = check_cover(rebound, set(reduced), {v: 1 for v in reduced})
        gap = total-target*den
        assert gap >= 0
        # A target-size independent set omitting one such clique would leave
        # more unused cover weight than the entire exact available slack.
        mandatory = [c['vertices'] for c in rebound['cover'] if c['units'] > gap]
        local = {v: i+1 for i, v in enumerate(reduced)}
        clauses = [[-local[a], -local[b]] for a, b in combinations(reduced, 2) if conflict(a, b)]
        clauses += [[local[v] for v in c] for c in mandatory]
        proof = proofs[face['index']]
        assert proof['status'] == 'proved_unsat' and proof['variable_vertices'] == reduced
        assert proof['clauses'] == clauses
        counts = replay_tree(clauses, proof['tree'], len(reduced))
        assert all(proof['statistics'][k] == v for k, v in counts.items())
        closed_cases.add((row['pool_key'], row['forbidden']))
        details.append(dict(forbidden=row['forbidden'], face_size=len(permitted),
                            reduced_size=len(reduced), mandatory_cliques=len(mandatory), **counts))
    assert replay_tree([[1], [-1]], None, 1) == {'nodes': 1, 'leaves': 1}
    try:
        replay_tree([[1, 2]], {'variable': 1, 'true': None, 'false': None}, 2)
    except AssertionError:
        pass
    else:
        raise AssertionError('A satisfiable CNF was accepted as UNSAT')
    return closed_cases, details, names


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--faces', action='store_true', help='Also verify the cover pruning, domination and Boolean proof trees')
    args = parser.parse_args()
    began = time.monotonic()
    cache = HERE/'breakout-perturb64-sep20-2049-component-0.jsonl.gz'
    with gzip.open(cache, 'rt') as f:
        metadata = json.loads(next(f))
        states = [set(json.loads(line)) for line in f]
    packed = sorted(struct.pack('<367H', *sorted(s)) for s in states)
    assert len(set(packed)) == 384
    assert hashlib.sha256(b''.join(packed)).hexdigest() == metadata['component_sha256']
    core = set.intersection(*states)
    seed_words = (HERE/'family-d-seed-words.txt').read_text().split()
    seed = {int(w, 7) for w in seed_words}
    assert len(seed) == len(seed_words) == 367 and len(core) == 356 and core <= seed
    assert all(not conflict(a, b) for a, b in combinations(seed, 2))
    files = ['two-slice-lp-d-core-barrier-sep21.json', 'two-slice-lp-d-six-open-sep21.json']
    reports = [json.loads((HERE/n).read_text()) for n in files]
    assert all(r['status'] == 'queries_complete' for r in reports)
    expected = set()
    domains = {}
    for axis in range(5):
        for start in range(7):
            key = f'{axis}:{start}'
            fixed = {v for v in seed if (WORDS[v][axis]-start) % 7 >= 2}
            pool = set(range(7**5))-set.union(*(set(closed(v)) for v in fixed))
            original = seed-fixed
            assert original <= pool
            domains[key] = pool, len(original), core & pool
            expected.update((key, v) for v in core & pool)
    assert len(expected) == 3560
    covered = set()
    checked = []
    for report in reports:
        for key, saved in report['pools'].items():
            pool, target, _ = domains[key]
            assert sorted(pool) == saved['pool'] and saved['fixed_size'] == 367-target
        for row in report['results']:
            key = row['pool_key']
            pool, target, local_core = domains[key]
            assert target == row['target']
            if report['core_barrier']:
                multiplier = len(local_core)+1
                assert row['multiplier'] == multiplier and row['core_in_pool'] == sorted(local_core)
                demands = {v: multiplier-int(v in core) for v in pool}
                assert row['demands'] == [{'vertex': v, 'weight': demands[v]} for v in sorted(pool)]
                total, den = check_cover(row, pool, demands)
                threshold = multiplier*target-len(local_core)+1
                forces = total < threshold*den
                assert row['weighted_escape_threshold'] == threshold and row['forces_all_core'] == forces
                if forces:
                    covered.update((key, v) for v in local_core)
                checked.append(dict(pool_key=key, mode='weighted', forces_all_core=forces,
                                    local_size_upper=(total+len(local_core)*den)//(multiplier*den)))
            else:
                forbidden = row['forbidden']
                assert forbidden in local_core
                domain = pool-{forbidden}
                total, den = check_cover(row, domain, {v: 1 for v in domain})
                excludes = total < target*den
                assert excludes == row['excludes_target']
                if excludes:
                    covered.add((key, forbidden))
                checked.append(dict(pool_key=key, mode='single_ban', forbidden=forbidden,
                                    excludes_target=excludes, local_size_upper=total//den))
    # Negative controls: a missing cover and a non-clique cannot be certificates.
    first = reports[0]['results'][0]
    pool, _, local_core = domains[first['pool_key']]
    demands = {v: len(local_core)+1-int(v in core) for v in pool}
    bad = dict(first, cover=[])
    try:
        check_cover(bad, pool, demands)
    except AssertionError:
        pass
    else:
        raise AssertionError('Empty cover accepted')
    pair = next((a, b) for a, b in combinations(sorted(pool), 2) if not conflict(a, b))
    bad = dict(first, cover=[{'vertices': list(pair), 'units': 1}])
    try:
        check_cover(bad, pool, demands)
    except AssertionError:
        pass
    else:
        raise AssertionError('Non-clique accepted')
    face_details = []
    if args.faces:
        cases, face_details, extra_files = check_faces(domains, reports[1])
        covered.update(cases)
        files += extra_files
    full_core = check_core_extensions(core, states)
    out = dict(checked_certificates=len(checked), expected_forbidden_core_cases=len(expected),
               covered_forbidden_core_cases=len(covered), uncovered=sorted(expected-covered),
               all_two_slice_core_escapes_excluded=(expected == covered),
               checked=checked, full_core=full_core, negative_controls_passed=2,
               face_proofs=face_details, boolean_replay_controls_passed=2 if args.faces else 0,
               seconds=time.monotonic()-began,
               hashes={n: hashlib.sha256((HERE/n).read_bytes()).hexdigest() for n in files},
               checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               scope='Only the pinned D seed and two adjacent coordinate values. Local separately implemented checker; no external replay or global bound.')
    path = HERE/('two-slice-cover-verification-with-faces-sep21.json' if args.faces else 'two-slice-cover-verification-sep21.json')
    if path.exists():
        raise FileExistsError(path)
    path.write_text(json.dumps(out, indent=2)+'\n')
    print(json.dumps({k: v for k, v in out.items() if k not in ('checked', 'hashes')}), flush=True)


if __name__ == '__main__':
    main()
