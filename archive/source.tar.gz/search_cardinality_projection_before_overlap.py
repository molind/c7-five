"""Alternate exact-cardinality rounding and nearest feasible LP points.

This is a bounded feasibility-pump experiment, not an exclusion algorithm.
Small support searches include the old independent hint and are also bounded.
Only direct coordinate checks can turn a returned set into a construction.
"""
import argparse
import hashlib
import json
from pathlib import Path
import time

import numpy as np
from scipy.optimize import linprog
from scipy.sparse import csr_matrix
from check_two_slice_covers import WORDS, closed
from probe_local_rank_cuts import query
from search_with_clique_cycles import load_proof


def pair_edges(vertices):
    coordinates=np.asarray(WORDS)[vertices]
    delta=(coordinates[:,None,:]-coordinates[None,:,:])%7
    return np.argwhere(np.triu(np.all((delta==0)|(delta==1)|(delta==6),axis=2),1)).tolist()


def rounded(values,target,rng):
    # Randomness breaks numerical ties only. Cardinality is always exact.
    return np.sort(np.argsort(-(values+rng.uniform(-1e-9,1e-9,len(values))))[:target])


def pump(matrix,caps,pool,fixed,hint,initial,args,save,target_size=368):
    n=len(pool);target=target_size-len(fixed);rng=np.random.default_rng(args.seed)
    assert 0 < target <= n
    equality=csr_matrix(np.ones((1,n)))
    local={v:i for i,v in enumerate(pool)}
    adjacency=[{local[w] for w in closed(v) if w in local and w!=v} for v in pool]
    hint_set={pool[i] for i in hint}
    began=time.monotonic();best=n;seen_supports=set();archive=set()
    report=dict(status='running',seed=args.seed,target=target,target_size=target_size,rows=[],support_searches=[],
                candidates=[],best_conflicts=None,scope='Bounded cardinality projection and selected support searches only; no exclusions.')
    def record():
        report['seconds']=time.monotonic()-began;save(report)
    for restart in range(args.starts):
        values=initial.copy();seen=set()
        if restart%2:
            values=np.zeros(n);values[hint]=1
            extras=[i for i in range(n) if i not in hint]
            minimum=min(len(adjacency[i]&set(hint)) for i in extras)
            choices=[i for i in extras if len(adjacency[i]&set(hint))==minimum]
            values[rng.choice(choices)]=1
        for step in range(args.rounds):
            if time.monotonic()-began>=args.budget:
                report['status']='time_limit';record();return report
            chosen=rounded(values,target,rng);key=tuple(map(int,chosen));shaken=False
            if key in seen:
                # Exchange uncertain entries, increasing the shake after cycles.
                count=min(3+step//10,target,n-target)
                outside=np.setdiff1d(np.arange(n),chosen,assume_unique=True)
                remove_candidates=chosen[np.argsort(values[chosen])[:max(count,3*count)]]
                add_candidates=outside[np.argsort(-values[outside])[:max(count,3*count)]]
                chosen=np.sort(np.concatenate([np.setdiff1d(chosen,rng.choice(remove_candidates,count,replace=False)),
                                               rng.choice(add_candidates,count,replace=False)]))
                key=tuple(map(int,chosen));shaken=True
            seen.add(key)
            conflicts=sum(len(adjacency[i]&set(key)) for i in key)//2
            row=dict(restart=restart,step=step,rounded_vertices=[pool[i] for i in key],conflicts=conflicts,shaken=shaken)
            report['rows'].append(row)
            improved=conflicts<best
            if improved:
                best=conflicts;report['best_conflicts']=best
                print(json.dumps(dict(restart=restart,step=step,best_conflicts=best)),flush=True)
            if conflicts==0:
                full=sorted(fixed+[pool[i] for i in key]);assert len(full)==len(set(full))==target_size and not pair_edges(full)
                report['candidates'].append(dict(size=target_size,vertices=full,pair_checks=target_size*(target_size-1)//2))
                report['status']='verified_target';record();return report
            objective=np.ones(n);objective[chosen]=-1
            remaining=args.budget-(time.monotonic()-began)
            if remaining<=0:
                report['status']='time_limit';record();return report
            result=linprog(objective,A_ub=matrix,b_ub=caps,A_eq=equality,b_eq=[target],bounds=(0,1),
                           method=args.method,options={'time_limit':min(args.lp_seconds,remaining)})
            row['lp_status']=int(result.status);row['message']=result.message
            if not result.success:
                row['unresolved']=True;record();break
            values=result.x
            assert abs(sum(values)-target)<1e-6 and np.all(matrix@values<=caps+1e-6)
            assert min(values)>=-1e-6 and max(values)<=1+1e-6
            row['distance']=float(target+result.fun)
            row['primal']=[[pool[i],float(x)] for i,x in enumerate(values) if x>1e-8]
            if improved or step%10==9:
                support=sorted(hint_set|{pool[i] for i in chosen}|{pool[i] for i,x in enumerate(values) if x>1e-7})
                support_key=tuple(support)
                if support_key not in seen_supports and time.monotonic()-began<args.budget:
                    seen_supports.add(support_key)
                    answer,edges=query(support,target,args.support_ms,hint_set)
                    returned=sorted(fixed+[support[i] for i in answer['vertices']])
                    assert len(returned)==len(set(returned)) and not pair_edges(returned)
                    report['support_searches'].append(dict(row=len(report['rows'])-1,pool=support,edges=edges,result=answer,full_size=len(returned)))
                    if len(returned)>=367 and tuple(returned) not in archive:
                        archive.add(tuple(returned));report['candidates'].append(dict(size=len(returned),vertices=returned,pair_checks=len(returned)*(len(returned)-1)//2))
                    if len(returned)>=target_size:
                        report['status']='verified_target';record();return report
            record()
    report['status']='bounded_search_complete';record();return report


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True)
    p.add_argument('--base-verification',type=Path,required=True)
    p.add_argument('--seed',type=int,default=202609211)
    p.add_argument('--starts',type=int,default=4)
    p.add_argument('--rounds',type=int,default=30)
    p.add_argument('--budget',type=float,default=180)
    p.add_argument('--lp-seconds',type=float,default=10)
    p.add_argument('--method',choices=['highs-ds','highs-ipm'],default='highs-ipm')
    p.add_argument('--support-ms',type=int,default=750)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();assert __debug__ and not args.output.exists()
    assert min(args.starts,args.rounds,args.budget,args.lp_seconds,args.support_ms)>0
    proof,model,matrix,caps=load_proof(args.input,args.base_verification)
    assert proof['final_primal'] is not None
    local={v:i for i,v in enumerate(model['pool'])};values=np.zeros(len(local))
    for v,x in proof['final_primal']:values[local[v]]=x
    provenance=dict(input=str(args.input),input_sha256=hashlib.sha256(args.input.read_bytes()).hexdigest(),
                    base_verification=str(args.base_verification),base_verification_sha256=hashlib.sha256(args.base_verification.read_bytes()).hexdigest(),
                    source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                    kernel_sha256=hashlib.sha256((Path(__file__).parent/'slice_clique').read_bytes()).hexdigest(),
                    parameters={k:str(v) if isinstance(v,Path) else v for k,v in vars(args).items()})
    def save(report):
        tmp=args.output.with_suffix('.tmp');tmp.write_text(json.dumps(provenance|report,indent=2)+'\n');tmp.replace(args.output)
    report=pump(matrix,caps,model['pool'],model['fixed'],model['hint'],values,args,save)
    print(json.dumps({k:v for k,v in report.items() if k not in ('rows','support_searches','candidates')}),flush=True)


if __name__=='__main__':
    main()
