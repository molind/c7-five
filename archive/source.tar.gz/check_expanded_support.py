"""Replay inherited rows and witnesses of a heuristic expanded-support search."""
import argparse
import gzip
import hashlib
from itertools import combinations
import json
from pathlib import Path
import struct

from check_two_slice_covers import check_core_extensions, conflict
from search_sparse_cylinders import check_solution


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    r=json.loads(args.input.read_text())
    assert r['status'] in ('bounded_search_complete','candidate_found') and r['full_target']==368
    source_path=Path(r['input']);verification_path=Path(r['verification'])
    assert hashlib.sha256(source_path.read_bytes()).hexdigest()==r['input_sha256']
    assert hashlib.sha256(verification_path.read_bytes()).hexdigest()==r['verification_sha256']
    source=json.loads(source_path.read_text());checked=json.loads(verification_path.read_text())
    assert checked['input_sha256']==r['input_sha256'] and not checked['target_witness_found']
    full=source['model'];local={v:i for i,v in enumerate(full['pool'])}
    assert r['fixed']==full['fixed']==r['model']['fixed']
    for c in source['learned_cuts']:
        full['members'].append([local[v] for v in c['vertices']]);full['capacities'].append(c['capacity'])
    core_proof=None
    if r.get('core_exclusion'):
        c=r['core_exclusion'];path=Path(c['cache'])
        assert hashlib.sha256(path.read_bytes()).hexdigest()==c['cache_sha256']
        with gzip.open(path,'rt') as handle:
            meta=json.loads(next(handle));states=[set(json.loads(line)) for line in handle]
        packed=sorted(struct.pack('<367H',*sorted(s)) for s in states)
        assert len(set(packed))==384
        assert hashlib.sha256(b''.join(packed)).hexdigest()==c['component_sha256']==meta['component_sha256']
        core=set.intersection(*states)
        assert sorted(core)==c['core']
        core_proof=check_core_extensions(core,states)
        assert core_proof==c['verification'] and len(core)+core_proof['residual_alpha']==367
        vertices=sorted(core-set(r['fixed']))
        assert c['vertices']==vertices and c['capacity']==len(vertices)-1 and vertices
        full['members'].append([local[v] for v in vertices]);full['capacities'].append(c['capacity'])
    restricted=r['model'];pool=restricted['pool']
    assert pool==sorted(set(pool)) and set(pool)<=set(full['pool'])
    reindex={local[v]:i for i,v in enumerate(pool)}
    expected={}
    for row,cap in zip(full['members'],full['capacities']):
        projected=tuple(reindex[v] for v in row if v in reindex)
        if len(projected)>cap:
            expected[projected]=min(cap,expected.get(projected,cap))
    assert restricted['members']==[list(row) for row in sorted(expected)]
    assert restricted['capacities']==[expected[row] for row in sorted(expected)]
    original_hint=set(full['hint'])
    hint=original_hint-{local[v] for v in source['learned_hint_removed']}
    inherited_pool=set()
    if r.get('previous_support'):
        prev=r['previous_support'];path=Path(prev['file']);vp=Path(prev['verification'])
        assert hashlib.sha256(path.read_bytes()).hexdigest()==prev['sha256']
        assert hashlib.sha256(vp.read_bytes()).hexdigest()==prev['verification_sha256']
        previous=json.loads(path.read_text());pv=json.loads(vp.read_text())
        assert pv['input_sha256']==prev['sha256'] and not pv['target_witness_found']
        assert previous['status']=='bounded_search_complete' and previous['input_sha256']==r['input_sha256']
        assert previous['fixed']==r['fixed'] and previous.get('core_exclusion')==r.get('core_exclusion')
        check_solution(full,previous['result'])
        inherited_pool=set(previous['model']['pool'])
        assert set(previous['result']['vertices'])<=inherited_pool<=set(full['pool'])
        hint={local[v] for v in previous['result']['vertices']}
    assert restricted['hint']==sorted(reindex[v] for v in hint)
    assert r.get('initial_full_size',len(r['fixed'])+len(hint))==len(r['fixed'])+len(hint)
    primal=r['lp']['primal'];x={v:value for v,value in primal}
    assert len(x)==len(primal) and set(x)<=set(full['pool'])
    assert all(0<value<=1+1e-6 for value in x.values())
    assert sum(x.values())>=368-len(r['fixed'])-1e-5
    assert all(sum(x.get(full['pool'][i],0) for i in row)<=cap+1e-5 for row,cap in zip(full['members'],full['capacities']))
    assert set(pool)==set(x)|{full['pool'][i] for i in original_hint|hint}|inherited_pool
    assert r['result']['target']==368-len(r['fixed'])
    assert r['result']['initial_size']==len(hint)
    reported_size=r['result'].get('full_size')
    reported_pairs=r['result'].get('verified_pairs')
    check_solution(restricted,r['result']);check_solution(full,r['result'])
    assert r['result'].get('full_size')==reported_size
    assert r['result'].get('verified_pairs')==reported_pairs
    candidates=[]
    for c in r['candidates']:
        words=[int(w,7) for w in c['words']]
        assert len(words)==len(set(words))==c['size']>=367
        assert set(words)==set(r['fixed'])|set(r['result']['vertices'])
        assert all(not conflict(a,b) for a,b in combinations(words,2))
        assert c['verified_pairs']==len(words)*(len(words)-1)//2
        candidates.append(dict(size=len(words),verified_pairs=c['verified_pairs']))
    found=any(c['size']>=368 for c in candidates)
    assert (r['status']=='candidate_found')==found
    result=dict(input_sha256=hashlib.sha256(args.input.read_bytes()).hexdigest(),
                restricted_pool=len(pool),inherited_rows=len(full['members']),retained_rows=len(expected),
                core_exclusion_replayed=core_proof,candidates=candidates,target_witness_found=found,
                inherited_pool=len(inherited_pool),initial_full_size=len(r['fixed'])+len(hint),
                source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                scope='Only retained-row validity and returned witnesses checked; heuristic support restriction proves no full-domain exclusion.')
    args.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)


if __name__=='__main__':
    main()
