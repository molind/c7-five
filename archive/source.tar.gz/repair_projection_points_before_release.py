"""Repair rounded368 points while retaining their certified search domain.

Reuse the existing weighted conflict state. Moves retain the fixed exterior,
stay inside its complete candidate pool, and obey the verified C-overlap cap.
Bounded walks produce candidates, never exclusions.
"""
import argparse
from collections import deque
import hashlib
import json
from pathlib import Path
import random
import time

import numpy as np
from breakout_conflicts import State,graph
from check_cardinality_projection import conflicts,verify
from search_cardinality_projection import load_projection_model


def walk(adjacency,start,fixed,pool,limited,cap,seed,steps,seconds,penalty_period,learning_steps=None):
    assert learning_steps is None or learning_steps>0
    state=State(adjacency,start);rng=random.Random(seed);n=len(adjacency)
    allowed=np.zeros(n,dtype=bool);allowed[pool]=True
    limited_mask=np.zeros(n,dtype=bool);limited_mask[limited]=True
    assert set(fixed)<=set(start) and set(start)-set(fixed)<=set(pool)
    assert int(sum(state.selected[limited]))<=cap
    best=int(sum(state.count[state.selected]))//2;best_words=sorted(start)
    tabu=deque(maxlen=8);moves=[];began=time.monotonic();penalties=0;status='step_limit'
    phase_reset=None;unit_score_checks=0
    for step in range(steps):
        if time.monotonic()-began>=seconds:status='time_limit';break
        energy=int(sum(state.count[state.selected]))//2
        if energy==0:status='independent';break
        if learning_steps is not None and step>=learning_steps:
            assert np.array_equal(state.score,state.count)
            unit_score_checks+=1
        removable=np.flatnonzero(state.selected & allowed & (state.count>0)).tolist()
        assert removable, 'All pool words are compatible with the fixed exterior'
        old=rng.choice(removable);state.drop(old)
        eligible=allowed & ~state.selected;eligible[old]=False
        if int(sum(state.selected[limited]))==cap:eligible &= ~limited_mask
        eligible_without_tabu=eligible.copy()
        for v in tabu:eligible[v]=False
        # Preserve the existing search's rule: a true zero-conflict completion
        # overrides tabu restrictions, but never the certified domain or cap.
        if not np.any(state.count[state.selected]):
            free=eligible_without_tabu & (state.count==0)
            if np.any(free):eligible=free
        if not np.any(eligible):eligible=eligible_without_tabu
        choices=np.flatnonzero(eligible);assert len(choices)
        minimum=min(state.score[choices]);new=rng.choice(choices[state.score[choices]==minimum].tolist())
        state.add(new);tabu.append(old)
        after=int(sum(state.count[state.selected]))//2
        moves.append([int(old),int(new),after])
        if after<best:
            best=after;best_words=np.flatnonzero(state.selected).tolist()
        if after==0:status='independent';break
        if step+1==learning_steps:
            phase_reset=dict(after_step=step+1,conflicts=after,maximum_weight_before=int(state.weight.max()),
                             selected_sha256=hashlib.sha256(np.flatnonzero(state.selected).astype('<u2').tobytes()).hexdigest())
            state.weight.fill(1);state.score[:]=state.count
            assert np.all(state.weight==1) and np.array_equal(state.score,state.count)
        if penalty_period and (step+1)%penalty_period==0 and (learning_steps is None or step+1<learning_steps):
            state.penalize();penalties+=1
    return dict(status=status,seed=seed,penalty_period=penalty_period,penalty_updates=penalties,
                learning_steps=learning_steps,phase_reset=phase_reset,unit_score_checks=unit_score_checks,
                seconds=time.monotonic()-began,steps=len(moves),start=sorted(start),moves=moves,
                best_conflicts=best,best_words=best_words,final_words=np.flatnonzero(state.selected).tolist())


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--seeds',type=int,default=3)
    p.add_argument('--steps',type=int,default=50000)
    p.add_argument('--seconds',type=float,default=20)
    p.add_argument('--penalty-periods',type=int,nargs='+',default=[0,32])
    p.add_argument('--learning-steps',type=int)
    p.add_argument('--starts-from',type=Path,help='Use best points of an earlier repair on this same trajectory')
    p.add_argument('--seed',type=int,default=2026092300)
    a=p.parse_args();assert __debug__ and not a.output.exists()
    assert min(a.seeds,a.steps,a.seconds)>0 and min(a.penalty_periods)>=0
    assert a.learning_steps is None or 0<a.learning_steps<=a.steps
    trajectory=json.loads(a.input.read_text());assert trajectory['status']!='running'
    trajectory_check=verify(trajectory);overlap=trajectory['overlap']
    _,model,_,_,cap,bounded=load_projection_model(Path(trajectory['input']),Path(trajectory['base_verification']),Path(overlap['certificate']))
    assert cap is not None
    fixed=model['fixed'];pool=model['pool'];limited=[pool[i] for i in bounded]
    candidates={tuple(row['rounded_vertices']):row['conflicts'] for row in trajectory['rows']}
    start_source=None
    if a.starts_from is not None:
        prior=json.loads(a.starts_from.read_text())
        assert prior['input_sha256']==hashlib.sha256(a.input.read_bytes()).hexdigest()
        assert prior['fixed']==fixed and prior['pool']==pool and prior['limited']==limited and prior['cap']==cap
        candidates={}
        for run in prior['runs']:
            full=run['best_words']
            assert len(full)==len(set(full))==368 and set(fixed)<=set(full)
            assert set(full)-set(fixed)<=set(pool) and len(set(full)&set(limited))<=cap
            assert conflicts(full)==run['best_conflicts']
            candidates[tuple(v for v in full if v not in set(fixed))]=run['best_conflicts']
        start_source=dict(file=str(a.starts_from),sha256=hashlib.sha256(a.starts_from.read_bytes()).hexdigest())
    starts=[]
    while candidates and len(starts)<a.seeds:
        chosen=min(candidates,key=lambda s:(candidates[s],-min((len(set(s)^set(old)) for old in starts),default=0),s))
        starts.append(chosen);del candidates[chosen]
    _,adjacency=graph(5)
    digest=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
    report=dict(status='running',input=str(a.input),input_sha256=digest(a.input),source_sha256=digest(__file__),
                state_source_sha256=digest(Path(__file__).parent/'breakout_conflicts.py'),
                trajectory_verification=trajectory_check,fixed=fixed,pool=pool,limited=limited,cap=cap,
                start_source=start_source,runs=[],candidates=[],scope=__doc__)
    def save():
        temp=a.output.with_suffix('.tmp');temp.write_text(json.dumps(report,separators=(',',':'))+'\n');temp.replace(a.output)
    save()
    for i,start in enumerate(starts):
        full=sorted(fixed+list(start));assert len(full)==368
        for period in a.penalty_periods:
            result=walk(adjacency,full,fixed,pool,limited,cap,a.seed+10*i+period,a.steps,a.seconds,period,a.learning_steps)
            assert conflicts(result['best_words'])==result['best_conflicts']
            assert set(fixed)<=set(result['best_words']) and set(result['best_words'])-set(fixed)<=set(pool)
            assert len(set(result['best_words'])&set(limited))<=cap
            report['runs'].append(result)
            print(json.dumps({k:v for k,v in result.items() if k not in ('start','moves','best_words','final_words')}),flush=True)
            if result['best_conflicts']==0:
                report['candidates'].append(dict(size=368,vertices=result['best_words'],pair_checks=67528))
                report['status']='verified_target';save();return
            save()
    report['status']='bounded_search_complete';save()


if __name__=='__main__':main()
