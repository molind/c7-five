"""Stdlib replay of primal/dual structural probes, from the saved core only."""
import hashlib
import itertools
import json
from fractions import Fraction
from pathlib import Path
from check_one_core_covers import check

ROOT = Path(__file__).resolve().parent


def main():
    core = list(map(tuple, json.loads((ROOT/'two-core-cover-results.json').read_text())['core']))
    assert len(core) == len(set(core)) == 308
    assert all(len(w) == 5 and all(type(x) is int and 0 <= x < 7 for x in w) for w in core)
    for a, b in itertools.combinations(core, 2):
        assert any((x-y) % 7 in (2, 3, 4, 5) for x, y in zip(a, b))
    blockers = {w: 0 for w in itertools.product(range(7), repeat=5)}
    for i, w in enumerate(core):
        for v in itertools.product(*[((x-1) % 7, x, (x+1) % 7) for x in w]):
            blockers[v] |= 1 << i
    paths = [ROOT/'cover-structure-optima.json', ROOT/'shared-low-blocker-covers.json']
    results = []
    for source in paths:
        for row in json.loads(source.read_text())['cases']:
            if 'blocker_radius' in row:
                expected = {w for w, m in blockers.items() if m.bit_count() <= row['blocker_radius']}
            else:
                deleted = row['deleted_core_indices']
                assert len(deleted) == len(set(deleted)) and all(0 <= i < 308 for i in deleted)
                kept = ((1 << 308)-1) ^ sum(1 << i for i in deleted)
                expected = {w for w, m in blockers.items() if not m & kept}
            words = list(map(tuple, row['words']))
            assert len(words) == len(set(words)) == row['candidate_count']
            assert set(words) == expected
            if not row.get('optimum_proved'):
                results.append({'name': row.get('name', row.get('blocker_radius')), 'optimum_verified': False})
                continue
            total = Fraction(row['primal_total'])
            assert check(row['cover'], expected, total+1) == total
            witness = {tuple(e['word']): Fraction(e['weight']) for e in row['dual']}
            assert len(witness) == len(row['dual']) and set(witness) <= expected
            assert all(q >= 0 for q in witness.values())
            assert sum(witness.values(), Fraction(0)) == total
            # Direct modular membership, different from the generator's corner
            # expansion. Accumulate each point into every box containing it.
            loads = {}
            for w, q in witness.items():
                for origin in itertools.product(*[((x-1) % 7, x) for x in w]):
                    loads[origin] = loads.get(origin, Fraction(0)) + q
            assert all(q <= 1 for q in loads.values())
            integral = all(q == 1 for q in witness.values())
            if integral:
                for a, b in itertools.combinations(witness, 2):
                    assert any((x-y) % 7 in (2, 3, 4, 5) for x, y in zip(a, b))
            results.append({'name': row.get('name', row.get('blocker_radius')),
                            'candidate_count': len(expected), 'optimum_verified': True,
                            'box_cover_optimum': str(total), 'dual_is_independent_set': integral,
                            'primal_boxes': len(row['cover']),
                            'primal_all_unit_weights': all(Fraction(e['weight']) == 1 for e in row['cover'])})
    free_words = {w for w, mask in blockers.items() if mask == 0}
    adjacent = {w: set() for w in free_words}
    for a, b in itertools.combinations(free_words, 2):
        if all((x-y) % 7 in (0, 1, 6) for x, y in zip(a, b)):
            adjacent[a].add(b)
            adjacent[b].add(a)
    reached = {min(free_words)}
    stack = list(reached)
    while stack:
        unseen = adjacent[stack.pop()] - reached
        reached.update(unseen)
        stack.extend(unseen)
    assert reached == free_words
    free_cover = json.loads(paths[0].read_text())['cases'][0]['cover']
    covered = set()
    for row in free_cover:
        covered.update(itertools.product(*[(x, (x+1) % 7) for x in row['origin']]))
    obstructed = []
    for i in range(308):
        remaining = [w for w, m in blockers.items() if m == 1 << i and w not in covered]
        if any(any((x-y) % 7 in (2, 3, 4, 5) for x, y in zip(a, b))
               for a, b in itertools.combinations(remaining, 2)):
            obstructed.append(i)
    recorded = json.loads((ROOT/'shared-cover-obstructions.json').read_text())
    assert obstructed == [r['core_index'] for r in recorded]
    for row in recorded:
        i, a, b = row['core_index'], tuple(row['a']), tuple(row['b'])
        assert tuple(row['core_word']) == core[i]
        assert blockers[a] == blockers[b] == 1 << i
        assert a not in covered and b not in covered
        assert any((x-y) % 7 in (2, 3, 4, 5) for x, y in zip(a, b))
    report = {'inputs': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},
              'free_graph': {'vertices': len(free_words), 'edges': sum(map(len, adjacent.values()))//2,
                             'connected': True},
              'fixed_free_cover_obstructed_indices': obstructed,
              'cases': results}
    (ROOT/'cover-structure-verification.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report, indent=2), flush=True)


if __name__ == '__main__':
    main()
