"""Small controls for frozen trade variables, sampling and preserved hints."""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np

from search_lp_trade_neighborhoods import permitted_removals,variable_upper_bounds
from solve_two_blocker_mip import build_model
from solve_hinted_blocker_trades import solve_binary_trade


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',required=True,type=Path)
    a=p.parse_args();assert __debug__ and not a.output.exists()
    active=list(range(8));weights=list(map(float,active));mandatory=[0,2];cases=0
    for budget in (2,4,8):
        for trial in (0,1,2):
            chosen=permitted_removals(active,weights,mandatory,budget,trial,917+trial)
            assert chosen==sorted(set(chosen)) and len(chosen)==budget and set(mandatory)<=set(chosen)
            assert chosen==permitted_removals(active,weights,mandatory,budget,trial,917+trial)
            cases+=1
    assert permitted_removals(active,weights,mandatory,4,0,917)==[0,2,6,7]
    d=dict(pool_ids=[0,1,2,3],blocker_sets=[[0],[0],[1],[1]],active_old_indices=[0,1],conflict_edges=[])
    A,lo,hi,c=build_model(d,'improve');initial=np.array([1,1,0,0,1,0]);objective=5*c;objective[:4]-=1
    outputs=[]
    for permitted,gain in [([0],1),([0,1],2)]:
        upper=variable_upper_bounds(d,permitted)
        assert all(upper[i]==int(set(b)<=set(permitted)) for i,b in enumerate(d['blocker_sets']))
        row,solution=solve_binary_trade(A,lo,hi,objective,initial,2,-10,upper)
        assert solution is not None and int(sum(solution[:4])-sum(solution[4:]))==gain
        assert np.all(solution<=upper)
        outputs.append(dict(permitted=permitted,gain=gain,solver_status=row['solver_status']))
    try:solve_binary_trade(A,lo,hi,objective,initial,2,-10,np.zeros(6))
    except AssertionError:invalid_hint_rejected=True
    else:raise AssertionError('A hint violating frozen bounds was accepted')
    here=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    out=dict(sampling_cases=cases,solver_controls=outputs,invalid_hint_rejected=invalid_hint_rejected,
        hashes={n:sha(here/n) for n in [Path(__file__).name,'search_lp_trade_neighborhoods.py','solve_hinted_blocker_trades.py','solve_two_blocker_mip.py']})
    a.output.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))


if __name__=='__main__':main()
