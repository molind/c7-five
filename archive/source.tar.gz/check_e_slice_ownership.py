"""Metamorphic control: reorder slice IDs and duplicate a parent cycle.

The geometry and unique relative neighbor relations must remain unchanged.
Parent-occurrence counts may increase. Both runs use the independent dense
coordinate coverage checker, not merely identical search-output counts.
"""
from collections import Counter
import copy
import hashlib
import json
from pathlib import Path
import random
import subprocess
import sys

from check_slice_library import check
from search_slice_library import cycle_optimum

HERE = Path(__file__).parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    output = HERE/'e-slice-ownership-controls-sep21.json'
    if output.exists():
        raise FileExistsError(output)
    source_path = HERE/'slice-library-e-all-cycles-sep21.json'
    source = json.loads(source_path.read_text())
    reference_path = HERE/'exact-aligned-e-slices-all-sep21.json'
    reference = json.loads(reference_path.read_text())
    assert reference['status'] == 'complete' and reference['input_sha256'] == sha(source_path)
    changed = copy.deepcopy(source)
    order = list(range(len(source['slices'])))
    random.Random(2026092118).shuffle(order)
    inverse = {old:new for new, old in enumerate(order)}
    changed['slices'] = [source['slices'][old] for old in order]
    changed['adjacency'] = [sorted(inverse[v] for v in source['adjacency'][old]) for old in order]
    changed['weights'] = list(map(len, changed['slices']))
    changed['parents'] = [dict(p, slices=[inverse[v] for v in p['slices']]) for p in reversed(source['parents'])]
    # Choose a cycle with an actual edge in the tested transform interval.
    chosen = next(pl['parent'] for pl in reference['placements'] if pl['transform'] < 8)
    duplicate = dict(source['parents'][chosen], slices=[inverse[v] for v in source['parents'][chosen]['slices']])
    changed['parents'].append(duplicate)
    best, cycle = cycle_optimum(changed['weights'], changed['adjacency'])
    changed.update(best=best, cycle=cycle)
    words = sorted((layer, *w) for layer, sl in enumerate(cycle) for w in changed['slices'][sl])
    changed['candidates'] = [dict(step=0, size=best, words=[''.join(map(str, w)) for w in words], verified_pairs=best*(best-1)//2)]
    changed['stats']['degree_histogram'] = {str(k):v for k,v in Counter(map(len, changed['adjacency'])).items()}
    changed['stats']['slice_sizes'] = {str(k):v for k,v in Counter(changed['weights']).items()}
    changed.pop('parent_cycle_completion', None)
    changed['assembly'] = 'Control input with reordered slice IDs and one duplicate parent; unchanged geometry.'
    changed_path = HERE/'e-slice-ownership-control-input-sep21.json'
    verification_path = HERE/'e-slice-ownership-control-input-verification-sep21.json'
    placement_path = HERE/'e-slice-ownership-control-placements-sep21.json'
    coverage_path = HERE/'e-slice-ownership-control-coverage-sep21.json'
    for path in (changed_path, verification_path, placement_path, coverage_path):
        if path.exists():
            raise FileExistsError(path)
    verified = check(changed)
    changed_path.write_text(json.dumps(changed, indent=2)+'\n')
    verification_path.write_text(json.dumps(verified | dict(input_sha256=sha(changed_path)), indent=2)+'\n')
    commands = [
        ['search_slice_placements_exact.py', '--input', str(changed_path), '--verification', str(verification_path), '--count', '8', '--output', str(placement_path)],
        ['check_slice_placement_coverage.py', '--input', str(placement_path), '--output', str(coverage_path)],
    ]
    for command in commands:
        run = subprocess.run([sys.executable, str(HERE/command[0]), *command[1:]],
                             capture_output=True, text=True, timeout=90)
        if run.returncode:
            raise RuntimeError(run.stderr)
    actual = json.loads(placement_path.read_text())
    original_ids = {tuple(map(tuple, sl)):i for i, sl in enumerate(source['slices'])}

    def edges(report, library):
        unique, occurrences = set(), 0
        for placement in report['placements']:
            if placement['transform'] >= 8:
                continue
            for left, position in placement['cross_edges']:
                right = library['parents'][placement['parent']]['slices'][position]
                a = original_ids[tuple(map(tuple, library['slices'][left]))]
                b = original_ids[tuple(map(tuple, library['slices'][right]))]
                unique.add((placement['transform'], a, b, tuple(placement['shift'])))
                occurrences += 1
        return unique, occurrences

    expected, before = edges(reference, source)
    obtained, after = edges(actual, changed)
    assert expected == obtained and after > before
    assert actual['best'] == reference['best'] == 367
    result = dict(source_sha256=sha(Path(__file__)), reference_sha256=sha(reference_path),
        control_input_sha256=sha(changed_path), placement_sha256=sha(placement_path),
        coverage_sha256=sha(coverage_path), transforms=8, reordered_slices=len(order),
        original_parents=len(source['parents']), control_parents=len(changed['parents']),
        unique_relative_edges=len(expected), original_parent_occurrences=before,
        duplicate_parent_occurrences=after, identical_unique_geometry=True,
        scope='Reindexing and duplicate-parent control on8transforms, with independently rebuilt coordinate coverage. Not an additional C7 bound.')
    output.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
