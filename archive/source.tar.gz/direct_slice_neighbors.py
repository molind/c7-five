"""Prepare and collect exact compiled relative-neighbor enumeration artifacts."""
import argparse
import hashlib
from itertools import combinations
import json
from pathlib import Path
import struct

HERE=Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_edges(path):
    data=Path(path).read_bytes();assert data[:4]==b'C7RN'
    n,nt=struct.unpack_from('<II',data,4);assert 1<=n<=65535 and 1<=nt<=384
    offset=12;rows=[]
    for _ in range(n):
        count,=struct.unpack_from('<I',data,offset);offset+=4
        row=[]
        for _ in range(count):
            right,t,shift=struct.unpack_from('<HHH',data,offset);offset+=6
            assert right<n and t<nt and shift<2401
            row.append([right,t,shift])
        assert len(set(map(tuple,row)))==len(row)
        rows.append(row)
    assert data[offset:]==b'DONE'
    return rows,nt


def main():
    if not __debug__:raise RuntimeError('Run without -O')
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path)
    p.add_argument('--classes',type=Path)
    p.add_argument('--prefix',type=Path,required=True)
    p.add_argument('--count',type=int,default=384)
    p.add_argument('--collect',action='store_true')
    args=p.parse_args();prepared=Path(str(args.prefix)+'.prepared.json');output=Path(str(args.prefix)+'.json')
    if args.collect:
        if output.exists():raise FileExistsError(output)
        r=json.loads(prepared.read_text());assert r['kernel_sha256']==sha(HERE/'relative_slice_neighbors')
        assert r['input_sha256']==sha(r['input']) and r['encoded_input_sha256']==sha(r['encoded_input'])
        rows,nt=read_edges(Path(str(args.prefix)+'.bin'))
        assert len(rows)==len(r['base_indices']) and nt==r['count']
        r.update(status='complete',method='direct_relative_templates',neighbors=rows,
            binary_sha256=sha(Path(str(args.prefix)+'.bin')),collector_sha256=sha(__file__),
            slice_pairs=len(rows)**2*nt,edges=sum(map(len,rows)))
        output.write_text(json.dumps(r,separators=(',',':'))+'\n')
        print(json.dumps(dict(slices=len(rows),transforms=nt,edges=r['edges'],slice_pairs=r['slice_pairs'])),flush=True)
        return
    if prepared.exists() or output.exists() or Path(str(args.prefix)+'.txt').exists():raise FileExistsError(args.prefix)
    if not args.input or not 1<=args.count<=384:p.error('Input and transform count1..384 required')
    s=json.loads(args.input.read_text());indices=list(range(len(s['slices'])))
    if args.classes:
        c=json.loads(args.classes.read_text());assert c['input_sha256']==sha(args.input)
        indices=c['representatives'];assert len(indices)==len(set(indices))
    lines=[str(len(indices))]
    for i in indices:
        assert type(i)is int and 0<=i<len(s['slices'])
        sl=s['slices'][i];assert sl and len(sl)==len(set(map(tuple,sl)))
        assert all(len(w)==4 and all(type(x)is int and 0<=x<7 for x in w) for w in sl)
        assert all(any((x-y)%7 in (2,3,4,5) for x,y in zip(a,b)) for a,b in combinations(sl,2))
        ids=[sum(x*7**(3-k) for k,x in enumerate(w)) for w in sl]
        lines.append(' '.join(map(str,[len(ids),*ids])))
    encoded=Path(str(args.prefix)+'.txt');encoded.write_text('\n'.join(lines)+'\n')
    r=dict(input=str(args.input),input_sha256=sha(args.input),base_indices=indices,count=args.count,
        encoded_input=str(encoded),encoded_input_sha256=sha(encoded),kernel_sha256=sha(HERE/'relative_slice_neighbors'),
        kernel_source_sha256=sha(HERE/'relative_slice_neighbors.cpp'),preparer_sha256=sha(__file__),
        scope='All relative transforms of selected4Dslice shapes; no global C7 bound.')
    if args.classes:r.update(classes=str(args.classes),classes_sha256=sha(args.classes))
    prepared.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(dict(slices=len(indices),encoded_input=str(encoded))),flush=True)


if __name__=='__main__':main()
