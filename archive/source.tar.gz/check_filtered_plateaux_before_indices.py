"""Replay filtered plateau discovery edges directly in C7 coordinates.

Checks every discovered independent366 state and its parent transition, the
visited-state digest, intersection/union and farthest distance. Returned367/368
witnesses are checked pairwise. Ignored augmentations are checked for exact
membership in the referenced known cache; their occurrence counters are not
independently reconstructed. A truncated exploration proves no component bound.
"""
import argparse
import gzip
import hashlib
from itertools import product
import json
from pathlib import Path
import struct

import numpy as np


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();assert __debug__ and not a.output.exists()
    report=json.loads(a.input.read_text());assert report['status'] in ('bounded_filtered_search_complete','verified_target')
    source=Path(report['input']);assert hashlib.sha256(source.read_bytes()).hexdigest()==report['input_sha256']
    originals=json.loads(source.read_text());coords=np.array(list(product(range(7),repeat=5)))
    known=set()
    for ref in report['known_components']:
        path=Path(ref['file']);assert hashlib.sha256(path.read_bytes()).hexdigest()==ref['sha256']
        with gzip.open(path,'rt') as f:
            metadata=json.loads(next(f));assert metadata==ref['metadata']
            ids=[json.loads(line) for line in f]
        assert all(vs==sorted(vs) and len(vs)==len(set(vs))==367 for vs in ids)
        keys={struct.pack('<367H',*vs) for vs in ids}
        assert len(ids)==len(keys)==metadata['states']
        assert hashlib.sha256(b''.join(sorted(keys))).hexdigest()==metadata['component_sha256'];known.update(keys)
    assert len(known)==report['known_sets']
    def compatible(v,others):
        delta=(coords[others]-coords[v])%7
        return np.any((delta>=2)&(delta<=5),axis=1)
    def full_check(ids):
        assert len(ids)==len(set(ids)) and all(type(v) is int and 0<=v<16807 for v in ids)
        for i,v in enumerate(ids):assert compatible(v,ids[i+1:]).all()
        return len(ids)*(len(ids)-1)//2
    def ids_of(words):
        assert all(len(w)==5 and all(type(x) is int and 0<=x<7 for x in w) for w in words)
        return sorted(sum(x*7**(4-i) for i,x in enumerate(w)) for w in words)
    checks=0;rows=[]
    expected_bases=list(range(report['start'],report['start']+report['count']))
    if report['status']=='bounded_filtered_search_complete':assert len(report['rows'])==report['count']
    for qi,row in enumerate(report['rows']):
        bi=row['base'];assert bi==expected_bases[qi]
        r=row['result'];initial=originals['bases'][bi]['words'];assert len(initial)==366
        checks+=full_check(initial);packed=struct.pack('<366H',*initial)
        states=[packed];seen={packed};fixed=set(initial);union=set(initial);initial_mask=np.zeros(16807,dtype=bool);initial_mask[initial]=True
        max_removed=0
        for index,(parent,old,new) in enumerate(r['discovery'],1):
            assert type(parent) is int and 0<=parent<index and type(old) is int and type(new) is int and 0<=new<16807
            previous=np.frombuffer(states[parent],dtype='<u2');assert old in previous and new not in previous
            remaining=previous[previous!=old];assert len(remaining)==365 and compatible(new,remaining).all();checks+=365
            current=np.sort(np.append(remaining,new)).astype('<u2');key=current.tobytes();assert key not in seen
            states.append(key);seen.add(key);fixed.intersection_update(current.tolist());union.update(current.tolist())
            max_removed=max(max_removed,366-int(initial_mask[current].sum()))
        assert len(states)==r['states_visited'] and r['directed_moves_traversed']>=len(states)-1
        assert hashlib.sha256(b''.join(sorted(seen))).hexdigest()==r['component_sha256']
        assert ids_of(r['fixed_across_visited_words'])==sorted(fixed)
        assert ids_of(r['variable_across_visited_words'])==sorted(union-fixed)
        farthest=ids_of(r['farthest_words']);assert struct.pack('<366H',*farthest) in seen
        assert max_removed==r['max_removed_from_input']==len(set(initial)-set(farthest))
        ignored=[struct.pack('<367H',*vs) for vs in r['ignored_known_augmentations']]
        assert len(ignored)==len(set(ignored)) and set(ignored)<=known and r['ignored_known_hits']>=len(ignored)
        assert r['known_augmentation_filter'] and r['gain_two_checked_through_deletions']==1 and r['neutral_exchange_width']==1
        if r['improved_words'] is not None:
            full=ids_of(r['improved_words']);assert len(full) in (367,368);checks+=full_check(full)
            if len(full)==367:assert struct.pack('<367H',*full) not in known
            last=set(np.frombuffer(states[-1],dtype='<u2').tolist())
            assert len(last-set(full))<=1 and len(set(full)-last)==len(full)-366+len(last-set(full))
            assert r['status']=='improved'
        else:
            assert r['status'] in ('budget_exhausted','exhausted')
            if r['status']=='exhausted':assert r['remaining_stack_frames']==r['remaining_frame_moves']==0
        rows.append(dict(base=bi,status=r['status'],states=len(states),directly_checked_transitions=len(states)-1,
                         known_augmentations=len(ignored),max_removed=max_removed))
    actual={c['step']:c for c in report['candidates']}
    assert set(actual)=={r['base'] for r in report['rows'] if r['result']['improved_words'] is not None}
    for row in report['rows']:
        if row['base'] not in actual:continue
        c=actual[row['base']];words=[''.join(map(str,w)) for w in row['result']['improved_words']]
        assert words==c['words'] and len(words)==c['size'] and c['pair_checks']==len(words)*(len(words)-1)//2
    found=any(c['size']==368 for c in report['candidates']);assert (report['status']=='verified_target')==found
    out=dict(input=str(a.input),input_sha256=hashlib.sha256(a.input.read_bytes()).hexdigest(),checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
             rows=rows,coordinate_pair_checks=checks,target_found=found,scope=__doc__)
    a.output.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)


if __name__=='__main__':main()
