"""Exhaustive existence and ordered-result tests for conditional pair counts."""
from itertools import combinations
from pathlib import Path
import json, random, subprocess, sys
from check_exchange_dfs import graph_text

binary = Path(sys.argv[1]).resolve()
rng = random.Random(2026091912)
positive = 0
for case in range(320):
    n = rng.randrange(1, 11); d = rng.randrange(1, 5); prefix = rng.randrange(n+1)
    cb = [sum(1 << j for j in rng.sample(range(8), rng.randrange(4))) for _ in range(n)]
    comp = [0]*n
    for i,j in combinations(range(n),2):
        if rng.randrange(4): comp[i] |= 1 << j; comp[j] |= 1 << i
    singles = [rng.randrange(d+2) if rng.randrange(3)==0 else 0 for _ in range(n)]
    pairs = [(i,j,rng.randrange(d+3)) for i,j in combinations(range(n),2) if rng.randrange(4)==0]
    root = prefix if case % 4 == 0 else None
    limit = rng.randrange(d+1) if case % 3 == 0 else None
    for neutral in [False,True]:
        target = d if neutral else d+1
        expected = {'neutral':[], 'improving':[]}; witness = []
        for chosen in combinations(range(n), target):
            mask = 0
            for i in chosen: mask |= cb[i]
            if mask.bit_count() > d: continue
            if root is not None and not any(i < root for i in chosen): continue
            if not neutral and limit is not None and (mask >> 2).bit_count() > limit: continue
            required = max([0]+[singles[i] for i in chosen]+[k for a,b,k in pairs if a in chosen and b in chosen])
            if sum(i < prefix for i in chosen) < required: continue
            if not all(comp[i] >> j & 1 for i,j in combinations(chosen,2)): continue
            if not witness: witness = list(chosen)
            expected['neutral' if mask.bit_count()==d else 'improving'].append(list(chosen))
        positive += bool(witness)
        for subset in [False,True]:
            opts = ['--anchor-bounds',str(prefix),'--pair-bounds']
            if root is not None: opts += ['--root-prefix',str(root)]
            if neutral: opts += ['--neutral']
            elif limit is not None: opts += ['--noncore-limit','2',str(limit)]
            if subset: opts += ['--subset']
            data = graph_text(cb,comp,d,1)+' '.join(map(str,singles))+'\n'+str(len(pairs))+'\n'
            data += ''.join(f'{a} {b} {k}\n' for a,b,k in pairs)
            r = json.loads(subprocess.run([str(binary),'5',*opts],input=data,text=True,capture_output=True,check=True,timeout=7).stdout)
            if neutral:
                assert r['status']=='exhausted' and all(r[k]==v for k,v in expected.items())
                assert r['nodes_started']==r['nodes_completed']
            else:
                assert r['status']==('witness' if witness else 'exhausted') and r['chosen']==witness
# Pair endpoints straddling compatibility words, with and without a satisfying count.
for n in [64,65,128,129]:
    comp=[0]*n;comp[0]=1<<(n-1);comp[n-1]=1
    data=graph_text([1]*n,comp,1,1)+' '.join(['0']*n)+f'\n1\n0 {n-1} 2\n'
    for prefix in [n-1,n]:
        r=json.loads(subprocess.run([str(binary),'5','--anchor-bounds',str(prefix),'--pair-bounds'],input=data,text=True,capture_output=True,check=True,timeout=7).stdout)
        assert r['chosen']==([0,n-1] if prefix==n else [])
base=graph_text([1]*3,[6,5,3],2,1)+'0 0 0\n'
bad=['','-1\n','200001\n','1\n','1\n0 3 1\n','1\n1 1 2\n','1\n2 1 2\n','1\n0 1 20001\n']
for trailer in bad:
    r=subprocess.run([str(binary),'5','--anchor-bounds','3','--pair-bounds'],input=base+trailer,text=True,capture_output=True,timeout=7)
    assert r.returncode!=0
r=subprocess.run([str(binary),'5','--pair-bounds'],input=base,text=True,capture_output=True,timeout=7)
assert r.returncode!=0
report=dict(cases=320,modes=4,positive_mode_cases=positive,boundary_runs=8,invalid_controls=9,seed=2026091912,binary=str(binary))
Path(__file__).with_name(binary.name+'-pair-count-controls.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report),flush=True)
