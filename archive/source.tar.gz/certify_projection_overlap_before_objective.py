"""Integer dual bound on retained hint words at the requested cardinality.

For A*x<=b, sum(x)=t, 0<=x<=1, use nonnegative integer row
weights Y, a signed equality weight Z, and nonnegative upper-bound weights U.
If A^T Y + Z + U >= D*h, then h*x <= (b*Y+t*Z+sum(U))/D.
The replay uses Python integer arithmetic; LP optimality is unnecessary.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path

from search_with_clique_cycles import load_proof


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def replay(certificate,model,matrix,caps):
    denominator=certificate['denominator'];z=certificate['equality_units']
    y=certificate['row_units'];u=certificate['upper_units'];target=certificate['target']
    assert type(denominator) is int and denominator>0 and type(z) is int
    assert type(target) is int and target==368-len(model['fixed'])
    assert len(y)==matrix.shape[0] and len(u)==matrix.shape[1]
    assert all(type(v) is int and v>=0 for v in y+u)
    coefficients=[z+v for v in u]
    total=target*z+sum(u)
    rows=matrix.tocsr()
    for i,weight in enumerate(y):
        assert float(caps[i]).is_integer()
        total+=int(caps[i])*weight
        for k in range(rows.indptr[i],rows.indptr[i+1]):
            assert float(rows.data[k]).is_integer()
            coefficients[int(rows.indices[k])]+=int(rows.data[k])*weight
    hint=set(model['hint'])
    assert all(value>=denominator*int(i in hint) for i,value in enumerate(coefficients))
    assert total==certificate['total_units'] and total//denominator==certificate['integer_overlap_upper']
    assert len(hint)==certificate['hint_size'] and len(hint)<target
    assert len(hint)-total//denominator==certificate['minimum_omissions']
    # A larger independent completion can be trimmed to t while retaining all
    # selected hint words, since the entire hint has fewer than t words.
    return dict(variables=len(coefficients),rows=len(y),total_units=total,denominator=denominator,
                integer_overlap_upper=total//denominator,minimum_omissions=certificate['minimum_omissions'],
                applies_to='All independent completions of the fixed exterior with full size at least368.')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True)
    p.add_argument('--base-verification',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--verify',action='store_true')
    a=p.parse_args();assert __debug__ and not a.output.exists()
    source=json.loads(a.input.read_text())
    numerical=json.loads(Path(source['input']).read_text()) if a.verify else source
    if a.verify:assert digest(source['input'])==source['input_sha256']
    assert digest(numerical['cuts_input'])==numerical['cuts_input_sha256']
    proof,model,matrix,caps=load_proof(Path(numerical['cuts_input']),a.base_verification)
    assert numerical['model_sha256']==proof['model_sha256']
    if a.verify:
        assert digest(a.base_verification)==source['base_verification_sha256']
        result=replay(source,model,matrix,caps)
        result.update(input_sha256=digest(a.input),checker_sha256=digest(__file__))
    else:
        assert numerical['status']==0
        d=1000000;y=[max(0,math.ceil(-v*d)) for v in numerical['inequality_dual']]
        z=round(-numerical['equality_dual'][0]*d)
        assert len(y)==matrix.shape[0]
        coefficients=[z]*len(model['pool']);rows=matrix.tocsr()
        for i,weight in enumerate(y):
            for k in range(rows.indptr[i],rows.indptr[i+1]):
                coefficients[int(rows.indices[k])]+=int(rows.data[k])*weight
        hint=set(model['hint']);u=[max(0,d*int(i in hint)-v) for i,v in enumerate(coefficients)]
        target=368-len(model['fixed']);total=sum(int(cap)*weight for cap,weight in zip(caps,y))+target*z+sum(u)
        result=dict(input=str(a.input),input_sha256=digest(a.input),base_verification=str(a.base_verification),
                    base_verification_sha256=digest(a.base_verification),source_sha256=digest(__file__),
                    denominator=d,row_units=y,equality_units=z,upper_units=u,total_units=total,target=target,
                    hint_size=len(hint),integer_overlap_upper=total//d,minimum_omissions=len(hint)-total//d)
        result['verification']=replay(result,model,matrix,caps)
    a.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('row_units','upper_units')}),flush=True)


if __name__=='__main__':main()
