"""Audit improving root intervals around one pinned 367-word reference.

Replays exact lower-degree certificates, checks pool coverage by direct
coordinate comparisons and reconstructs native graphs from verified geometry.
An earlier hash-bound radius audit supplies the induction premise. Native
exhaustion still relies on the tested kernel, not an independent proof trace.
"""
import argparse
import hashlib
from itertools import combinations, product
import json
from pathlib import Path

import numpy as np

from check_blocker_radius import check as check_radius
from check_farthest_exchange_inputs import conflict_rows


def audit(seed, previous, queries):
    here = Path(__file__).resolve().parent
    dependencies = {}

    def sha(path):
        return hashlib.sha256(Path(path).read_bytes()).hexdigest()

    def read(path):
        dependencies[str(path)] = sha(path)
        return json.loads(Path(path).read_text())

    tokens = Path(seed).read_text().split()
    assert all(len(t) == 5 and set(t) <= set('0123456') for t in tokens)
    reference = sorted(int(t, 7) for t in tokens)
    assert len(reference) == len(set(reference)) == 367
    dependencies[str(seed)] = sha(seed)
    coords = np.array(list(product(range(7), repeat=5)), dtype=np.int16)
    old = coords[reference]
    blockers = []
    for _, bad in conflict_rows(coords, old):
        blockers.extend(np.flatnonzero(row).tolist() for row in bad)
    assert all(blockers[v] == [i] for i, v in enumerate(reference))
    outside = sorted(set(range(16807)) - set(reference))
    assert all(blockers[v] for v in outside), 'A free insertion would already improve the reference'

    prior = read(previous)
    assert prior['checker_sha256'] == sha(here / 'check_seed_exchange_results.py')
    assert prior['dependencies'][str(seed)] == sha(seed)
    assert all(sha(p) == h for p, h in prior['dependencies'].items())
    assert not prior['target_sets']
    bound = prior['full_local_radius_excluded']
    assert type(bound) is int and bound >= 2
    previous_bound = bound
    models, prefixes, graphs = {}, {}, {}
    segments = {}
    target_sets = []
    for path in queries:
        run = read(path)
        assert run['status'] in ('complete', 'verified_target')
        assert run['source_sha256'] == sha(here / 'run_four_blocker_dfs.py')
        for name in ('kernel', 'kernel_source'):
            assert run[name + '_sha256'] == sha(run[name])
            dependencies[run[name]] = sha(run[name])
        assert run['kernel_sha256'] == sha(here / 'exchange_dfs_residual_two')
        assert run['kernel_source_sha256'] == sha(here / 'exchange_dfs_residual_two.cpp')
        assert run['binary_budget'] and run['residual_budget'] and run['budget_bitsets'] and run['degree_order']
        assert 'count_proof' not in run
        radius = run['max_removals']
        assert type(radius) is int and previous_bound < radius <= 10
        assert run['target_insertions'] == radius + 1
        mp = run['input']
        assert run['input_sha256'] == sha(mp)
        if mp not in models:
            model = read(mp)
            assert model['status'] == 'complete' and model['min_blockers'] == 1
            assert model['input_sha256'] == sha(model['input'])
            bases = read(model['input'])['bases']
            geom = read(run['geometry_proof'])
            assert geom['model_sha256'] == sha(mp)
            assert geom['checker_sha256'] == sha(here / 'check_blocker_trade_results.py')
            assert len(model['rows']) == len(geom['rows']) == 1
            domain = model['rows'][0]
            bi = domain['base']
            assert bases[bi]['words'] == reference
            assert next(r for r in geom['rows'] if r['base'] == bi)['all_16807_blocker_rows_checked']
            assert domain['pool_ids'] == [v for v in outside if len(blockers[v]) <= model['max_blockers']]
            assert domain['blocker_sets'] == [blockers[v] for v in domain['pool_ids']]
            models[mp] = (model, domain)
        model, domain = models[mp]
        assert radius <= model['max_blockers']
        assert run['geometry_proof_sha256'] == sha(run['geometry_proof'])
        assert read(run['geometry_proof'])['model_sha256'] == sha(mp)
        pp = run['prefix_proof']
        assert run['prefix_proof_sha256'] == sha(pp)
        if pp not in prefixes:
            proof = read(pp)
            assert proof['checker_sha256'] == sha(here / 'check_blocker_radius.py')
            assert proof['input_sha256'] == sha(proof['input'])
            cert = read(proof['input'])
            assert cert['status'] == 'complete' and cert['input_sha256'] == sha(cert['input'])
            lower = read(cert['input'])
            assert lower['status'] == 'complete' and lower['min_blockers'] == 1
            assert lower['input_sha256'] == model['input_sha256']
            assert proof['geometry_proof_sha256'] == sha(proof['geometry_proof'])
            lg = read(proof['geometry_proof'])
            assert lg['model_sha256'] == sha(cert['input'])
            assert lg['checker_sha256'] == sha(here / 'check_blocker_trade_results.py')
            assert len(lower['rows']) == len(cert['rows']) == len(proof['rows']) == 1
            ld = lower['rows'][0]
            assert ld['base'] == domain['base']
            degree = lower['max_blockers'] + 1
            assert list(zip(ld['pool_ids'], ld['blocker_sets'])) == [(v, blockers[v]) for v in outside if len(blockers[v]) < degree]
            checked = check_radius(cert['rows'][0], ld)
            assert checked == proof['rows'][0] and checked['integer_gain_upper'] == 0
            assert 'max_four_insertions' not in checked
            prefixes[pp] = (degree, checked['max_removals'], lower['input_sha256'])
        degree, cap, ref_hash = prefixes[pp]
        assert ref_hash == model['input_sha256'] and cap >= radius
        assert run['prefix_blocker_degree'] == degree <= model['max_blockers']
        pool, blocked = domain['pool_ids'], domain['blocker_sets']
        n = len(pool)
        order = sorted(range(n), key=lambda i: (len(blocked[i]) < degree, -len(blocked[i]), pool[i]))
        prefix = sum(len(b) >= degree for b in blocked)
        assert len(run['rows']) == 1
        row = run['rows'][0]
        assert row['base'] == domain['base'] and row['mode'] == 'improve'
        assert row['kernel_order'] == order and row['prefix'] == prefix and row['rows_replayed'] == n
        assert row['minimum_prefix_insertions'] == 1
        graph = row['graph']
        gh = sha(graph)
        assert gh == row['graph_sha256']
        dependencies[graph] = gh
        if gh not in graphs:
            inverse = {i: j for j, i in enumerate(order)}
            bad = [1 << j for j in range(n)]
            for u, v in domain['conflict_edges']:
                i, j = inverse[u], inverse[v]
                bad[i] |= 1 << j
                bad[j] |= 1 << i
            with Path(graph).open() as f:
                assert list(map(int, next(f).split())) == [n, 6, radius]
                for j, i in enumerate(order):
                    words = [int(w, 16) for w in next(f).split()]
                    assert len(words) == 6 + (n + 63) // 64 and all(0 <= w < 1 << 64 for w in words)
                    assert sum(w << (64*k) for k, w in enumerate(words[:6])) == sum(1 << b for b in blocked[i])
                    assert sum(w << (64*k) for k, w in enumerate(words[6:])) == ((1 << n) - 1) ^ bad[j]
                assert not f.read().strip()
            graphs[gh] = (mp, radius, degree)
        assert graphs[gh] == (mp, radius, degree)
        k = row['kernel_result']
        assert k['status'] in ('timeout', 'exhausted', 'witness')
        assert k['subset_index'] and k['binary_budget'] and k['residual_budget'] and k['budget_bitsets']
        assert not k['enumerate_neutral'] and not k['anchor_bounds'] and not k['pair_bounds'] and not k['noncore_bound']
        assert not k['neutral'] and not k['improving']
        assert all(type(k[f]) is int for f in ('root_start', 'root_end', 'next_root'))
        assert row['root_start'] == k['root_start'] and row['root_end'] == k['root_end'] == k['root_prefix']
        assert 0 <= k['root_start'] <= k['next_root'] <= k['root_end'] <= prefix
        if k['status'] == 'exhausted':
            assert k['next_root'] == k['root_end'] and k['nodes_started'] == k['nodes_completed']
        if k['status'] == 'witness':
            chosen = k['chosen']
            assert len(chosen) == len(set(chosen)) == radius + 1
            assert all(type(i) is int and 0 <= i < n for i in chosen)
            assert k['root_start'] <= min(chosen) < k['root_end']
            selected = sorted(order[i] for i in chosen)
            removed = sorted({j for i in selected for j in blocked[i]})
            assert len(removed) <= radius
            words = sorted((set(reference) - {reference[i] for i in removed}) | {pool[i] for i in selected})
            assert len(words) >= 368
            assert all(any((int(a)-int(b)) % 7 in (2, 3, 4, 5) for a, b in zip(coords[u], coords[v])) for u, v in combinations(words, 2))
            expected = [''.join(map(str, coords[v])) for v in words]
            assert len(run['candidates']) == 1 and run['candidates'][0]['words'] == expected
            assert run['status'] == 'verified_target'
            target_sets.append(words)
        else:
            assert not k['chosen'] and not run['candidates'] and run['status'] == 'complete'
        key = (radius, gh, prefix)
        segments.setdefault(key, []).append(dict(file=str(path),start=k['root_start'],end=k['next_root'],status=k['status']))
    rows = []
    for (radius, gh, prefix), parts in sorted(segments.items()):
        end = 0
        for part in sorted(parts, key=lambda r: r['start']):
            assert part['start'] == end, 'Gap or overlap in completed root intervals'
            end = part['end']
        complete = end == prefix
        if complete and radius == bound + 1:
            bound = radius
        rows.append(dict(radius=radius,graph_sha256=gh,closed_until=end,root_end=prefix,
                         target_insertions_excluded=complete,segments=parts))
    return dict(dependencies=dependencies,rows=rows,previous_radius=previous_bound,
                full_local_radius_excluded=bound,minimum_removed_for_368=bound+1,target_sets=target_sets)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--seed', required=True)
    p.add_argument('--previous', required=True)
    p.add_argument('--queries', required=True, nargs='+')
    p.add_argument('--output', required=True, type=Path)
    a = p.parse_args()
    assert __debug__ and not a.output.exists()
    inputs = {k: v for k, v in vars(a).items() if k != 'output'}
    result = audit(**inputs)
    out = dict(checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), inputs=inputs, scope=__doc__, **result)
    a.output.write_text(json.dumps(out, indent=2) + '\n')
    print(json.dumps(dict(full_local_radius_excluded=result['full_local_radius_excluded'],
                         rows=[{k:v for k,v in r.items() if k!='segments'} for r in result['rows']], targets=len(result['target_sets']))))


if __name__ == '__main__':
    main()
