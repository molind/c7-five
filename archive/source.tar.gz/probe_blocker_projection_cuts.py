"""Add strip/plane capacity cuts to a bounded-blocker trade model.

All non-free coordinates lie in adjacent pairs. Projection of an independent
set onto the free coordinates is injective and independent. One free C7 axis
has capacity3. Two have capacity10: each adjacent-row pair has at most3 columns,
so summing seven such inequalities gives twice the cardinality at most21.

Uses the existing cylinder generator. Optional higher-dimensional capacities
follow its adjacent-layer recurrence, or the explicitly cited published cubic
theorem when --published-cube is selected; that computation is not replayed here.

LP objectives are floating-point diagnostics, not exact rational certificates.
"""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import time

import numpy as np
from scipy.optimize import linprog

from solve_two_blocker_mip import build_model
from cylinder_bounds import constraints, CAPACITY, PUBLISHED_CAPACITY, PUBLISHED_SOURCE


def projection_cuts(pool, old, dimensions, capacities=None):
    """Return complete domain memberships, retaining an anchor for each cut."""
    assert len(set(pool+old))==len(pool)+len(old)
    members,descriptions,_=constraints(pool+old,dimensions,capacities)
    out=[];n=len(pool)
    for vs,d in zip(members,descriptions):
        candidates=[i for i in vs if i<n];old_indices=[i-n for i in vs if i>=n]
        assert len(old_indices)<=d['capacity']
        if candidates:
            out.append(dict(free_coordinates=d['free'],anchor=[max(0,v) for v in d['origin']],
                capacity=d['capacity'],candidates=candidates,old_indices=old_indices))
    return out


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--dimensions',type=int,choices=(1,2,3,4),nargs='+',default=[1,2])
    p.add_argument('--published-cube',action='store_true',help='Use the cited published cubic capacity33 and its derived four-dimensional bound115.')
    p.add_argument('--seconds',type=float,default=30)
    a=p.parse_args();assert __debug__ and not a.output.exists() and a.seconds>0
    assert len(set(a.dimensions))==len(a.dimensions)
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    data=json.loads(a.input.read_text());assert data['status']=='complete'
    source=Path(data['input']);assert sha(source)==data['input_sha256']
    bases=json.loads(source.read_text())['bases'];out=copy.deepcopy(data);out['status']='running'
    capacities=PUBLISHED_CAPACITY if a.published_cube else CAPACITY
    out['projection_capacities']=capacities
    out['projection_dependency']=dict(url=PUBLISHED_SOURCE,theorem=4,printed_page=102,local_computation_replayed=False,
        pdf='research/c7/sources/baumert-packing-1971.pdf',pdf_sha256=sha(Path(__file__).with_name('sources')/'baumert-packing-1971.pdf')) if a.published_cube else None
    out['projection_probe']=dict(input=str(a.input),input_sha256=sha(a.input),source_sha256=sha(__file__),
        builder_sha256=sha(Path(__file__).with_name('solve_two_blocker_mip.py')),
        cylinder_source_sha256=sha(Path(__file__).with_name('cylinder_bounds.py')),
        dimensions=a.dimensions,seconds_per_lp=a.seconds,rows=[],scope=__doc__)
    def save():
        temp=a.output.with_suffix('.tmp');temp.write_text(json.dumps(out,separators=(',',':'))+'\n');temp.replace(a.output)
    save()
    for domain in out['rows']:
        assert not domain.get('projection_cuts')
        cuts=projection_cuts(domain['pool_ids'],bases[domain['base']]['words'],a.dimensions,capacities)
        for label in ('base','projection'):
            if label=='projection':domain['projection_cuts']=cuts
            A,lo,hi,c=build_model(domain,'improve');assert np.all(np.isneginf(lo))
            assert np.all(hi>=0)  # The unchanged independent reference remains feasible.
            start=time.monotonic()
            lp=linprog(c,A_ub=A,b_ub=hi,bounds=(0,1),method='highs-ipm',options={'time_limit':a.seconds})
            row=dict(base=domain['base'],label=label,status=int(lp.status),seconds=time.monotonic()-start,
                gain_bound=-float(lp.fun) if lp.success else None,
                cut_counts={str(k):sum(len(c['free_coordinates'])==k for c in domain.get('projection_cuts',[])) for k in a.dimensions})
            if lp.success:assert np.all(A@lp.x<=hi+1e-6)
            out['projection_probe']['rows'].append(row);save();print(json.dumps(row),flush=True)
    out['status']='complete';save()


if __name__=='__main__':main()
