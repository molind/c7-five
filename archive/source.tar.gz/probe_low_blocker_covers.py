"""Try one shared adjacent-box cover of all vertices with few core blockers.

Keep the first pool whose exact box-cover optimum is above 367, or stop if
the bounded solver queries fail to provide matching certificates.
"""
import json
from fractions import Fraction
from pathlib import Path
import one_core_cover_replay as p
from optimize_cover_structure import optimize

ROOT = Path(__file__).resolve().parent


def main():
    initial = json.loads((ROOT/'cover-low-blocker-optimum.json').read_text())
    initial['blocker_radius'] = 1
    assert initial['optimum_proved'] and Fraction(initial['primal_total']) == 367
    cases = [initial]
    output = ROOT/'shared-low-blocker-covers.json'
    for radius in (2, 3):
        words = [w for w, mask in zip(p.W, p.blocked) if mask.bit_count() <= radius]
        result = optimize(words)
        result.update(blocker_radius=radius, words=words)
        cases.append(result)
        output.write_text(json.dumps({'protocol': 'Joint cover of all low-blocker vertices; stop at radius3 or first proved optimum>367 or unresolved optimization.', 'cases': cases}, indent=2)+'\n')
        print(json.dumps({k: v for k, v in result.items() if k not in ('cover', 'dual', 'words')}), flush=True)
        if not result.get('optimum_proved') or Fraction(result['primal_total']) > 367:
            break


if __name__ == '__main__':
    main()
