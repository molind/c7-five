"""Extract checked equal-size trade endpoints and analyze their local unions."""
import argparse
import hashlib
from itertools import combinations, product
import json
from pathlib import Path

from analyze_bipartite_trade import analyze_trade
from check_neutral_trades import union_states


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path, nargs='+', required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    assert __debug__ and not a.output.exists()
    sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
    coords = list(product(range(7), repeat=5))
    def compatible(u, v):
        return any((x-y) % 7 in (2, 3, 4, 5) for x, y in zip(coords[u], coords[v]))
    bases = []
    for path in a.input:
        data = json.loads(path.read_text())
        assert data['status'] == 'complete'
        mp = Path(data['input']); assert sha(mp) == data['input_sha256']
        model = json.loads(mp.read_text())
        sp = Path(model['input']); assert sha(sp) == model['input_sha256']
        starts = json.loads(sp.read_text())['bases']
        for candidate in data['candidates']:
            assert candidate['size'] == 366
            original = starts[candidate['source_base']]['words']
            full = sorted(int(w, 7) for w in candidate['words'])
            assert len(full) == len(set(full)) == len(original) == len(set(original)) == 366
            assert all(compatible(u, v) for group in (original, full) for u, v in combinations(group, 2))
            old = sorted(set(original)-set(full)); new = sorted(set(full)-set(original))
            if not old: continue
            assert len(old) == len(new)
            analysis = analyze_trade(old, new, compatible)
            blockers = [sum(1 << i for i, u in enumerate(old) if not compatible(u, v)) for v in new]
            assert len(new) <= 16  # Bound the independent exhaustive subset check.
            maximum, width = union_states(old, new, blockers)
            assert maximum == len(analysis['maximum']) == len(old)
            assert width == analysis['minimum_step_width']
            free = [v for v in range(16807) if v not in full and all(compatible(v, u) for u in full)]
            assert not free
            row = dict(source=str(path), source_sha256=sha(path), source_base=candidate['source_base'],
                       words=full, removed=old, added=new, analysis=analysis,
                       local_blockers=blockers, subset_checks=1 << len(new),
                       pair_checks=2*366*365//2, free=free)
            if full not in [b['words'] for b in bases]: bases.append(row)
            print(json.dumps({k: v for k, v in row.items() if k != 'words'}), flush=True)
    out = dict(status='complete', source_sha256=sha(__file__),
               inputs={str(p): sha(p) for p in a.input}, bases=bases, scope=__doc__)
    a.output.write_text(json.dumps(out, indent=2)+'\n')


if __name__ == '__main__': main()
