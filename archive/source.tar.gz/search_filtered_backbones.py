"""Continue366 plateau searches past explicitly known367 augmentations."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import struct
import time

from search_exchanges import verify
from search_plateau import search


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True)
    p.add_argument('--known-component',type=Path,nargs='+',required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--indices',type=int,nargs='+')
    p.add_argument('--start',type=int,default=0)
    p.add_argument('--count',type=int,default=12)
    p.add_argument('--seconds',type=float,default=5)
    p.add_argument('--states',type=int,default=12000)
    p.add_argument('--width',type=int,choices=[1,2],default=1)
    p.add_argument('--prefer-unknown-region',action='store_true')
    a=p.parse_args();assert __debug__ and not a.output.exists()
    assert a.start>=0 and a.count>0 and a.seconds>0 and a.states>0
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    source=json.loads(a.input.read_text());assert source['status']=='complete'
    indices=a.indices if a.indices is not None else list(range(a.start,a.start+a.count))
    assert len(indices)==len(set(indices)) and all(0<=i<len(source['bases']) for i in indices)
    known=set();references=[]
    for path in a.known_component:
        with gzip.open(path,'rt') as f:
            metadata=json.loads(next(f));keys=set()
            for line in f:
                ids=json.loads(line)
                assert len(ids)==len(set(ids))==367 and ids==sorted(ids)
                assert all(type(v) is int and 0<=v<16807 for v in ids)
                keys.add(struct.pack('<367H',*ids))
        assert metadata['cardinality']==367 and len(keys)==metadata['states']
        assert hashlib.sha256(b''.join(sorted(keys))).hexdigest()==metadata['component_sha256']
        known.update(keys);references.append(dict(file=str(path),sha256=sha(path),metadata=metadata))
    report=dict(input=str(a.input),input_sha256=sha(a.input),source_sha256=sha(__file__),
                search_source_sha256=sha(Path(__file__).with_name('search_plateau.py')),
                known_components=references,known_sets=len(known),start=a.start,count=len(indices),base_indices=indices,
                status='running',rows=[],candidates=[],width=a.width,scope='One-for-one moves and selected two-for-two moves generate the corresponding component. Some decomposable two-for-two moves are omitted. Known367 augmentations are skipped; gain-two tests through the selected deletion width seek368. A budget limit does not close a component. Unseen367 is not automatically a new family.')
    began=time.monotonic()
    def save():
        report['seconds']=time.monotonic()-began
        tmp=a.output.with_suffix('.tmp');tmp.write_text(json.dumps(report,separators=(',',':'))+'\n');tmp.replace(a.output)
    save()
    for bi in indices:
        base=source['bases'][bi]
        words=[[v//7**j%7 for j in range(4,-1,-1)] for v in base['words']]
        assert len(words)==366;verify(words)
        result=search(words,a.seconds,a.states,a.width,known_augmentations=known,prefer_unknown_region=a.prefer_unknown_region)
        report['rows'].append(dict(base=bi,result=result))
        if result['improved_words'] is not None:
            full=result['improved_words'];checks=verify(full)
            assert len(full) in (367,368)
            encoded=struct.pack('<'+str(len(full))+'H',*sorted(int(''.join(map(str,w)),7) for w in full))
            assert len(full)==368 or encoded not in known
            report['candidates'].append(dict(step=bi,words=[''.join(map(str,w)) for w in full],size=len(full),pair_checks=checks))
            if len(full)==368:report['status']='verified_target';save();return
        save();print(json.dumps(dict(base=bi,status=result['status'],states=result['states_visited'],ignored=result['ignored_known_hits'],new_augmentation=len(result['improved_words'] or []))),flush=True)
    report['status']='bounded_filtered_search_complete';save()


if __name__=='__main__':main()
