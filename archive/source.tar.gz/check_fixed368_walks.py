"""Replay fixed-size replacement histories using separately built coordinate masks.

This checks actual moves, endpoint claims and archived subsets. It does not
reproduce RNG choices or prove that a bounded heuristic search was exhaustive.
"""
import argparse
from collections import defaultdict
from functools import lru_cache
import gzip
import hashlib
from itertools import product
import json
from pathlib import Path

import numpy as np

WORDS = np.array(list(product(range(7), repeat=5)), dtype=np.int16)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    with (gzip.open if Path(path).suffix == '.gz' else open)(path, 'rt') as f:
        return json.load(f)


def ids(tokens, size):
    assert len(tokens) == size
    assert all(isinstance(w, str) and len(w) == 5 and set(w) <= set('0123456') for w in tokens)
    result = {int(w, 7) for w in tokens}
    assert len(result) == size
    return result


def bits(values):
    return sum(1 << v for v in values)


@lru_cache(None)
def neighbors(v):
    digits = [int(x) for x in WORDS[v]]
    mask = 0
    for a, b, c, d, e in product(*[[(x-1) % 7, x, (x+1) % 7] for x in digits]):
        w = 2401*a+343*b+49*c+7*d+e
        if w != v:
            mask |= 1 << w
    return mask


def direct_energy(values):
    """Explicit differences for all unordered pairs, independent of masks."""
    points = WORDS[sorted(values)]
    delta = (points[:, None, :]-points[None, :, :]) % 7
    close = np.all((delta == 0) | (delta == 1) | (delta == 6), axis=2)
    return int(np.triu(close, 1).sum())


def check(data):
    start = ids(data['start_words'], 368)
    state = set(start)
    mask = start_mask = bits(start)
    energy = direct_energy(start)
    best_energy, best_state = energy, set(start)
    max_energy, max_distance = energy, 0
    e1_states = set()
    archives = defaultdict(list)
    assert data['candidate_count'] == len(data['candidates'])
    distinct_candidates = set()
    for candidate in data['candidates']:
        words = ids(candidate['words'], 367)
        encoded = bits(words)
        assert encoded not in distinct_candidates
        distinct_candidates.add(encoded)
        assert 1 <= candidate['step'] <= len(data['moves'])
        assert direct_energy(words) == 0
        archives[candidate['step']].append((candidate, encoded))
    traces = {row['step']: row for row in data['trace']}
    assert len(traces) == len(data['trace'])
    assert all(1 <= step <= len(data['moves']) for step in traces)
    assert len(data['moves']) == data['steps']
    for step, move in enumerate(data['moves'], 1):
        assert len(move) == 3 and all(type(v) is int for v in move)
        old, new, expected = move
        assert old in state and new not in state and 0 <= new < 16807
        state.remove(old)
        mask ^= 1 << old
        energy += (neighbors(new) & mask).bit_count() - (neighbors(old) & mask).bit_count()
        state.add(new)
        mask |= 1 << new
        assert len(state) == 368 and energy == expected and energy >= 0
        distance = 368-(mask & start_mask).bit_count()
        max_energy, max_distance = max(max_energy, energy), max(max_distance, distance)
        if energy < best_energy or (energy == best_energy and distance > len(start-best_state)):
            best_energy, best_state = energy, set(state)
        if energy == 1:
            e1_states.add(mask)
        for candidate, encoded in archives[step]:
            removed = candidate['removed']
            assert removed in state and (mask ^ (1 << removed)) == encoded
            assert candidate['energy'] == energy
        if step in traces:
            assert traces[step]['energy'] == energy and traces[step]['distance'] == distance
    assert state == ids(data['final_words'], 368)
    assert energy == data['final_energy'] == direct_energy(state)
    assert best_state == ids(data['best_words'], 368)
    assert best_energy == data['best_energy'] == direct_energy(best_state)
    assert max_energy == data['max_energy'] and max_distance == data['max_distance_from_start']
    assert len(e1_states) == data['unique_E1_states']
    independent_size = None
    if data['independent_words'] is not None:
        independent_size = len(data['independent_words'])
        assert independent_size in (367, 368)
        independent = ids(data['independent_words'], independent_size)
        assert independent <= state and direct_energy(independent) == 0
    if data['status'] == 'independent368':
        assert independent_size == 368 and energy == 0
    else:
        assert energy > 0
    return dict(steps=len(data['moves']), candidates=len(data['candidates']),
                best_energy=best_energy, final_energy=energy, max_energy=max_energy,
                max_distance=max_distance, independent_size=independent_size,
                direct_pair_checks=3*67528+len(data['candidates'])*67161,
                exact_neighbor_intersections=2*len(data['moves']))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('inputs', nargs='+', type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    if not __debug__:
        raise RuntimeError('Run without -O')
    if args.output.exists():
        raise FileExistsError(args.output)
    rows = []
    for path in args.inputs:
        data = load(path)
        source = data.get('start_source')
        if source:
            assert sha(source['file']) == source['sha256']
            assert ids(load(source['file'])['final_words'], 368) == ids(data['start_words'], 368)
        row = dict(file=str(path), sha256=sha(path), **check(data))
        rows.append(row)
        print(json.dumps(row), flush=True)
    result = dict(rows=rows, source_sha256=sha(__file__),
                  scope='Exact move replay, direct endpoint and archived-code pair checks. No RNG-policy replay, external replay, or search-exhaustion claim.')
    args.output.write_text(json.dumps(result, indent=2)+'\n')


if __name__ == '__main__':
    main()
