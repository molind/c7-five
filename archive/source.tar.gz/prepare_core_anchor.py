"""Prepare the full family-C d7 graph with U2-excluded words first."""
import contextlib,hashlib,io,json,runpy
from itertools import product
from pathlib import Path
from check_exchange_dfs import graph_text
p=Path(__file__).parent
with contextlib.redirect_stdout(io.StringIO()) as out:
    cert=runpy.run_path(str(p/'shared_u2_compact_replay.py'))
print(out.getvalue(),end='')
tokens=(p/'exchange-dfs-family-c-words.txt').read_text().split()
assert hashlib.sha256(' '.join(tokens).encode()).hexdigest()=='7fed46596bf35cb433d9e81c7a13f3b1fb3d6cfe31f1d8905f286556b87cb21c'
state=[tuple(map(int,w)) for w in tokens]
assert state[:308]==cert['core'] and set(state)<=cert['U2']
occupied=set(state);coord=[[0]*7 for _ in range(5)]
for i,w in enumerate(state):
    for k,x in enumerate(w):coord[k][x]|=1<<i
pool=[];blockers={};coremask=(1<<308)-1
for w in product(range(7),repeat=5):
    if w in occupied:continue
    mask=(1<<367)-1
    for k,x in enumerate(w):mask&=coord[k][(x-1)%7]|coord[k][x]|coord[k][(x+1)%7]
    if mask.bit_count()<=7:pool.append(w);blockers[w]=mask
pool.sort(key=lambda w:(((blockers[w]&coremask).bit_count()<3),blockers[w].bit_count()))
anchors=sum((blockers[w]&coremask).bit_count()>=3 for w in pool)
assert all((w not in cert['U2'])==(i<anchors) for i,w in enumerate(pool))
pc=[[0]*7 for _ in range(5)]
for i,w in enumerate(pool):
    for k,x in enumerate(w):pc[k][x]|=1<<i
full=(1<<len(pool))-1;comp=[]
for w in pool:
    mask=full
    for k,x in enumerate(w):mask&=pc[k][(x-1)%7]|pc[k][x]|pc[k][(x+1)%7]
    comp.append(full^mask)
graph=graph_text([blockers[w] for w in pool],comp,7,6)
(p/'core-anchor-family-c-d7.txt').write_text(graph)
meta=dict(anchors=anchors,candidates=len(pool),radius=7,core_prefix=308,noncore_limit=3,graph_sha256=hashlib.sha256(graph.encode()).hexdigest(),u2_certificate_verified=True,pool=pool)
(p/'core-anchor-family-c-input.json').write_text(json.dumps(meta)+'\n')
print(json.dumps({k:v for k,v in meta.items() if k!='pool'}))
