"""Audit contiguous native root intervals in the complete radius-nine pool.

Rechecks each graph once and binds all query settings to the same model and
identified kernel. Completed root intervals rely on the tested native checkpoint
implementation; this does not independently replay its exhaustive search trace.
"""
import argparse
import hashlib
import json
from pathlib import Path

from check_four_radius_chain import check_chain


def audit(queries, geometry, coverage, prefix_proof, previous_radius, kernel, source):
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    read=lambda p:json.loads(Path(p).read_text())
    runs=[(str(p),read(p)) for p in queries];assert runs
    model_path=Path(runs[0][1]['input']);model=read(model_path)
    assert model['status']=='complete' and model['min_blockers']==1 and model['max_blockers']==9
    geom=read(geometry);assert geom['model_sha256']==sha(model_path)
    assert geom['checker_sha256']==sha(Path(__file__).with_name('check_blocker_trade_results.py'))
    cov=read(coverage);assert cov['model_sha256']==sha(model_path)
    lower=read(prefix_proof);replay=check_chain(**lower['inputs'])
    assert all(lower[k]==v for k,v in replay.items())
    lower_model=read(lower['inputs']['model'])
    assert lower_model['input_sha256']==model['input_sha256']
    prev=read(previous_radius);assert prev['model_sha256']==sha(model_path)
    for dep in prev['dependencies']:assert sha(dep['path'])==dep['sha256']
    programs=(sha(kernel),sha(source));by_base={};graphs={}
    for path,run in runs:
        assert run['status']=='complete' and run['input_sha256']==sha(model_path)
        assert run['max_removals']==9 and run['target_insertions']==10 and run['prefix_blocker_degree']==5
        assert run['prefix_proof_sha256']==sha(prefix_proof) and not run['candidates']
        assert (run['kernel_sha256'],run['kernel_source_sha256'])==programs
        for row in run['rows']:
            bi=row['base'];d=next(d for d in model['rows'] if d['base']==bi);pool=d['pool_ids'];blocked=d['blocker_sets'];n=len(pool)
            ld=next(d for d in lower_model['rows'] if d['base']==bi)
            assert list(zip(ld['pool_ids'],ld['blocker_sets']))==[(v,b) for v,b in zip(pool,blocked) if len(b)<=4]
            assert next(r for r in lower['rows'] if r['base']==bi)['max_removals']>=9
            pr=next(r for r in prev['rows'] if r['base']==bi);assert pr['no_gain'] and pr['max_removals']==8
            cr=next(r for r in cov['rows'] if r['base']==bi);assert cr['covers_all_possible_insertions_within_radius']>=9
            assert cr['eligible_for_at_most_nine_removals']==n and cr['omitted_blockers']>9
            order=sorted(range(n),key=lambda i:(len(blocked[i])<5,pool[i]));prefix=sum(len(b)>=5 for b in blocked)
            assert row['kernel_order']==order and row['prefix']==prefix and row['rows_replayed']==n
            assert row['minimum_prefix_insertions']==1
            k=row['kernel_result'];assert k['status'] in ('timeout','exhausted')
            assert not k['chosen'] and not k['neutral'] and not k['improving']
            assert k['budget_bitsets'] and not k['enumerate_neutral'] and not k['anchor_bounds'] and not k['pair_bounds'] and not k['noncore_bound']
            assert row['root_start']==k['root_start'] and row['root_end']==k['root_end']==k['root_prefix']==prefix
            assert all(type(k[name]) is int for name in ('root_start','root_end','next_root'))
            assert 0<=k['root_start']<=k['next_root']<=prefix
            if k['status']=='exhausted':assert k['next_root']==prefix and k['nodes_started']==k['nodes_completed']
            graph=Path(row['graph']);assert sha(graph)==row['graph_sha256']
            if bi not in graphs:
                inverse={i:j for j,i in enumerate(order)};bad=[1<<j for j in range(n)]
                for u,v in d['conflict_edges']:
                    i,j=inverse[u],inverse[v];bad[i]|=1<<j;bad[j]|=1<<i
                full=(1<<n)-1;cw=(n+63)//64
                with graph.open() as f:
                    assert list(map(int,next(f).split()))==[n,6,9]
                    for j,i in enumerate(order):
                        words=[int(x,16) for x in next(f).split()];assert len(words)==6+cw and all(0<=v<1<<64 for v in words)
                        assert sum(v<<(64*w) for w,v in enumerate(words[:6]))==sum(1<<v for v in blocked[i])
                        assert sum(v<<(64*w) for w,v in enumerate(words[6:]))==full^bad[j]
                    assert not f.read().strip()
                graphs[bi]=dict(path=str(graph),sha256=sha(graph),checked_rows=n)
            else:assert graphs[bi]['sha256']==sha(graph)
            by_base.setdefault(bi,[]).append(dict(file=path,sha256=sha(path),start=k['root_start'],end=k['next_root'],prefix=prefix,status=k['status']))
    rows=[]
    for bi,segments in sorted(by_base.items()):
        end=0
        for segment in sorted(segments,key=lambda r:r['start']):
            assert segment['start']==end, 'Gap or overlap in completed root intervals'
            end=segment['end']
        complete=end==segments[0]['prefix']
        rows.append(dict(base=bi,closed_until=end,root_end=segments[0]['prefix'],complete_radius9=complete,
                         minimum_removed_for_any_368_set=10 if complete else 9,segments=segments))
    dependencies={str(p):sha(p) for p in [model_path,geometry,coverage,prefix_proof,previous_radius,kernel,source]}
    return dict(rows=rows,graphs=graphs,dependencies=dependencies)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--queries',required=True,nargs='+')
    for flag in ('geometry','coverage','prefix-proof','previous-radius','kernel','source'):p.add_argument('--'+flag,required=True)
    p.add_argument('--output',required=True,type=Path)
    a=p.parse_args();assert __debug__ and not a.output.exists()
    args={k:v for k,v in vars(a).items() if k!='output'};result=audit(**args)
    out=dict(checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),inputs=args,scope=__doc__,**result)
    a.output.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps([{k:v for k,v in r.items() if k!='segments'} for r in result['rows']]))


if __name__=='__main__':main()
