"""Screen saved parent unions with replayable projected-rank covers."""
import argparse
import hashlib
from itertools import combinations
import json
from pathlib import Path
import time

from check_two_slice_covers import HERE,WORDS,conflict
from check_cylinder_covers import check_entries
from probe_rank_branches import bound,characterize,CAPACITIES
from recombine_sets import FILES


def source_rows(data):
    return data if isinstance(data,list) else data['results']


def encoded_pool(source):
    words=source['pool_words']
    assert all(len(w)==5 and all(type(c) is int and 0<=c<7 for c in w)for w in words)
    pool=sorted(sum(x*7**(4-i)for i,x in enumerate(word))for word in words)
    assert len(pool)==len(set(pool))
    return pool


def replay(report):
    source=Path(report['input'])
    assert hashlib.sha256(source.read_bytes()).hexdigest()==report['input_sha256']
    original=source_rows(json.loads(source.read_text()))
    parents={label:{int(w,7)for w in (HERE/name).read_text().split()}for label,name in FILES.items()}
    for label,words in parents.items():
        assert hashlib.sha256((HERE/FILES[label]).read_bytes()).hexdigest()==report['parent_hashes'][label]
        assert len(words)==367 and all(not conflict(a,b)for a,b in combinations(words,2))
    results=[]
    assert [r['index']for r in report['results']]==list(range(len(report['results'])))
    assert len(report['results'])<=len(original)
    if report['status']=='complete':assert len(report['results'])==len(original)
    for record in report['results']:
        original_row=original[record['index']]
        pool=encoded_pool(original_row)
        if 'parents'in original_row:
            union=set().union(*(parents[label]for label in original_row['parents']))
            assert union==set(pool) and record['parents']==original_row['parents']
        else:
            assert record['label']==original_row['label']
        assert record['pool']==pool
        assert any(words<=set(pool)for words in parents.values()), 'No verified 367-word lower bound'
        if 'certificate' in record:
            total,den=check_entries(record['certificate'],record['pool'],CAPACITIES)
            assert record['full_upper']==total//den and record['excludes_target']==(total<368*den)
            assert total>=367*den
            results.append(dict(label=record.get('label',record.get('parents')),pool=len(pool),integer_upper=total//den,
                                total_units=total,denominator=den,excludes368=total<368*den))
    for candidate in report['candidates']:
        words=[int(w,7)for w in candidate['words']]
        assert len(words)==len(set(words))==candidate['size']>=367
        assert set(words)<=set(report['results'][candidate['step']]['pool'])
        assert all(not conflict(a,b)for a,b in combinations(words,2))
        assert candidate['verified_pairs']==len(words)*(len(words)-1)//2
    return dict(results=results,candidates=len(report['candidates']),scope='Each saved finite union only; no fixed exterior and no global bound.')


def main():
    if not __debug__:raise RuntimeError('Run without -O')
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,default=HERE/'recombination-three-parent-pools.json')
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--seconds',type=float,default=10)
    p.add_argument('--verify',action='store_true')
    args=p.parse_args()
    if args.output.exists():raise FileExistsError(args.output)
    if args.seconds<=0:p.error('Positive limit required')
    data=json.loads(args.input.read_text())
    if args.verify:
        result=replay(data);result['input_sha256']=hashlib.sha256(args.input.read_bytes()).hexdigest()
        args.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True);return
    report=dict(status='running',input=str(args.input),input_sha256=hashlib.sha256(args.input.read_bytes()).hexdigest(),
                source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),results=[],candidates=[],
                parent_hashes={label:hashlib.sha256((HERE/name).read_bytes()).hexdigest()for label,name in FILES.items()})
    cache={tuple(r['projection']):r for r in json.loads((HERE/'three-slice-screen-sep21/cubic-probes.json').read_text())['results']}
    began=time.monotonic()
    for index,source in enumerate(source_rows(data)):
        pool=encoded_pool(source)
        row=bound(pool,cache,args.seconds,50);row['index']=index
        row.update({k:source[k]for k in ('parents','label')if k in source})
        candidate=characterize(row,[],368)
        report['results'].append(row)
        if candidate:report['candidates'].append(candidate|{'step':index})
        report['elapsed_seconds']=time.monotonic()-began
        args.output.write_text(json.dumps(report,indent=2)+'\n')
        print(json.dumps(dict(label=source.get('label',source.get('parents')),pool=len(pool),status=row['status'],
                              upper=row.get('full_upper'),floating=row.get('floating_bound'),
                              candidate_size=None if candidate is None else candidate['size'])),flush=True)
        if candidate and candidate['size']>=368:break
    report['status']='candidate_found'if any(c['size']>=368 for c in report['candidates'])else 'complete'
    report['verification']=replay(report)
    args.output.write_text(json.dumps(report,indent=2)+'\n')


if __name__=='__main__':main()
