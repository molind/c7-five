"""Join old degree-split searches with new F width-seven closure at one root.

The old neutral mode chooses eight insertions, so the separate full radius-nine
gain exclusion is essential. This does not close width eight for all36 F states.
"""
import gzip
import hashlib
import json
from pathlib import Path
import struct

from check_all_word_root_intervals import audit


def main():
    assert __debug__
    root = Path('research/c7')
    output = root / 'component-F-selected-root8-verification-sep22.json'
    assert not output.exists()
    dependencies = {}

    def sha(p):
        return hashlib.sha256(Path(p).read_bytes()).hexdigest()

    def read(p):
        dependencies[str(p)] = sha(p)
        return json.loads(Path(p).read_text())

    lower = read(root / 'component-F-incremental7-final-verification-sep22.json')
    assert lower['checker_sha256'] == sha(root / 'check_component_atomic7_incremental.py')
    assert all(sha(p) == h for p, h in lower['dependencies'].items())
    dependencies.update(lower['dependencies'])
    assert lower['complete_atomic7'] and lower['width7_component_equals_width6']
    assert lower['seven_removal_augmentations_excluded'] and not lower['outside']
    forest_path = root / 'component-F-incremental-sep22-input.json'
    forest = read(forest_path)
    assert lower['dependencies'][str(forest_path)] == sha(forest_path)
    assert sha(forest['source']) == forest['source_sha256']
    with gzip.open(forest['source'], 'rt') as f:
        next(f)
        states = [json.loads(line) for line in f]
    starts_path = root / 'cardinality367-trade-starts-sep21.json'
    starts = read(starts_path)
    words = starts['bases'][1]['words']
    assert words == sorted(set(words)) and len(words) == 367
    matches = [i for i, s in enumerate(states) if s == words]
    assert matches == [5] and len(states) == lower['states'] == 36

    # Reuse the actual auditor, not just the previous result's claimed flags.
    gain = read(root / 'reference367-full-radius9-final-verification-sep21.json')
    assert gain['checker_sha256'] == sha(root / 'check_all_word_root_intervals.py')
    # The auditor returns integer graph keys; JSON stores those keys as strings.
    replay = json.loads(json.dumps(audit(**gain['inputs'])))
    assert all(gain[k] == v for k, v in replay.items())
    dependencies.update(gain['dependencies'])
    for item in gain['rows']:
        for segment in item['segments']:
            assert sha(segment['file']) == segment['sha256']
            dependencies[segment['file']] = segment['sha256']
    gain_row = next(r for r in gain['rows'] if r['base'] == 1)
    assert gain_row['complete_radius9'] and gain_row['minimum_removed_for_any_368_set'] == 10
    model = read(gain['inputs']['coverage'])
    model_path = model['model']
    domain = read(model_path)
    assert domain['input'] == str(starts_path) and domain['input_sha256'] == sha(starts_path)
    assert domain['max_blockers'] == 9 and domain['min_blockers'] == 1

    # Fresh reconstruction of the <=4-blocker native input already succeeded.
    low_proof = read(root / 'reference367-atomic8-root-recheck-sep22.json')
    assert low_proof['checker_sha256'] == sha(root / 'check_reference_atomic.py')
    low_path = root / 'reference367-atomic8-sep21.json'
    low = read(low_path)
    assert low_proof['inputs'][str(low_path)] == sha(low_path)
    assert low['input'] == str(starts_path) and low['input_sha256'] == sha(starts_path)
    assert low['radius'] == 8 and low['max_blockers'] == 4 and low['atomic_only']
    coverage = next(r for r in low_proof['coverage'] if r['base'] == 1)
    assert coverage['radius'] == 8 and coverage['complete']
    checked = next(r for r in low_proof['rows'] if r['base'] == 1)
    assert checked['status'] == 'exhausted' and checked['neutral'] == checked['improving'] == 0

    high = read(root / 'reference367-neutral8-root-F-replay-sep22.json')
    assert high['status'] == 'complete' and high['base'] == 1 and high['radius'] == 8
    assert high['source_sha256'] == sha(root / 'resume_reference_neutral.py')
    assert high['input'] == model_path and high['input_sha256'] == sha(model_path)
    assert high['kernel_sha256'] == sha(high['kernel'])
    assert high['kernel_source_sha256'] == sha(Path(high['kernel']).with_suffix('.cpp'))
    query = read(high['graph_query'])
    assert sha(high['graph_query']) == high['graph_query_sha256']
    assert query['input_sha256'] == sha(model_path) and query['max_removals'] == 8
    qr = next(r for r in query['rows'] if r['base'] == 1)
    assert high['graph_sha256'] == sha(high['graph']) == qr['graph_sha256']
    d = next(r for r in domain['rows'] if r['base'] == 1)
    prefix = sum(len(b) >= 5 for b in d['blocker_sets'])
    assert high['minimum_blocker_degree'] == 5
    assert sorted(qr['kernel_order']) == list(range(len(d['pool_ids'])))
    assert all((len(d['blocker_sets'][i]) >= 5) == (j < prefix)
               for j, i in enumerate(qr['kernel_order']))
    graph9 = gain['graphs']['1']
    assert sha(graph9['path']) == graph9['sha256']
    # The graph rows and order are identical; only the requested cardinality
    # in the first header changes from9 to8. There is no unbound old raw run.
    with Path(high['graph']).open() as f, Path(graph9['path']).open() as g:
        assert list(map(int, next(f).split())) == [len(d['pool_ids']), 6, 8]
        assert list(map(int, next(g).split())) == [len(d['pool_ids']), 6, 9]
        assert all(a == b for a, b in zip(f, g, strict=True))
    dependencies[high['graph']] = sha(high['graph'])
    k = high['kernel_result']
    assert k['enumerate_neutral'] and k['status'] == 'exhausted'
    assert k['root_start'] == 0
    assert k['root_end'] == k['root_prefix'] == k['next_root'] == prefix
    assert high['root_start'] == 0 and high['root_end'] == high['full_prefix_end'] == prefix
    assert k['nodes_started'] == k['nodes_completed']
    assert k['budget_bitsets'] and k['binary_budget'] and k['residual_budget']
    assert not k['anchor_bounds'] and not k['pair_bounds'] and not k['noncore_bound']
    assert not k['neutral'] and not k['improving'] and not k['chosen'] and not high['candidates']
    for path in [root / 'check_all_word_root_intervals.py', root / 'check_reference_atomic.py',
                 root / 'resume_reference_neutral.py', forest['source']]:
        dependencies[str(path)] = sha(path)
    result = dict(checker_sha256=sha(__file__), dependencies=dependencies,
                  passed=True, component_states=36, component_sha256=forest['component_sha256'],
                  reference_forest_index=5, root_words=words,
                  root_sha256=hashlib.sha256(struct.pack('<367H', *words)).hexdigest(),
                  lower_component_radius=7, checked_root_radius=8,
                  neutral_radius8_stays_in_component=True, no_augmentation_through_radius8=True,
                  low_blocker_pool=checked['pool'], high_blocker_roots=prefix,
                  whole_component_width8_closed=False,
                  scope='One exact selected F reference. Width-seven component closure handles reducible eight-removal neutral moves. The two exhaustive degree cases exclude irreducible neutral eight-moves. A separately replayed complete radius-nine gain audit excludes augmentations. Other35 F states are not yet covered at radius eight.')
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('dependencies', 'root_words', 'scope')}))


if __name__ == '__main__':
    main()
