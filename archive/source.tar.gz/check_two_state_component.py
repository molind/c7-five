"""Directly replay the two-state 367-word component found in mixed domain02.

The checker scans every outside word against every selected word using direct
coordinate differences. No exchange-search graph or cached adjacency is used.
"""
import argparse
from collections import Counter
import gzip
import hashlib
from itertools import combinations, product
import json
from pathlib import Path
import struct

import numpy as np


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--component', type=Path, required=True)
    p.add_argument('--candidate', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    with gzip.open(args.component, 'rt') as f:
        metadata = json.loads(next(f))
        states = [set(json.loads(line)) for line in f]
    assert len(states) == metadata['states'] == 2
    assert all(len(s) == 367 and all(type(v) is int and 0 <= v < 16807 for v in s) for s in states)
    packed = sorted(struct.pack('<367H', *sorted(s)) for s in states)
    assert len(set(packed)) == 2
    assert hashlib.sha256(b''.join(packed)).hexdigest() == metadata['component_sha256']
    source = json.loads(args.candidate.read_text())
    candidate = {int(w, 7) for w in source['candidates'][0]['words']}
    assert candidate in states
    universe = np.array(list(product(range(7), repeat=5)), dtype=np.int16)
    total_outside_pairs = witness_pairs = 0
    results = []
    for index, state in enumerate(states):
        selected = sorted(state)
        array = universe[selected]
        d = (array[:, None, :]-array[None, :, :]) % 7
        assert not np.any(np.triu(np.all((d == 0) | (d == 1) | (d == 6), axis=2), 1))
        witness_pairs += 367*366//2
        outside = sorted(set(range(16807))-state)
        neighbors, unblocked, histogram = [], [], Counter()
        for begin in range(0, len(outside), 128):
            ids = outside[begin:begin+128]
            d = (universe[ids, None, :]-array[None, :, :]) % 7
            blocked = np.all((d == 0) | (d == 1) | (d == 6), axis=2)
            counts = blocked.sum(axis=1)
            histogram.update(map(int, counts))
            for i in np.flatnonzero(counts == 0):
                unblocked.append(ids[int(i)])
            for i in np.flatnonzero(counts == 1):
                old = selected[int(np.flatnonzero(blocked[int(i)])[0])]
                new = ids[int(i)]
                image = (state-{old}) | {new}
                assert image in states and image != state
                neighbors.append(dict(removed=old, added=new, target=states.index(image)))
            total_outside_pairs += len(ids)*367
        assert not unblocked and len(neighbors) == 1 and neighbors[0]['target'] == 1-index
        results.append(dict(index=index, one_for_one_neighbors=neighbors, unblocked_words=unblocked,
                            outside_blocker_counts=dict(sorted(histogram.items()))))
    assert sum(len(r['one_for_one_neighbors']) for r in results) == metadata['directed_edges'] == 2
    core = set.intersection(*states)
    assert len(core) == 366
    result = dict(component_sha256=metadata['component_sha256'],
        component_file_sha256=hashlib.sha256(args.component.read_bytes()).hexdigest(),
        candidate_sha256=hashlib.sha256(args.candidate.read_bytes()).hexdigest(),
        checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        states=2, core_size=366, variable_words=sorted(set.union(*states)-core),
        direct_witness_pairs=witness_pairs, direct_outside_word_pairs=total_outside_pairs,
        results=results, closed_under_all_one_for_one_exchanges=True, immediate_augmentation=False,
        distinct_from_recorded_five_component_sizes=[243, 7, 78, 5971, 384],
        scope='A two-state one-for-one exchange component. Its cardinality distinguishes it from the five previously recorded components under graph automorphisms; no claim of literature novelty or368.')
    args.output.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k != 'results'}), flush=True)


if __name__ == '__main__':
    main()
