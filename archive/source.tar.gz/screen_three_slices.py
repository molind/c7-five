"""Screen all remaining three-adjacent-slice exteriors of the pinned D seed.

Each domain retains all compatible words. Exact integer cylinder covers are
checked before a bound is recorded. Small cubic graph searches can strengthen
rank rows; a timed-out projection keeps its previous valid upper bound.
"""
import argparse
from collections import Counter
import hashlib
from itertools import combinations
import json
from pathlib import Path
import time

import numpy as np
import scipy
from scipy.optimize import linprog

from check_two_slice_covers import HERE, WORDS, closed, conflict
from check_cylinder_covers import check_entries
from cylinder_bounds import CAPACITY, certify
from lift_cylinder_ranks import lifted_constraints
from probe_cubic_ranks import probe


def save(path, data):
    tmp = path.with_name(path.name+'.tmp')
    tmp.write_text(json.dumps(data, indent=2)+'\n')
    tmp.replace(path)


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output-dir', type=Path, required=True)
    p.add_argument('--seconds', type=float, default=12)
    p.add_argument('--cubic-ms', type=int, default=100)
    p.add_argument('--resume', action='store_true')
    args = p.parse_args()
    if args.seconds <= 0 or args.cubic_ms < 1:
        p.error('Positive budgets required')
    if not args.resume:
        args.output_dir.mkdir(exist_ok=False)
    seed_path = HERE/'family-d-seed-words.txt'
    seed = {int(w, 7) for w in seed_path.read_text().split()}
    assert len(seed) == 367 and all(not conflict(a, b) for a, b in combinations(seed, 2))
    previous_path = HERE/'three-slice-exact-cubic-ranks-sep21.json'
    previous = json.loads(previous_path.read_text())
    assert (previous['axis'], previous['start'], previous['width']) == (0, 3, 3)
    check_entries(previous['certificate'], previous['pool'], CAPACITY)
    probe_path = HERE/'three-slice-cubic-probe-sep21.json'
    cached = json.loads(probe_path.read_text())
    cache = {tuple(r['projection']): r for r in cached['results']}
    index = dict(status='running', results=[], candidates=[], scipy_version=scipy.__version__,
                 seconds_per_lp=args.seconds, milliseconds_per_new_cubic=args.cubic_ms,
                 reused_window=dict(axis=0, start=3, file=str(previous_path),
                                    sha256=hashlib.sha256(previous_path.read_bytes()).hexdigest(), upper=368),
                 initial_probe_file=str(probe_path),
                 initial_probe_sha256=hashlib.sha256(probe_path.read_bytes()).hexdigest(),
                 hashes={n: hashlib.sha256((HERE/n).read_bytes()).hexdigest() for n in
                         (Path(__file__).name, 'lift_cylinder_ranks.py', 'probe_cubic_ranks.py',
                          'check_cylinder_covers.py', 'slice_clique', seed_path.name)},
                 scope='The35 pinned-seed three-adjacent-slice domains only; no global C7^5 bound.')
    completed = set()
    previous_elapsed = 0
    if args.resume:
        saved = json.loads((args.output_dir/'index.json').read_text())
        assert saved['status'] == 'running'
        assert saved['seconds_per_lp'] == args.seconds and saved['milliseconds_per_new_cubic'] == args.cubic_ms
        assert saved['hashes'][seed_path.name] == index['hashes'][seed_path.name]
        assert saved['reused_window'] == index['reused_window']
        for row in saved['results']:
            assert hashlib.sha256(Path(row['file']).read_bytes()).hexdigest() == row['sha256']
            completed.add((row['axis'], row['start']))
        assert len(completed) == len(saved['results'])
        saved.setdefault('resumed_with_hashes', []).append(index['hashes'])
        index = saved
        previous_elapsed = saved['elapsed_seconds']
        cache = {tuple(r['projection']): r for r in json.loads((args.output_dir/'cubic-probes.json').read_text())['results']}
    vertices = np.array(WORDS)
    began = time.monotonic()
    for axis in range(5):
        for start in range(7):
            if (axis, start) == (0, 3) or (axis, start) in completed:
                continue
            job_start = time.monotonic()
            fixed = sorted(v for v in seed if (WORDS[v][axis]-start) % 7 >= 3)
            pool = sorted(set(range(7**5))-set.union(*(set(closed(v)) for v in fixed)))
            free = np.ones(len(vertices), dtype=bool)
            for v in fixed:
                delta = (vertices-vertices[v]) % 7
                free &= ~np.all((delta == 0) | (delta == 1) | (delta == 6), axis=1)
            assert np.flatnonzero(free).tolist() == pool
            members, desc, matrix, stats = lifted_constraints(pool)
            improved_rows = 0
            for d in desc:
                if not d.get('layer_rank_bound'):
                    continue
                projection = tuple(d['projection'])
                if projection not in cache:
                    cache[projection] = dict(projection=list(projection), upper=d['capacity'],
                                             result=probe(projection, d['capacity'], args.cubic_ms))
                recorded = cache[projection]
                assert recorded['upper'] == d['capacity']
                result = recorded['result']
                if result['status'] == 'exhausted' and result['best_size'] < d['capacity']:
                    d.pop('layer_rank_bound')
                    d.update(capacity=result['best_size'], cubic_rank=True)
                    improved_rows += 1
            caps = [d['capacity'] for d in desc]
            hint = np.array([v in seed for v in pool], dtype=float)
            assert len(fixed)+int(hint.sum()) == 367 and np.all(matrix @ hint <= caps)
            built = time.monotonic()
            solved = linprog(-np.ones(len(pool)), A_ub=matrix, b_ub=caps, bounds=(0, None),
                             method='highs-ipm', options={'time_limit': args.seconds})
            row = dict(axis=axis, start=start, width=3, fixed=fixed, pool=pool,
                       target=int(hint.sum()), status=int(solved.status), message=solved.message,
                       capacity_sequence=CAPACITY, stats=stats | {'exact_cubic_rows': improved_rows},
                       build_seconds=built-job_start, solve_seconds=time.monotonic()-built,
                       constraints=len(members), nonzeros=int(matrix.nnz))
            if solved.success:
                row['floating_bound'] = float(-solved.fun)
                row['certificate'] = certify(pool, members, desc, -solved.ineqlin.marginals)
                total, den = check_entries(row['certificate'], pool, CAPACITY)
                row['full_upper'] = len(fixed)+total//den
                assert row['full_upper'] >= 367
                row['primal'] = [[v, float(x)] for v, x in zip(pool, solved.x) if x > 1e-8]
                if np.max(np.abs(solved.x-np.rint(solved.x))) < 1e-7:
                    chosen = fixed+[v for v, x in zip(pool, solved.x) if x > .5]
                    if len(chosen) >= 368:
                        assert len(chosen) == len(set(chosen))
                        assert all(not conflict(a, b) for a, b in combinations(chosen, 2))
                        index['candidates'].append(dict(step=len(index['results']),
                            words=[''.join(map(str, WORDS[v])) for v in chosen],
                            verified_pairs=len(chosen)*(len(chosen)-1)//2))
            path = args.output_dir/f'axis{axis}-start{start}.json'
            save(path, row)
            summary = dict(axis=axis, start=start, file=str(path),
                           sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                           pool=len(pool), fixed=len(fixed), status=row['status'],
                           full_upper=row.get('full_upper'),
                           floating_full_upper=len(fixed)+row.get('floating_bound', float('inf')))
            index['results'].append(summary)
            index['elapsed_seconds'] = previous_elapsed+time.monotonic()-began
            index['projection_statuses'] = dict(Counter(r['result']['status'] for r in cache.values()))
            save(args.output_dir/'index.json', index)
            save(args.output_dir/'cubic-probes.json', dict(results=list(cache.values())))
            print(json.dumps(summary | {'done':len(index['results']), 'elapsed_seconds':index['elapsed_seconds']}), flush=True)
            if index['candidates']:
                index['status'] = 'candidate_found'
                save(args.output_dir/'index.json', index)
                return
    assert len(index['results']) == 34
    index['status'] = 'complete'
    save(args.output_dir/'index.json', index)


if __name__ == '__main__':
    main()
