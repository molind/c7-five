// Complete replay using direct coordinate-sum tables. No rotation/search code.
#include <algorithm>
#include <array>
#include <bitset>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <stdexcept>
#include <vector>
constexpr int Q=2401;
using W=std::array<int,4>;
using B=std::bitset<Q>;
void require(bool ok,const char* text){if(!ok)throw std::runtime_error(text);}
unsigned read16(std::istream& f){int a=f.get(),b=f.get();require(a>=0&&b>=0,"Truncated binary");return unsigned(a+256*b);}
unsigned read32(std::istream& f){unsigned a=read16(f),b=read16(f);return a+(b<<16);}
int id(const W& w){return w[0]*343+w[1]*49+w[2]*7+w[3];}
int main(int argc,char** argv){
 try{
  require(argc==2,"Expected binary path; text slices on stdin");
  int n;require(bool(std::cin>>n)&&n>0&&n<=65535,"Invalid N");
  std::vector<std::vector<int>> slices(n);
  for(auto& sl:slices){int size;require(bool(std::cin>>size)&&size>0&&size<=Q,"Invalid size");B seen;
   for(int j=0;j<size;++j){int v;require(bool(std::cin>>v)&&v>=0&&v<Q&&!seen[v],"Invalid point");seen[v]=true;sl.push_back(v);}}
  std::string tail;require(!(std::cin>>tail),"Extra text input");
  std::ifstream binary(argv[1],std::ios::binary);char magic[4];binary.read(magic,4);
  require(std::string(magic,4)=="C7RN"&&read32(binary)==unsigned(n),"Wrong header");
  unsigned nt=read32(binary);require(nt>0&&nt<=384,"Invalid transform count");
  std::array<W,Q> points{};
  for(int i=0;i<Q;++i)for(int k=0,stride=343;k<4;++k,stride/=7)points[i][k]=(i/stride)%7;
  std::vector<std::array<std::uint16_t,Q>> addition(Q);
  for(int x=0;x<Q;++x)for(int y=0;y<Q;++y){W z{};for(int k=0;k<4;++k)z[k]=(points[x][k]+points[y][k])%7;addition[x][y]=id(z);}
  std::vector<std::vector<std::vector<int>>> images;
  W p={0,1,2,3};
  do{for(unsigned bits=0;bits<16&&images.size()<nt;++bits){std::vector<std::vector<int>> im(n);
    for(int j=0;j<n;++j)for(int v:slices[j]){W w{};for(int k=0;k<4;++k){int z=points[v][p[k]];w[k]=(bits&(1u<<(3-k)))?z:(7-z)%7;}im[j].push_back(id(w));}
    images.push_back(std::move(im));}}
  while(images.size()<nt&&std::next_permutation(p.begin(),p.end()));
  require(images.size()==nt,"Transform list mismatch");
  auto began=std::chrono::steady_clock::now();std::uint64_t total=0,pairs=0;
  for(int left=0;left<n;++left){
   unsigned count=read32(binary);std::map<unsigned,B> expected;
   for(unsigned j=0;j<count;++j){unsigned right=read16(binary),t=read16(binary),shift=read16(binary);
    require(right<unsigned(n)&&t<nt&&shift<Q,"Invalid edge");auto& mask=expected[right*nt+t];require(!mask[shift],"Duplicate edge");mask[shift]=true;}
   std::array<bool,Q> free{};
   for(int v=0;v<Q;++v){bool blocked=false;for(int w:slices[left]){bool conflict=true;
     for(int k=0;k<4;++k){int d=std::abs(points[v][k]-points[w][k]);if(d>=2&&d<=5){conflict=false;break;}}
     if(conflict){blocked=true;break;}}free[v]=!blocked;}
   std::vector<B> translated(Q);
   for(int point=0;point<Q;++point)for(int shift=0;shift<Q;++shift)
    if(free[addition[point][shift]])translated[point].set(shift);
   for(int right=0;right<n;++right)for(unsigned t=0;t<nt;++t){B possible;possible.set();
    for(int v:images[t][right]){possible&=translated[v];if(possible.none())break;}
    auto at=expected.find(right*nt+t);if(at==expected.end())require(possible.none(),"Missing relative edge");
    else{require(possible==at->second,"Incorrect relative shift set");expected.erase(at);}++pairs;}
   require(expected.empty(),"Unvisited saved edge");total+=count;
   if(left%64==63||left==n-1)std::cerr<<"{\"rows\":"<<left+1<<",\"seconds\":"<<std::chrono::duration<double>(std::chrono::steady_clock::now()-began).count()<<"}\n";
  }
  binary.read(magic,4);require(bool(binary)&&std::string(magic,4)=="DONE"&&binary.peek()==EOF,"Wrong footer");
  std::cout<<"{\"slices\":"<<n<<",\"transforms\":"<<nt<<",\"slice_pairs\":"<<pairs<<",\"edges\":"<<total<<",\"complete_relative_placement_coverage\":true,\"seconds\":"<<std::chrono::duration<double>(std::chrono::steady_clock::now()-began).count()<<"}\n";
 }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
}
