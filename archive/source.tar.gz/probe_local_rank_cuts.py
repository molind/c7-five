"""Bound small induced neighborhoods exactly to separate a fractional point.

An exhausted native MIS search proves sum(x on S) <= alpha(S). Target hits
and timeouts do not produce cuts. Neighborhood selection is only a pilot.
"""
import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import subprocess
import time

import numpy as np
from scipy.optimize import linprog
from scipy.sparse import csr_matrix, vstack
from check_two_slice_covers import HERE, WORDS, closed, conflict
from search_clique_cycle_cuts import matrix_for
from search_with_clique_cycles import load_proof


def query(vertices,target,milliseconds,hint):
    points=np.array(WORDS)[vertices]
    delta=(points[:,None,:]-points[None,:,:])%7
    edges=np.argwhere(np.triu(np.all((delta==0)|(delta==1)|(delta==6),axis=2),1)).tolist()
    local={v:i for i,v in enumerate(vertices)}
    h=[local[v] for v in vertices if v in hint]
    text=f'{len(vertices)} {len(edges)} {target} {milliseconds} {len(h)}\n'+' '.join(map(str,h))+'\n'+''.join(f'{a} {b}\n' for a,b in edges)
    run=subprocess.run([str(HERE/'slice_clique')],input=text,text=True,capture_output=True,check=True,timeout=milliseconds/1000+5)
    result=json.loads(run.stdout)
    assert all(type(i) is int and 0 <= i < len(vertices) for i in result['vertices'])
    chosen=[vertices[i] for i in result['vertices']]
    assert len(chosen)==len(set(chosen))==result['best_size']
    assert all(not conflict(a,b) for i,a in enumerate(chosen) for b in chosen[i+1:])
    return result,len(edges)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True)
    p.add_argument('--base-verification',type=Path,required=True)
    p.add_argument('--hubs',type=int,default=128)
    p.add_argument('--milliseconds',type=int,default=30)
    p.add_argument('--query-limit',type=int,default=256)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();assert __debug__ and min(args.hubs,args.milliseconds,args.query_limit)>0 and not args.output.exists()
    proof,model,matrix,caps=load_proof(args.input,args.base_verification)
    assert proof['final_primal'] is not None
    positive=[400,2458,5153,5545,3193]
    control,_=query(positive,3,30,set());assert control['status']=='exhausted' and control['best_size']==2
    pool=model['pool'];local={v:i for i,v in enumerate(pool)};values=np.zeros(len(pool))
    for v,x in proof['final_primal']:values[local[v]]=x
    hint={pool[i] for i in model['hint']}
    other_path=HERE/'family-f-seed-words.txt'
    other_list=[int(w,7) for w in other_path.read_text().split()]
    assert len(other_list)==len(set(other_list))==367
    assert all(not conflict(a,b) for i,a in enumerate(other_list) for b in other_list[i+1:])
    other=set(other_list)
    hubs=sorted((i for i,x in enumerate(values) if 1e-6<x<1-1e-6),key=lambda i:(-values[i],i))[:args.hubs]
    seen=set();rows=[];cuts=[];skipped=Counter();started=time.monotonic()
    for hub in hubs:
        available=sorted({local[w] for w in closed(pool[hub]) if w in local})
        for threshold in (1e-8,.01,.03,.08):
            vertices=tuple(pool[i] for i in available if values[i]>threshold)
            if len(vertices)<5 or vertices in seen:
                continue
            seen.add(vertices)
            mass=float(sum(values[local[v]] for v in vertices));target=math.ceil(mass-1e-6)
            if max(len(set(vertices)&hint),len(set(vertices)&other))>=target:
                skipped['known_witness']+=1;continue
            result,edges=query(list(vertices),target,args.milliseconds,hint)
            row=dict(vertices=list(vertices),fractional_sum=mass,target=target,edges=edges,result=result)
            rows.append(row)
            if result['status']=='exhausted' and result['best_size']<mass-1e-6:
                cuts.append(dict(vertices=list(vertices),capacity=result['best_size'],query=len(rows)-1,violation=mass-result['best_size']))
            if len(rows)>=args.query_limit:break
        if len(rows)>=args.query_limit:break
    output=dict(input=str(args.input),input_sha256=hashlib.sha256(args.input.read_bytes()).hexdigest(),
                base_verification=str(args.base_verification),base_verification_sha256=hashlib.sha256(args.base_verification.read_bytes()).hexdigest(),
                source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),kernel_sha256=hashlib.sha256((HERE/'slice_clique').read_bytes()).hexdigest(),
                other_seed_sha256=hashlib.sha256(other_path.read_bytes()).hexdigest(),
                rows=rows,cuts=cuts,known_witness_skips=dict(skipped),unique_subsets=len(seen),positive_C5_control=control,
                bound_before=proof['last_successful_bound'],scope='Selected induced subgraphs only; cuts require exhaustive native MIS. Timeouts and absence of sampled cuts are not exclusions.')
    if cuts:
        ri=[];ci=[]
        for i,c in enumerate(cuts):
            ri.extend([i]*len(c['vertices']));ci.extend(local[v] for v in c['vertices'])
        extra=csr_matrix((np.ones(len(ri)),(ri,ci)),shape=(len(cuts),len(pool)))
        matrix=vstack([matrix,extra],format='csr');caps=np.concatenate([caps,[c['capacity'] for c in cuts]])
        h=np.zeros(len(pool));h[model['hint']]=1;assert np.all(matrix@h<=caps)
        lp=linprog(-np.ones(len(pool)),A_ub=matrix,b_ub=caps,bounds=(0,1),method='highs-ipm',options={'time_limit':10})
        output['lp']=dict(status=int(lp.status),message=lp.message,floating_full_bound=len(model['fixed'])-float(lp.fun) if lp.success else None)
        output['primal']=[[v,float(x)] for v,x in zip(pool,lp.x) if x>1e-8] if lp.success else None
    output['seconds']=time.monotonic()-started
    args.output.write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps(dict(queries=len(rows),cuts=len(cuts),statuses=dict(Counter(row['result']['status'] for row in rows)),skipped=dict(skipped),lp=output.get('lp'),seconds=output['seconds'])),flush=True)


if __name__=='__main__':
    main()
