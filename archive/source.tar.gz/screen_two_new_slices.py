"""Check integer clique covers of two-new-slice projection domains.

Projection IDs embed in C7^5 with a constant leading zero, so the existing
box builder and exact cover checker apply without altering the graph.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import time

from check_two_slice_covers import check_cover
from probe_slice_lp import build_cliques, solve_cover
from search_two_new_slices import prepare_jobs, extend


def main():
    if not __debug__:raise RuntimeError('Run without -O')
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True);p.add_argument('--verification',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--seconds',type=float,default=2)
    p.add_argument('--start',type=int,default=0);p.add_argument('--limit',type=int,default=10000)
    args=p.parse_args()
    if args.output.exists():raise FileExistsError(args.output)
    if args.seconds<=0 or args.start<0 or args.limit<1:p.error('Valid positive limits required')
    source=json.loads(args.input.read_text());checked=json.loads(args.verification.read_text())
    digest=hashlib.sha256(args.input.read_bytes()).hexdigest()
    assert checked['input_sha256']==digest and source['best']==367 and not checked['target_witness_found']
    began=time.monotonic();jobs,vertices,blocked=prepare_jobs(source)
    report=dict(status='running',input=str(args.input),input_sha256=digest,verification=str(args.verification),
        verification_sha256=hashlib.sha256(args.verification.read_bytes()).hexdigest(),
        source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        planner_sha256=hashlib.sha256(Path(__file__).with_name('search_two_new_slices.py').read_bytes()).hexdigest(),
        start=args.start,limit=args.limit,total_jobs=len(jobs),results=[],candidates=[],seconds=args.seconds,
        scope='Each saved five-library-slice exterior with two arbitrary adjacent slices; no global bound.')
    def save():
        report['elapsed_seconds']=time.monotonic()-began
        tmp=args.output.with_suffix('.tmp');tmp.write_text(json.dumps(report,indent=2)+'\n');tmp.replace(args.output)
    save()
    for index in range(args.start,min(len(jobs),args.start+args.limit)):
        job=jobs[index];pool=job['pool']
        row=dict(index=index,job=job)
        if len(pool)<job['target']:
            row.update(status='cardinality_closed',full_upper=job['path_size']+len(pool),excludes368=True)
        else:
            cliques=build_cliques(pool)
            cover=solve_cover(pool,cliques,None,args.seconds,method='highs-ipm',keep_primal=True)
            row.update(status=cover['status'],cover=cover,excludes368=False)
            if cover['status']=='certified_cover':
                total,den=check_cover(cover,set(pool),{v:1 for v in pool})
                row.update(full_upper=job['path_size']+total//den,excludes368=total<job['target']*den)
                primal=cover['primal']
                if all(abs(x['value']-round(x['value']))<1e-7 for x in primal):
                    selected=[x['vertex']for x in primal if x['value']>.5]
                    full=extend(source,job,selected,vertices,blocked)
                    row['integral_full_size']=len(full)
                    if len(full)>=368:
                        report['candidates'].append(dict(step=index,size=len(full),words=[''.join(map(str,w))for w in full],verified_pairs=len(full)*(len(full)-1)//2))
        report['results'].append(row)
        if index%10==0 or report['candidates']:save()
        if job['mixed']or index%50==0:
            print(json.dumps(dict(index=index,pool=len(pool),status=row['status'],upper=row.get('full_upper'),excludes368=row['excludes368'])),flush=True)
        if report['candidates']:break
    report['status']='candidate_found'if report['candidates']else'complete'
    report['statistics']=dict(Counter('closed'if r['excludes368']else'open'for r in report['results']))
    save();print(json.dumps(dict(status=report['status'],processed=len(report['results']),total_jobs=len(jobs),statistics=report['statistics'])),flush=True)


if __name__=='__main__':main()
