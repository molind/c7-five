"""Check distant-reference neutral outputs using pinned improving graph audits.

Graph geometry is inherited from hash-bound prior graph audits. Every returned
set is checked directly with scalar coordinate differences. Native exhaustive
trees are not independently replayed. A complete interval applies only to the
intentional blocker-degree filter in that exact reference and graph order.
"""
import argparse
import hashlib
from itertools import combinations
import json
from pathlib import Path


from check_pinned_prefix_chain import audit as audit_pinned


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',required=True,nargs='+',type=Path)
    p.add_argument('--graph-proofs',required=True,nargs='+',type=Path)
    p.add_argument('--output',required=True,type=Path)
    a=p.parse_args();assert __debug__ and not a.output.exists()
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    read=lambda p:json.loads(Path(p).read_text())
    here=Path(__file__).resolve().parent
    sources={sha(here/f) for f in ['resume_reference_neutral_initial.py','resume_reference_neutral.py']}
    graph_checkers={sha(here/f) for f in ['check_all_word_root_intervals.py','check_complete_radius10_intervals.py','check_pinned_prefix_chain.py']}
    bindings={};dependencies={}
    for path in a.graph_proofs:
        proof=read(path);assert proof['checker_sha256'] in graph_checkers
        assert all(sha(p)==v for p,v in proof['dependencies'].items())
        dependencies[str(path)]=sha(path)
        if proof['checker_sha256']==sha(here/'check_pinned_prefix_chain.py'):
            replay=audit_pinned(**proof['inputs'])
            assert all(proof[k]==v for k,v in replay.items())
            for query_path in proof['inputs']['queries']:
                query=read(query_path)
                for row in query['rows']:
                    assert sha(row['graph'])==row['graph_sha256']
                    bindings[row['graph_sha256']]=(row['rows_replayed'],proof['dependencies'])
        else:
            for row in proof['graphs'].values():
                assert sha(row['path'])==row['sha256']
                bindings[row['sha256']]=(row['checked_rows'],proof['dependencies'])
    models={};queries={};grouped={};records=[];total_pairs=0
    coords=[tuple((v//(7**k))%7 for k in range(4,-1,-1)) for v in range(16807)]
    for path in a.input:
        d=read(path);assert d['status'] in ('complete','verified_target') and d['source_sha256'] in sources
        assert d['kernel_sha256']==sha(d['kernel']) and d['kernel_source_sha256']==sha(Path(d['kernel']).with_suffix('.cpp'))
        mp=d['input'];assert d['input_sha256']==sha(mp)
        if mp not in models:
            model=read(mp);assert model['status']=='complete' and model['input_sha256']==sha(model['input'])
            models[mp]=(model,read(model['input'])['bases'])
        model,bases=models[mp];domain=next(r for r in model['rows'] if r['base']==d['base'])
        old=bases[d['base']]['words'];assert old==sorted(set(old)) and len(old)==367
        qp=d['graph_query'];assert d['graph_query_sha256']==sha(qp)
        if qp not in queries:queries[qp]=read(qp)
        q=queries[qp];assert q['input_sha256']==sha(mp) and q['max_removals']==d['radius']
        row=next(r for r in q['rows'] if r['base']==d['base']);order=row['kernel_order']
        assert sorted(order)==list(range(len(domain['pool_ids'])))
        gh=d['graph_sha256'];assert gh==sha(d['graph'])==row['graph_sha256']
        checked,deps=bindings[gh];assert checked==len(order) and deps[mp]==sha(mp)
        degree=d['minimum_blocker_degree'];prefix=sum(len(b)>=degree for b in domain['blocker_sets'])
        assert all((len(domain['blocker_sets'][i])>=degree)==(j<prefix) for j,i in enumerate(order))
        assert d.get('full_prefix_end',prefix)==prefix
        k=d['kernel_result'];assert k['status'] in ('timeout','output_limit','exhausted')
        assert k['enumerate_neutral'] and k['budget_bitsets'] and k['binary_budget'] and k['residual_budget']
        assert not k['anchor_bounds'] and not k['pair_bounds'] and not k['noncore_bound'] and not k['chosen']
        assert d['root_start']==k['root_start'] and d['root_end']==k['root_end']==k['root_prefix']
        assert all(type(k[f]) is int for f in ['root_start','root_end','next_root'])
        assert 0<=k['root_start']<=k['next_root']<=k['root_end']<=prefix
        if k['status']=='exhausted':assert k['next_root']==k['root_end'] and k['nodes_started']==k['nodes_completed']
        expected=[];seen=set();pairs=0
        for kind in ['neutral','improving']:
            for index,chosen in enumerate(k[kind]):
                assert len(chosen)==len(set(chosen))==d['radius'] and all(type(i) is int and 0<=i<len(order) for i in chosen)
                assert k['root_start']<=min(chosen)<k['root_end']
                selected=[order[i] for i in chosen]
                removed=sorted({v for i in selected for v in domain['blocker_sets'][i]})
                assert len(removed)<=d['radius'] and (len(removed)==d['radius'])==(kind=='neutral')
                words=tuple(sorted((set(old)-{old[i] for i in removed})|{domain['pool_ids'][i] for i in selected}))
                assert len(words)==367+d['radius']-len(removed)
                if words in seen:continue
                seen.add(words)
                for u,v in combinations(words,2):assert any((a-b)%7 in (2,3,4,5) for a,b in zip(coords[u],coords[v]))
                count=len(words)*(len(words)-1)//2;pairs+=count
                expected.append(dict(step=len(expected),source_base=d['base'],native_kind=kind,native_index=index,
                    chosen_indices=selected,removed_indices=removed,size=len(words),pair_checks=count,
                    words=[''.join(map(str,coords[v])) for v in words]))
        assert d['candidates']==expected
        assert (d['status']=='verified_target')==any(r['size']>=368 for r in expected)
        total_pairs+=pairs
        key=(mp,d['base'],d['radius'],degree,gh,prefix)
        grouped.setdefault(key,[]).append(dict(file=str(path),sha256=sha(path),start=k['root_start'],end=k['next_root'],status=k['status']))
        records.append(dict(file=str(path),sha256=sha(path),sets=len(expected),pair_checks=pairs))
    rows=[]
    for (mp,bi,radius,degree,gh,prefix),segments in sorted(grouped.items()):
        end=0
        for segment in sorted(segments,key=lambda s:s['start']):
            assert segment['start']==end,'Gap or overlap in neutral root intervals'
            end=segment['end']
        rows.append(dict(model=mp,base=bi,radius=radius,minimum_blocker_degree=degree,closed_until=end,
                         root_end=prefix,restricted_prefix_exhausted=end==prefix,segments=segments))
    out=dict(checker_sha256=sha(__file__),scope=__doc__,graph_proofs=dependencies,rows=rows,results=records,positive_pair_checks=total_pairs)
    a.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps([dict(base=r['base'],radius=r['radius'],closed_until=r['closed_until'],root_end=r['root_end'],complete=r['restricted_prefix_exhausted']) for r in rows]))


if __name__=='__main__':main()
