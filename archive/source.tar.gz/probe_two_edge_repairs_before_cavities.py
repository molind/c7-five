"""Exactly complete366 backbones extracted from selected two-edge points.

Try all four endpoint removals and then zero or one further nonfixed omission.
Search every independent pair/triple in the resulting full compatible pool.
This is a finite neighborhood check, not a global upper bound.
"""
import argparse
import hashlib
from itertools import combinations,product
import json
from pathlib import Path
import time

import numpy as np
from check_two_slice_covers import closed,conflict
from check_cardinality_projection import conflicts
from search_cardinality_projection import pair_edges


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();assert __debug__ and not a.output.exists()
    source=json.loads(a.input.read_text());fixed=set(source['fixed']);bases=set()
    for run in source['runs']:
        words=run['best_words'];edges=pair_edges(words)
        assert len(words)==len(set(words))==368 and len(edges)==run['best_conflicts']
        if len(edges)!=2 or set(edges[0])&set(edges[1]):continue
        for endpoints in product(*edges):
            omitted={words[i] for i in endpoints}
            assert not omitted&fixed
            base=tuple(v for v in words if v not in omitted)
            assert len(base)==366 and not conflicts(list(base));bases.add(base)
    report=dict(status='running',input=str(a.input),input_sha256=hashlib.sha256(a.input.read_bytes()).hexdigest(),
                source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),fixed=sorted(fixed),
                bases=[],candidates=[],scope=__doc__)
    began=time.monotonic();total_tests=0;total_domains=0
    def save():
        report['seconds']=time.monotonic()-began;report['subset_tests']=total_tests;report['domains']=total_domains
        temp=a.output.with_suffix('.tmp');temp.write_text(json.dumps(report,indent=2)+'\n');temp.replace(a.output)
    for base in sorted(bases):
        counts=np.zeros(16807,dtype=np.int16)
        for v in base:counts[list(closed(v))]+=1
        free=set(np.flatnonzero(counts==0).tolist())
        record=dict(words=list(base),free=sorted(free),queries=[]);report['bases'].append(record)
        for omitted in [None]+sorted(set(base)-fixed):
            available=sorted(free if omitted is None else free|{v for v in closed(omitted) if counts[v]==1})
            need=2+int(omitted is not None);tests=0;found=None
            for selected in combinations(available,need):
                tests+=1
                if all(not conflict(u,v) for u,v in combinations(selected,2)):
                    found=selected;break
            record['queries'].append(dict(omitted=omitted,pool=available,target=need,subsets_tested=tests,found=list(found) if found else None))
            total_domains+=1;total_tests+=tests
            if found:
                full=sorted((set(base)-({omitted} if omitted is not None else set()))|set(found))
                assert len(full)==368 and fixed<=set(full) and not conflicts(full)
                report['candidates'].append(dict(size=368,vertices=full,pair_checks=67528))
                report['status']='verified_target';save();print(json.dumps(dict(status=report['status'],domains=total_domains)),flush=True);return
        save()
    report['status']='complete';save()
    print(json.dumps(dict(status=report['status'],bases=len(bases),domains=total_domains,subset_tests=total_tests,seconds=report['seconds'])),flush=True)


if __name__=='__main__':main()
