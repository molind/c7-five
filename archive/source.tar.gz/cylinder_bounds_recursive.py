"""Add exact cyclic-cylinder rank inequalities to three-slice relaxations.

A cylinder leaves d coordinates free and restricts every other coordinate to
an adjacent pair. Independent words project injectively to C7^d. The recursive
bound a[0]=1, a[d]=floor(7*a[d-1]/2) follows because the seven adjacent layer
pairs each contain at most a[d-1] words and count every selected word twice.
"""
import argparse
import hashlib
from itertools import combinations, product
import json
from pathlib import Path
import time

import numpy as np
from scipy.optimize import linprog
from scipy.sparse import csc_matrix

from check_two_slice_covers import HERE, WORDS

CAPACITY = [1]
for _ in range(5):
    CAPACITY.append(7*CAPACITY[-1]//2)


def constraints(pool, dimensions):
    unique = {}
    for d in sorted(set(dimensions)):
        for free in combinations(range(5), d):
            fixed = [i for i in range(5) if i not in free]
            buckets = {}
            for i, v in enumerate(pool):
                for values in product(*[((WORDS[v][k]-1) % 7, WORDS[v][k]) for k in fixed]):
                    buckets.setdefault(values, []).append(i)
            for values, vs in buckets.items():
                if d and len(vs) <= CAPACITY[d]:
                    continue
                key = tuple(vs)
                if key not in unique or unique[key]['capacity'] > CAPACITY[d]:
                    origin = [-1]*5
                    for k, x in zip(fixed, values):
                        origin[k] = x
                    unique[key] = dict(free=list(free), origin=origin, capacity=CAPACITY[d])
    members = sorted(unique)
    desc = [unique[c] for c in members]
    rows = [i for i, c in enumerate(members) for _ in c]
    cols = [v for c in members for v in c]
    matrix = csc_matrix((np.ones(len(rows)), (rows, cols)), shape=(len(members), len(pool)))
    return members, desc, matrix


def certify(pool, members, descriptions, weights):
    den = 1_000_000
    units = np.ceil(np.maximum(0, weights)*den).astype(np.int64)
    coverage = [0]*len(pool)
    incident = [[] for _ in pool]
    for i, c in enumerate(members):
        for v in c:
            coverage[v] += int(units[i])
            incident[v].append(i)
    for v in range(len(pool)):
        if coverage[v] < den:
            j = min(incident[v], key=lambda j: descriptions[j]['capacity'])
            delta = den-coverage[v]
            units[j] += delta
            for u in members[j]:
                coverage[u] += delta
    certificate = []
    for c, desc, n in zip(members, descriptions, units):
        if n:
            certificate.append(desc | {'vertices': [pool[v] for v in c], 'units': int(n)})
    assert min(coverage) >= den
    total = sum(c['units']*c['capacity'] for c in certificate)
    return dict(denominator=den, total_units=total, integer_upper_bound=total//den, cover=certificate)


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, default=HERE/'three-slice-d-pilot-sep21.json')
    parser.add_argument('--start', type=int, default=3)
    parser.add_argument('--dimensions', type=int, nargs='+', choices=range(5), default=[0, 1, 2])
    parser.add_argument('--seconds', type=float, default=30)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.seconds <= 0 or 0 not in args.dimensions:
        parser.error('A positive time limit and dimension0 constraints are required')
    if args.output.exists():
        raise FileExistsError(args.output)
    source = json.loads(args.input.read_text())
    row = next(r for r in source['results'] if r['start'] == args.start)
    pool = row['pool']
    began = time.monotonic()
    members, desc, matrix = constraints(pool, args.dimensions)
    bounds = np.array([d['capacity'] for d in desc], dtype=float)
    hint = np.zeros(len(pool));hint[row['hint']] = 1
    assert np.max(matrix @ hint-bounds) <= 0
    built = time.monotonic()
    result = linprog(-np.ones(len(pool)), A_ub=matrix, b_ub=bounds, bounds=(0, None),
                     method='highs-ipm', options={'time_limit': args.seconds})
    report = dict(status=int(result.status), message=result.message,
                  source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  input_sha256=hashlib.sha256(args.input.read_bytes()).hexdigest(),
                  start=args.start, axis=source['axis'], width=source['width'],
                  fixed=row['fixed'], pool=pool, target=row['target'], dimensions=args.dimensions,
                  constraints=len(members), nonzeros=int(matrix.nnz),
                  build_seconds=built-began, solve_seconds=time.monotonic()-built,
                  capacity_sequence=CAPACITY, incumbent_satisfies_every_constraint=True,
                  scope='Rank inequalities on the complete saved slab pool; only checked integer covers can certify an exclusion.')
    if result.success:
        report['floating_bound'] = float(-result.fun)
        report['certificate'] = certify(pool, members, desc, -result.ineqlin.marginals)
        report['primal'] = [[v, float(x)] for v, x in zip(pool, result.x) if x > 1e-8]
    args.output.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps({k: v for k, v in report.items() if k not in ('fixed', 'pool', 'primal', 'certificate')} |
                     {'integer_bound': report.get('certificate', {}).get('integer_upper_bound')}), flush=True)


if __name__ == '__main__':
    main()
