"""Bounded hot/cold excursions from the verified outside-support E3 entries."""
from itertools import combinations, product
import hashlib
import json
from pathlib import Path
import random
import time

from search_low_conflict import WORDS, TOKENS, family_start, independent_target, successors

HERE = Path(__file__).resolve().parent


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    source = HERE / 'family-a-cap3-boundary-entries.json'
    data = json.loads(source.read_text())
    original, known = family_start('A')
    assert {int(w,7) for w in data['start_words']} == original
    adjacency = [tuple(2401*a+343*b+49*c+7*d+e
        for a,b,c,d,e in product(*[((x-1)%7,x,(x+1)%7) for x in w])
        if 2401*a+343*b+49*c+7*d+e != v) for v,w in enumerate(WORDS)]
    results = []
    began = time.monotonic()
    for entry in data['entries']:
        if time.monotonic()-began > 60:
            break
        state = frozenset(int(w,7) for w in entry['final_words'])
        rng = random.Random(2026092010 + entry['source_index'])
        path, examined, independent = [], 0, None
        status = 'step_limit'
        entry_began = time.monotonic()
        for step in range(200):
            choice, degree, best = None, 0, None
            for target, energy, removed, added, conflicts in successors(state, adjacency, 3):
                examined += 1
                if examined % 1024 == 0 and (time.monotonic()-entry_began > 5 or time.monotonic()-began > 60):
                    status = 'timeout'
                    break
                independent = independent_target(target, conflicts, known)
                if independent is not None:
                    choice = target, energy, removed, added
                    status = 'independent368' if energy == 0 else 'outside_A367'
                    break
                if step >= 50:
                    if best is not None and energy > best:
                        continue
                    if best is None or energy < best:
                        best, degree = energy, 0
                degree += 1
                if rng.randrange(degree) == 0:
                    choice = target, energy, removed, added
            if status == 'timeout':
                break
            assert choice is not None
            state, energy, removed, added = choice
            path.append(dict(removed=TOKENS[removed], added=TOKENS[added], energy=energy))
            if independent is not None:
                break
            if step >= 50 and energy == 1:
                status = 'returned_A_E1'
                break
        replay = {int(w,7) for w in entry['final_words']}
        conflict = lambda a,b: all((x-y)%7 in (0,1,6) for x,y in zip(WORDS[a],WORDS[b]))
        energy = sum(conflict(a,b) for a,b in combinations(replay,2))
        assert energy == 3
        for move in path:
            removed, added = int(move['removed'],7), int(move['added'],7)
            assert removed in replay and added not in replay
            replay.remove(removed)
            energy += sum(conflict(added,v)-conflict(removed,v) for v in replay)
            replay.add(added)
            assert len(replay) == 368 and energy == move['energy'] and 0 <= energy <= 3
        assert replay == state
        if independent is not None:
            assert len(independent) in (367,368) and independent not in known
            assert not any(conflict(a,b) for a,b in combinations(independent,2))
        results.append(dict(source_index=entry['source_index'], seed=2026092010+entry['source_index'],
                            status=status, steps=len(path), examined=examined, path=path,
                            final_energy=energy,
                            independent_words=None if independent is None else [TOKENS[v] for v in sorted(independent)]))
        if independent is not None:
            break
    report = dict(source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                  results=results, total_seconds=time.monotonic()-began,
                  scope='50 uniform hot moves followed by up to150 minimum-energy moves per prepared entry;5s/entry and60s total guards. Partial scans discarded. No exhaustive exclusion.')
    (HERE / 'family-a-cap3-boundary-excursions.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps([{k:v for k,v in r.items() if k not in ('path','independent_words')} for r in results]))


if __name__ == '__main__':
    main()
