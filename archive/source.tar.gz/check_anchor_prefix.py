"""Compare the prefix-restricted DFS with exhaustive compatible subsets."""
from itertools import combinations
import json
from pathlib import Path
import random
import subprocess
import sys
from check_exchange_dfs import graph_text, controls

binary=Path(sys.argv[1]).resolve()
rng=random.Random(2026091814)
positive=0
for case in range(300):
    n=rng.randrange(1,12);d=rng.randrange(1,7);prefix=rng.randrange(n+1)
    positions=[0,1,63,64,127,128,307,366,511]
    cb=[sum(1<<x for x in rng.sample(positions,rng.randrange(5))) for _ in range(n)]
    comp=[0]*n
    for i,j in combinations(range(n),2):
        if rng.randrange(4):comp[i]|=1<<j;comp[j]|=1<<i
    for neutral in [False,True]:
        target=d if neutral else d+1
        core,limit=128,rng.randrange(d+1)
        noncore=not neutral and case%2==0
        expected={'neutral':[],'improving':[]};witness=[]
        for chosen in combinations(range(n),target):
            mask=0
            for i in chosen:mask|=cb[i]
            if chosen[0]>=prefix or mask.bit_count()>d:continue
            if noncore and (mask>>core).bit_count()>limit:continue
            if not all(comp[i]>>j&1 for i,j in combinations(chosen,2)):continue
            if not witness:witness=list(chosen)
            expected['neutral' if mask.bit_count()==d else 'improving'].append(list(chosen))
        positive+=bool(witness)
        for subset in [False,True]:
            opts=['--root-prefix',str(prefix)]
            if subset:opts+=['--subset']
            if neutral:opts+=['--neutral']
            if noncore:opts+=['--noncore-limit',str(core),str(limit)]
            out=json.loads(subprocess.run([str(binary),'5',*opts],input=graph_text(cb,comp,d,8),text=True,capture_output=True,check=True,timeout=7).stdout)
            if neutral:
                assert out['status']=='exhausted'
                assert all(out[k]==v for k,v in expected.items())
                assert out['nodes_started']==out['nodes_completed']
            else:
                assert out['status']==('witness' if witness else 'exhausted')
                assert out['chosen']==witness
for n in [63,64,65,127,128,129]:
    cb=[1]*n;comp=[0]*n
    comp[n-2]=1<<(n-1);comp[n-1]=1<<(n-2)
    for prefix in [0,n-2,n-1,n]:
        for opts in [[],['--subset']]:
            out=json.loads(subprocess.run([str(binary),'5','--root-prefix',str(prefix),*opts],input=graph_text(cb,comp,1,1),text=True,capture_output=True,check=True,timeout=7).stdout)
            assert out['chosen']==([n-2,n-1] if prefix>=n-1 else [])
for value in ['-1','4','20001']:
    r=subprocess.run([str(binary),'5','--root-prefix',value],input=graph_text([1]*3,[6,5,3],2,1),text=True,capture_output=True,timeout=7)
    assert r.returncode!=0
report=dict(cases=300,modes=4,positive_mode_cases=positive,boundary_runs=48,invalid_controls=3,seed=2026091814,binary=str(binary))
Path(__file__).with_name(binary.name+'-anchor-controls.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
controls(binary)
controls(binary,['--subset'])
