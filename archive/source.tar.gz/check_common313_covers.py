"""Verify every two-core-omission cover, including compositional certificates."""
import argparse
import hashlib
from itertools import combinations, product
import json
from pathlib import Path

from check_common314_covers import decode, encode


def box_words(origin):
    assert type(origin) is int and 0<=origin<16807
    return {encode(w) for w in product(*[(x,(x+1)%7) for x in decode(origin)])}


def verify_cover(pool,cover,denominator):
    coverage={v:0 for v in pool};total=0
    for c in cover:
        units=c['units'];assert type(units) is int and units>0
        for v in box_words(c['origin'])&pool:coverage[v]+=units
        total+=units
    assert min(coverage.values())>=denominator
    return total


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();assert __debug__ and not args.output.exists()
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    d=json.loads(args.input.read_text());assert d['status']=='complete'
    assert all(sha(f)==h for f,h in d['dependencies'].items())
    single=json.loads(Path(d['single_covers']).read_text());base=json.loads(Path(single['base_certificate']).read_text())
    assert sha(single['base_certificate'])==single['base_sha256'] and sha(base['input'])==base['input_sha256']
    parents=json.loads(Path(base['input']).read_text())['bases'];core=sorted(set(parents[0]['words'])&set(parents[1]['words']))
    assert core==sorted(base['fixed']) and len(core)==315
    blockers=[set() for _ in range(16807)]
    for v in core:
        for w in product(*[((x-1)%7,x,(x+1)%7) for x in decode(v)]):blockers[encode(w)].add(v)
    buckets={}
    for v,bk in enumerate(blockers):
        if len(bk)<=2:buckets.setdefault(tuple(sorted(bk)),set()).add(v)
    prior={r['omitted']:r for r in single['rows']};D=d['denominator'];assert D==single['denominator']>0
    assert sorted(prior)==core and len(single['rows'])==len(core)
    base_total={}
    for i,r in prior.items():
        pool=buckets[()]|buckets[(i,)];assert pool==set(r['pool'])
        total=verify_cover(pool,r['cover'],D);assert total==r['total_units']<54*D;base_total[i]=total
    assert [tuple(r['omitted']) for r in d['rows']]==list(combinations(core,2))
    checked_boxes={};extensions=lps=0;maximum=0;opened=[]
    for r in d['rows']:
        i,j=r['omitted'];extra=buckets.get((i,j),set())
        if r['kind']=='extension':
            parent=r['parent_omission'];assert parent in (i,j);new=j if parent==i else i
            origin=r['extra_box_origin']
            if origin not in checked_boxes:checked_boxes[origin]=box_words(origin)
            assert buckets[(new,)]|extra<=checked_boxes[origin]
            total=base_total[parent]+D;extensions+=1
        else:
            assert r['kind']=='lp';pool=buckets[()]|buckets[(i,)]|buckets[(j,)]|extra
            assert pool==set(r['pool']) and len(pool)==len(r['pool'])
            total=verify_cover(pool,r['cover'],D);lps+=1
        assert total==r['total_units']
        if total>=55*D:opened.append((i,j))
        maximum=max(maximum,total)
    assert opened==[tuple(r['omitted']) for r in d['open_domains']]
    witness=base['witness'];assert len(witness)==len(set(witness))==367 and set(core)<=set(witness)
    pairs=0
    for a,b in combinations(witness,2):
        assert any((x-y)%7 in (2,3,4,5) for x,y in zip(decode(a),decode(b)));pairs+=1
    out=dict(passed=True,cases=len(d['rows']),extensions=extensions,lp_covers=lps,open_domains=opened,
             maximum_total_units=maximum,denominator=D,witness_pair_checks=pairs,
             minimum_core_omissions_for368=3 if not opened else None,
             any368_retains_at_most_core_words=312 if not opened else None,
             checker_sha256=sha(__file__),dependencies={str(args.input):sha(args.input),d['single_covers']:sha(d['single_covers']),single['base_certificate']:sha(single['base_certificate']),base['input']:sha(base['input'])},
             scope='Exact315core. Only when no domain is open: every368set omits>=3core words; no global independence bound.')
    args.output.write_text(json.dumps(out,indent=2)+'\n');print(out)


if __name__=='__main__':main()
