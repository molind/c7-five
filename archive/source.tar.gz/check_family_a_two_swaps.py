"""Independent blocker construction and removal-first neutral-exchange check."""
from collections import defaultdict
import hashlib
from itertools import combinations, product
import json
from pathlib import Path

HERE = Path(__file__).parent
component = json.loads((HERE/'family-a-component.json').read_text())
expected = json.loads((HERE/'family-a-two-swaps.json').read_text())
states = []
for row in component['states']:
    tokens = Path(row['words_file']).read_text().split()
    assert hashlib.sha256(' '.join(tokens).encode()).hexdigest() == row['sha256']
    states.append(frozenset(tuple(map(int, w)) for w in tokens))
known = {s: i for i, s in enumerate(states)}
checks = []
for si, occupied in enumerate(states):
    state = sorted(occupied)
    coord = [[0]*7 for _ in range(5)]
    for i, w in enumerate(state):
        for k, symbol in enumerate(w):
            coord[k][symbol] |= 1 << i
    groups = defaultdict(list)
    for w in product(range(7), repeat=5):
        if w in occupied:
            continue
        mask = (1 << len(state))-1
        for k, symbol in enumerate(w):
            mask &= coord[k][(symbol-1) % 7] | coord[k][symbol] | coord[k][(symbol+1) % 7]
        assert mask
        if mask.bit_count() <= 2:
            groups[mask].append(w)
    # Independently check every two-old-word deletion, not every addition pair.
    targets, legal, outside = set(), 0, set()
    empty = ()
    for i, j in combinations(range(len(state)), 2):
        bi, bj = 1 << i, 1 << j
        eligible = [*groups.get(bi, empty), *groups.get(bj, empty), *groups.get(bi | bj, empty)]
        for a, b in combinations(eligible, 2):
            if all((x-y) % 7 in (0, 1, 6) for x, y in zip(a, b)):
                continue
            # Full pairwise verification of each resulting 367-word set.
            target = (occupied-{state[i], state[j]}) | {a, b}
            assert len(target) == 367
            assert all(any((x-y) % 7 not in (0, 1, 6) for x, y in zip(u, v))
                       for u, v in combinations(target, 2))
            legal += 1
            if target in known:
                targets.add(known[target])
            else:
                outside.add(target)
    row = expected['rows'][si]
    assert len(list(combinations(range(len(state)), 2))) == 67161
    assert sorted(targets) == row['known_targets']
    assert legal == row['legal_two_swaps'] and not outside
    assert sum(map(len, groups.values())) == row['pool']
    checks.append(dict(state=si, removal_pairs=67161, legal_moves=legal, outside=0))
edges = sorted((i, j) for i, s in enumerate(states) for j, t in enumerate(states)
               if i != j and len(s-t) == 1)
assert edges == sorted(map(tuple, component['directed_edges']))
report = dict(states=7, removal_pairs=7*67161, checks=checks, outside=0,
              one_word_adjacency_matches=True,
              method='Coordinate bitmask intersections; enumerate deleted pairs; directly verify every resulting set')
(HERE/'family-a-two-swaps-verification.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report))
