"""Check optional small-frontier coloring against exhaustive subsets.

Runs partitioned improving and neutral searches, including 64-bit boundaries.
The old root-resume kernel supplies a second implementation comparison.
"""
import hashlib
from itertools import combinations
import json
from pathlib import Path
import random
import subprocess
import sys


def main():
    assert __debug__
    output = Path(sys.argv[1]); assert not output.exists()
    here = Path(__file__).resolve().parent
    new = here / 'exchange_dfs_coloring'; old = here / 'exchange_dfs_root_resume'
    rng = random.Random(2192110); rows = []
    for case in range(96):
        n = 12 if case < 88 else 70
        radius = 2 + case % 5 if n == 12 else 2
        neutral = bool(case % 2); target = radius if neutral else radius + 1
        space = [0, 2, 63, 64, 65, 90, 100, 123, 126]
        blocked = [sum(1 << j for j in rng.sample(space, rng.randrange(10))) for _ in range(n)]
        if case % 3 == 0:
            blocked = [sum(1 << j for j in space[:radius])] * n
        compatible = [0] * n
        for i, j in combinations(range(n), 2):
            edge = (i % (target - 1) != j % (target - 1)) if case % 3 == 0 else rng.random() < .72
            if edge: compatible[i] |= 1 << j; compatible[j] |= 1 << i
        prefix = n if n == 12 else (63, 64, 65, 70)[case % 4]
        start = case % 4 if n == 12 else 61
        expected = []; tested = 0
        for c in combinations(range(n), target):
            tested += 1
            if not start <= c[0] < prefix: continue
            if any(not (compatible[i] >> j) & 1 for i, j in combinations(c, 2)): continue
            union = 0
            for i in c: union |= blocked[i]
            if union.bit_count() <= radius: expected.append((list(c), union.bit_count()))
        mask = (1 << 64) - 1; cw = (n + 63) // 64
        lines = [f'{n} 2 {radius}']
        for b, c in zip(blocked, compatible):
            lines.append(' '.join(f'{v:x}' for v in [b & mask, b >> 64] + [(c >> (64*w)) & mask for w in range(cw)]))
        data = '\n'.join(lines) + '\n'; results = []
        for binary, limit in [(old, None), (new, 0), (new, 8), (new, 64)]:
            command = [str(binary), '5', '--budget-bitsets', '--root-start', str(start), '--root-prefix', str(prefix)]
            if neutral: command += ['--neutral']
            if limit is not None: command += ['--color-limit', str(limit)]
            r = json.loads(subprocess.run(command, input=data, text=True, capture_output=True, check=True, timeout=8).stdout)
            assert r['status'] in ('witness', 'exhausted'), r
            if neutral:
                assert r['neutral'] == [c for c, b in expected if b == radius]
                assert r['improving'] == [c for c, b in expected if b < radius]
            else:
                assert (r['status'] == 'witness') == bool(expected)
                if expected: assert r['chosen'] == expected[0][0]
                assert not any(c[0] < r['next_root'] for c, b in expected)
            if r['status'] == 'exhausted':
                assert r['nodes_started'] == r['nodes_completed'] and r['next_root'] == prefix
            results.append(r)
        rows.append(dict(case=case, n=n, radius=radius, neutral=neutral, tested_subsets=tested,
                         solutions=len(expected), color_checks=results[-1]['color_checks'],
                         color_prunes=results[-1]['color_prunes']))
    assert sum(r['color_prunes'] for r in rows) > 0
    sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
    result = dict(source_sha256=sha(__file__), kernel_sha256=sha(new),
                  kernel_source_sha256=sha(here/'exchange_dfs_coloring.cpp'),
                  comparison_kernel_sha256=sha(old), rows=rows)
    output.write_text(json.dumps(result, indent=2)+'\n')
    print(dict(cases=len(rows), subsets=sum(r['tested_subsets'] for r in rows),
               solutions=sum(r['solutions'] for r in rows), prunes=sum(r['color_prunes'] for r in rows)))


if __name__ == '__main__': main()
