"""Finite independent-graph controls of the parent/child commutation lemma."""
import hashlib
from itertools import combinations
import json
from pathlib import Path
import random


def main():
    assert __debug__
    rng = random.Random(2026092208)
    counts = dict(graphs=200, parent_child_edges=0, targets=0, inserted_removed=0,
                  commuting=0, commuting_improvements=0, critical_retained=0)
    n, size, radius = 8, 3, 2
    for test in range(counts['graphs']):
        adj = [0] * n
        for i, j in combinations(range(n), 2):
            if rng.random() < (0.15, 0.30, 0.45, 0.60)[test % 4]:
                adj[i] |= 1 << j
                adj[j] |= 1 << i

        def independent(mask):
            return all(not (mask & adj[i]) for i in range(n) if mask >> i & 1)

        states = [m for m in range(1 << n) if m.bit_count() == size and independent(m)]
        targets = [m for m in range(1 << n) if m.bit_count() in (size, size + 1) and independent(m)]
        for parent in states:
            for child in states:
                x, y = child & ~parent, parent & ~child
                if x.bit_count() != 1 or y.bit_count() != 1:
                    continue
                xi, yi = x.bit_length() - 1, y.bit_length() - 1
                if not adj[xi] & y:
                    # Such a parent admits immediate insertion of x, and is
                    # excluded by the real scanner's lower-radius premise.
                    continue
                counts['parent_child_edges'] += 1
                for target in targets:
                    if (child & ~target).bit_count() > radius:
                        continue
                    counts['targets'] += 1
                    if not target & x:
                        assert (parent & ~target).bit_count() <= radius
                        counts['inserted_removed'] += 1
                        continue
                    inserted = target & ~child
                    if inserted & adj[yi]:
                        counts['critical_retained'] += 1
                        continue
                    transformed = (target & ~x) | y
                    assert not target & y
                    assert transformed.bit_count() == target.bit_count()
                    assert independent(transformed)
                    assert (parent & ~transformed).bit_count() <= radius
                    assert (target ^ transformed).bit_count() == 2
                    counts['commuting'] += 1
                    counts['commuting_improvements'] += target.bit_count() > size
    assert all(counts[k] > 0 for k in counts)
    result = dict(passed=True, checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  controls=counts, vertices=n, old_size=size, radius=radius,
                  scope='Exhaustive parent/child/target enumeration within 200 seeded finite graphs. Tests the algebraic commutation reduction, not native C7 exhaustion or a formal proof.')
    output = Path('research/c7/incremental-reduction-controls-sep22.json')
    assert not output.exists()
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
