"""Bounded complete neutral d-for-d enumeration on the seven pinned states."""
import hashlib
import argparse
from itertools import combinations, product
import json
from pathlib import Path
import sys
import subprocess

from neutral_exchanges import enumerate_exchanges
from check_exchange_dfs import graph_text

HERE = Path(__file__).parent
if not __debug__:
    raise RuntimeError('Run without -O')
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('radius', type=int)
parser.add_argument('--cpp', type=Path)
args = parser.parse_args()
d = args.radius
assert 1 <= d <= (8 if args.cpp else 4)
binary = args.cpp.resolve() if args.cpp else None
component = json.loads((HERE/'family-a-component.json').read_text())
states = []
for row in component['states']:
    tokens = Path(row['words_file']).read_text().split()
    assert hashlib.sha256(' '.join(tokens).encode()).hexdigest() == row['sha256']
    states.append(tuple(tuple(map(int, w)) for w in tokens))
known = {frozenset(s): i for i, s in enumerate(states)}
report = dict(radius=d, rows=[], outside={})
if binary:
    report.update(backend=str(binary), binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
                  search_limit_seconds=60, parent_limit_seconds=75)
for si, state in enumerate(states):
    occupied = frozenset(state)
    coord = [[0]*7 for _ in range(5)]
    for i, w in enumerate(state):
        for k, x in enumerate(w):
            coord[k][x] |= 1 << i
    pool, cb = [], []
    for w in product(range(7), repeat=5):
        if w in occupied:
            continue
        mask = (1 << len(state))-1
        for k, x in enumerate(w):
            mask &= coord[k][(x-1) % 7] | coord[k][x] | coord[k][(x+1) % 7]
        if mask.bit_count() <= d:
            pool.append(w)
            cb.append(mask)
    order = sorted(range(len(pool)), key=lambda i: cb[i].bit_count())
    pool, cb = [pool[i] for i in order], [cb[i] for i in order]
    pc = [[0]*7 for _ in range(5)]
    for i, w in enumerate(pool):
        for k, x in enumerate(w):
            pc[k][x] |= 1 << i
    full = (1 << len(pool))-1
    comp = []
    for w in pool:
        conflicts = full
        for k, x in enumerate(w):
            conflicts &= pc[k][(x-1) % 7] | pc[k][x] | pc[k][(x+1) % 7]
        comp.append(full ^ conflicts)
    if binary:
        graph = graph_text(cb, comp, d, 6)
        try:
            run = subprocess.run([str(binary), '60', '--neutral', '--subset'],
                input=graph, text=True, capture_output=True, check=True, timeout=75)
            result = json.loads(run.stdout)
        except subprocess.TimeoutExpired:
            result = dict(status='parent_timeout', neutral=[], improving=[],
                          nodes_started=None, nodes_completed=None, seconds=None)
        result['candidate_visits'] = result['nodes_started']
        result['graph_sha256'] = hashlib.sha256(graph.encode()).hexdigest()
        if result['status'] == 'exhausted':
            assert result['nodes_started'] == result['nodes_completed']
    else:
        result = enumerate_exchanges(cb, comp, d, seconds=60)
    targets, outside = set(), set()
    for chosen in result['neutral']:
        mask = 0
        for i in chosen:
            mask |= cb[i]
        removed = {w for i, w in enumerate(state) if mask >> i & 1}
        added = {pool[i] for i in chosen}
        target = (occupied-removed) | added
        assert len(removed) == len(added) == d and len(target) == 367
        assert all(any((x-y) % 7 in (2, 3, 4, 5) for x, y in zip(a, b))
                   for a, b in combinations(target, 2))
        if target in known:
            targets.add(known[target])
        else:
            tokens = [''.join(map(str, w)) for w in sorted(target)]
            digest = hashlib.sha256(' '.join(tokens).encode()).hexdigest()
            outside.add(digest)
            report['outside'].setdefault(digest, dict(parent=si,
                removed=[''.join(map(str, w)) for w in sorted(removed)],
                added=[''.join(map(str, w)) for w in sorted(added)], words=' '.join(tokens)))
    row = dict(state=si, status=result['status'], pool=len(pool),
               neutral_count=len(result['neutral']), improving_count=len(result['improving']),
               known_targets=sorted(targets), outside=sorted(outside),
               candidate_visits=result['candidate_visits'], seconds=result['seconds'])
    report['rows'].append(row)
    print(json.dumps(row), flush=True)
    row['search'] = result
    suffix = '-cpp' if binary else ''
    (HERE/f'family-a-neutral-{d}{suffix}-results.json').write_text(json.dumps(report, indent=2)+'\n')
    assert result['status'] == 'exhausted' and not result['improving'], 'Incomplete or unexpected result saved above'
print('distinct outside states', len(report['outside']), flush=True)
