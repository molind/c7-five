"""Bounded IPM-guided branching for an exact368 core-domain construction.

Branch bounds are binary restrictions on words. Checkpoints preserve earlier
branch decisions and retry unfinished LP nodes without re-solving completed nodes. Conflict propagation and
the deletion cap prune impossible insertions. Interior LP solutions are used
directly; crossover to a basic solution is unnecessary for binary branching. LP infeasibility is numerical;
this exploratory search deliberately makes no certificate/exclusion claim.
"""
import argparse
import json
import math
from pathlib import Path
import time

import numpy as np
from scipy.sparse import csc_matrix, vstack
from scipy.optimize._highspy import _core as high

from check_two_slice_covers import closed
from search_core_radius_cut import sha
from search_core_regions import independence
from solve_core_radius_ipm import build_model, load_radius_model, model_digest


from check_core_subtree_cuts import verify as verify_subtree_cuts
from search_core_ipm_branches_v2 import propagate
from certify_core_ipm_leaves_dual_v3 import recheck_certificate


def path_key(row):
    return tuple(row['inside']), tuple(row['outside'])


def completed(row):
    return 'branch' in row or row['status'] in ('Infeasible', 'exact_conflict_or_radius', 'exact_integer_contradiction')


def validate_partial_tree(tree):
    """Reconstruct the exact DFS partition, including pending and unknown nodes."""
    assert tree['status'] == 'bounded_attempt_complete'
    pending, unknown, seen = [((), ())], [], set()
    for row in tree['rows']:
        key = path_key(row)
        assert pending and pending.pop() == key and key not in seen
        seen.add(key)
        inside, outside = key
        assert len(set(inside)) == len(inside) and len(set(outside)) == len(outside)
        assert not set(inside) & set(outside)
        if 'branch' in row:
            v = row['branch']
            assert type(v) is int and v not in inside and v not in outside
            pending.append((inside, outside + (v,)))
            pending.append((inside + (v,), outside))
        elif not completed(row):
            unknown.append(key)
    assert pending == [path_key(row) for row in tree['pending_nodes']]
    assert unknown == [path_key(row) for row in tree['unknown_nodes']]
    return {path_key(row): row for row in tree['rows']}


def load_checkpoint(path, expected, active=None):
    """Keep unvisited cached subtrees across any number of resumptions."""
    active = set() if active is None else active
    path = Path(path)
    resolved = path.resolve()
    assert resolved not in active
    active.add(resolved)
    tree = json.loads(path.read_text())
    for key in ('radius', 'original_model_sha256', 'target_model_sha256'):
        assert tree[key] == expected[key]
    assert Path(tree['input']).resolve() == Path(expected['input']).resolve()
    assert all(sha(f) == h for f, h in tree['dependencies'].items())
    assert tree['dependencies'][tree['input']] == sha(expected['input'])
    names = ('search_core_ipm_branches.py', 'search_core_ipm_branches_v2.py', 'search_core_ipm_branches_v3.py', 'search_core_ipm_branches_v4.py', 'search_core_ipm_branches_v5.py', 'search_core_ipm_branches_v6.py', 'search_core_ipm_branches_v8.py', 'search_core_ipm_branches_v9.py', 'search_core_ipm_branches_v10.py', 'search_core_ipm_branches_v11.py')
    assert any(sha(Path(__file__).with_name(name)) == tree['source_sha256'] for name in names)
    cached = {}
    if tree.get('resume_from'):
        parent = tree['resume_from']
        assert tree['dependencies'][parent] == sha(parent)
        cached = load_checkpoint(parent, expected, active)
    for key, row in validate_partial_tree(tree).items():
        if key in cached and completed(cached[key]):
            assert row == cached[key], 'A previously completed decision changed during resumption'
        cached[key] = row
    active.remove(resolved)
    return cached


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path, required=True)
    p.add_argument('--radius', type=int, required=True)
    p.add_argument('--nodes', type=int, default=64)
    p.add_argument('--seconds', type=float, default=120)
    p.add_argument('--lp-seconds', type=float, default=5)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--resume', type=Path)
    p.add_argument('--leaf-certificates', type=Path)
    p.add_argument('--domain-exclusion', type=Path, required=True)
    p.add_argument('--common-core-proof', type=Path, required=True)
    p.add_argument('--common-core-base', type=Path, required=True)
    p.add_argument('--branching', choices=('new-gain', 'old-fractional'), default='new-gain')
    p.add_argument('--subtree-cuts', type=Path, required=True)
    args = p.parse_args()
    assert __debug__ and not args.output.exists()
    assert args.nodes > 0 and args.seconds > 0 and args.lp_seconds > 0
    data, matrix, lower, upper, variable_upper, initial = load_radius_model(args.input, args.radius)
    exclusion = json.loads(args.domain_exclusion.read_text())
    assert exclusion['passed'] and exclusion['target'] == 368
    assert exclusion['input'] == str(args.input) and exclusion['deletion_radius'] == args.radius
    assert exclusion['fixed'] == data['fixed'] and exclusion['exact_parent'] == data['parent_words']
    assert exclusion['parent_deletion_count_preserved'] and exclusion['eligible_pool_mapping_checked']
    assert exclusion['dependencies'][str(args.input)] == sha(args.input)
    assert all(sha(f) == h for f, h in exclusion['dependencies'].items())
    checker = Path(__file__).with_name('derive_core_domain_exclusion.py')
    assert exclusion['checker_sha256'] == sha(checker)
    words = exclusion['inside']
    assert words and len(words) == len(set(words)) and exclusion['outside'] == []
    assert exclusion['inequality_upper'] == len(words)-1
    positions = {v: i for i, v in enumerate(data['pool'])}
    cut = csc_matrix(([1]*len(words), ([0]*len(words), [positions[v] for v in words])),
                     shape=(1, len(positions)))
    matrix = vstack((matrix[:-3], cut, matrix[-3:]), format='csc')
    lower = np.r_[lower[:-3], 0, lower[-3:]]
    upper = np.r_[upper[:-3], len(words)-1, upper[-3:]]
    core_proof = json.loads(args.common_core_proof.read_text())
    core_base = json.loads(args.common_core_base.read_text())
    assert core_proof['passed'] and not core_proof['open_domains']
    assert core_proof['checker_sha256'] == sha(Path(__file__).with_name('check_common312_covers.py'))
    assert all(sha(f) == h for f, h in core_proof['dependencies'].items())
    assert core_proof['dependencies'][str(args.common_core_base)] == sha(args.common_core_base)
    assert core_base['input_sha256'] == sha(core_base['input'])
    parents = json.loads(Path(core_base['input']).read_text())['bases']
    core = set(parents[0]['words']) & set(parents[1]['words'])
    assert core == set(core_base['fixed']) and len(core) == 315
    assert core_proof['cases'] == math.comb(len(core), 3)
    assert core_proof['minimum_core_omissions_for368'] == 4
    assert core_proof['any368_retains_at_most_core_words'] == 311
    assert core_proof['denominator'] > 0 and core_proof['maximum_total_units'] < 56*core_proof['denominator']
    fixed = set(data['fixed'])
    assert fixed <= core and set(data['parent_words']) in [set(p['words']) for p in parents]
    core_words = sorted(core-fixed)
    core_upper = 311-len(fixed)
    assert 0 <= core_upper < len(core_words)
    core_cut = csc_matrix(([1]*len(core_words), ([0]*len(core_words), [positions[v] for v in core_words])),
                          shape=(1, len(positions)))
    # This inequality is conditional on target368. It must not be applied to
    # a neutral367 model; the exact target cardinality is set below.
    matrix = vstack((matrix[:-3], core_cut, matrix[-3:]), format='csc')
    lower = np.r_[lower[:-3], 0, lower[-3:]]
    upper = np.r_[upper[:-3], core_upper, upper[-3:]]
    subtree_cuts = verify_subtree_cuts(args.subtree_cuts)
    assert subtree_cuts['input'] == str(args.input) and subtree_cuts['radius'] == args.radius
    target_lower = lower.copy()
    target_lower[-3] = data['target']
    assert model_digest(matrix, target_lower, upper, variable_upper) == subtree_cuts['target_model_sha256']
    indices, columns, coefficients, cut_lower, cut_upper = [], [], [], [], []
    for i, clause in enumerate(subtree_cuts['clauses']):
        assert not set(clause['inside']) & set(clause['outside'])
        for word, coefficient in [(v, 1) for v in clause['inside']] + [(v, -1) for v in clause['outside']]:
            indices.append(i); columns.append(positions[word]); coefficients.append(coefficient)
        cut_lower.append(-len(clause['outside']))
        cut_upper.append(len(clause['inside'])-1)
    clause_matrix = csc_matrix((coefficients, (indices, columns)),
                              shape=(len(subtree_cuts['clauses']), len(positions)))
    matrix = vstack((matrix[:-3], clause_matrix, matrix[-3:]), format='csc')
    lower = np.r_[lower[:-3], cut_lower, lower[-3:]]
    upper = np.r_[upper[:-3], cut_upper, upper[-3:]]
    model_sha = model_digest(matrix, lower, upper, variable_upper)
    target = data['target']
    assert upper[-3] == target and lower[-3] == 0
    lower[-3] = target  # Search only the requested368, not neutral367 optima.
    pool, old = set(data['pool']), set(data['parent_words']) - set(data['fixed'])
    positions = {v: i for i, v in enumerate(data['pool'])}
    neighborhoods = {v: closed(v) & pool for v in pool}
    out = dict(status='running', input=str(args.input), radius=args.radius,
               original_model_sha256=model_sha, target_model_sha256=model_digest(matrix, lower, upper, variable_upper),
               source_sha256=sha(__file__), dependencies={str(args.input): sha(args.input)},
               parameters=dict(nodes=args.nodes, seconds=args.seconds, lp_seconds=args.lp_seconds, crossover=False, branching=args.branching),
               rows=[], unknown_nodes=[], scope=__doc__,
               resume_from=str(args.resume) if args.resume else None, fresh_nodes=0, replayed_nodes=0)
    for name in ('solve_core_radius_ipm.py', 'check_two_slice_covers.py', 'search_core_regions.py', 'search_core_ipm_branches_v2.py'):
        path = Path(__file__).with_name(name)
        out['dependencies'][str(path)] = sha(path)
    out['dependencies'][str(args.domain_exclusion)] = sha(args.domain_exclusion)
    out['dependencies'][str(checker)] = sha(checker)
    out['domain_exclusion'] = str(args.domain_exclusion)
    out['excluded_jointly_present_words'] = exclusion['inside']
    out['dependencies'][str(args.common_core_proof)] = sha(args.common_core_proof)
    out['dependencies'][str(args.common_core_base)] = sha(args.common_core_base)
    core_checker = Path(__file__).with_name('check_common312_covers.py')
    out['dependencies'][str(core_checker)] = sha(core_checker)
    out['common_core_proof'] = str(args.common_core_proof)
    out['common_core_base'] = str(args.common_core_base)
    out['common_core_cut_words'] = core_words
    out['common_core_cut_upper'] = core_upper
    out['subtree_cuts'] = str(args.subtree_cuts)
    out['subtree_cut_count'] = len(subtree_cuts['clauses'])
    out['dependencies'][str(args.subtree_cuts)] = sha(args.subtree_cuts)
    for name in ('check_core_subtree_cuts.py', 'derive_core_subtree_cuts.py'):
        path = Path(__file__).with_name(name)
        out['dependencies'][str(path)] = sha(path)
    cached = load_checkpoint(args.resume, out) if args.resume else {}
    if args.resume:
        out['dependencies'][str(args.resume)] = sha(args.resume)
    out['cached_nodes_available'] = len(cached)
    exact_leaves = {}
    if args.leaf_certificates:
        bundle = json.loads(args.leaf_certificates.read_text())
        assert bundle['status'] == 'complete_attempt'
        assert all(sha(f) == h for f, h in bundle['dependencies'].items())
        certificate_tree_path = Path(bundle['tree'])
        assert bundle['dependencies'][str(certificate_tree_path)] == sha(certificate_tree_path)
        certificate_tree = json.loads(certificate_tree_path.read_text())
        for key in ('radius', 'target_model_sha256', 'original_model_sha256'):
            assert certificate_tree[key] == out[key]
        assert Path(certificate_tree['input']).resolve() == args.input.resolve()
        for record in bundle['rows']:
            if record['certificate'] is None:
                continue
            index = record['tree_index']
            assert type(index) is int and 0 <= index < len(certificate_tree['rows'])
            key = path_key(certificate_tree['rows'][index])
            assert key not in exact_leaves
            assert all(v in pool for part in key for v in part)
            assert not set(key[0]) & set(key[1])
            forbidden = propagate(pool, old, neighborhoods, *key, args.radius)
            assert forbidden is not None
            vlo, vhi = np.zeros(len(pool)), variable_upper.copy()
            for v in key[0]:
                vlo[positions[v]] = 1
            for v in forbidden:
                vhi[positions[v]] = 0
            recheck_certificate(matrix, lower, upper, vlo, vhi, record['certificate'])
            exact_leaves[key] = record['certificate']
        out['dependencies'][str(args.leaf_certificates)] = sha(args.leaf_certificates)
        helper = Path(__file__).with_name('certify_core_ipm_leaves_dual_v3.py')
        out['dependencies'][str(helper)] = sha(helper)
    out['exact_certificates_available'] = len(exact_leaves)
    stack = [((), ())]
    began = time.monotonic()
    def save():
        out['seconds'] = time.monotonic() - began
        out['pending_nodes'] = [dict(inside=list(a), outside=list(b)) for a, b in stack]
        args.output.write_text(json.dumps(out, indent=2) + '\n')
    save()
    while stack:
        key = stack[-1]
        if key in cached and completed(cached[key]):
            stack.pop()
            row = cached[key]
            out['rows'].append(row)
            out['replayed_nodes'] += 1
            if 'branch' in row:
                inside, outside = key
                branch = row['branch']
                stack.append((inside, outside + (branch,)))
                stack.append((inside + (branch,), outside))
            continue
        if key in exact_leaves:
            stack.pop()
            row = dict(inside=list(key[0]), outside=list(key[1]), status='exact_integer_contradiction',
                       certificate=exact_leaves[key], certificate_source=str(args.leaf_certificates))
            out['rows'].append(row)
            continue
        if out['fresh_nodes'] >= args.nodes or time.monotonic() - began >= args.seconds:
            break
        inside, outside = stack.pop()
        out['fresh_nodes'] += 1
        row = dict(inside=list(inside), outside=list(outside))
        forbidden = propagate(pool, old, neighborhoods, inside, outside, args.radius)
        if forbidden is None:
            row['status'] = 'exact_conflict_or_radius'
        else:
            variable_lo = np.zeros(len(pool))
            variable_hi = variable_upper.copy()
            for v in inside:
                variable_lo[positions[v]] = 1
            for v in forbidden:
                variable_hi[positions[v]] = 0
            solver = high._Highs()
            for key, value in dict(output_flag=False, solver='ipm', run_crossover='off',
                                   time_limit=float(max(0.0, min(args.lp_seconds, args.seconds - (time.monotonic() - began))))).items():
                assert solver.setOptionValue(key, value) == high.HighsStatus.kOk
            model = build_model(matrix, lower, upper, variable_hi, False)
            model.col_lower_ = variable_lo
            assert solver.passModel(model) == high.HighsStatus.kOk
            start = time.monotonic()
            solver.run()
            info, solution = solver.getInfo(), solver.getSolution()
            row.update(status=solver.modelStatusToString(solver.getModelStatus()), seconds=time.monotonic() - start,
                       ipm_iterations=info.ipm_iteration_count, objective=info.objective_function_value,
                       forced_zero=len(forbidden), forced_old_deletions=len(forbidden & old))
            if solution.value_valid and info.primal_solution_status == high.kSolutionStatusFeasible:
                x = np.asarray(solution.col_value)
                activity = matrix @ x
                valid_point = (np.all(np.isfinite(x)) and np.all(np.isfinite(activity))
                               and np.all(x >= variable_lo - 1e-6) and np.all(x <= variable_hi + 1e-6)
                               and np.all(activity >= lower - 1e-6) and np.all(activity <= upper + 1e-6))
                if not valid_point:
                    # A solver feasibility flag is not evidence when direct
                    # residual checks fail. Preserve this branch for retry.
                    row['solver_status'] = row['status']
                    row['status'] = 'numerical_point_rejected'
                    if np.all(np.isfinite(x)) and np.all(np.isfinite(activity)):
                        row['maximum_violation'] = float(max(0.0, np.max(variable_lo-x), np.max(x-variable_hi),
                                                             np.max(lower-activity), np.max(activity-upper)))
                    out['unknown_nodes'].append(dict(inside=list(inside), outside=list(outside)))
                    out['rows'].append(row)
                    save()
                    print(dict(node=len(out['rows']), **{k: v for k, v in row.items() if k not in ('inside', 'outside')}), flush=True)
                    continue
                fractional = np.abs(x - np.rint(x)) > 1e-6
                row['fractional'] = int(fractional.sum())
                if not np.any(fractional):
                    words = sorted(data['fixed'] + [v for v, value in zip(data['pool'], np.rint(x)) if value])
                    assert len(words) == 368 and independence(words) == 67528
                    out.update(status='verified_improvement', verified368=words, pair_checks=67528)
                else:
                    available = [v for v in pool - old - set(inside) - forbidden if fractional[positions[v]]]
                    # LP solutions can retain fractional old words even when
                    # every new word is integral. Branch on an old variable
                    # in that case; no integrality claim follows from the old
                    # set being independent.
                    if not available:
                        available = [v for v in pool - set(inside) - forbidden if fractional[positions[v]]]
                    assert available
                    deleted = forbidden & old
                    branch = max(available, key=lambda v: (x[positions[v]] / max(1, len(neighborhoods[v] & old - deleted)), -v))
                    if args.branching == 'old-fractional':
                        retained = [v for v in old - set(inside) - forbidden if fractional[positions[v]]]
                        if retained:
                            # Fix the most ambiguous parent word first. Keeping
                            # it propagates every conflicting new word to zero.
                            branch = min(retained, key=lambda v: (abs(x[positions[v]]-0.5), v))
                    row.update(branch=branch, branch_value=float(x[positions[branch]]))
                    stack.append((inside, outside + (branch,)))
                    stack.append((inside + (branch,), outside))
            elif solver.getModelStatus() != high.HighsModelStatus.kInfeasible:
                out['unknown_nodes'].append(dict(inside=list(inside), outside=list(outside)))
        out['rows'].append(row)
        save()
        print(dict(node=len(out['rows']), **{k: v for k, v in row.items() if k not in ('inside', 'outside')}), flush=True)
        if out['status'] == 'verified_improvement':
            break
    if out['status'] == 'running':
        out['status'] = 'bounded_attempt_complete'
    if out['status'] == 'bounded_attempt_complete':
        validate_partial_tree(out | {'pending_nodes': [dict(inside=list(a), outside=list(b)) for a, b in stack]})
    save()


if __name__ == '__main__':
    main()
