"""Compare the previous59-cut LP with the next checked generation of clauses."""
import argparse
import json
from pathlib import Path
import numpy as np
from check_core_subtree_cuts import verify as verify_first, sha
from check_core_subtree_cuts_v2 import verify as verify_refined
from solve_core_radius_ipm import load_radius_model, model_digest
from search_core_with_subtree_cuts import append_before_radius, solve


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--cuts', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    assert __debug__ and not args.output.exists()
    cuts = verify_refined(args.cuts)
    tree_path = Path(cuts['clauses'][0]['tree'])
    tree = json.loads(tree_path.read_text())
    first_path = Path(tree['subtree_cuts'])
    first = verify_first(first_path)
    data, matrix, lower, upper, vhi, _ = load_radius_model(Path(cuts['input']), cuts['radius'])
    pos = {v: i for i, v in enumerate(data['pool'])}
    exclusion = json.loads(Path(tree['domain_exclusion']).read_text())
    entries = [[(pos[v], 1) for v in exclusion['inside']],
               [(pos[v], 1) for v in tree['common_core_cut_words']]]
    matrix, lower, upper = append_before_radius(matrix, lower, upper, entries, [0, 0],
        [exclusion['inequality_upper'], tree['common_core_cut_upper']])
    lower[-3] = data['target']
    for generation in (first, cuts):
        assert generation['input'] == cuts['input'] and generation['radius'] == cuts['radius']
        assert model_digest(matrix, lower, upper, vhi) == generation['target_model_sha256']
        entries = [[(pos[v], 1) for v in c['inside']] + [(pos[v], -1) for v in c['outside']]
                   for c in generation['clauses']]
        lo = [-len(c['outside']) for c in generation['clauses']]
        hi = [len(c['inside'])-1 for c in generation['clauses']]
        before = matrix, lower, upper
        matrix, lower, upper = append_before_radius(matrix, lower, upper, entries, lo, hi)
    out = dict(status='running', input=cuts['input'], radius=cuts['radius'],
               original_model_sha256=cuts['target_model_sha256'],
               strengthened_model_sha256=model_digest(matrix, lower, upper, vhi),
               added_clauses=len(cuts['clauses']), source_sha256=sha(__file__),
               dependencies={str(p): sha(p) for p in (args.cuts, tree_path, first_path)},
               scope='Numerical LP comparison only. No integer solution or exclusion claimed.')
    for name in ('check_core_subtree_cuts.py', 'derive_core_subtree_cuts.py',
                 'check_core_subtree_cuts_v2.py', 'derive_core_subtree_cuts_v2.py',
                 'solve_core_radius_ipm.py', 'search_core_with_subtree_cuts.py'):
        p = Path(__file__).with_name(name)
        out['dependencies'][str(p)] = sha(p)
    cost = np.zeros(len(pos))
    for j, value in entries[0]:
        cost[j] = -value
    for label, a, low, high in [('before', *before), ('after', matrix, lower, upper)]:
        result, values = solve(a, low, high, vhi, 30, False, cost)
        if values is not None:
            result['values'] = values.tolist()
            result['first_clause_lhs'] = float(-cost @ values)
            result['first_clause_violation'] = float(-cost @ values-hi[0])
        out[label] = result
        args.output.write_text(json.dumps(out, indent=2)+'\n')
        print(label, {k:v for k,v in result.items() if k!='values'}, flush=True)
    out['status'] = 'complete_attempt'
    args.output.write_text(json.dumps(out, indent=2)+'\n')


if __name__ == '__main__':
    main()
