"""Check first-word partitions and interruption checkpoints against subsets."""
import hashlib
from itertools import combinations
import json
from pathlib import Path
import random
import subprocess
import sys


def main():
    assert __debug__
    output=Path(sys.argv[1]);assert not output.exists()
    here=Path(__file__).resolve().parent;binary=here/'exchange_dfs_root_resume'
    rng=random.Random(219190);records=[]
    def encode(blocked,compatible,radius):
        n=len(blocked);mask=(1<<64)-1;cw=(n+63)//64
        lines=[f'{n} 2 {radius}']
        for b,c in zip(blocked,compatible):
            lines.append(' '.join(format(v,'x') for v in [b&mask,b>>64]+[(c>>(64*w))&mask for w in range(cw)]))
        return '\n'.join(lines)+'\n'
    def run(data,start,end,neutral=False,seconds='2'):
        args=[str(binary),seconds,'--subset','--budget-bitsets','--root-start',str(start),'--root-prefix',str(end)]
        if neutral:args+=['--neutral']
        p=subprocess.run(args,input=data,text=True,capture_output=True,check=True,timeout=5)
        r=json.loads(p.stdout);assert r['root_start']==start and r['root_end']==end and start<=r['next_root']<=end
        return r
    for case in range(40):
        n=12 if case<32 else 70;radius=2+case%4 if case<32 else 2
        neutral=bool(case%2);target=radius if neutral else radius+1
        prefix=n if case<32 else (63,64,65,70)[case%4]
        space=[0,2,61,63,64,65,90,100,127]
        blocked=[sum(1<<j for j in rng.sample(space,rng.randint(0,5))) for _ in range(n)]
        compatible=[0]*n
        for i,j in combinations(range(n),2):
            if rng.random()<.8:compatible[i]|=1<<j;compatible[j]|=1<<i
        expected=[];tested=0
        for c in combinations(range(n),target):
            tested+=1
            if c[0]>=prefix or any(not (compatible[i]>>j)&1 for i,j in combinations(c,2)):continue
            union=0
            for i in c:union|=blocked[i]
            if union.bit_count()<=radius:expected.append((list(c),union.bit_count()))
        data=encode(blocked,compatible,radius);cuts=sorted(set([0,1,prefix//2,prefix]));rows=[]
        for start,end in zip(cuts,cuts[1:]):
            wanted=[(c,b) for c,b in expected if start<=c[0]<end]
            r=run(data,start,end,neutral);assert r['status'] in ('witness','exhausted')
            if neutral:
                assert r['neutral']==[c for c,b in wanted if b==radius]
                assert r['improving']==[c for c,b in wanted if b<radius]
            else:
                assert (r['status']=='witness')==bool(wanted)
                if wanted:assert r['chosen']==wanted[0][0]
                assert not any(c[0]<r['next_root'] for c,b in wanted)
            if r['status']=='exhausted':assert r['next_root']==end and r['nodes_started']==r['nodes_completed']
            rows.append(dict(start=start,end=end,status=r['status'],next_root=r['next_root']))
        empty=run(data,prefix,prefix,neutral);assert empty['status']=='exhausted' and empty['nodes_started']==0
        records.append(dict(case=case,n=n,radius=radius,neutral=neutral,subsets=tested,positive=len(expected),partitions=rows))
    # Twenty isolated roots finish quickly. The remaining graph has eight
    # cliques of ten vertices, so no ten-vertex compatible subset exists.
    # Enumerating it interrupts inside a later root, preserving earlier roots.
    n=100;blocked=[1]*n;compatible=[0]*n
    for i,j in combinations(range(20,n),2):
        if (i-20)//10!=(j-20)//10:compatible[i]|=1<<j;compatible[j]|=1<<i
    data=encode(blocked,compatible,9);timed=run(data,0,n,seconds='.01')
    assert timed['status']=='timeout' and 20<=timed['next_root']<n
    replay=run(data,0,timed['next_root']);assert replay['status']=='exhausted'
    resumed=run(data,timed['next_root'],n,seconds='.01')
    assert resumed['status']=='timeout' and resumed['next_root']>=timed['next_root']
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    out=dict(source_sha256=sha(__file__),kernel_sha256=sha(binary),kernel_source_sha256=sha(here/'exchange_dfs.cpp'),
             cases=records,timeout=timed,closed_prefix_replay=replay,resumed=resumed)
    output.write_text(json.dumps(out,indent=2)+'\n')
    print('cases',len(records),'subsets',sum(r['subsets'] for r in records),'checkpoint',timed['next_root'])


if __name__=='__main__':main()
