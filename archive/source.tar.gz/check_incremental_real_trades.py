"""Check the parent reduction on real trades from the original radius-six run."""
import gzip
import hashlib
from itertools import product
import json
from pathlib import Path

import numpy as np


def main():
    assert __debug__
    root = Path('research/c7')
    output = root / 'component-incremental6-real-trade-controls-sep22.json'
    assert not output.exists()
    dependencies = {}

    def sha(p):
        return hashlib.sha256(Path(p).read_bytes()).hexdigest()

    def read(p):
        dependencies[str(p)] = sha(p)
        return json.loads(Path(p).read_text())

    baseline = read(root / 'component-CB-atomic6-C-joined-verification-sep22.json')
    prefix = read(root / 'component-CB-incremental6-partial-verification-sep22.json')
    for proof in (baseline, prefix):
        assert all(sha(p) == h for p, h in proof['dependencies'].items())
        assert not proof['outside'] and not proof['improving']
        dependencies.update(proof['dependencies'])
    manifest_path = root / 'component-CB-incremental-sep22-input.json'
    manifest = read(manifest_path)
    assert prefix['dependencies'][str(manifest_path)] == sha(manifest_path)
    reference = read(manifest['reference_manifest'])
    assert sha(manifest['reference_manifest']) == manifest['reference_manifest_sha256']
    assert baseline['dependencies'][reference['source']] == reference['source_sha256']
    assert sha(manifest['source']) == manifest['source_sha256']
    dependencies[manifest['source']] = sha(manifest['source'])
    with gzip.open(manifest['source'], 'rt') as f:
        next(f)
        states = [tuple(json.loads(line)) for line in f]
    known = set(states)
    inverse = {original: i for i, original in enumerate(manifest['source_indices'])}
    coords = np.array(list(product(range(7), repeat=5)), dtype=np.int16)
    observed = []
    pairs = 0
    counts = dict(covered_by_parent=0, commuting=0, retained_critical=0, root=0)
    required = []
    for interval in baseline['intervals']:
        run = read(interval['file'])
        for row in run['rows']:
            if row.get('event') != 'trade':
                continue
            index = inverse[row['state']]
            old = states[index]
            target = tuple(sorted((set(old) - set(row['removed'])) | set(row['added'])))
            assert target in known
            parent_index = manifest['parents'][index]
            branch = 'root'
            if parent_index >= 0:
                parent = states[parent_index]
                x, = set(old) - set(parent)
                y, = set(parent) - set(old)
                if x not in target:
                    assert len(set(parent)-set(target)) <= 6
                    branch = 'covered_by_parent'
                else:
                    inserted = sorted(set(target)-set(old))
                    diff = (coords[inserted]-coords[y]) % 7
                    critical = np.any(np.all((diff == 0) | (diff == 1) | (diff == 6), axis=1))
                    if critical:
                        branch = 'retained_critical'
                    else:
                        transformed = tuple(sorted((set(target)-{x}) | {y}))
                        assert len(transformed) == 367 and transformed in known
                        assert len(set(parent)-set(transformed)) <= 6
                        points = coords[list(transformed)]
                        diff = (points[:, None, :] - points[None, :, :]) % 7
                        bad = np.all((diff == 0) | (diff == 1) | (diff == 6), axis=2)
                        assert np.array_equal(bad, np.eye(367, dtype=bool))
                        pairs += 367 * 366 // 2
                        branch = 'commuting'
            counts[branch] += 1
            if branch in ('root', 'retained_critical'):
                required.append(dict(state=index, removed=row['removed'], added=row['added']))
            observed.append(dict(original_state=row['state'], forest_state=index, branch=branch))
    prefix_rows = []
    for interval in prefix['intervals']:
        prefix_rows.extend(read(interval['file'])['rows'])
    for row in required:
        if row['state'] < prefix['next_state']:
            assert any(r.get('event') == 'trade' and r['state'] == row['state']
                       and set(r['removed']) == set(row['removed'])
                       and set(r['added']) == set(row['added']) for r in prefix_rows)
    assert len(observed) == baseline['checked_trades'] == 12
    result = dict(checker_sha256=sha(__file__), dependencies=dependencies,
                  passed=True, trades=len(observed), branches=counts,
                  additional_pair_checks=pairs, observed=observed,
                  required_in_incremental_trace=required,
                  scope='Twelve actual internal neutral trades from the checked original-order prefix. Verifies parent coverage or commutation, and records any trades that the incremental scan must emit. No new construction or full-union closure claim.')
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('dependencies', 'observed', 'scope')}))


if __name__ == '__main__':
    main()
