// Scan atomic three-removal trades at every state in a supplied finite cache.
// A neutral trade returns 3 insertions; an improvement returns 4.
// Candidates have 2 or 3 blockers, and equal two-blocker pairs cannot coexist.
// This file does not prove that the supplied cache is closed under width two.
#include <algorithm>
#include <array>
#include <cassert>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <map>
#include <random>
#include <set>
#include <stdexcept>
#include <string>
#include <vector>

struct Candidate { int word; std::vector<int> blockers; };
using Choice = std::vector<int>;
using Clock = std::chrono::steady_clock;

static int pair_key(int a, int b) { return (a << 9) | b; }
static int triple_key(int a, int b, int c) { return (a << 18) | (b << 9) | c; }

template<class Compatible, class Emit>
static std::uint64_t enumerate(int old_count, const std::vector<Candidate>& pool,
                               Compatible compatible, Emit emit) {
    assert(old_count > 0 && old_count < 512);
    std::map<int, std::vector<int>> pairs, triples;
    std::vector<std::set<int>> adjacent(old_count);
    for (int i = 0; i < static_cast<int>(pool.size()); ++i) {
        const auto& b = pool[i].blockers;
        assert((b.size() == 2 || b.size() == 3) && std::is_sorted(b.begin(), b.end()));
        assert(b.front() >= 0 && b.back() < old_count && std::adjacent_find(b.begin(), b.end()) == b.end());
        if (b.size() == 2) {
            pairs[pair_key(b[0], b[1])].push_back(i);
            adjacent[b[0]].insert(b[1]); adjacent[b[1]].insert(b[0]);
        } else triples[triple_key(b[0], b[1], b[2])].push_back(i);
    }
    // If a trade has no degree-three candidate, its three distinct blocker
    // pairs must form a triangle. All other eligible triples already have a key.
    for (const auto& [key, unused] : pairs) {
        int a = key >> 9, b = key & 511;
        for (int c : adjacent[b])
            if (c > b && adjacent[a].count(c)) triples.try_emplace(triple_key(a, b, c));
    }
    auto allowed = [&](int i, int j) {
        return !(pool[i].blockers.size() == 2 && pool[i].blockers == pool[j].blockers)
            && compatible(i, j);
    };
    for (const auto& [key, degree_three] : triples) {
        std::array<int, 3> b = {key >> 18, (key >> 9) & 511, key & 511};
        Choice eligible = degree_three;
        for (int i = 0; i < 3; ++i) for (int j = i+1; j < 3; ++j) {
            auto it = pairs.find(pair_key(b[i], b[j]));
            if (it != pairs.end()) eligible.insert(eligible.end(), it->second.begin(), it->second.end());
        }
        std::sort(eligible.begin(), eligible.end());
        assert(std::adjacent_find(eligible.begin(), eligible.end()) == eligible.end());
        for (std::size_t i = 0; i < eligible.size(); ++i)
        for (std::size_t j = i+1; j < eligible.size(); ++j) {
            int u = eligible[i], v = eligible[j]; if (!allowed(u, v)) continue;
            for (std::size_t k = j+1; k < eligible.size(); ++k) {
                int w = eligible[k]; if (!allowed(u,w) || !allowed(v,w)) continue;
                for (std::size_t l = k+1; l < eligible.size(); ++l) {
                    int x = eligible[l];
                    if (allowed(u,x) && allowed(v,x) && allowed(w,x)) emit(Choice{u,v,w,x});
                }
                emit(Choice{u,v,w});
            }
        }
    }
    return triples.size();
}

static void self_test() {
    std::mt19937 rng(20260922);
    std::uint64_t tested = 0, emitted = 0, improvements = 0;
    for (int test = 0; test < 200; ++test) {
        int old = 3 + test % 5, n = 4 + test % 7;
        std::vector<Candidate> pool;
        for (int i = 0; i < n; ++i) {
            int degree = (test == 0 || rng()%2) ? 3 : 2;
            std::set<int> b;
            while (static_cast<int>(b.size()) < degree) b.insert(rng()%old);
            pool.push_back({i, {b.begin(), b.end()}});
        }
        std::vector<std::vector<bool>> comp(n, std::vector<bool>(n));
        for (int i=0; i<n; ++i) for (int j=i+1; j<n; ++j)
            comp[i][j] = comp[j][i] = (test == 0 || rng()%2);
        std::set<Choice> actual, expected;
        enumerate(old, pool, [&](int i,int j){return comp[i][j];}, [&](const Choice& c){
            if (!actual.insert(c).second) throw std::runtime_error("Duplicate emitted trade");
        });
        for (unsigned mask=0; mask < (1u<<n); ++mask) {
            int count=__builtin_popcount(mask); if(count!=3 && count!=4) continue;
            ++tested; Choice c; std::set<int> blockers; bool ok=true;
            for(int i=0;i<n;++i) if(mask>>i&1) {
                c.push_back(i); blockers.insert(pool[i].blockers.begin(),pool[i].blockers.end());
                for(int j=0;j<i;++j) if(mask>>j&1)
                    ok &= comp[i][j] && !(pool[i].blockers.size()==2 && pool[i].blockers==pool[j].blockers);
            }
            if(ok && blockers.size()<=3) expected.insert(c);
        }
        if(actual!=expected) throw std::runtime_error("Disagreement with exhaustive subset control");
        emitted += actual.size();
        for(const auto& c:actual) improvements += c.size()==4;
    }
    assert(improvements > 0);
    std::cout << "{\"status\":\"passed\",\"cases\":200,\"subsets\":" << tested
              << ",\"trades\":" << emitted << ",\"improvements\":" << improvements << "}\n";
}

static void print_words(const std::vector<int>& words) {
    std::cout << '[';
    for(std::size_t i=0;i<words.size();++i) { if(i)std::cout<<',';std::cout<<words[i]; }
    std::cout << ']';
}

int main(int argc,char** argv) {
    try {
        if(argc==2 && std::string(argv[1])=="--self-test") { self_test(); return 0; }
        if(argc!=3) throw std::runtime_error("Usage: scan_component_atomic3 SECONDS START_STATE < cache.txt");
        double seconds=std::stod(argv[1]); int start=std::stoi(argv[2]);
        int nstates, size; if(!(std::cin>>nstates>>size)) throw std::runtime_error("Missing header");
        if(size!=367 || nstates<=0 || start<0 || start>nstates || !(seconds>0)) throw std::runtime_error("Invalid input limits");
        std::vector<std::vector<int>> states(nstates,std::vector<int>(size));
        std::set<std::vector<int>> known;
        for(auto& state:states) {
            for(int& v:state) if(!(std::cin>>v) || v<0 || v>=16807) throw std::runtime_error("Bad word");
            if(!std::is_sorted(state.begin(),state.end()) || std::adjacent_find(state.begin(),state.end())!=state.end()
               || !known.insert(state).second) throw std::runtime_error("Unsorted/duplicate state");
        }
        std::string extra; if(std::cin>>extra) throw std::runtime_error("Unexpected trailer");
        std::array<std::array<int,5>,16807> coords;
        for(int v=0;v<16807;++v) {int x=v;for(int k=4;k>=0;--k){coords[v][k]=x%7;x/=7;}}
        auto compatible = [&](int u,int v) {
            for(int k=0;k<5;++k) {int d=(coords[u][k]-coords[v][k]+7)%7;if(d>=2 && d<=5)return true;}
            return false;
        };
        std::vector<std::array<int,243>> neighbors(16807);
        for(int v=0;v<16807;++v) for(int s=0;s<243;++s) {
            int bits=s, word=0;
            for(int k=0;k<5;++k) {int delta=bits%3-1;bits/=3;word=7*word+(coords[v][k]+delta+7)%7;}
            neighbors[v][s]=word;
        }
        auto began=Clock::now(); auto elapsed=[&]{return std::chrono::duration<double>(Clock::now()-began).count();};
        std::array<int,16807> count;
        std::array<std::array<int,3>,16807> blocked;
        std::array<bool,16807> chosen;
        std::uint64_t total_groups=0,total_neutral=0,total_internal=0,total_improving=0;
        int state_index=start; std::string status="exhausted";
        for(;state_index<nstates;++state_index) {
            if(elapsed()>=seconds) {status="timeout";break;}
            const auto& ref=states[state_index];count.fill(0);chosen.fill(false);
            for(int i=0;i<size;++i) {
                chosen[ref[i]]=true;
                for(int v:neighbors[ref[i]]) {if(count[v]<3)blocked[v][count[v]]=i;++count[v];}
            }
            for(int v:ref) if(count[v]!=1) throw std::runtime_error("Reference is not independent");
            std::vector<Candidate> pool;
            for(int v=0;v<16807;++v) {
                if(count[v]==0) throw std::runtime_error("Reference admits immediate insertion");
                if(!chosen[v] && (count[v]==2 || count[v]==3))
                    pool.push_back({v,{blocked[v].begin(),blocked[v].begin()+count[v]}});
            }
            std::vector<int> escape, improvement;
            Choice escape_choice,improvement_choice;
            auto make_words=[&](const Choice& c) {
                std::set<int> removed;
                for(int i:c) removed.insert(pool[i].blockers.begin(),pool[i].blockers.end());
                assert(removed.size()==3);
                std::vector<int> words;
                for(int i=0;i<size;++i) if(!removed.count(i))words.push_back(ref[i]);
                for(int i:c)words.push_back(pool[i].word);
                std::sort(words.begin(),words.end());return words;
            };
            total_groups+=enumerate(size,pool,[&](int i,int j){return compatible(pool[i].word,pool[j].word);},[&](const Choice& c){
                std::set<int> removed;
                std::vector<int> inserted;
                for(int i:c) {removed.insert(pool[i].blockers.begin(),pool[i].blockers.end());inserted.push_back(pool[i].word);}
                std::vector<int> deleted;
                for(int i:removed)deleted.push_back(ref[i]);
                std::cout<<"{\"event\":\"trade\",\"state\":"<<state_index<<",\"removed\":";
                print_words(deleted);std::cout<<",\"added\":";print_words(inserted);std::cout<<"}\n";
                if(c.size()==4) {
                    ++total_improving;
                    if(improvement.empty()){improvement=make_words(c);improvement_choice=c;}
                } else {
                    ++total_neutral;auto words=make_words(c);
                    if(known.count(words))++total_internal;
                    else if(escape.empty()){escape=std::move(words);escape_choice=c;}
                }
            });
            if(!improvement.empty() || !escape.empty()) {
                const auto& result=improvement.empty()?escape:improvement;
                for(std::size_t i=0;i<result.size();++i) for(std::size_t j=0;j<i;++j)
                    if(!compatible(result[i],result[j]))throw std::runtime_error("Returned construction conflicts");
                std::cout<<"{\"event\":\"candidate\",\"state\":"<<state_index<<",\"size\":"<<result.size()<<",\"words\":";
                print_words(result);std::cout<<"}\n";
                ++state_index;status=improvement.empty()?"escape":"witness";break;
            }
        }
        std::cout<<"{\"status\":\""<<status<<"\",\"start_state\":"<<start<<",\"next_state\":"<<state_index
                 <<",\"total_states\":"<<nstates<<",\"groups\":"<<total_groups<<",\"neutral\":"<<total_neutral
                 <<",\"internal_neutral\":"<<total_internal<<",\"improving\":"<<total_improving
                 <<",\"seconds\":"<<elapsed()<<"}\n";
    } catch(const std::exception& e) {std::cerr<<e.what()<<'\n';return 1;}
}
