"""Enumerate all compatible d-tuples with at most d incumbent blockers."""
import time


def enumerate_exchanges(blockers, compatible, d, seconds=60, max_results=100000):
    assert 1 <= d <= 6 and len(blockers) == len(compatible)
    groups = {}
    for i, mask in enumerate(blockers):
        assert mask >= 0
        groups[mask] = groups.get(mask, 0) | (1 << i)
    began = time.monotonic()
    deadline = began + seconds
    neutral, improving = [], []
    examined = 0

    def visit(chosen, used, allowed):
        nonlocal examined
        if time.monotonic() >= deadline:
            raise TimeoutError
        if len(chosen) == d:
            (neutral if used.bit_count() == d else improving).append(chosen)
            if len(neutral)+len(improving) >= max_results:
                raise OverflowError
            return
        if used.bit_count() == d:
            eligible, sub = 0, used
            while True:
                eligible |= groups.get(sub, 0)
                if not sub:
                    break
                sub = (sub-1) & used
            allowed &= eligible
        if allowed.bit_count() < d-len(chosen):
            return
        while allowed:
            bit = allowed & -allowed
            allowed ^= bit
            i = bit.bit_length()-1
            examined += 1
            if examined % 1024 == 0 and time.monotonic() >= deadline:
                raise TimeoutError
            merged = used | blockers[i]
            if merged.bit_count() <= d:
                visit(chosen+(i,), merged, allowed & compatible[i])

    status = 'exhausted'
    try:
        visit((), 0, (1 << len(blockers))-1)
    except TimeoutError:
        status = 'timeout'
    except OverflowError:
        status = 'output_limit'
    return dict(status=status, neutral=neutral, improving=improving,
                candidate_visits=examined, seconds=time.monotonic()-began)
