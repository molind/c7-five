"""Attach verified necessary anchor counts; keep the existing graph order."""
import json,hashlib
from pathlib import Path
from collections import Counter
p=Path(__file__).parent
m=json.loads((p/'core-anchor-family-c-input.json').read_text());raw=(p/'core-anchor-family-c-d7.txt').read_bytes()
assert hashlib.sha256(raw).hexdigest()==m['graph_sha256']
old=json.loads((p/'two-anchor-global-results.json').read_text());by_word={r['anchor']:r for r in old['rows']}
updates=json.loads((p/'optimized-anchor-bound-updates.json').read_text());tight={r['anchor']:r for r in updates}
base=[];improved=[]
for i,w in enumerate(m['pool']):
    token=''.join(map(str,w))
    if i<m['anchors']:
        r=by_word[token];k=368-r['cover_units']//1000000
        assert 1<=k<=8
    else:k=0
    base.append(k);improved.append(max(k,tight[token]['min_outside_u2']) if token in tight else k)
for name,req in [('base',base),('tight',improved)]:
    graph=raw.decode()+' '.join(map(str,req))+'\n'
    (p/f'anchor-count-{name}-d7.txt').write_text(graph)
    first,rest=graph.split('\n',1);n,bw,d=map(int,first.split());assert d==7
    (p/f'anchor-count-{name}-d6.txt').write_text(f'{n} {bw} 6\n'+rest)
    print(name,dict(sorted(Counter(req[:m['anchors']]).items())),flush=True)
meta=dict(anchors=m['anchors'],candidates=m['candidates'],changed=[dict(index=i,word=''.join(map(str,m['pool'][i])),old=a,new=b) for i,(a,b) in enumerate(zip(base,improved)) if a!=b],base=base,tight=improved)
(p/'anchor-count-input.json').write_text(json.dumps(meta)+'\n')
