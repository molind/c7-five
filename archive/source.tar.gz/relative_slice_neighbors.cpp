// Exact relative neighbors of C7^4 slices. No parent cycles or placed library.
// stdin: N, then N rows: point-count followed by lexicographic base-7 IDs.
// stdout little-endian: C7RN, u32 N, u32 transforms, then N rows:
// u32 edge-count followed by (u16 right, u16 transform, u16 shift), then DONE.
#include <algorithm>
#include <array>
#include <bitset>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <stdexcept>
#include <vector>

constexpr int V = 2401;
using Mask = std::bitset<V>;
using Word = std::array<int,4>;
using Edge = std::array<std::uint16_t,3>;

int encode(const Word& w) { return ((w[0]*7+w[1])*7+w[2])*7+w[3]; }
void u16(unsigned x) { std::cout.put(char(x&255)); std::cout.put(char((x>>8)&255)); }
void u32(unsigned x) { u16(x&65535); u16(x>>16); }

int main(int argc, char** argv) {
    try {
        const int nt = argc == 2 ? std::stoi(argv[1]) : 384;
        if (argc>2 || nt<1 || nt>384) throw std::runtime_error("Expected transform count 1..384");
        std::ios::sync_with_stdio(false);
        int n;
        if (!(std::cin>>n) || n<1 || n>65535) throw std::runtime_error("Invalid slice count");
        std::array<Word,V> words{};
        for (int v=0;v<V;++v) { int x=v; for(int k=3;k>=0;--k) {words[v][k]=x%7;x/=7;} }
        std::vector<std::vector<int>> slices(n);
        for (auto& sl:slices) {
            int count;
            if (!(std::cin>>count) || count<1 || count>V) throw std::runtime_error("Invalid slice size");
            Mask seen;
            for(int j=0;j<count;++j) {
                int v;
                if (!(std::cin>>v) || v<0 || v>=V || seen[v]) throw std::runtime_error("Invalid point");
                seen.set(v);sl.push_back(v);
            }
        }
        std::string extra;
        if (std::cin>>extra) throw std::runtime_error("Trailing input");
        std::array<std::array<Mask,7>,4> lows{};
        const std::array<int,4> stride={343,49,7,1};
        for(int k=0;k<4;++k) for(int a=1;a<7;++a) for(int v=0;v<V;++v)
            if(words[v][k]<a) lows[k][a].set(v);
        std::vector<Mask> neighborhoods(V);
        for(int v=0;v<V;++v) for(int a=-1;a<=1;++a) for(int b=-1;b<=1;++b)
            for(int c=-1;c<=1;++c) for(int d=-1;d<=1;++d)
                neighborhoods[v].set(encode({(words[v][0]+a+7)%7,(words[v][1]+b+7)%7,
                    (words[v][2]+c+7)%7,(words[v][3]+d+7)%7}));
        // Transform order matches permutations(range(4)), product((-1,1), repeat=4).
        std::vector<std::vector<std::vector<int>>> moved;
        Word perm={0,1,2,3};
        do {
            for(int bits=0;bits<16 && int(moved.size())<nt;++bits) {
                std::vector<std::vector<int>> sets(n);
                for(int r=0;r<n;++r) for(int v:slices[r]) {
                    Word w{};
                    for(int k=0;k<4;++k) w[k]=(((bits&(8>>k))?1:-1)*words[v][perm[k]]+7)%7;
                    sets[r].push_back(encode(w));
                }
                moved.push_back(std::move(sets));
            }
        } while(int(moved.size())<nt && std::next_permutation(perm.begin(),perm.end()));
        if(int(moved.size())!=nt) throw std::runtime_error("Transform enumeration failed");
        auto began=std::chrono::steady_clock::now();
        std::cout.write("C7RN",4);u32(n);u32(nt);
        std::uint64_t total=0;
        for(int left=0;left<n;++left) {
            Mask allowed;allowed.set();
            for(int v:slices[left]) allowed &= ~neighborhoods[v];
            std::vector<Mask> table(V);
            for(int b=0;b<V;++b) {
                Mask current=allowed;
                for(int k=0;k<4;++k) {
                    const int a=words[b][k];
                    if(a) {const Mask low=current&lows[k][a];current=((current^low)>>(a*stride[k]))|(low<<((7-a)*stride[k]));}
                }
                table[b]=current;
            }
            std::vector<Edge> edges;
            for(int t=0;t<nt;++t) for(int right=0;right<n;++right) {
                const auto& sl=moved[t][right];
                Mask good=table[sl[0]];
                for(std::size_t j=1;j<sl.size() && good.any();++j) good &= table[sl[j]];
                if(good.any()) for(int shift=0;shift<V;++shift) if(good[shift])
                    edges.push_back({std::uint16_t(right),std::uint16_t(t),std::uint16_t(shift)});
            }
            if(edges.size()>UINT32_MAX) throw std::runtime_error("Too many row edges");
            u32(unsigned(edges.size()));for(const auto& e:edges)for(auto x:e)u16(x);
            if(!std::cout) throw std::runtime_error("Output error");
            total+=edges.size();
            if(left%32==31 || left==n-1) {
                std::cout.flush();
                double seconds=std::chrono::duration<double>(std::chrono::steady_clock::now()-began).count();
                std::cerr<<"{\"rows\":"<<left+1<<",\"edges\":"<<total<<",\"seconds\":"<<seconds<<"}\n";
            }
        }
        std::cout.write("DONE",4);std::cout.flush();
        if(!std::cout) throw std::runtime_error("Output error");
    } catch(const std::exception& e) {std::cerr<<e.what()<<'\n';return 1;}
}
