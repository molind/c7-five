"""Exact residual problem after fixing the verified356-word Family-D core."""
from functools import lru_cache
import gzip
import hashlib
from itertools import combinations, product
import json
from pathlib import Path
import struct

HERE=Path(__file__).resolve().parent
if not __debug__: raise RuntimeError('Run without -O')
with gzip.open(HERE/'breakout-perturb64-sep20-2049-component-0.jsonl.gz','rt') as f:
    metadata=json.loads(next(f));states=[set(json.loads(line)) for line in f]
keys={struct.pack('<367H',*sorted(s)) for s in states}
assert len(keys)==384 and hashlib.sha256(b''.join(sorted(keys))).hexdigest()==metadata['component_sha256']
words=list(product(range(7),repeat=5));core=set.intersection(*states)
conflict=lambda a,b: all((x-y)%7 in (0,1,6) for x,y in zip(a,b))
assert len(core)==356 and not any(conflict(words[a],words[b]) for a,b in combinations(core,2))
blocked={v for w in core for v in product(*[[(x-1)%7,x,(x+1)%7] for x in words[w]])}
allowed=[w for w in words if w not in blocked]
adj=[sum(1<<j for j,v in enumerate(allowed) if j!=i and conflict(w,v)) for i,w in enumerate(allowed)]
@lru_cache(None)
def solve(mask):
    if not mask:return 0,(0,)
    v=max((i for i in range(len(allowed)) if mask>>i&1),key=lambda i:(adj[i]&mask).bit_count())
    bit=1<<v;without=mask^bit
    a,aa=solve(without);b,bb=solve(without&~adj[v]);b+=1
    if a>b:return a,aa
    with_v=tuple(s|bit for s in bb)
    if b>a:return b,with_v
    return a,aa+with_v
alpha,maxima=solve((1<<len(allowed))-1)
# An exhaustive include/exclude recursion partitions all independent subsets.
candidates=[];all_keys=set()
for mask in maxima:
    selected=[allowed[i] for i in range(len(allowed)) if mask>>i&1]
    target=sorted([words[v] for v in core]+selected)
    assert len(target)==len(set(target))==len(core)+alpha
    assert not any(conflict(a,b) for a,b in combinations(target,2))
    ids=[int(''.join(map(str,w)),7) for w in target]
    key=struct.pack('<'+str(len(ids))+'H',*ids);all_keys.add(key)
    if key not in keys:
        candidates.append(dict(step=0,words=[''.join(map(str,w)) for w in target],source='exact fixed-core residual'))
assert len(all_keys)==len(maxima)
r=dict(core_size=len(core),allowed_words=[''.join(map(str,w)) for w in allowed],residual_alpha=alpha,
       full_size=len(core)+alpha,maximum_sets=len(maxima),known_maxima=len(all_keys&keys),
       new_maxima=len(candidates),candidates=candidates,dp_subproblems=solve.cache_info().currsize,
       source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
       scope='Exact only with the356 core words fixed; no global upper bound.')
(HERE/'family-d-fixed-core-result.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:v for k,v in r.items() if k not in ('candidates','allowed_words')}))
