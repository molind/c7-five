"""Try arbitrary full-space additions to every verified orbit-search witness."""
import argparse
from collections import Counter
from itertools import combinations
import json
from pathlib import Path
import subprocess
import time

import numpy as np
from breakout_conflicts import graph
from check_orbit_two_new import check_words
from direct_slice_neighbors import sha


def main():
    if not __debug__:raise RuntimeError('Run without -O')
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True)
    p.add_argument('--verification',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args()
    if args.output.exists():raise FileExistsError(args.output)
    verification=json.loads(args.verification.read_text());assert verification['input_sha256']==sha(args.input)
    rows=[json.loads(x)for x in args.input.read_text().splitlines()]
    words,adj=graph(5);kernel=Path(__file__).with_name('slice_clique')
    report=dict(status='running',input_sha256=sha(args.input),verification_sha256=sha(args.verification),
        source_sha256=sha(__file__),kernel_sha256=sha(kernel),results=[],candidates=[],
        scope='All arbitrary additions retaining each saved witness; replacements are not considered.')
    began=time.monotonic();seen=set()
    def save():
        report['elapsed_seconds']=time.monotonic()-began
        tmp=args.output.with_suffix('.tmp');tmp.write_text(json.dumps(report,indent=2)+'\n');tmp.replace(args.output)
    save()
    for row in rows:
        fixed=row['words'];target=368-len(fixed);assert target>0
        blocked=np.zeros(16807,dtype=bool);blocked[fixed]=True;blocked[adj[fixed].ravel()]=True
        pool=np.flatnonzero(~blocked).tolist();r=dict(root=row['root'],fixed_size=len(fixed),target=target,pool=pool)
        if not pool:r.update(status='no_free_words',full_size=len(fixed));report['results'].append(r);continue
        delta=(words[pool][:,None,:]-words[pool][None,:,:])%7
        edges=np.argwhere(np.triu(np.all((delta==0)|(delta==1)|(delta==6),axis=2),1)).tolist()
        data=f'{len(pool)} {len(edges)} {target} 100 0\n\n'+''.join(f'{a} {b}\n'for a,b in edges)
        run=subprocess.run([str(kernel)],input=data,text=True,capture_output=True,check=True,timeout=5)
        result=json.loads(run.stdout);assert result['status']in ('exhausted','timeout','target_found')
        selected=result['vertices'];assert len(selected)==len(set(selected))==result['best_size']
        assert all(type(i)is int and 0<=i<len(pool)for i in selected)
        full=sorted(fixed+[pool[i]for i in selected]);pairs=check_words([tuple(map(int,words[v]))for v in full])
        assert (result['status']=='target_found')==(len(full)>=368)
        r.update(status=result['status'],result=result,full_size=len(full),verified_pairs=pairs)
        report['results'].append(r)
        if len(full)>=367 and tuple(full)not in seen:
            seen.add(tuple(full));report['candidates'].append(dict(step=row['root'],size=len(full),words=[''.join(map(str,words[v]))for v in full],verified_pairs=pairs))
        if len(report['results'])%100==0 or len(full)>=368:save()
        if len(full)>=368:break
    report['status']='candidate_found'if any(c['size']>=368 for c in report['candidates'])else'complete'
    report['statistics']=dict(Counter(r['status']for r in report['results']))
    report['size_histogram']=dict(Counter(r['full_size']for r in report['results']))
    save();print(json.dumps({k:report[k]for k in ['status','statistics','size_histogram','elapsed_seconds']}),flush=True)


if __name__=='__main__':main()
