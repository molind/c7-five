"""Join checked strong-model leaf proofs to directly verified weaker points."""
import argparse
import hashlib
from itertools import product
import json
from pathlib import Path

import numpy as np


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--probe', type=Path, required=True)
    p.add_argument('--verification', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    assert __debug__ and not args.output.exists()
    probe, proof = json.loads(args.probe.read_text()), json.loads(args.verification.read_text())
    assert probe['status'] == 'complete_attempt' and proof['passed']
    assert proof['checker_sha256'] == sha(Path(__file__).with_name('check_core_branch_certificates_v7.py'))
    for artifact in (probe, proof):
        assert all(sha(f) == h for f, h in artifact['dependencies'].items())
    tree_path = Path(probe['tree'])
    assert proof['dependencies'][str(tree_path)] == sha(tree_path)
    tree = json.loads(tree_path.read_text())
    bundles = []
    for f in proof['dependencies']:
        if Path(f).suffix == '.json':
            obj = json.loads(Path(f).read_text())
            if isinstance(obj, dict) and obj.get('tree') == str(tree_path) and obj.get('status') == 'complete_attempt':
                bundles.append(obj)
    assert len(bundles) == 1
    certs = {r['tree_index']: r['certificate'] for r in bundles[0]['rows'] if r['certificate'] is not None}
    data = json.loads(Path(tree['input']).read_text())
    cuts = json.loads(Path(tree['subtree_cuts']).read_text())
    assert probe['old_model_sha256'] == cuts['target_model_sha256']
    core = json.loads(Path(tree['common_core_base']).read_text())['fixed']
    exclusion = json.loads(Path(tree['domain_exclusion']).read_text())
    pool, fixed = data['pool'], set(data['fixed'])
    old = sorted(set(data['parent_words'])-fixed)
    old_set, pool_set = set(old), set(pool)
    coords = np.array(list(product(range(7), repeat=5)), dtype=np.int16)
    delta = (coords[pool, None, :] - coords[None, old, :]) % 7
    old_neighbors = np.all((delta == 0) | (delta == 1) | (delta == 6), axis=2)
    del delta
    base = set(next(r for r in data['rows'] if r['radius'] == tree['radius'])['excluded_words'])
    results = []
    for row in probe['rows']:
        if not row['feasible_fractional_point']:
            continue
        index = row['tree_index']
        node = tree['rows'][index]
        assert row['inside'] == node['inside'] and row['outside'] == node['outside'] and index in certs
        inside, outside = set(node['inside']), set(node['outside'])
        forbidden = outside | base
        for v in inside:
            delta = (coords[pool] - coords[v]) % 7
            neighbors = np.all((delta == 0) | (delta == 1) | (delta == 6), axis=1)
            forbidden |= set(np.array(pool)[neighbors].tolist()) - {v}
        deleted = forbidden & old_set
        assert not inside & forbidden and len(deleted) <= tree['radius']
        remaining = np.array([v not in deleted for v in old])
        blocked = len(deleted) + old_neighbors[:, remaining].sum(axis=1) > tree['radius']
        forbidden |= set(np.array(pool)[blocked].tolist()) - old_set - inside
        x = np.array(row['values'])
        assert x.shape == (len(pool),) and np.all(np.isfinite(x))
        values = np.zeros(16807)
        values[pool] = x
        values[list(fixed)] = 1
        grid = values.reshape((7,)*5)
        boxes = np.zeros_like(grid)
        for offsets in product((0, 1), repeat=5):
            boxes += np.roll(grid, tuple(-v for v in offsets), axis=(0, 1, 2, 3, 4))
        free, retained, m = float(x.sum()), float(values[old].sum()), len(old)
        violations = [0, float(-x.min()), float(x.max()-1), float(boxes.max()-1),
                      abs(free-data['target']), m-tree['radius']-retained, retained-m,
                      retained+10*free-11*m, float(values[core].sum()-311),
                      float(values[exclusion['inside']].sum()-exclusion['inequality_upper'])]
        if inside:
            violations.append(float(np.max(np.abs(values[list(inside)]-1))))
        if forbidden:
            violations.append(float(np.max(values[list(forbidden)])))
        residual = max(violations)
        assert residual < 1e-6 and abs(values.sum()-368) < 1e-6
        added_violation = max(float(values[c['inside']].sum()-values[c['outside']].sum()-(len(c['inside'])-1))
                              for c in cuts['clauses'])
        assert added_violation > 1e-6 and certs[index]['positive_gap'] > 0
        results.append(dict(tree_index=index, weaker_point_maximum_violation=residual,
                            maximum_added_clause_violation=added_violation,
                            exact_stronger_certificate_gap=certs[index]['positive_gap'], boxes_checked=16807))
    out = dict(passed=True, sampled_leaves=len(probe['rows']),
               weaker_fractional_feasible_and_stronger_certified=len(results), rows=results,
               checker_sha256=sha(__file__), dependencies={str(p): sha(p) for p in (args.probe, args.verification)},
               scope='Direct numerical weaker-point and forced-bound checks joined to previously checked exact stronger-model contradictions. Deterministic first-leaf sample; no global runtime claim.')
    args.output.write_text(json.dumps(out, indent=2) + '\n')
    print({k: v for k, v in out.items() if k not in ('dependencies', 'scope')})


if __name__ == '__main__':
    main()
