// Scan atomic four-removal trades at every state in a supplied finite cache.
// A neutral trade returns 4 insertions; an improvement returns 5.
// Candidates have 2..4 blockers; reducible one/two/three-insertion subsets are excluded.
// This file does not prove that the supplied cache is closed under width three.
#include <algorithm>
#include <array>
#include <cassert>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <map>
#include <random>
#include <set>
#include <stdexcept>
#include <string>
#include <vector>

struct Candidate { int word; std::vector<int> blockers; };
using Choice = std::vector<int>;
using Clock = std::chrono::steady_clock;

static int pair_key(int a, int b) { return (a << 9) | b; }
static int triple_key(int a, int b, int c) { return (a << 18) | (b << 9) | c; }

template<class Compatible, class Emit>
static std::uint64_t enumerate(int old_count, const std::vector<Candidate>& pool,
                               Compatible compatible, Emit emit) {
    assert(old_count > 0 && old_count < 512);
    std::map<int, std::vector<int>> pairs, triples;
    std::map<int, std::set<int>> third_by_pair;
    std::map<std::array<int,4>, std::vector<int>> groups;
    std::vector<std::set<int>> adjacent(old_count);
    for(int i=0;i<static_cast<int>(pool.size());++i) {
        const auto& b=pool[i].blockers;
        assert(b.size()>=2 && b.size()<=4 && std::is_sorted(b.begin(),b.end()));
        assert(b.front()>=0 && b.back()<old_count && std::adjacent_find(b.begin(),b.end())==b.end());
        if(b.size()==2) {
            pairs[pair_key(b[0],b[1])].push_back(i);
            adjacent[b[0]].insert(b[1]);adjacent[b[1]].insert(b[0]);
        } else if(b.size()==3) {
            triples[triple_key(b[0],b[1],b[2])].push_back(i);
            third_by_pair[pair_key(b[0],b[1])].insert(b[2]);
            third_by_pair[pair_key(b[0],b[2])].insert(b[1]);
            third_by_pair[pair_key(b[1],b[2])].insert(b[0]);
        } else groups[{b[0],b[1],b[2],b[3]}].push_back(i);
    }
    // A selected triple-blocker set can only grow to four through an edge
    // leaving it, a triple overlapping in two places, or a four-blocker word.
    for(const auto& entry:triples) {
        int key=entry.first;
        std::array<int,3> t={key>>18,(key>>9)&511,key&511};
        auto extend=[&](int x) {
            if(std::find(t.begin(),t.end(),x)!=t.end())return;
            std::array<int,4> q={t[0],t[1],t[2],x};std::sort(q.begin(),q.end());
            groups.try_emplace(q);
        };
        for(int a:t)for(int x:adjacent[a])extend(x);
        for(int i=0;i<3;++i)for(int j=i+1;j<3;++j) {
            auto it=third_by_pair.find(pair_key(t[i],t[j]));
            if(it!=third_by_pair.end())for(int x:it->second)extend(x);
        }
    }
    // Without degree-three/four words, four distinct blocker edges cannot
    // contain a triangle (a reducible triple), so they form a four-cycle.
    for(int a=0;a<old_count;++a) {
        std::vector<int> ns(adjacent[a].begin(),adjacent[a].end());
        for(std::size_t i=0;i<ns.size();++i)for(std::size_t j=i+1;j<ns.size();++j)
            for(int c:adjacent[ns[i]])if(c>a && c!=ns[j] && adjacent[ns[j]].count(c)) {
                std::array<int,4> q={a,ns[i],c,ns[j]};std::sort(q.begin(),q.end());
                groups.try_emplace(q);
            }
    }
    auto allowed=[&](int i,int j) {
        return !(pool[i].blockers.size()==2 && pool[i].blockers==pool[j].blockers) && compatible(i,j);
    };
    for(const auto& [q,fours]:groups) {
        Choice eligible=fours;
        for(int i=0;i<4;++i)for(int j=i+1;j<4;++j) {
            auto pair=pairs.find(pair_key(q[i],q[j]));
            if(pair!=pairs.end())eligible.insert(eligible.end(),pair->second.begin(),pair->second.end());
            for(int k=j+1;k<4;++k) {
                auto triple=triples.find(triple_key(q[i],q[j],q[k]));
                if(triple!=triples.end())eligible.insert(eligible.end(),triple->second.begin(),triple->second.end());
            }
        }
        std::sort(eligible.begin(),eligible.end());
        assert(std::adjacent_find(eligible.begin(),eligible.end())==eligible.end());
        std::vector<unsigned> masks;
        for(int c:eligible) {
            unsigned mask=0;
            for(int b:pool[c].blockers) {
                auto it=std::find(q.begin(),q.end(),b);assert(it!=q.end());
                mask|=1u<<static_cast<unsigned>(it-q.begin());
            }
            masks.push_back(mask);
        }
        auto irreducible3=[&](std::size_t i,std::size_t j,std::size_t k) {
            return (masks[i]|masks[j]|masks[k])==15;
        };
        for(std::size_t i=0;i<eligible.size();++i)
        for(std::size_t j=i+1;j<eligible.size();++j) {
            int u=eligible[i],v=eligible[j];if(!allowed(u,v))continue;
            for(std::size_t k=j+1;k<eligible.size();++k) {
                int w=eligible[k];
                if(!irreducible3(i,j,k) || !allowed(u,w) || !allowed(v,w))continue;
                for(std::size_t l=k+1;l<eligible.size();++l) {
                    int x=eligible[l];
                    if(!irreducible3(i,j,l) || !irreducible3(i,k,l) || !irreducible3(j,k,l)
                       || !allowed(u,x) || !allowed(v,x) || !allowed(w,x))continue;
                    for(std::size_t m=l+1;m<eligible.size();++m) {
                        int y=eligible[m];
                        if(!allowed(u,y)||!allowed(v,y)||!allowed(w,y)||!allowed(x,y))continue;
                        std::array<std::size_t,4> first={i,j,k,l};bool ok=true;
                        for(int a=0;a<4;++a)for(int b=a+1;b<4;++b)
                            ok &= irreducible3(first[a],first[b],m);
                        if(ok)emit(Choice{u,v,w,x,y});
                    }
                    emit(Choice{u,v,w,x});
                }
            }
        }
    }
    return groups.size();
}

static void self_test() {
    std::mt19937 rng(2026092204);
    std::uint64_t tested=0,emitted=0,improvements=0;
    for(int test=0;test<250;++test) {
        int old=4+test%5,n=5+test%7;
        std::vector<Candidate> pool;
        if(test==1) {
            old=4;n=4;pool={{0,{0,1}},{1,{1,2}},{2,{2,3}},{3,{0,3}}};
        } else if(test==2) {
            old=4;n=4;pool={{0,{0,1,2}},{1,{0,1,3}},{2,{0,2,3}},{3,{1,2,3}}};
        } else if(test==3) {
            old=4;n=4;pool={{0,{0,1,2}},{1,{0,3}},{2,{1,3}},{3,{2,3}}};
        } else for(int i=0;i<n;++i) {
            int degree=test==0?4:2+rng()%3;std::set<int> b;
            while(static_cast<int>(b.size())<degree)b.insert(rng()%old);
            pool.push_back({i,{b.begin(),b.end()}});
        }
        std::vector<std::vector<bool>> comp(n,std::vector<bool>(n));
        for(int i=0;i<n;++i)for(int j=i+1;j<n;++j)
            comp[i][j]=comp[j][i]=(test<4 || rng()%4!=0);
        std::set<Choice> actual,expected;
        enumerate(old,pool,[&](int i,int j){return comp[i][j];},[&](const Choice& c){
            if(!actual.insert(c).second)throw std::runtime_error("Duplicate emitted trade");
        });
        for(unsigned mask=0;mask<(1u<<n);++mask) {
            int count=__builtin_popcount(mask);if(count!=4 && count!=5)continue;
            ++tested;Choice c;std::set<int> all;bool ok=true;
            for(int i=0;i<n;++i)if(mask>>i&1) {
                c.push_back(i);all.insert(pool[i].blockers.begin(),pool[i].blockers.end());
                for(int j=0;j<i;++j)if(mask>>j&1)
                    ok &= comp[i][j] && !(pool[i].blockers.size()==2 && pool[i].blockers==pool[j].blockers);
            }
            for(std::size_t i=0;i<c.size();++i)for(std::size_t j=i+1;j<c.size();++j)
                for(std::size_t k=j+1;k<c.size();++k) {
                    std::set<int> b;
                    for(int v:{c[i],c[j],c[k]})b.insert(pool[v].blockers.begin(),pool[v].blockers.end());
                    ok &= b.size()>3;
                }
            if(ok && all.size()<=4)expected.insert(c);
        }
        if(actual!=expected)throw std::runtime_error("Disagreement with exhaustive subset control");
        if(test<4 && actual.empty())throw std::runtime_error("Explicit group-generator positive control failed");
        emitted+=actual.size();for(const auto& c:actual)improvements+=c.size()==5;
    }
    assert(improvements>0);
    std::cout<<"{\"status\":\"passed\",\"cases\":250,\"subsets\":"<<tested
             <<",\"trades\":"<<emitted<<",\"improvements\":"<<improvements<<"}\n";
}

static void print_words(const std::vector<int>& words) {
    std::cout << '[';
    for(std::size_t i=0;i<words.size();++i) { if(i)std::cout<<',';std::cout<<words[i]; }
    std::cout << ']';
}

int main(int argc,char** argv) {
    try {
        if(argc==2 && std::string(argv[1])=="--self-test") { self_test(); return 0; }
        if(argc!=3) throw std::runtime_error("Usage: scan_component_atomic4 SECONDS START_STATE < cache.txt");
        double seconds=std::stod(argv[1]); int start=std::stoi(argv[2]);
        int nstates, size; if(!(std::cin>>nstates>>size)) throw std::runtime_error("Missing header");
        if(size!=367 || nstates<=0 || start<0 || start>nstates || !(seconds>0)) throw std::runtime_error("Invalid input limits");
        std::vector<std::vector<int>> states(nstates,std::vector<int>(size));
        std::set<std::vector<int>> known;
        for(auto& state:states) {
            for(int& v:state) if(!(std::cin>>v) || v<0 || v>=16807) throw std::runtime_error("Bad word");
            if(!std::is_sorted(state.begin(),state.end()) || std::adjacent_find(state.begin(),state.end())!=state.end()
               || !known.insert(state).second) throw std::runtime_error("Unsorted/duplicate state");
        }
        std::string extra; if(std::cin>>extra) throw std::runtime_error("Unexpected trailer");
        std::array<std::array<int,5>,16807> coords;
        for(int v=0;v<16807;++v) {int x=v;for(int k=4;k>=0;--k){coords[v][k]=x%7;x/=7;}}
        auto compatible = [&](int u,int v) {
            for(int k=0;k<5;++k) {int d=(coords[u][k]-coords[v][k]+7)%7;if(d>=2 && d<=5)return true;}
            return false;
        };
        std::vector<std::array<int,243>> neighbors(16807);
        for(int v=0;v<16807;++v) for(int s=0;s<243;++s) {
            int bits=s, word=0;
            for(int k=0;k<5;++k) {int delta=bits%3-1;bits/=3;word=7*word+(coords[v][k]+delta+7)%7;}
            neighbors[v][s]=word;
        }
        auto began=Clock::now(); auto elapsed=[&]{return std::chrono::duration<double>(Clock::now()-began).count();};
        std::array<int,16807> count;
        std::array<std::array<int,4>,16807> blocked;
        std::array<bool,16807> chosen;
        std::uint64_t total_groups=0,total_neutral=0,total_internal=0,total_improving=0;
        int state_index=start; std::string status="exhausted";
        for(;state_index<nstates;++state_index) {
            if(elapsed()>=seconds) {status="timeout";break;}
            const auto& ref=states[state_index];count.fill(0);chosen.fill(false);
            for(int i=0;i<size;++i) {
                chosen[ref[i]]=true;
                for(int v:neighbors[ref[i]]) {if(count[v]<4)blocked[v][count[v]]=i;++count[v];}
            }
            for(int v:ref) if(count[v]!=1) throw std::runtime_error("Reference is not independent");
            std::vector<Candidate> pool;
            for(int v=0;v<16807;++v) {
                if(count[v]==0) throw std::runtime_error("Reference admits immediate insertion");
                if(!chosen[v] && (count[v]>=2 && count[v]<=4))
                    pool.push_back({v,{blocked[v].begin(),blocked[v].begin()+count[v]}});
            }
            std::vector<int> escape, improvement;
            auto make_words=[&](const Choice& c) {
                std::set<int> removed;
                for(int i:c) removed.insert(pool[i].blockers.begin(),pool[i].blockers.end());
                assert(removed.size()==4);
                std::vector<int> words;
                for(int i=0;i<size;++i) if(!removed.count(i))words.push_back(ref[i]);
                for(int i:c)words.push_back(pool[i].word);
                std::sort(words.begin(),words.end());return words;
            };
            total_groups+=enumerate(size,pool,[&](int i,int j){return compatible(pool[i].word,pool[j].word);},[&](const Choice& c){
                std::set<int> removed;
                std::vector<int> inserted;
                for(int i:c) {removed.insert(pool[i].blockers.begin(),pool[i].blockers.end());inserted.push_back(pool[i].word);}
                std::vector<int> deleted;
                for(int i:removed)deleted.push_back(ref[i]);
                std::cout<<"{\"event\":\"trade\",\"state\":"<<state_index<<",\"removed\":";
                print_words(deleted);std::cout<<",\"added\":";print_words(inserted);std::cout<<"}\n";
                if(c.size()==5) {
                    ++total_improving;
                    if(improvement.empty()){improvement=make_words(c);}
                } else {
                    ++total_neutral;auto words=make_words(c);
                    if(known.count(words))++total_internal;
                    else if(escape.empty()){escape=std::move(words);}
                }
            });
            if(!improvement.empty() || !escape.empty()) {
                const auto& result=improvement.empty()?escape:improvement;
                for(std::size_t i=0;i<result.size();++i) for(std::size_t j=0;j<i;++j)
                    if(!compatible(result[i],result[j]))throw std::runtime_error("Returned construction conflicts");
                std::cout<<"{\"event\":\"candidate\",\"state\":"<<state_index<<",\"size\":"<<result.size()<<",\"words\":";
                print_words(result);std::cout<<"}\n";
                ++state_index;status=improvement.empty()?"escape":"witness";break;
            }
        }
        std::cout<<"{\"status\":\""<<status<<"\",\"start_state\":"<<start<<",\"next_state\":"<<state_index
                 <<",\"total_states\":"<<nstates<<",\"groups\":"<<total_groups<<",\"neutral\":"<<total_neutral
                 <<",\"internal_neutral\":"<<total_internal<<",\"improving\":"<<total_improving
                 <<",\"seconds\":"<<elapsed()<<"}\n";
    } catch(const std::exception& e) {std::cerr<<e.what()<<'\n';return 1;}
}
