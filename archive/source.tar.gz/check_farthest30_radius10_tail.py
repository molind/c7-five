"""Join the farthest-center full-pool prefix to its certified four-blocker tail.

Every graph row is checked against verified geometry. Native traversal remains
a tested computational search, not an independently replayed proof trace.
"""
import argparse
import hashlib
import json
from pathlib import Path

from check_blocker_radius import check as check_radius
from check_pinned_prefix_chain import audit as audit_prefix


def audit(prefix, queries, geometry, count_proof, kernel, source):
    sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
    read = lambda p: json.loads(Path(p).read_text())
    pre = read(prefix)
    assert pre['checker_sha256'] == sha(Path(__file__).with_name('check_pinned_prefix_chain.py'))
    replay = json.loads(json.dumps(audit_prefix(**pre['inputs'])))
    assert all(pre[k] == v for k, v in replay.items())
    assert pre['full_local_radius_excluded'] >= 9 and not pre['target_sets']
    full_runs = [read(p) for p in pre['inputs']['queries'] if read(p)['max_removals'] == 10]
    assert full_runs and len({r['input_sha256'] for r in full_runs}) == 1
    full = read(full_runs[0]['input'])
    assert full['max_blockers'] == 10 and len(full['rows']) == 1
    assert len(full['rows'][0]['pool_ids']) == 16440
    runs = [(str(p), read(p)) for p in queries]; assert runs
    model_path = runs[0][1]['input']; model = read(model_path)
    assert model['status'] == 'complete' and model['min_blockers'] == 1 and model['max_blockers'] == 4
    assert model['input_sha256'] == full['input_sha256']
    geom = read(geometry)
    assert geom['model_sha256'] == sha(model_path)
    assert geom['checker_sha256'] == sha(Path(__file__).with_name('check_blocker_trade_results.py'))
    proof = read(count_proof); cert = read(proof['input'])
    assert proof['input_sha256'] == sha(proof['input']) and cert['input_sha256'] == sha(model_path)
    assert proof['checker_sha256'] == sha(Path(__file__).with_name('check_blocker_radius.py'))
    assert proof['geometry_proof_sha256'] == sha(geometry)
    programs = (sha(kernel), sha(source)); domains = {}; rows = {}; graphs = {}
    for d in model['rows']:
        bi = d['base']; fd = next(r for r in full['rows'] if r['base'] == bi)
        assert list(zip(d['pool_ids'], d['blocker_sets'])) == [(v,b) for v,b in zip(fd['pool_ids'],fd['blocker_sets']) if len(b)<=4]
        checked = check_radius(next(r for r in cert['rows'] if r['base']==bi), d)
        assert checked == next(r for r in proof['rows'] if r['base']==bi)
        assert checked['max_removals'] >= 10 and checked['integer_gain_upper'] == 0
        need = checked['minimum_four_insertions_for_gain']; assert need == 2
        order = sorted(range(len(d['pool_ids'])), key=lambda i:(len(d['blocker_sets'][i])<4,-len(d['blocker_sets'][i]),d['pool_ids'][i]))
        fo = sorted(range(len(fd['pool_ids'])), key=lambda i:(len(fd['blocker_sets'][i])<4,-len(fd['blocker_sets'][i]),fd['pool_ids'][i]))
        offset = sum(len(b)>=5 for b in fd['blocker_sets'])
        assert [d['pool_ids'][i] for i in order] == [fd['pool_ids'][i] for i in fo[offset:]]
        p = next(r for r in pre['rows'] if r['radius']==10)
        assert p['closed_until'] >= offset
        end = sum(len(b)==4 for b in d['blocker_sets'])
        assert p['root_end'] == offset + end
        domains[bi] = (d, order, end, need)
        rows[bi] = dict(base=bi, offset=offset, start=p['closed_until']-offset, root_end=end, segments=[])
    for path, run in runs:
        assert run['status']=='complete' and run['input_sha256']==sha(model_path) and not run['candidates']
        assert (run['kernel_sha256'],run['kernel_source_sha256'])==programs
        assert run['max_removals']==10 and run['target_insertions']==11 and run['prefix_blocker_degree']==4
        assert run['degree_order'] and run['binary_budget'] and run['residual_budget']
        assert run['geometry_proof_sha256']==sha(geometry) and run['count_proof_sha256']==sha(count_proof)
        for r in run['rows']:
            bi=r['base'];d,order,end,need=domains[bi];n=len(order);k=r['kernel_result']
            assert r['kernel_order']==order and r['prefix']==end and r['rows_replayed']==n
            assert r['minimum_prefix_insertions']==r['minimum_four_insertions']==need
            assert k['status'] in ('timeout','exhausted') and not k['chosen'] and not k['neutral'] and not k['improving']
            assert k['anchor_bounds'] and k['anchor_prefix']==end
            assert k['budget_bitsets'] and k['binary_budget'] and k['residual_budget']
            assert not k['enumerate_neutral'] and not k['noncore_bound'] and not k['pair_bounds']
            assert r['root_start']==k['root_start'] and r['root_end']==k['root_end']==k['root_prefix']==end
            assert all(type(k[f]) is int for f in ('root_start','root_end','next_root'))
            assert 0<=k['root_start']<=k['next_root']<=end
            if k['status']=='exhausted': assert k['next_root']==end and k['nodes_started']==k['nodes_completed']
            graph=Path(r['graph']);assert sha(graph)==r['graph_sha256']
            if bi not in graphs:
                inv={v:i for i,v in enumerate(order)};bad=[1<<i for i in range(n)]
                for a,b in d['conflict_edges']:
                    i,j=inv[a],inv[b];bad[i]|=1<<j;bad[j]|=1<<i
                cw=(n+63)//64;full_bits=(1<<n)-1
                with graph.open() as f:
                    assert list(map(int,next(f).split()))==[n,6,10]
                    for j,i in enumerate(order):
                        words=[int(v,16) for v in next(f).split()]
                        assert len(words)==6+cw and all(0<=v<1<<64 for v in words)
                        assert sum(v<<(64*w) for w,v in enumerate(words[:6]))==sum(1<<v for v in d['blocker_sets'][i])
                        assert sum(v<<(64*w) for w,v in enumerate(words[6:]))==full_bits^bad[j]
                    assert list(map(int,next(f).split()))==[need]*n and not f.read().strip()
                graphs[bi]=dict(path=str(graph),sha256=sha(graph),checked_rows=n)
            else: assert graphs[bi]['sha256']==sha(graph)
            rows[bi]['segments'].append(dict(file=path,sha256=sha(path),start=k['root_start'],end=k['next_root'],status=k['status']))
    for row in rows.values():
        end=row['start']
        for segment in sorted(row['segments'],key=lambda s:s['start']):
            assert segment['start']==end,'Gap or overlap at tail continuation'
            end=segment['end']
        row.update(closed_until=end,full_pool_closed_until=row['offset']+end,
                   complete_radius10=end==row['root_end'],minimum_removed_for_any_368_set=11 if end==row['root_end'] else 10)
    deps={str(p):sha(p) for p in [prefix,model_path,geometry,count_proof,proof['input'],kernel,source]}
    return dict(rows=list(rows.values()),graphs=graphs,dependencies=deps)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('prefix','geometry','count-proof','kernel','source'):p.add_argument('--'+name,required=True)
    p.add_argument('--queries',required=True,nargs='+');p.add_argument('--output',required=True,type=Path)
    a=p.parse_args();assert __debug__ and not a.output.exists()
    args={k:v for k,v in vars(a).items() if k!='output'};r=audit(**args)
    out=dict(checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),inputs=args,scope=__doc__,**r)
    a.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps([{k:v for k,v in row.items() if k!='segments'} for row in r['rows']]))


if __name__=='__main__':main()
