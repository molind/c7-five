"""Find and directly verify clique certificates bounding orbit-packet codes.

In a 2401-vertex translation-invariant graph, translates of a clique of size
c imply alpha <= floor(2401/c), by double counting. A found clique is a
certificate even when the heuristic finding it is not exhaustive.
"""

import itertools
import json
import random
import time

from search_translation_orbits import ROOT, directions


def main():
    rng = random.Random(20260915)
    results = []
    began = time.monotonic()
    for direction in directions():
        difference_set = {tuple((d[j]-direction[j]*d[0])%7 for j in range(1,5))
                          for d in itertools.product((-1,0,1),repeat=5)}
        vertices = sorted(difference_set-{(0,0,0,0)})
        adjacency = [0]*len(vertices)
        for i,u in enumerate(vertices):
            for j in range(i):
                v = vertices[j]
                if tuple((a-b)%7 for a,b in zip(u,v)) in difference_set:
                    adjacency[i] |= 1<<j
                    adjacency[j] |= 1<<i
        best = []
        for trial in range(500):
            available = (1<<len(vertices))-1
            clique = []
            while available:
                ids = [i for i in range(len(vertices)) if available>>i&1]
                # Greedy induced degree, with reproducible exploration among
                # the leading few candidates. Acceptance is verified below.
                ranked = sorted(ids,key=lambda i:(adjacency[i]&available).bit_count(),reverse=True)
                i = ranked[0] if trial==0 else rng.choice(ranked[:min(5,len(ranked))])
                clique.append(i)
                available &= adjacency[i]
            if len(clique)>len(best):
                best = clique
            if len(best)+1>=46:
                break
        certificate = [(0,0,0,0)]+[vertices[i] for i in best]
        if len(certificate)!=len(set(certificate)):
            raise ArithmeticError("Duplicate clique member")
        for u,v in itertools.combinations(certificate,2):
            # Directly check that some two words in the represented packets
            # are confusable, without using the projected difference set.
            if not any(all((x-y-t*a)%7 in (0,1,6)
                           for x,y,a in zip((0,)+u,(0,)+v,direction))
                       for t in range(7)):
                raise ArithmeticError((direction,u,v))
        c = len(certificate)
        result = {"direction":direction,"clique_size":c,
                  "packet_upper_bound":2401//c,"word_upper_bound":7*(2401//c),
                  "excludes_371":2401//c<53,"clique":certificate,"trials":trial+1}
        results.append(result)
        print(json.dumps({k:v for k,v in result.items() if k!='clique'}),flush=True)
    (ROOT/'orbit-clique-certificates.json').write_text(json.dumps({
        "seed":20260915,"quotient_vertices":2401,"results":results,
        "elapsed_seconds":time.monotonic()-began},indent=2)+'\n')


if __name__=='__main__':
    main()
