"""Bounded IPM-guided branching for an exact368 core-domain construction.

Branch bounds are binary restrictions on words. Checkpoints preserve earlier
branch decisions and retry unfinished LP nodes without re-solving completed nodes. Conflict propagation and
the deletion cap prune impossible insertions. Interior LP solutions are used
directly; crossover to a basic solution is unnecessary for binary branching. LP infeasibility is numerical;
this exploratory search deliberately makes no certificate/exclusion claim.
"""
import argparse
import json
from pathlib import Path
import time

import numpy as np
from scipy.optimize._highspy import _core as high

from check_two_slice_covers import closed
from search_core_radius_cut import sha
from search_core_regions import independence
from solve_core_radius_ipm import build_model, load_radius_model, model_digest


from search_core_ipm_branches_v2 import propagate


def path_key(row):
    return tuple(row['inside']), tuple(row['outside'])


def completed(row):
    return 'branch' in row or row['status'] in ('Infeasible', 'exact_conflict_or_radius')


def validate_partial_tree(tree):
    """Reconstruct the exact DFS partition, including pending and unknown nodes."""
    assert tree['status'] == 'bounded_attempt_complete'
    pending, unknown, seen = [((), ())], [], set()
    for row in tree['rows']:
        key = path_key(row)
        assert pending and pending.pop() == key and key not in seen
        seen.add(key)
        inside, outside = key
        assert len(set(inside)) == len(inside) and len(set(outside)) == len(outside)
        assert not set(inside) & set(outside)
        if 'branch' in row:
            v = row['branch']
            assert type(v) is int and v not in inside and v not in outside
            pending.append((inside, outside + (v,)))
            pending.append((inside + (v,), outside))
        elif not completed(row):
            unknown.append(key)
    assert pending == [path_key(row) for row in tree['pending_nodes']]
    assert unknown == [path_key(row) for row in tree['unknown_nodes']]
    return {path_key(row): row for row in tree['rows']}


def load_checkpoint(path, expected, active=None):
    """Keep unvisited cached subtrees across any number of resumptions."""
    active = set() if active is None else active
    path = Path(path)
    resolved = path.resolve()
    assert resolved not in active
    active.add(resolved)
    tree = json.loads(path.read_text())
    for key in ('radius', 'original_model_sha256', 'target_model_sha256'):
        assert tree[key] == expected[key]
    assert Path(tree['input']).resolve() == Path(expected['input']).resolve()
    assert all(sha(f) == h for f, h in tree['dependencies'].items())
    assert tree['dependencies'][tree['input']] == sha(expected['input'])
    names = ('search_core_ipm_branches.py', 'search_core_ipm_branches_v2.py', 'search_core_ipm_branches_v3.py', 'search_core_ipm_branches_v4.py', 'search_core_ipm_branches_v5.py')
    assert any(sha(Path(__file__).with_name(name)) == tree['source_sha256'] for name in names)
    cached = {}
    if tree.get('resume_from'):
        parent = tree['resume_from']
        assert tree['dependencies'][parent] == sha(parent)
        cached = load_checkpoint(parent, expected, active)
    for key, row in validate_partial_tree(tree).items():
        if key in cached and completed(cached[key]):
            assert row == cached[key], 'A previously completed decision changed during resumption'
        cached[key] = row
    active.remove(resolved)
    return cached


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path, required=True)
    p.add_argument('--radius', type=int, required=True)
    p.add_argument('--nodes', type=int, default=64)
    p.add_argument('--seconds', type=float, default=120)
    p.add_argument('--lp-seconds', type=float, default=5)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--resume', type=Path)
    args = p.parse_args()
    assert __debug__ and not args.output.exists()
    assert args.nodes > 0 and args.seconds > 0 and args.lp_seconds > 0
    data, matrix, lower, upper, variable_upper, initial = load_radius_model(args.input, args.radius)
    model_sha = model_digest(matrix, lower, upper, variable_upper)
    target = data['target']
    assert upper[-3] == target and lower[-3] == 0
    lower[-3] = target  # Search only the requested368, not neutral367 optima.
    pool, old = set(data['pool']), set(data['parent_words']) - set(data['fixed'])
    positions = {v: i for i, v in enumerate(data['pool'])}
    neighborhoods = {v: closed(v) & pool for v in pool}
    out = dict(status='running', input=str(args.input), radius=args.radius,
               original_model_sha256=model_sha, target_model_sha256=model_digest(matrix, lower, upper, variable_upper),
               source_sha256=sha(__file__), dependencies={str(args.input): sha(args.input)},
               parameters=dict(nodes=args.nodes, seconds=args.seconds, lp_seconds=args.lp_seconds, crossover=False),
               rows=[], unknown_nodes=[], scope=__doc__,
               resume_from=str(args.resume) if args.resume else None, fresh_nodes=0, replayed_nodes=0)
    for name in ('solve_core_radius_ipm.py', 'check_two_slice_covers.py', 'search_core_regions.py', 'search_core_ipm_branches_v2.py'):
        path = Path(__file__).with_name(name)
        out['dependencies'][str(path)] = sha(path)
    cached = load_checkpoint(args.resume, out) if args.resume else {}
    if args.resume:
        out['dependencies'][str(args.resume)] = sha(args.resume)
    out['cached_nodes_available'] = len(cached)
    stack = [((), ())]
    began = time.monotonic()
    def save():
        out['seconds'] = time.monotonic() - began
        out['pending_nodes'] = [dict(inside=list(a), outside=list(b)) for a, b in stack]
        args.output.write_text(json.dumps(out, indent=2) + '\n')
    save()
    while stack:
        key = stack[-1]
        if key in cached and completed(cached[key]):
            stack.pop()
            row = cached[key]
            out['rows'].append(row)
            out['replayed_nodes'] += 1
            if 'branch' in row:
                inside, outside = key
                branch = row['branch']
                stack.append((inside, outside + (branch,)))
                stack.append((inside + (branch,), outside))
            continue
        if out['fresh_nodes'] >= args.nodes or time.monotonic() - began >= args.seconds:
            break
        inside, outside = stack.pop()
        out['fresh_nodes'] += 1
        row = dict(inside=list(inside), outside=list(outside))
        forbidden = propagate(pool, old, neighborhoods, inside, outside, args.radius)
        if forbidden is None:
            row['status'] = 'exact_conflict_or_radius'
        else:
            variable_lo = np.zeros(len(pool))
            variable_hi = variable_upper.copy()
            for v in inside:
                variable_lo[positions[v]] = 1
            for v in forbidden:
                variable_hi[positions[v]] = 0
            solver = high._Highs()
            for key, value in dict(output_flag=False, solver='ipm', run_crossover='off',
                                   time_limit=float(max(0.0, min(args.lp_seconds, args.seconds - (time.monotonic() - began))))).items():
                assert solver.setOptionValue(key, value) == high.HighsStatus.kOk
            model = build_model(matrix, lower, upper, variable_hi, False)
            model.col_lower_ = variable_lo
            assert solver.passModel(model) == high.HighsStatus.kOk
            start = time.monotonic()
            solver.run()
            info, solution = solver.getInfo(), solver.getSolution()
            row.update(status=solver.modelStatusToString(solver.getModelStatus()), seconds=time.monotonic() - start,
                       ipm_iterations=info.ipm_iteration_count, objective=info.objective_function_value,
                       forced_zero=len(forbidden), forced_old_deletions=len(forbidden & old))
            if solution.value_valid and info.primal_solution_status == high.kSolutionStatusFeasible:
                x = np.asarray(solution.col_value)
                activity = matrix @ x
                valid_point = (np.all(np.isfinite(x)) and np.all(np.isfinite(activity))
                               and np.all(x >= variable_lo - 1e-6) and np.all(x <= variable_hi + 1e-6)
                               and np.all(activity >= lower - 1e-6) and np.all(activity <= upper + 1e-6))
                if not valid_point:
                    # A solver feasibility flag is not evidence when direct
                    # residual checks fail. Preserve this branch for retry.
                    row['solver_status'] = row['status']
                    row['status'] = 'numerical_point_rejected'
                    if np.all(np.isfinite(x)) and np.all(np.isfinite(activity)):
                        row['maximum_violation'] = float(max(0.0, np.max(variable_lo-x), np.max(x-variable_hi),
                                                             np.max(lower-activity), np.max(activity-upper)))
                    out['unknown_nodes'].append(dict(inside=list(inside), outside=list(outside)))
                    out['rows'].append(row)
                    save()
                    print(dict(node=len(out['rows']), **{k: v for k, v in row.items() if k not in ('inside', 'outside')}), flush=True)
                    continue
                fractional = np.abs(x - np.rint(x)) > 1e-6
                row['fractional'] = int(fractional.sum())
                if not np.any(fractional):
                    words = sorted(data['fixed'] + [v for v, value in zip(data['pool'], np.rint(x)) if value])
                    assert len(words) == 368 and independence(words) == 67528
                    out.update(status='verified_improvement', verified368=words, pair_checks=67528)
                else:
                    available = [v for v in pool - old - set(inside) - forbidden if fractional[positions[v]]]
                    # LP solutions can retain fractional old words even when
                    # every new word is integral. Branch on an old variable
                    # in that case; no integrality claim follows from the old
                    # set being independent.
                    if not available:
                        available = [v for v in pool - set(inside) - forbidden if fractional[positions[v]]]
                    assert available
                    deleted = forbidden & old
                    branch = max(available, key=lambda v: (x[positions[v]] / max(1, len(neighborhoods[v] & old - deleted)), -v))
                    row.update(branch=branch, branch_value=float(x[positions[branch]]))
                    stack.append((inside, outside + (branch,)))
                    stack.append((inside + (branch,), outside))
            elif solver.getModelStatus() != high.HighsModelStatus.kInfeasible:
                out['unknown_nodes'].append(dict(inside=list(inside), outside=list(outside)))
        out['rows'].append(row)
        save()
        print(dict(node=len(out['rows']), **{k: v for k, v in row.items() if k not in ('inside', 'outside')}), flush=True)
        if out['status'] == 'verified_improvement':
            break
    if out['status'] == 'running':
        out['status'] = 'bounded_attempt_complete'
    if out['status'] == 'bounded_attempt_complete':
        validate_partial_tree(out | {'pending_nodes': [dict(inside=list(a), outside=list(b)) for a, b in stack]})
    save()


if __name__ == '__main__':
    main()
