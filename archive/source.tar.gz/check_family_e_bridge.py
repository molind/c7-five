"""Check complete C/E fixed-exterior domains, integer covers and search models."""
import argparse
import hashlib
from itertools import combinations
import json
from pathlib import Path

import numpy as np

from check_two_slice_covers import WORDS
from check_cylinder_covers import check_entries
from check_mixed_three_layers import verify_words


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--domains', type=Path, required=True)
    parser.add_argument('--screen', type=Path, required=True)
    parser.add_argument('--searches', type=Path, nargs='*', default=[])
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    domains, screen = json.loads(args.domains.read_text()), json.loads(args.screen.read_text())
    assert domains['status'] == 'prepared' and screen['status'] == 'complete'
    assert screen['input_sha256'] == sha(args.domains)
    source_path = Path(domains['source'])
    assert sha(source_path) == domains['source_sha256']
    model = json.loads(source_path.read_text())['model']
    parent = set(model['fixed']) | {model['pool'][i] for i in model['hint']}
    seed_path = Path(__file__).parent/'family-e-seed-words.txt'
    assert sha(seed_path) == domains['seed_sha256']
    seed = {int(w, 7) for w in seed_path.read_text().split()}
    assert sorted(parent) == domains['parent'] and sorted(seed) == domains['seed']
    assert len(parent) == len(seed) == 367
    verify_words(sorted(parent)); verify_words(sorted(seed))
    common = parent & seed
    assert len(common) == 346 and sorted(common) == domains['common']
    removed = [row['vertex'] for row in domains['removals']]
    assert len(removed) == len(set(removed)) == max(domains['schedule']) and set(removed) <= common
    jobs = domains['jobs']
    assert [j['index'] for j in jobs] == list(range(len(jobs)))
    assert [j['released_common_points'] for j in jobs] == domains['schedule']
    assert screen['limit'] >= len(jobs)
    assert [r['index'] for r in screen['results']] == list(range(len(jobs)))
    capacity = [1]
    for _ in range(5):
        capacity.append(7*capacity[-1]//2)
    universe = np.array(WORDS, dtype=np.int16)
    checked, loaded = [], {}
    for job, summary in zip(jobs, screen['results']):
        path = Path(summary['file'])
        assert sha(path) == summary['sha256']
        row = json.loads(path.read_text())
        fixed = sorted(common-set(removed[:job['released_common_points']]))
        assert fixed == job['fixed'] == row['fixed']
        assert len(fixed) == job['fixed_size'] == summary['fixed']
        allowed = np.ones(16807, dtype=bool)
        for v in fixed:
            delta = (universe-universe[v]) % 7
            allowed &= ~np.all((delta == 0) | (delta == 1) | (delta == 6), axis=1)
        pool = np.flatnonzero(allowed).tolist()
        assert pool == job['pool'] == row['pool'] and len(pool) == summary['pool']
        assert sorted(seed-set(fixed)) == job['hint'] == row['hint']
        assert parent-set(fixed) <= set(pool)
        assert row['target'] == job['target'] == 368-len(fixed)
        assert row['initial_size'] == job['initial_size'] == summary['initial_size'] == 367
        assert row['status'] == summary['status'] and row['index'] == job['index'] == summary['index']
        upper = None
        if 'certificate' in row:
            assert row['status'] == 0 and row['capacity_sequence'] == capacity
            total, den = check_entries(row['certificate'], pool, capacity)
            upper = len(fixed)+total//den
            assert upper == row['full_upper'] == summary['full_upper'] >= 367
            assert row['excludes368'] == summary['excludes368'] == (upper < 368)
        else:
            assert not summary['excludes368'] and summary['full_upper'] is None
        if 'integral_vertices' in row:
            verify_words(row['integral_vertices'])
            assert set(fixed) <= set(row['integral_vertices']) <= set(fixed+pool)
            assert len(row['integral_vertices']) <= upper
        loaded[str(path)] = row
        checked.append(dict(index=job['index'], released=job['released_common_points'],
            fixed=len(fixed), pool=len(pool), upper=upper, excludes368=upper is not None and upper < 368,
            file=str(path), sha256=sha(path)))
    assert screen['candidates'] == []
    searches = []
    for path in args.searches:
        r = json.loads(path.read_text())
        src = Path(r['input'])
        assert sha(src) == r['input_sha256'] and str(src) in loaded
        row, model = loaded[str(src)], r['model']
        assert r['status'] in ('bounded_search_complete', 'candidate_found')
        assert model['fixed'] == row['fixed'] and model['pool'] == row['pool']
        pool = model['pool']
        assert [pool[i] for i in model['hint']] == row['hint']
        provenance = {tuple(sorted(e['vertices'])):e['capacity'] for e in row['certificate']['cover']}
        assert len(model['members']) == len(model['capacities'])
        edges = set()
        for indices, cap in zip(model['members'], model['capacities']):
            assert len(indices) == len(set(indices)) and all(type(i) is int and 0 <= i < len(pool) for i in indices)
            values = tuple(sorted(pool[i] for i in indices))
            if cap == 1:
                assert all(all((x-y) % 7 in (0, 1, 6) for x, y in zip(WORDS[a], WORDS[b]))
                           for a, b in combinations(values, 2))
                edges.update(tuple(sorted(pair)) for pair in combinations(indices, 2))
            else:
                assert type(cap) is int and cap > 1 and provenance.get(values) == cap
        actual = set()
        points = universe[pool]
        for i, point in enumerate(points):
            delta = (points[i+1:]-point) % 7
            actual.update((i, i+1+int(j)) for j in np.flatnonzero(np.all((delta == 0) | (delta == 1) | (delta == 6), axis=1)))
        assert actual == edges
        result = r['result']
        assert result['target'] == 368-len(model['fixed']) and result['forbidden'] is None
        assert result['initial_size'] == len(row['hint'])
        full_size, pairs = None, 0
        expected = []
        if 'vertices' in result:
            assert set(result['vertices']) <= set(pool)
            full = sorted(model['fixed']+result['vertices'])
            pairs = verify_words(full)
            full_size = len(full)
            assert full_size == result['full_size'] >= 367 and pairs == result['verified_pairs']
            expected = [dict(step=0, size=full_size, words=[''.join(map(str, WORDS[v])) for v in full], verified_pairs=pairs)]
        assert r['candidates'] == expected
        assert (r['status'] == 'candidate_found') == (full_size is not None and full_size >= 368)
        searches.append(dict(file=str(path), sha256=sha(path), full_size=full_size,
            direct_conflict_edges=len(edges), direct_witness_pairs=pairs, solver_status=result['solver_status']))
    report = dict(domains_sha256=sha(args.domains), screen_sha256=sha(args.screen),
        checker_sha256=sha(Path(__file__)), domains=checked, searches=searches,
        cover_closed=sum(row['excludes368'] for row in checked),
        target_witness_found=any((row['full_size'] or 0) >= 368 for row in searches),
        scope='Exactly the saved nested C/E fixed exteriors. All candidate domains rebuilt directly; integer rank covers and returned full codes checked. No global upper bound.')
    args.output.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(dict(domains=len(checked), cover_closed=report['cover_closed'], searches=len(searches),
                          target_witness_found=report['target_witness_found'])), flush=True)


if __name__ == '__main__':
    main()
