// Exercise the actual comparison-budget exit without a quadratic input matrix.
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wreturn-type"
#define main c7_compatible_scanner_main
#include "scan_component_atomic7_incremental_compatible.cpp"
#undef main
#pragma clang diagnostic pop
int main() {
    std::vector<Candidate> pool;
    for(int i=0;i<120;++i)for(int j=i+1;j<120;++j)
        pool.push_back({static_cast<int>(pool.size()),{i,j}});
    std::vector<bool> critical(pool.size(),true);
    auto result=compatible_requirements(pool,{&critical},[](int i,int j){return i!=j;},7);
    if(result.complete || !result.sets.empty() || result.comparisons!=20000001)
        throw std::runtime_error("Comparison limit did not discard unfinished cover result");
    std::cout<<"{\"passed\":true,\"pool\":"<<pool.size()<<",\"nodes\":"<<result.nodes
             <<",\"comparisons\":"<<result.comparisons<<",\"returned_sets\":"<<result.sets.size()<<"}\n";
}
