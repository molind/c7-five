"""Bounded clique-center separation with accumulated, geometrically checked cuts.

A clique Q common to every vertex of a (2k+1)-cycle gives
sum(cycle) + k*sum(Q) <= k. All cuts survive reoptimization. Numerical
separation and LP objectives are not exact infeasibility certificates.
"""
import argparse
from itertools import combinations, product
import hashlib
import json
from pathlib import Path
import time

import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix
from check_two_slice_covers import WORDS, closed, conflict
from probe_odd_cycle_cuts import separate


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def check_cut(cut, pool):
    cycle, centers, k = cut['cycle'], cut['centers'], cut['capacity']
    assert type(k) is int and k >= 1 and len(cycle) == len(set(cycle)) == 2*k+1
    assert len(centers) == len(set(centers)) and not set(cycle) & set(centers)
    assert set(cycle+centers) <= pool
    assert all(conflict(a,b) for a,b in zip(cycle,cycle[1:]+cycle[:1]))
    assert all(conflict(a,b) for a,b in combinations(centers,2))
    assert all(conflict(a,b) for a in centers for b in cycle)


def cut_key(cut):
    return tuple(sorted(cut['cycle'])),tuple(sorted(cut['centers']))


def matrix_for(model, cuts):
    local = {v:i for i,v in enumerate(model['pool'])}
    rows = [i for i,c in enumerate(model['members']) for _ in c]
    cols = [v for c in model['members'] for v in c]
    coefficients = [1]*len(cols)
    capacities = list(model['capacities'])
    for c in cuts:
        row = len(capacities)
        for v in c['cycle']:
            rows.append(row);cols.append(local[v]);coefficients.append(1)
        for v in c['centers']:
            rows.append(row);cols.append(local[v]);coefficients.append(c['capacity'])
        capacities.append(c['capacity'])
    matrix = coo_matrix((coefficients,(rows,cols)),shape=(len(capacities),len(local))).tocsr()
    return matrix,np.asarray(capacities)


def lift(cycle, adjacency, values, pool):
    common = set.intersection(*(adjacency[i] for i in cycle))-set(cycle)
    if not common:
        return []
    boxes = {}
    for i in common:
        for origin in product(*[[(x-1)%7,x] for x in WORDS[pool[i]]]):
            boxes.setdefault(origin,[]).append(i)
    return sorted(max(boxes.values(),key=lambda indices:(float(sum(values[i] for i in indices)),tuple(sorted(indices)))))


def find_cuts(model, adjacency, values, existing, deadline, max_cuts, start=0):
    pool = model['pool']
    center_sets = {tuple(i for i in row if values[i] > 1e-8)
                   for row,cap in zip(model['members'],model['capacities']) if cap == 1}
    # A maximal clique can contain cycle vertices. Its center-only subset
    # must also be tried, or even a two-center wheel can be missed entirely.
    for centers in list(center_sets):
        center_sets.update((i,) for i in centers)
        center_sets.update(combinations(centers,2))
    center_sets.add(())
    candidates = sorted(center_sets,key=lambda c:(-float(sum(values[i] for i in c)),c))
    cuts = []
    assert 0 <= start < len(candidates)
    statistics = dict(candidate_cliques=len(candidates),start=start,next_center=start,
                      visited=0,roots=0,numerically_skipped=0)
    for index in range(start,len(candidates)):
        centers = candidates[index]
        if time.monotonic() >= deadline or len(cuts) >= max_cuts:
            statistics['interrupted'] = True
            break
        statistics['next_center']=index+1
        mass = float(sum(values[i] for i in centers))
        if mass >= 1-1e-5:
            continue
        neighbors = sorted(set.intersection(*(adjacency[i] for i in centers))) if centers else list(range(len(pool)))
        if len(neighbors) < 3:
            continue
        local = {v:i for i,v in enumerate(neighbors)}
        edges = [(i,local[v]) for i,u in enumerate(neighbors) for v in adjacency[u] if v in local and i < local[v]]
        if not edges:
            continue
        normalized = values[neighbors]/(1-mass)
        roots = [i for i,x in enumerate(normalized) if 1e-6 < x < 1-1e-6]
        if not centers:
            roots = roots[:256]
        if not roots:
            continue
        if min(1-normalized[a]-normalized[b] for a,b in edges) < -1e-6:
            statistics['numerically_skipped'] += 1
            continue
        statistics['visited'] += 1
        statistics['roots'] += len(roots)
        for found in separate(len(neighbors),edges,normalized,roots):
            cycle = [neighbors[i] for i in found['cycle']]
            expanded = lift(cycle,adjacency,values,pool)
            k = found['capacity']
            cut = dict(cycle=[pool[i] for i in cycle],centers=[pool[i] for i in expanded],capacity=k)
            violation = float(sum(values[i] for i in cycle)+k*sum(values[i] for i in expanded)-k)
            if violation <= 1e-6 or cut_key(cut) in existing:
                continue
            check_cut(cut,set(pool))
            cut['initial_violation'] = violation
            cuts.append(cut);existing.add(cut_key(cut))
            if len(cuts) >= max_cuts:
                statistics['next_center']=index
                break
    statistics.setdefault('interrupted',False)
    return cuts,statistics


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True,help='Saved clique-lift LP with a feasible primal')
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--rounds',type=int,default=3)
    p.add_argument('--budget',type=float,default=120)
    p.add_argument('--seconds',type=float,default=10)
    p.add_argument('--max-cuts',type=int,default=512)
    p.add_argument('--center-start',type=int,default=0,help='Resume a candidate-center suffix on the unchanged input primal; only used in round0')
    args = p.parse_args()
    assert __debug__ and not args.output.exists() and min(args.rounds,args.budget,args.seconds,args.max_cuts)>0
    prior = json.loads(args.input.read_text())
    assert prior['status'] == 0 and digest(prior['model']) == prior['model_sha256'] and digest(prior['cut']) == prior['cut_sha256']
    base = json.loads(Path(prior['model']).read_text());model = base['model']
    seed_cut = json.loads(Path(prior['cut']).read_text())
    cuts = [dict(cycle=seed_cut['cycle'],centers=seed_cut['best_center_clique'],capacity=seed_cut['capacity'])]
    pool,local = model['pool'],{v:i for i,v in enumerate(model['pool'])}
    check_cut(cuts[0],set(pool))
    values = np.zeros(len(pool))
    for v,x in prior['primal']:
        values[local[v]] = x
    matrix,caps = matrix_for(model,cuts)
    assert np.min(values)>=-1e-6 and np.max(values)<=1+1e-6 and np.all(matrix@values<=caps+1e-6)
    hint = np.zeros(len(pool));hint[model['hint']] = 1
    assert np.all(matrix@hint<=caps)
    adjacency = [{local[w] for w in closed(v) if w != v and w in local} for v in pool]
    report = dict(status='running',input=str(args.input),input_sha256=digest(args.input),
                  model=prior['model'],model_sha256=prior['model_sha256'],source_sha256=digest(__file__),
                  initial_bound=prior['floating_full_bound'],initial_cut_count=1,cuts=cuts,rounds=[],candidates=[],
                  scope='Selected clique-center cycle inequalities; all retained rows are valid for independent sets. No exact exclusion follows from a numerical LP or separation budget.')
    started = time.monotonic();deadline = started+args.budget
    existing = {cut_key(c) for c in cuts};last_bound = prior['floating_full_bound'];stagnant = 0
    def save():
        report['seconds'] = time.monotonic()-started
        temp=args.output.with_suffix('.tmp');temp.write_text(json.dumps(report,indent=2)+'\n');temp.replace(args.output)
    save()
    for iteration in range(args.rounds):
        additions,stats = find_cuts(model,adjacency,values,existing,deadline,args.max_cuts,
                                  args.center_start if iteration == 0 else 0)
        cuts.extend(additions)
        step = dict(iteration=iteration,added=len(additions),total_cuts=len(cuts),separation=stats)
        report['rounds'].append(step)
        if not additions:
            report['status']='separation_limit' if stats['interrupted'] else 'no_new_cuts'
            break
        matrix,caps=matrix_for(model,cuts);assert np.all(matrix@hint<=caps)
        lp=linprog(-np.ones(len(pool)),A_ub=matrix,b_ub=caps,bounds=(0,1),method='highs-ipm',options={'time_limit':args.seconds})
        step.update(status=int(lp.status),message=lp.message)
        if not lp.success:
            report['status']='numerical_unresolved';values=None;save();break
        values=lp.x;bound=len(model['fixed'])-float(lp.fun)
        assert bound<=last_bound+1e-5
        step['floating_full_bound']=bound
        stagnant=stagnant+1 if last_bound-bound<1e-6 else 0
        last_bound=bound
        if np.max(np.abs(values-np.rint(values)))<1e-7:
            full=sorted(model['fixed']+[v for v,x in zip(pool,values) if x>.5])
            assert len(full)==len(set(full)) and all(not conflict(a,b) for a,b in combinations(full,2))
            if len(full)>=367:
                report['candidates'].append(dict(size=len(full),words=[''.join(map(str,WORDS[v])) for v in full],verified_pairs=len(full)*(len(full)-1)//2))
            if len(full)>=368:
                report['status']='candidate_found';save();break
        save();print(json.dumps(step),flush=True)
        if stagnant>=2 or time.monotonic()>=deadline:
            report['status']='stagnant' if stagnant>=2 else 'time_limit';break
    else:
        report['status']='round_limit'
    report['final_primal']=[[v,float(x)] for v,x in zip(pool,values) if x>1e-8] if values is not None else None
    report['last_successful_bound']=last_bound
    save();print(json.dumps(dict(status=report['status'],cuts=len(cuts),bound=last_bound)),flush=True)


if __name__ == '__main__':
    main()
