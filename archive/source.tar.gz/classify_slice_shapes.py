"""Partition saved 4D slices by exact signed-permutation/translation equivalence.

Marginals only reject impossible maps; full point sets accept each map.
For each unresolved marginal bucket all compatible coordinate maps are tried.
"""
import argparse
from collections import Counter, defaultdict
from itertools import permutations, product
import json
from pathlib import Path
import time
from check_orbit_two_new import digest


def histograms(sl):
    return [tuple(Counter(w[i] for w in sl)[x] for x in range(7)) for i in range(4)]


def image_hist(h, sign, shift):
    out = [0]*7
    for x, n in enumerate(h):
        out[(sign*x+shift)%7] = n
    return tuple(out)


def invariant(hs):
    return tuple(sorted(min(image_hist(h,s,t) for s in (-1,1) for t in range(7)) for h in hs))


def mapping(source, target, sh, th):
    choices = [[[(s,t) for s in (-1,1) for t in range(7) if image_hist(sh[j],s,t)==th[i]]
                for j in range(4)] for i in range(4)]
    targets = set(target)
    for p in permutations(range(4)):
        if not all(choices[i][p[i]] for i in range(4)):
            continue
        for st in product(*(choices[i][p[i]] for i in range(4))):
            if all(tuple((st[i][0]*w[p[i]]+st[i][1])%7 for i in range(4)) in targets for w in source):
                return dict(permutation=p, signs=[s for s,t in st], shift=[t for s,t in st])
    return None


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path, required=True)
    p.add_argument('--original-count', type=int, required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    r = json.loads(args.input.read_text()); slices = [tuple(map(tuple, sl)) for sl in r['slices']]
    assert 0 < args.original_count <= len(slices)
    hist = [histograms(sl) for sl in slices]
    buckets = defaultdict(list); rows = []; reps = []; attempts = 0; began = time.monotonic()
    for i, sl in enumerate(slices):
        key = invariant(hist[i]); found = None
        for rep in buckets[key]:
            attempts += 1
            move = mapping(sl, slices[rep], hist[i], hist[rep])
            if move is not None:
                # Verify explicitly again as equality, including cardinality.
                actual = {tuple((move['signs'][j]*w[move['permutation'][j]]+move['shift'][j])%7 for j in range(4)) for w in sl}
                assert actual == set(slices[rep]) and len(actual) == len(sl)
                found = dict(index=i, representative=rep, transform=move)
                break
        if found is None:
            buckets[key].append(i); reps.append(i)
            found = dict(index=i, representative=i, transform=dict(permutation=list(range(4)), signs=[1]*4, shift=[0]*4))
        rows.append(found)
        if i%500 == 0:
            print(json.dumps(dict(processed=i+1, classes=len(reps), comparisons=attempts)), flush=True)
    new = [i for i in reps if i >= args.original_count]
    result = dict(input=str(args.input), input_sha256=digest(args.input), source_sha256=digest(__file__),
        original_count=args.original_count, rows=rows, representatives=reps, new_representatives=new,
        statistics=dict(slices=len(slices), classes=len(reps), original_classes=len(reps)-len(new),
            new_classes=len(new), marginal_buckets=len(buckets), full_mapping_attempts=attempts,
            new_class_sizes=dict(Counter(len(slices[i]) for i in new))),
        elapsed_seconds=time.monotonic()-began,
        scope='Inequivalence only to the supplied library under independent signs, translations, and coordinate permutations; no global novelty claim.')
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result['statistics']),flush=True)


if __name__ == '__main__':
    main()
