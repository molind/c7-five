// Enumerate coordinate permutations, reflections, and translations preserving S.
// Input: nonempty whitespace-separated base-7 words of a common length 1..5.
// A preserving map must send the first word to a word of S. Once that image,
// the coordinate permutation, and signs are fixed, the translation is unique.
#include <algorithm>
#include <array>
#include <chrono>
#include <iostream>
#include <numeric>
#include <stdexcept>
#include <string>
#include <vector>

int main()
{
    try {
        using Word = std::array<int, 5>;
        std::vector<Word> words;
        std::string token;
        int dimension = 0, universe = 1;
        while (std::cin >> token) {
            if (words.empty()) {
                dimension = int(token.size());
                if (dimension < 1 || dimension > 5) throw std::runtime_error("Word length must be 1..5");
                for (int i = 0; i < dimension; ++i) universe *= 7;
            }
            if (int(token.size()) != dimension) throw std::runtime_error("Mixed word lengths");
            Word word{};
            for (int i = 0; i < dimension; ++i) {
                if (token[i] < '0' || token[i] > '6') throw std::runtime_error("Invalid digit");
                word[i] = token[i] - '0';
            }
            words.push_back(word);
        }
        if (words.empty()) throw std::runtime_error("Empty input");
        auto index = [&](const Word &w) {
            int v = 0;
            for (int i = 0; i < dimension; ++i) v = 7 * v + w[i];
            return v;
        };
        std::vector<bool> member(universe, false);
        for (const auto &w : words) {
            int v = index(w);
            if (member[v]) throw std::runtime_error("Duplicate word");
            member[v] = true;
        }
        auto start = std::chrono::steady_clock::now();
        Word permutation{0, 1, 2, 3, 4};
        uint64_t candidates = 0, found = 0;
        std::cout << "{\"dimension\":" << dimension << ",\"words\":" << words.size() << ",\"maps\":[";
        do {
            for (unsigned signMask = 0; signMask < (1u << dimension); ++signMask) {
                for (const auto &image : words) {
                    Word sign{}, shift{};
                    for (int i = 0; i < dimension; ++i) {
                        sign[i] = (signMask & (1u << i)) ? -1 : 1;
                        shift[i] = (image[i] - sign[i] * words[0][permutation[i]] + 7) % 7;
                    }
                    ++candidates;
                    bool valid = true;
                    for (const auto &w : words) {
                        int encoded = 0;
                        for (int i = 0; i < dimension; ++i)
                            encoded = 7 * encoded + (sign[i] * w[permutation[i]] + shift[i] + 7) % 7;
                        if (!member[encoded]) { valid = false; break; }
                    }
                    if (!valid) continue;
                    if (found++) std::cout << ',';
                    std::cout << "{\"permutation\":[";
                    for (int i = 0; i < dimension; ++i) { if (i) std::cout << ','; std::cout << permutation[i]; }
                    std::cout << "],\"sign_mask\":" << signMask << ",\"shift\":[";
                    for (int i = 0; i < dimension; ++i) { if (i) std::cout << ','; std::cout << shift[i]; }
                    std::cout << "]}";
                }
            }
        } while (std::next_permutation(permutation.begin(), permutation.begin() + dimension));
        std::cout << "],\"candidates\":" << candidates << ",\"stabilizer_size\":" << found
                  << ",\"elapsed_seconds\":" << std::chrono::duration<double>(std::chrono::steady_clock::now() - start).count() << "}\n";
    } catch (const std::exception &e) { std::cerr << e.what() << '\n'; return 1; }
}
