// Rooted seven-walk search on a complete relative-neighbor table.
// Independently transformed slices are deduplicated by their actual point sets.
#include <algorithm>
#include <array>
#include <bitset>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <numeric>
#include <stdexcept>
#include <unordered_map>
#include <vector>
constexpr int V=2401;
using Word=std::array<int,4>;
using Mask=std::bitset<V>;
using Points=std::vector<std::uint16_t>;
struct Frame{int base,linear,shift;};
struct Node{Frame g;Mask points,allowed;std::vector<int> adjacent;bool expanded=false;};
struct Hash{std::size_t operator()(const Points& p)const{std::size_t h=p.size();for(auto v:p)h=(h^v)*1099511628211ULL;return h;}};
void need(bool b,const char* s){if(!b)throw std::runtime_error(s);}
unsigned u16(std::istream& f){int a=f.get(),b=f.get();need(a>=0&&b>=0,"Truncated neighbors");return a+256*b;}
unsigned u32(std::istream& f){unsigned a=u16(f),b=u16(f);return a+(b<<16);}
int encode(const Word& w){return ((w[0]*7+w[1])*7+w[2])*7+w[3];}

int main(int argc,char** argv){try{
 need(argc==4||argc==5,"Args: neighbors.bin start count [endpoint-prefix]; slices on stdin");
 int start=std::stoi(argv[2]),count=std::stoi(argv[3]),n;need(bool(std::cin>>n)&&n>0&&n<=65535,"N");
 need(start>=0&&count>0&&start+count<=n,"Root range");
 std::vector<Points> base(n);for(auto& sl:base){int k;need(bool(std::cin>>k)&&k>0&&k<=V,"Slice size");Mask seen;
  for(int j=0;j<k;++j){int v;need(bool(std::cin>>v)&&v>=0&&v<V&&!seen[v],"Point");seen.set(v);sl.push_back(v);}}
 std::string extra;need(!(std::cin>>extra),"Trailing slices");
 std::ifstream f(argv[1],std::ios::binary);char magic[4]{};f.read(magic,4);need(bool(f)&&std::string(magic,4)=="C7RN"&&u32(f)==unsigned(n)&&u32(f)==384,"Header");
 std::vector<std::vector<Frame>> templates(n);
 for(auto& row:templates){unsigned k=u32(f);for(unsigned j=0;j<k;++j){int b=u16(f),t=u16(f),s=u16(f);need(b<n&&t<384&&s<V,"Edge");row.push_back({b,t,s});}}
 f.read(magic,4);need(bool(f)&&std::string(magic,4)=="DONE"&&f.peek()==EOF,"Footer");
 std::array<Word,V> words{};for(int v=0;v<V;++v){int x=v;for(int k=3;k>=0;--k){words[v][k]=x%7;x/=7;}}
 std::vector<std::array<std::uint16_t,V>> add(V);
 for(int a=0;a<V;++a)for(int b=0;b<V;++b){Word w{};for(int k=0;k<4;++k)w[k]=(words[a][k]+words[b][k])%7;add[a][b]=encode(w);}
 std::vector<Word> permutations,signs;std::map<std::array<int,8>,int> index;
 Word perm={0,1,2,3};do{for(int bits=0;bits<16;++bits){Word sign{};std::array<int,8> key{};
  for(int k=0;k<4;++k){sign[k]=(bits&(8>>k))?1:-1;key[k]=perm[k];key[k+4]=sign[k];}
  index[key]=int(permutations.size());permutations.push_back(perm);signs.push_back(sign);}}
 while(std::next_permutation(perm.begin(),perm.end()));
 std::vector<std::array<std::uint16_t,V>> linear(384);
 for(int t=0;t<384;++t)for(int v=0;v<V;++v){Word w{};for(int k=0;k<4;++k)w[k]=(signs[t][k]*words[v][permutations[t][k]]+7)%7;linear[t][v]=encode(w);}
 std::vector<std::array<std::uint16_t,384>> compose(384);
 for(int a=0;a<384;++a)for(int b=0;b<384;++b){std::array<int,8> key{};for(int k=0;k<4;++k){key[k]=permutations[b][permutations[a][k]];key[k+4]=signs[a][k]*signs[b][permutations[a][k]];}compose[a][b]=index.at(key);}
 std::array<std::array<Mask,7>,4> lows{};const Word strides={343,49,7,1};
 for(int k=0;k<4;++k)for(int a=1;a<7;++a)for(int v=0;v<V;++v)if(words[v][k]<a)lows[k][a].set(v);
 std::vector<Mask> neighborhoods(V);
 for(int v=0;v<V;++v)for(int a=-1;a<=1;++a)for(int b=-1;b<=1;++b)for(int c=-1;c<=1;++c)for(int d=-1;d<=1;++d)
  neighborhoods[v].set(encode({(words[v][0]+a+7)%7,(words[v][1]+b+7)%7,(words[v][2]+c+7)%7,(words[v][3]+d+7)%7}));
 std::vector<Points> free(n);
 for(int b=0;b<n;++b){Mask blocked;for(auto v:base[b])blocked|=neighborhoods[v];for(int v=0;v<V;++v)if(!blocked[v])free[b].push_back(v);}
 std::unordered_map<int,Mask> allowed_linear;
 auto began=std::chrono::steady_clock::now();int completed=0;
 for(int root=start;root<start+count;++root){
  std::vector<Node> nodes;std::unordered_map<Points,int,Hash> lookup;
  auto make_node=[&](Frame g){Points points;points.reserve(base[g.base].size());for(auto v:base[g.base])points.push_back(add[linear[g.linear][v]][g.shift]);std::sort(points.begin(),points.end());
   auto found=lookup.find(points);if(found!=lookup.end())return found->second;
   int key=g.base*384+g.linear;auto it=allowed_linear.find(key);if(it==allowed_linear.end()){Mask m;for(auto v:free[g.base])m.set(linear[g.linear][v]);it=allowed_linear.emplace(key,m).first;}
   Mask allowed=it->second;for(int k=0;k<4;++k){int a=(7-words[g.shift][k])%7;if(a){Mask low=allowed&lows[k][a];allowed=((allowed^low)>>(a*strides[k]))|(low<<((7-a)*strides[k]));}}
   Mask mask;for(auto v:points)mask.set(v);int id=int(nodes.size());lookup.emplace(std::move(points),id);nodes.push_back({g,mask,allowed,{},false});return id;};
  auto neighbors=[&](int u)->const std::vector<int>&{if(!nodes[u].expanded){Frame a=nodes[u].g;std::vector<int> adjacent;
    for(Frame b:templates[a.base]){Frame g={b.base,compose[a.linear][b.linear],add[linear[a.linear][b.shift]][a.shift]};int v=make_node(g);
     need((nodes[v].points&nodes[u].allowed)==nodes[v].points,"Composed edge is invalid");adjacent.push_back(v);}
    std::sort(adjacent.begin(),adjacent.end());adjacent.erase(std::unique(adjacent.begin(),adjacent.end()),adjacent.end());nodes[u].adjacent=std::move(adjacent);nodes[u].expanded=true;}
   return nodes[u].adjacent;};
  const int origin=make_node({root,15,0});std::vector<std::pair<int,int>> current={{origin,int(base[root].size())}};
  std::vector<std::vector<int>> history;
  for(int step=0;step<3;++step){std::vector<int> score(nodes.size(),-1),prev(nodes.size(),-1),order;
   for(auto [u,value]:current){const auto& adj=neighbors(u);score.resize(nodes.size(),-1);prev.resize(nodes.size(),-1);
    for(int v:adj){int s=value+int(base[nodes[v].g.base].size());if(score[v]<0)order.push_back(v);if(s>score[v]){score[v]=s;prev[v]=u;}}}
   current.clear();for(int v:order)current.emplace_back(v,score[v]);history.push_back(std::move(prev));}
  std::sort(current.begin(),current.end(),[](auto a,auto b){return a.second!=b.second?a.second>b.second:a.first<b.first;});
  int best=-1,left=-1,right=-1;std::uint64_t comparisons=0;
  for(std::size_t i=0;i<current.size();++i){auto [u,score]=current[i];for(std::size_t j=i+1;j<current.size();++j){auto [v,other]=current[j];int value=score+other-int(base[root].size());if(value<=best)break;++comparisons;
    if((nodes[v].points&nodes[u].allowed)==nodes[v].points){best=value;left=u;right=v;}}}
  need(left>=0,"No seven-cycle at root");
  auto path=[&](int v){std::vector<int> out={v};for(auto it=history.rbegin();it!=history.rend();++it){v=(*it)[v];need(v>=0,"Broken predecessor");out.push_back(v);}std::reverse(out.begin(),out.end());return out;};
  auto cycle=path(left),other=path(right);for(int j=3;j>=1;--j)cycle.push_back(other[j]);
  std::vector<int> full;for(int layer=0;layer<7;++layer)for(int v=0;v<V;++v)if(nodes[cycle[layer]].points[v])full.push_back(layer*V+v);
  need(int(full.size())==best,"Wrong witness size");
  for(std::size_t i=0;i<full.size();++i)for(std::size_t j=0;j<i;++j){int x=full[i],y=full[j];bool conflict=true;for(int k=0;k<5;++k){int d=((x%7)-(y%7)+7)%7;if(d!=0&&d!=1&&d!=6){conflict=false;break;}x/=7;y/=7;}need(!conflict,"Invalid full witness");}
  if(argc==5){std::vector<std::pair<Points,int>> states;for(auto [v,score]:current){Points ids;for(int w=0;w<V;++w)if(nodes[v].points[w])ids.push_back(w);states.emplace_back(std::move(ids),score);}std::sort(states.begin(),states.end());
   std::ofstream out(std::string(argv[4])+std::to_string(root)+".json");out<<'[';bool first=true;for(const auto& state:states){if(!first)out<<',';first=false;out<<"[[";for(std::size_t i=0;i<state.first.size();++i){if(i)out<<',';out<<state.first[i];}out<<"],"<<state.second<<']';}out<<']';need(bool(out),"Endpoint output failure");}
  double elapsed=std::chrono::duration<double>(std::chrono::steady_clock::now()-began).count();
  std::cout<<"{\"root\":"<<root<<",\"nodes\":"<<nodes.size()<<",\"endpoints\":"<<current.size()<<",\"comparisons\":"<<comparisons<<",\"best\":"<<best<<",\"elapsed_seconds\":"<<elapsed<<",\"cycle\":[";
  for(int j=0;j<7;++j){if(j)std::cout<<',';Frame g=nodes[cycle[j]].g;std::cout<<'['<<g.base<<','<<g.linear<<','<<g.shift<<']';}
  std::cout<<"],\"words\":[";for(std::size_t j=0;j<full.size();++j){if(j)std::cout<<',';std::cout<<full[j];}std::cout<<"]}\n";std::cout.flush();need(bool(std::cout),"Output failure");++completed;
  if(best>=368){std::cerr<<"{\"status\":\"candidate_found\",\"completed\":"<<completed<<"}\n";return 0;}
  if(completed%25==0)std::cerr<<"{\"roots\":"<<completed<<",\"last_root\":"<<root<<",\"seconds\":"<<elapsed<<"}\n";
 }
 std::cerr<<"{\"status\":\"complete\",\"completed\":"<<completed<<"}\n";
 }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
