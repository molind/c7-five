"""Corroborate exchange queries using explicit pair conflicts, not cliques."""

import argparse
import hashlib
import itertools
import json
import time
from pathlib import Path

import z3

from search_exchanges import verify


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, default=Path(__file__).with_name("baseline.json"))
    parser.add_argument("--radius", type=int, default=4)
    parser.add_argument("--timeout", type=int, default=120)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    source = args.input
    words = json.loads(source.read_text())["words"]
    verify(words)
    original = set(map(tuple, words))
    all_words = list(itertools.product(range(7), repeat=5))
    blockers = {}
    began = time.monotonic()
    for candidate in all_words:
        if candidate in original:
            continue
        bs = [i for i, word in enumerate(words)
              if all((a - b) % 7 in (0, 1, 6)
                     for a, b in zip(candidate, word))]
        if len(bs) <= args.radius:
            blockers[candidate] = bs
    candidates = list(blockers)
    index = {w: i for i, w in enumerate(candidates)}
    add = [z3.Bool(f"a{i}") for i in range(len(candidates))]
    remove = [z3.Bool(f"r{i}") for i in range(len(words))]
    solver = z3.SolverFor("QF_FD")
    solver.set(timeout=args.timeout * 1000, random_seed=20260915)
    solver.add(z3.PbLe([(x, 1) for x in remove], args.radius))
    solver.add(z3.PbGe([(x, 1) for x in add], args.radius + 1))
    for i, word in enumerate(candidates):
        for b in blockers[word]:
            solver.add(z3.Or(z3.Not(add[i]), remove[b]))
    edges = 0
    shifts = list(itertools.product((-1, 0, 1), repeat=5))
    for i, word in enumerate(candidates):
        for shift in shifts:
            neighbor = tuple((a + d) % 7 for a, d in zip(word, shift))
            j = index.get(neighbor)
            if j is not None and i < j:
                solver.add(z3.Or(z3.Not(add[i]), z3.Not(add[j])))
                edges += 1
    build_seconds = time.monotonic() - began
    print(json.dumps({"built": True, "candidates": len(candidates),
                      "edges": edges, "seconds": build_seconds}), flush=True)
    began = time.monotonic()
    status = solver.check()
    report = {"input_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
              "radius": args.radius, "status": str(status),
              "candidates": len(candidates), "conflict_edges": edges,
              "build_seconds": build_seconds,
              "solve_seconds": time.monotonic() - began,
              "timeout_ms": args.timeout * 1000,
              "z3_version": z3.get_version_string()}
    if status == z3.unknown:
        report["reason"] = solver.reason_unknown()
    if status == z3.sat:
        model = solver.model()
        solution = [w for i, w in enumerate(words)
                    if not z3.is_true(model.eval(remove[i]))]
        solution += [list(w) for i, w in enumerate(candidates)
                     if z3.is_true(model.eval(add[i]))]
        verify(solution)
        assert len(solution) > len(words)
        report["size"] = len(solution)
        args.output.with_suffix(".solution.json").write_text(
            json.dumps({"words": solution}, indent=2) + "\n")
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
