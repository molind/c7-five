"""Test non-geometric r-for-(r+2) exchanges from saved366 backbones.

Every omitted word of the backbone may change, including the earlier fixed
exterior. Separate radii cover their requested sizes only. Z3 unsat responses
are solver results; no independently checked UNSAT certificate is produced.
"""
import argparse
import hashlib
from itertools import product
import json
from pathlib import Path
import time

from run_seed_exchanges import coordinate_masks,nearby
from search_exchanges import graph_data,solve_radius,verify


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--radii',type=int,nargs='+',default=[2,3])
    p.add_argument('--seconds',type=int,default=10)
    p.add_argument('--start',type=int,default=0)
    p.add_argument('--count',type=int,default=12)
    a=p.parse_args();assert __debug__ and not a.output.exists()
    assert min(a.radii)>0 and a.seconds>0 and a.start>=0 and a.count>0
    source=json.loads(a.input.read_text());assert source['status']=='complete'
    selected=source['bases'][a.start:a.start+a.count];assert len(selected)==a.count
    report=dict(input=str(a.input),input_sha256=hashlib.sha256(a.input.read_bytes()).hexdigest(),
                source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                solver_source_sha256=hashlib.sha256((Path(__file__).parent/'search_exchanges.py').read_bytes()).hexdigest(),
                start=a.start,count=a.count,radii=a.radii,seconds_per_query=a.seconds,status='running',rows=[],candidates=[],scope=__doc__)
    began=time.monotonic()
    def save():
        report['seconds']=time.monotonic()-began
        tmp=a.output.with_suffix('.tmp');tmp.write_text(json.dumps(report,separators=(',',':'))+'\n');tmp.replace(a.output)
    save()
    for bi,base in enumerate(selected,a.start):
        words=[[v//7**j%7 for j in range(4,-1,-1)] for v in base['words']]
        assert len(words)==366;verify(words)
        vertices,ids,blockers,cliques=graph_data(words)
        masks=coordinate_masks(words)
        for v,w in enumerate(vertices):
            assert sum(1<<i for i in blockers[v])==nearby(w,masks,366)
        for radius in a.radii:
            result,solution=solve_radius(words,vertices,ids,blockers,cliques,radius,a.seconds*1000,2026093000+10*bi+radius,2)
            row=dict(base=bi,all_16807_blocker_rows_rebuilt=True,result=result)
            report['rows'].append(row)
            if solution is not None:
                assert len(solution)>=368;checks=verify(solution)
                report['candidates'].append(dict(base=bi,radius=radius,words=solution,pair_checks=checks))
                report['status']='verified_target';save();return
            save();print(json.dumps(dict(base=bi,**result)),flush=True)
    report['status']='bounded_exchange_search_complete';save()


if __name__=='__main__':main()
