"""Numerically screen all signed coordinate maps for high-overlap parent pairs.

FFT ranks translations. Every retained overlap and union-MIS witness is checked
exactly. Numerical screening is discovery, not a certified excluded-map bound.
"""
import argparse
import hashlib
from itertools import permutations, product
import json
from pathlib import Path
import time

import numpy as np
from recombine_sets import cross_graph, optimum, verify
from search_translated_slices import correlations


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_words(path):
    tokens = path.read_text().split()
    assert len(tokens) == len(set(tokens)) == 367
    assert all(len(t) == 5 and set(t) <= set('0123456') for t in tokens)
    result = [tuple(map(int, t)) for t in tokens]
    verify(result)
    return result


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--target', required=True, type=Path)
    p.add_argument('--source', required=True, type=Path)
    p.add_argument('--keep', type=int, default=32)
    p.add_argument('--output', required=True, type=Path)
    args = p.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    if args.keep < 1:
        p.error('Positive retained-alignment count required')
    target, source = read_words(args.target), read_words(args.source)
    target_set = set(target)
    source_array = np.array(source, dtype=np.int16)
    target_indicator = np.zeros((7,)*5, dtype=np.int8)
    target_indicator[tuple(np.array(target).T)] = 1
    # Explicit wrapped singleton shift tests the five-dimensional convention.
    control_a = np.zeros((7,)*5, dtype=np.int8)
    control_b = control_a.copy()
    control_a[1, 2, 3, 4, 5] = 1
    control_b[6, 5, 4, 3, 2] = 1
    control = correlations(control_a, control_b)
    assert control[2, 4, 6, 1, 3] == 1 and np.count_nonzero(control) == 1
    kept = {}
    best_overlap = -1
    scanned = 0
    began = time.monotonic()
    for perm in permutations(range(5)):
        for signs in product((-1, 1), repeat=5):
            linear = (source_array[:, perm]*np.array(signs)) % 7
            indicator = np.zeros((7,)*5, dtype=np.int8)
            indicator[tuple(linear.T)] = 1
            scores = correlations(target_indicator, indicator)
            best = int(scores.max())
            best_overlap = max(best_overlap, best)
            floor = min((row['overlap'] for row in kept.values()), default=-1) if len(kept) >= args.keep else -1
            if best >= floor:
                for shift in np.argwhere(scores == best):
                    image = tuple(sorted(tuple(map(int, w)) for w in (linear+shift) % 7))
                    overlap = len(target_set & set(image))
                    assert overlap == best
                    if image not in kept:
                        kept[image] = dict(permutation=list(perm), signs=list(signs), shift=shift.tolist(), overlap=overlap)
                if len(kept) > args.keep:
                    kept = dict(sorted(kept.items(), key=lambda item: (-item[1]['overlap'], item[0]))[:args.keep])
            scanned += 1
            if scanned % 640 == 0:
                print(json.dumps(dict(linear_maps=scanned, best_overlap=best_overlap, seconds=time.monotonic()-began)), flush=True)
    rows, candidates = [], []
    for image, transform in sorted(kept.items(), key=lambda item: (-item[1]['overlap'], item[0])):
        verify(image)
        source_set = set(image)
        common = sorted(target_set & source_set)
        left, right = sorted(target_set-source_set), sorted(source_set-target_set)
        graph = cross_graph(left, right)
        matching, take_left, take_right = optimum(graph, len(right))
        full = sorted(common+[left[i] for i in take_left]+[right[i] for i in take_right])
        verify(full)
        assert len(full) == len(target_set | source_set)-len(matching)
        row = dict(**transform, common=[''.join(map(str, w)) for w in common],
                   source_words=[''.join(map(str, w)) for w in image], union_optimum=len(full),
                   matching=matching, left_size=len(left), right_size=len(right))
        rows.append(row)
        if len(full) >= 368:
            candidates.append(dict(step=len(rows)-1, size=len(full), words=[''.join(map(str, w)) for w in full],
                                   verified_pairs=len(full)*(len(full)-1)//2))
    report = dict(status='verified_improvement' if candidates else 'complete',
        target=str(args.target), target_sha256=sha(args.target), source=str(args.source), source_sha256=sha(args.source),
        script_sha256=sha(__file__), correlation_source_sha256=sha(Path(__file__).with_name('search_translated_slices.py')),
        matching_source_sha256=sha(Path(__file__).with_name('recombine_sets.py')), linear_maps=scanned,
        best_screened_overlap=best_overlap, retained=len(rows), rows=rows, candidates=candidates,
        seconds=time.monotonic()-began, wrapped5Dcontrol=True,
        scope='All3840signed permutations numerically screened over16807translations each; retained maps and their union optima exactly checked. Not a proof that every discarded alignment is suboptimal or has union optimum367.')
    args.output.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(dict(status=report['status'], best_overlap=best_overlap, retained=len(rows),
        best_union=max(row['union_optimum'] for row in rows), seconds=report['seconds'])), flush=True)


if __name__ == '__main__':
    main()
