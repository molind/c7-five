"""Exhaustively compare binary trade constraints and exact-pattern exclusions."""
import argparse
from collections import Counter
import hashlib
from itertools import combinations
import json
from pathlib import Path
import random

import numpy as np
from scipy.optimize import milp,Bounds,LinearConstraint

from solve_two_blocker_mip import build_model


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();assert __debug__ and not a.output.exists();rng=random.Random(2026092140)
    cases=[([[0,1]]*5,[],[]),([[0,1,2]]*3,[],[]),([[0,1,2]]*5,[],[[0,1,2,3]])]
    for trial in range(80):
        old=rng.randrange(3,6);n=rng.randrange(3,9)
        blockers=[sorted(rng.sample(range(old),rng.randrange(2,min(3,old)+1))) for _ in range(n)]
        edges=[list(pair) for pair in combinations(range(n),2) if rng.random()<.25]
        excluded=[rng.sample(range(n),rng.randrange(0,n+1)) for _ in range(trial%3)]
        cases.append((blockers,edges,excluded))
    totals=Counter()
    for ci,(blockers,edges,excluded) in enumerate(cases):
        n=len(blockers);active=sorted({v for b in blockers for v in b})
        domain=dict(pool_ids=list(range(n)),blocker_sets=blockers,conflict_edges=edges,active_old_indices=active)
        for mode in ('gain_two','long_cycle'):
            matrix,lo,hi,objective=build_model(domain,mode,excluded);feasible=[]
            for mask in range(1<<n):
                chosen={i for i in range(n) if mask>>i&1};removed={v for i in chosen for v in blockers[i]}
                expected=len(chosen)>=3 and len(chosen)-len(removed)>=(2 if mode=='gain_two' else 0)
                expected &= not any(i in chosen and j in chosen for i,j in edges)
                if mode=='long_cycle':expected &= not any(len(blockers[i])==2 and blockers[i]==blockers[j] for i,j in combinations(chosen,2))
                expected &= all(chosen!=set(pattern) for pattern in excluded)
                x=np.array([int(i in chosen) for i in range(n)]+[int(i in removed) for i in active]);values=matrix@x
                actual=bool(np.all(values>=lo) and np.all(values<=hi));assert actual==expected
                if actual:feasible.append((float(objective@x),mask))
                totals['assignments']+=1
            result=milp(objective,integrality=np.ones(len(objective)),bounds=Bounds(0,1),constraints=LinearConstraint(matrix,lo,hi),options={'time_limit':2,'mip_rel_gap':0})
            if feasible:
                assert result.status==0 and abs(result.fun-min(x[0] for x in feasible))<1e-7;totals['feasible_models']+=1
            else:assert result.status==2;totals['infeasible_models']+=1
            if ci==1 and mode=='long_cycle':assert len(feasible)==1 and feasible[0][1]==7
            if ci==2 and mode=='long_cycle':
                masks={x[1] for x in feasible};assert 7 in masks and 31 in masks and 15 not in masks
            totals['models']+=1
    assert totals['feasible_models'] and totals['infeasible_models']
    here=Path(__file__).resolve().parent
    out=dict(cases=len(cases),totals=dict(totals),source_sha256=hashlib.sha256((here/'solve_two_blocker_mip.py').read_bytes()).hexdigest(),checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope=__doc__)
    a.output.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))


if __name__=='__main__':main()
