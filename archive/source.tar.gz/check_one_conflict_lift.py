"""Check the energy-one lift of Family B and its one-replacement barrier."""
from collections import deque
from itertools import combinations
import hashlib
import json
from pathlib import Path
import random
import struct

from family_a_component import component, TOKENS, WORDS

HERE = Path(__file__).resolve().parent
if not __debug__:
    raise RuntimeError('Run without -O')
seed = tuple(int(w, 7) for w in (HERE/'family-b-seed-words.txt').read_text().split())
assert hashlib.sha256(' '.join(TOKENS[i] for i in seed).encode()).hexdigest() == 'ab9029e1f7074e0c40d3468b2a02d11717498386474194126b2362eb1d1d85ea'
states, _, edges = component(seed)
assert len(states) == 78 and len(edges) == 326
assert hashlib.sha256(b''.join(sorted(struct.pack('<367H', *s) for s in states))).hexdigest() == 'e927b8f9bca659c274c788ece758d9d8c8b0294ffc397435dbf2864d7b89546e'
sets = [frozenset(s) for s in states]
def conflict(a, b):
    return all((x-y)%7 in (0, 1, 6) for x,y in zip(WORDS[a], WORDS[b]))
assert all(not conflict(a,b) for s in states for a,b in combinations(s,2))
lifts = {}
for a,b in edges:
    if a >= b:
        continue
    union = sets[a] | sets[b]
    assert len(union) == 368 and union not in lifts
    added, = union-sets[a]
    neighbors = {v for v in sets[a] if conflict(added,v)}
    assert neighbors == sets[a]-sets[b] and len(neighbors) == 1
    lifts[union] = (a,b)
assert len(lifts) == 163
ordered = sorted(lifts, key=lambda s:tuple(sorted(s)))
adj = [set() for _ in ordered]
for i,j in combinations(range(len(ordered)),2):
    if len(ordered[i]-ordered[j]) == 1:
        adj[i].add(j); adj[j].add(i)
seen, todo = {0}, deque([0])
while todo:
    for j in adj[todo.popleft()]-seen:
        seen.add(j); todo.append(j)
assert len(seen) == 163

# Test the general transition lemma on independent random small graphs.
rng = random.Random(20260919)
transitions = zero_exits = 0
for trial in range(150):
    n = rng.randrange(4, 10); k = rng.randrange(2, min(5,n))
    es = {frozenset(p) for p in combinations(range(n),2) if rng.random()<0.35}
    def energy(s): return sum(e <= s for e in es)
    indep = [frozenset(s) for s in combinations(range(n),k) if energy(frozenset(s)) == 0]
    labels = {}
    for s in indep:
        if s in labels: continue
        label = len(labels); labels[s] = label; q = [s]
        while q:
            a = q.pop()
            for b in indep:
                if b not in labels and len(a-b)==1:
                    labels[b]=label; q.append(b)
    near = [frozenset(s) for s in combinations(range(n),k+1) if energy(frozenset(s))==1]
    near_labels = {}
    for s in near:
        sub = [s-{v} for v in s if s-{v} in labels]
        assert len(sub)==2 and len({labels[t] for t in sub})==1
        near_labels[s]=labels[sub[0]]
    for a,b in combinations(near,2):
        if len(a-b)==1:
            assert near_labels[a]==near_labels[b]; transitions+=1
    zeros = [frozenset(s) for s in combinations(range(n),k+1) if energy(frozenset(s))==0]
    for a in near:
        for b in zeros:
            if len(a-b)==1:
                common = a & b
                assert labels[common]==near_labels[a]
                assert any(not energy(s|{v}) for s in indep if labels[s]==near_labels[a]
                           for v in set(range(n))-s)
                zero_exits+=1
report = dict(component_states=78, directed_single_exchanges=326, energy_one_states=163,
              energy_one_undirected_edges=sum(map(len,adj))//2, connected=True,
              energy_one_sha256=hashlib.sha256(b''.join(struct.pack('<368H', *sorted(s)) for s in ordered)).hexdigest(),
              control_graphs=150, checked_one_to_one_transitions=transitions, checked_one_to_zero_transitions=zero_exits,
              scope='Fixed 368 distinct vertices; energy counts forbidden pairs; moves replace one word. Staying at energy<=1 cannot escape the maximal Family-B component or reach energy0. Energy>=2 or a larger move is necessary, not sufficient.')
(HERE/'one-conflict-family-b-result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report),flush=True)
