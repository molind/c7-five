"""Rebuild full native inputs and check every returned trade with subset search.

Local union maxima and width-two reachability are enumerated from coordinate
conflicts, without importing the matching/SCC analyzer. Native search trees are
not independently replayed; timeout/output-limit rows remain partial.
"""
import argparse
from collections import Counter
import hashlib
from itertools import combinations,product
import json
from pathlib import Path

import numpy as np

from check_exchange_dfs import graph_text
from check_farthest_exchange_inputs import conflict_rows


def union_states(old,added,blockers):
    r=len(old);full=(1<<r)-1;states=set();maximum=0
    for new_mask in range(1<<r):
        blocked=0
        for i,b in enumerate(blockers):
            if new_mask>>i&1:blocked|=b
        allowed=[i for i in range(r) if not blocked>>i&1]
        k=new_mask.bit_count();maximum=max(maximum,k+len(allowed))
        for chosen in combinations(allowed,r-k):states.add(sum(1<<i for i in chosen)|(new_mask<<r))
    assert full in states and full<<r in states
    def connected(width):
        seen={full};queue=[full]
        for state in queue:
            if state==full<<r:return True
            for other in states-seen:
                if (state^other).bit_count()<=2*width:seen.add(other);queue.append(other)
        return False
    width=next(k for k in range(1,r+1) if connected(k))
    return maximum,width


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,nargs='+',required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();assert __debug__ and not a.output.exists()
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    coords=np.array(list(product(range(7),repeat=5)),dtype=np.int16);here=Path(__file__).resolve().parent
    source_versions=['enumerate_reference_atomic_initial.py','enumerate_reference_atomic.py']
    versions={sha(here/n):n for n in source_versions};rows=[];totals=Counter();intervals={}
    for path in a.input:
        data=json.loads(path.read_text());assert data['status']=='complete'
        assert data['source_sha256'] in versions
        assert sha(here/'exchange_dfs_residual_two')==data['kernel_sha256'] and sha(here/'exchange_dfs_residual_two.cpp')==data['kernel_source_sha256']
        source=Path(data['input']);assert sha(source)==data['input_sha256'];bases=json.loads(source.read_text())['bases']
        radius=data.get('radius',3);expected_bases={};expected_origins={};expected_candidates=set()
        assert [row['base'] for row in data['rows']]==data['indices']
        for row in data['rows']:
            ids=bases[row['base']]['words'];assert ids==sorted(set(ids)) and len(ids)==367
            b=[]
            for start,bad in conflict_rows(coords,coords[ids]):
                b.extend(int.from_bytes(v.tobytes(),'little') for v in np.packbits(bad,axis=1,bitorder='little'))
            assert all(b[v]==1<<i for i,v in enumerate(ids));occupied=set(ids)
            outside=[v for v in range(16807) if v not in occupied];assert all(b[v] for v in outside)
            sign=-1 if data.get('order')=='many_first' else 1
            pool=sorted((v for v in outside if (2 if data.get('atomic_only') else 1)<=b[v].bit_count()<=data.get('max_blockers',radius)),key=lambda v:sign*b[v].bit_count());assert pool==row['pool_ids']
            comp=[]
            for start,bad in conflict_rows(coords[pool],coords[pool]):
                comp.extend(int.from_bytes(v.tobytes(),'little') for v in np.packbits(~bad,axis=1,bitorder='little'))
            if data.get('atomic_only'):
                groups={}
                for i,v in enumerate(pool):
                    if b[v].bit_count()==2:groups[b[v]]=groups.get(b[v],0)|(1<<i)
                for i,v in enumerate(pool):
                    if b[v].bit_count()==2:comp[i]&=~groups[b[v]]
            encoded=graph_text([b[v] for v in pool],comp,radius,6)
            assert hashlib.sha256(encoded.encode()).hexdigest()==row['graph_sha256']
            result=row['result'];assert result['enumerate_neutral'] and result['status'] in ('exhausted','timeout','output_limit')
            assert result['root_end']==len(pool) and result['root_prefix']==-1
            assert not result['anchor_bounds'] and not result['pair_bounds'] and not result['noncore_bound']
            assert result['budget_bitsets'] and result['binary_budget'] and result['residual_budget']
            assert all(type(result[k]) is int for k in ['root_start','root_end','next_root'])
            assert 0<=result['root_start']<=result['next_root']<=len(pool)
            if data.get('previous'):
                prior=json.loads(Path(data['previous']).read_text());assert sha(data['previous'])==data['previous_sha256']
                assert prior['input_sha256']==data['input_sha256']
                old_row=next(r for r in prior['rows'] if r['base']==row['base'])
                assert old_row['graph_sha256']==row['graph_sha256'] and old_row['pool_ids']==pool
                assert old_row['result']['next_root']==result['root_start']
            else:assert result['root_start']==0
            intervals.setdefault((data['input_sha256'],row['base'],radius,row['graph_sha256'],len(pool)),[]).append(dict(file=str(path),start=result['root_start'],end=result['next_root'],status=result['status']))
            if result['status']=='exhausted':assert result['nodes_started']==result['nodes_completed'] and result['next_root']==len(pool)
            wide=[];decomposed=0;union_improvements=[];widths=Counter()
            seen_choices=set()
            for kind in ('neutral','improving'):
                for index,chosen in enumerate(result[kind]):
                    assert len(chosen)==len(set(chosen))==radius and all(type(i) is int and 0<=i<len(pool) for i in chosen)
                    assert tuple(chosen) not in seen_choices;seen_choices.add(tuple(chosen))
                    used=0
                    for i in chosen:used|=b[pool[i]]
                    assert used.bit_count()<=radius and (used.bit_count()==radius)==(kind=='neutral')
                    assert all(comp[i]>>j&1 for i,j in combinations(chosen,2))
                    old=[v for j,v in enumerate(ids) if used>>j&1];added=[pool[i] for i in chosen]
                    new=tuple(sorted((occupied-set(old))|set(added)))
                    if kind=='improving':expected_candidates.add(new);continue
                    local=[]
                    for v in added:
                        delta=(coords[old]-coords[v])%7
                        bad=np.all((delta==0)|(delta==1)|(delta==6),axis=1)
                        local.append(sum(1<<i for i,flag in enumerate(bad) if flag))
                    maximum,width=union_states(old,added,local);widths[width]+=1
                    if maximum>radius:
                        union_improvements.append(index)
                        ref=next(x for x in row['union_improvements'] if x['native_index']==index)['analysis']
                        assert len(ref['maximum'])==maximum
                        maximum_ids=ref['maximum'];assert len(set(maximum_ids))==maximum and set(maximum_ids)<=set(old+added)
                        for start,bad in conflict_rows(coords[maximum_ids],coords[maximum_ids]):
                            assert int(bad.sum())==len(bad)
                        expected_candidates.add(tuple(sorted((occupied-set(old))|set(maximum_ids))))
                    elif width>2:
                        wide.append(index);expected_bases[new]=(row['base'],index,width)
                        expected_origins[new,row['base'],index]=width
                    else:decomposed+=1
            assert wide==row.get('requires_wide_step',row.get('locally_indecomposable')) and decomposed==row['decomposable']
            assert union_improvements==[x['native_index'] for x in row.get('union_improvements',[])]
            rows.append(dict(input=str(path),base=row['base'],radius=radius,pool=len(pool),status=result['status'],neutral=len(result['neutral']),improving=len(result['improving']),minimum_width_counts=dict(widths)))
            totals['directed_compatibility_entries']+=len(pool)**2;totals['blocker_coordinate_pairs']+=16807*367
            totals['checked_trades']+=len(seen_choices);print(json.dumps(rows[-1]),flush=True)
        actual_bases={tuple(x['words']):x for x in data['bases']};assert set(actual_bases)==set(expected_bases)
        for key,x in actual_bases.items():
            # A duplicate endpoint may have multiple valid source edges.
            ref=next(row for row in data['rows'] if row['base']==x['source_base'])
            assert x['native_index'] in ref.get('requires_wide_step',ref.get('locally_indecomposable'))
            if 'analysis' in x:assert x['analysis']['minimum_step_width']==expected_origins[key,x['source_base'],x['native_index']]
        assert {tuple(sorted(int(w,7) for w in x['words'])) for x in data['candidates']}==expected_candidates
        assert data['enumeration_complete']==all(row['result']['status']=='exhausted' for row in data['rows'])
    coverage=[]
    for (input_sha,bi,radius,graph_sha,n),segments in sorted(intervals.items()):
        segments.sort(key=lambda s:s['start']);first=segments[0]['start'];end=first
        for segment in segments:
            assert segment['start']==end,'Gap or overlap in atomic intervals'
            end=segment['end']
        coverage.append(dict(base=bi,radius=radius,start=first,closed_until=end,root_end=n,complete=first==0 and end==n,segments=segments))
    out=dict(inputs={str(path):sha(path) for path in a.input},checker_sha256=sha(__file__),rows=rows,totals=dict(totals),coverage=coverage,scope=__doc__)
    a.output.write_text(json.dumps(out,indent=2)+'\n')


if __name__=='__main__':main()
