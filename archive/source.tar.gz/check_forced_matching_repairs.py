"""Replay real forced-repair cases without SCCs, using direct graph reachability.

Check three completed cuts per translation: first, middle and last. Rebuild
exterior-word blocker lists directly from coordinate differences. This is an
independent implementation sample, not a replay of every cut in the search.
"""
import argparse
from itertools import combinations, product
import hashlib
import json
from pathlib import Path
import struct

import numpy as np


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--runs',type=Path,nargs='+',required=True)
    p.add_argument('--translations',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();assert __debug__ and not args.output.exists()
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    t=json.loads(args.translations.read_text())
    assert sha(t['matching_file'])==t['matching_sha256']
    assert sha(t['parents_file'])==t['parents_sha256']
    ids=[sorted(x['words']) for x in json.loads(Path(t['parents_file']).read_text())['bases']]
    coords=np.array(list(product(range(7),repeat=5)),dtype=np.int16)
    powers=np.array([2401,343,49,7,1],dtype=np.int32)
    raw=Path(t['matching_file']).read_bytes();records=[];word_cases=pair_cases=0
    dependencies={str(args.translations):sha(args.translations)}
    for path in args.runs:
        d=json.loads(path.read_text());dependencies[str(path)]=sha(path)
        assert all(sha(f)==h for f,h in d['dependencies'].items())
        for row in d['rows']:
            if not row['cuts']:continue
            shift=row['shift'];mate=struct.unpack_from('<367H',raw,734*(shift-t['start']))
            right_ids=(((coords[ids[1]]+coords[shift])%7)@powers).tolist()
            right_ids=[right_ids[j] for j in mate]
            a,b=coords[ids[0]],coords[right_ids]
            delta=(a[:,None,:]-b[None,:,:])%7
            graph=np.all((delta==0)|(delta==1)|(delta==6),axis=2)
            assert np.all(np.diag(graph))
            common=[i for i in range(367) if ids[0][i]==right_ids[i]]
            union=set(ids[0])|set(right_ids)
            eligible=np.array([v for v in range(16807) if v not in union],dtype=np.int32)
            # Independent coordinate construction, with chunking for memory.
            exterior=[];pa=[];pb=[]
            for start in range(0,len(eligible),512):
                chunk=eligible[start:start+512]
                da=(coords[chunk,None,:]-a[None,:,:])%7
                db=(coords[chunk,None,:]-b[None,:,:])%7
                ca=np.all((da==0)|(da==1)|(da==6),axis=2)
                cb=np.all((db==0)|(db==1)|(db==6),axis=2)
                for v,x,y in zip(chunk,ca,cb):
                    if np.any(x[common]):continue
                    exterior.append(int(v));pa.append(np.flatnonzero(x).tolist());pb.append(np.flatnonzero(y).tolist())
            assert len(exterior)==row['exterior_words']
            selected=sorted({0,len(row['cuts'])//2,len(row['cuts'])-1})
            for at in selected:
                r=row['cuts'][at];cut=r['cut'];all_bits=((1<<367)-1)^(1<<cut)
                adjacency=[sum(1<<int(j) for j in np.flatnonzero(line) if j!=cut) for line in graph]
                reach={}
                def closure(v):
                    if v not in reach:
                        seen=todo=1<<v
                        while todo:
                            bit=todo&-todo;todo^=bit;i=bit.bit_length()-1
                            new=adjacency[i]&all_bits&~seen
                            seen|=new;todo|=new
                        reach[v]=seen
                    return reach[v]
                feasible=[]
                for v,aa,bb in zip(exterior,pa,pb):
                    forbidden=sum(1<<i for i in aa if i!=cut)
                    required=0
                    for j in bb:
                        if j!=cut:required|=closure(j)
                    word_cases+=1
                    if not(required&forbidden):feasible.append((v,required,forbidden))
                assert len(feasible)==r['feasible_exterior_words']
                tested=0
                for (v,ra,fa),(w,rb,fb) in combinations(feasible,2):
                    tested+=1;pair_cases+=1
                    independent=any(int(x-y)%7 in (2,3,4,5) for x,y in zip(coords[v],coords[w]))
                    assert not(independent and not((ra|rb)&(fa|fb))), 'Verified 368 extension in replay'
                assert tested==r['tested_pairs']
                records.append(dict(run=str(path),shift=shift,cut=cut,exterior_words=len(exterior),
                                    feasible_words=len(feasible),pairs=tested))
    out=dict(passed=True,sampled_cuts=len(records),exterior_word_queries=word_cases,
             feasible_pair_queries=pair_cases,records=records,dependencies=dependencies,
             checker_sha256=sha(__file__),scope='First/middle/last completed cut per translation; direct geometry and reachability, no SCC code import.')
    args.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k not in ('records','dependencies')}))


if __name__=='__main__':main()
