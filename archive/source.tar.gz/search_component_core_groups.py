"""Optimize unrestricted noncore replacements for exact core omissions.

The omitted original core words are forbidden; all other words compatible with
the retained core are admitted. A completed group range is a local result only.
Uses the existing tested memoized MIS solver, with direct-coordinate inputs.
"""
import argparse
from collections import Counter
import gzip
import hashlib
from itertools import combinations, islice, product
import json
import math
from pathlib import Path
import struct
import time

import numpy as np
from search_family_d_core_groups import bits, controls, make_solver


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--component', required=True, type=Path)
    p.add_argument('--verification', required=True, type=Path)
    p.add_argument('--release-size', required=True, type=int, choices=range(1, 9))
    p.add_argument('--groups-file', type=Path, help='Explicit distinct groups of omitted core word IDs')
    p.add_argument('--start', type=int, default=0)
    p.add_argument('--limit', type=int)
    p.add_argument('--seconds', type=float, default=60)
    p.add_argument('--output', required=True, type=Path)
    args = p.parse_args()
    if args.seconds <= 0 or args.start < 0 or (args.limit is not None and args.limit < 1):
        p.error('Invalid time/range')
    if args.output.exists():
        raise FileExistsError(args.output)
    verification = json.loads(args.verification.read_text())
    assert verification['component_file_sha256'] == sha(args.component)
    assert verification['connected'] and verification['closed_under_all_one_for_one_exchanges']
    with gzip.open(args.component, 'rt') as f:
        metadata = json.loads(next(f))
        states = [frozenset(json.loads(line)) for line in f]
    assert metadata['cardinality'] == 367 and len(states) == metadata['states']
    keys = sorted(struct.pack('<367H', *sorted(s)) for s in states)
    assert len(set(keys)) == len(keys) and hashlib.sha256(b''.join(keys)).hexdigest() == metadata['component_sha256']
    core = sorted(frozenset.intersection(*states))
    assert core == verification['core_words'] and len(core) >= args.release_size
    core_set = set(core)
    words = np.array(list(product(range(7), repeat=5)), dtype=np.int16)
    outsiders = [v for v in range(16807) if v not in core_set]
    pool, blockers = [], []
    # Explicit comparisons to the whole retained-core candidate set.
    for begin in range(0, len(outsiders), 128):
        chunk = outsiders[begin:begin+128]
        delta = (words[chunk, None, :]-words[core][None, :, :]) % 7
        blocked = np.all((delta == 0) | (delta == 1) | (delta == 6), axis=2)
        for i in np.flatnonzero(blocked.sum(axis=1) <= args.release_size):
            pool.append(chunk[int(i)])
            blockers.append(sum(1 << int(j) for j in np.flatnonzero(blocked[int(i)])))
    groups = {}
    for i, mask in enumerate(blockers):
        groups[mask] = groups.get(mask, 0) | (1 << i)
    adjacency = []
    for i, v in enumerate(pool):
        delta = (words[pool]-words[v]) % 7
        row = np.all((delta == 0) | (delta == 1) | (delta == 6), axis=1)
        row[i] = False
        adjacency.append(int.from_bytes(np.packbits(row, bitorder='little').tobytes(), 'little'))
    selected_groups = None
    if args.groups_file:
        selected_groups = json.loads(args.groups_file.read_text())
        assert isinstance(selected_groups, list) and selected_groups
        assert all(isinstance(g, list) and len(g) == len(set(g)) == args.release_size
                   and all(type(v) is int and v in core_set for v in g) for g in selected_groups)
        selected_groups = sorted(tuple(sorted(g)) for g in selected_groups)
        assert len(set(selected_groups)) == len(selected_groups)
    total = len(selected_groups) if selected_groups is not None else math.comb(len(core), args.release_size)
    if args.start >= total:
        p.error('Start outside group space')
    end = min(total, args.start+(total if args.limit is None else args.limit))
    report = dict(status='running', component=str(args.component), component_file_sha256=sha(args.component),
        verification=str(args.verification), verification_sha256=sha(args.verification),
        source_sha256=sha(__file__), solver_sha256=sha(Path(__file__).with_name('search_family_d_core_groups.py')),
        controls=controls(), core=core, pool=pool, blockers=blockers, release_size=args.release_size,
        start=args.start, end=end, total_groups=total, rows=[], candidates=[], best_full_size=0,
        next_index=args.start, scope='Exact omitted core words forbidden; other noncore words unrestricted. Complete ranges give only local bounds; budget limits exclude nothing.')
    if selected_groups is not None:
        report.update(selection='explicit', groups_file=str(args.groups_file), groups_file_sha256=sha(args.groups_file))
    else:
        report['selection'] = 'all'
    began = time.monotonic()
    deadline = began+args.seconds
    solve = make_solver(adjacency, deadline)
    archived = set()
    def save():
        report['seconds'] = time.monotonic()-began
        report['cache_info'] = solve.cache_info()._asdict()
        report['alpha_histogram'] = dict(Counter(row['alpha'] for row in report['rows']))
        report['domain_histogram'] = dict(Counter(row['domain_size'] for row in report['rows']))
        temporary = args.output.with_name(args.output.name+'.tmp')
        with (gzip.open if args.output.suffix == '.gz' else open)(temporary, 'wt') as f:
            json.dump(report, f, separators=(',', ':'))
            f.write('\n')
        temporary.replace(args.output)
    save()
    core_index = {v:i for i, v in enumerate(core)}
    iterator = combinations(range(len(core)), args.release_size) if selected_groups is None else (
        tuple(core_index[v] for v in group) for group in selected_groups)
    for index, omitted_indices in enumerate(islice(iterator, args.start, end), args.start):
        omission = sum(1 << i for i in omitted_indices)
        domain = groups.get(0, 0)
        sub = omission
        while sub:
            domain |= groups.get(sub, 0)
            sub = (sub-1) & omission
        try:
            if time.monotonic() >= deadline:
                raise TimeoutError
            alpha, chosen = solve(domain)
        except TimeoutError:
            report['status'] = 'timeout'
            break
        assert chosen & ~domain == 0 and chosen.bit_count() == alpha
        assert all(not (adjacency[i] & chosen) for i in bits(chosen))
        omitted = [core[i] for i in omitted_indices]
        residual = [pool[i] for i in bits(chosen)]
        full_size = len(core)-args.release_size+alpha
        report['rows'].append(dict(index=index, omitted=omitted, domain_size=domain.bit_count(), alpha=alpha, residual=residual))
        report['next_index'] = index+1
        report['best_full_size'] = max(report['best_full_size'], full_size)
        if full_size >= 367:
            full = frozenset(core_set-set(omitted)) | frozenset(residual)
            assert len(full) == full_size
            points = words[sorted(full)]
            delta = (points[:, None, :]-points[None, :, :]) % 7
            assert not np.any(np.triu(np.all((delta == 0) | (delta == 1) | (delta == 6), axis=2), 1))
            if full not in archived:
                archived.add(full)
                report['candidates'].append(dict(step=index, size=full_size, omitted=omitted,
                    words=[''.join(map(str, words[v])) for v in sorted(full)], verified_pairs=full_size*(full_size-1)//2))
            if full_size >= 368:
                report['status'] = 'verified_improvement'
                break
        if (index-args.start+1) % 10000 == 0:
            print(json.dumps(dict(completed=index-args.start+1, best=report['best_full_size'], seconds=time.monotonic()-began)), flush=True)
            save()
    else:
        report['status'] = ('exhausted' if selected_groups is None else 'selection_complete') if args.start == 0 and end == total else 'range_complete'
    save()
    print(json.dumps(dict(status=report['status'], completed=len(report['rows']), total=total,
        pool=len(pool), alpha_histogram=report['alpha_histogram'], best_full_size=report['best_full_size'],
        candidates=len(report['candidates']), seconds=report['seconds'])), flush=True)


if __name__ == '__main__':
    main()
