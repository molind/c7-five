"""Finite controls for commutation with a previously covered d-word neighbor."""
import hashlib
import json
from pathlib import Path
import random


def main():
    assert __debug__
    rng=random.Random(2026092401);n,size,radius=9,4,3
    counts=dict(graphs=160,parents=0,targets=0,all_x_removed=0,critical=0,commuting=0,commuting_gains=0,strict_gains=0)
    distances={}
    for test in range(counts['graphs']):
        adj=[0]*n
        for i in range(n):
            for j in range(i):
                if rng.random()<(0.15,0.3,0.45,0.6)[test%4]:adj[i]|=1<<j;adj[j]|=1<<i
        def independent(m):return all(not (m&adj[i]) for i in range(n) if m>>i&1)
        states=[m for m in range(1<<n) if m.bit_count()==size and independent(m)]
        targets=[m for m in range(1<<n) if m.bit_count()>=size and independent(m)]
        for parent in states:
            for child in states:
                x,y=child&~parent,parent&~child;d=x.bit_count()
                if not 1<=d<=3:continue
                counts['parents']+=1;distances[d]=distances.get(d,0)+1
                conflicting_y=y
                for i in range(n):
                    if y>>i&1:conflicting_y|=adj[i]
                for t in targets:
                    if (child&~t).bit_count()>radius:continue
                    counts['targets']+=1
                    if not x&t:
                        assert (parent&~t).bit_count()<=radius
                        counts['all_x_removed']+=1;continue
                    added=t&~child
                    if added&conflicting_y:
                        counts['critical']+=1;continue
                    transformed=(t&~x)|y
                    assert independent(transformed)
                    assert transformed.bit_count()>=t.bit_count()
                    assert (parent&~transformed).bit_count()<=radius
                    if transformed.bit_count()==t.bit_count():
                        assert (transformed^t).bit_count()==2*d
                        assert x&t==x
                    else:counts['strict_gains']+=1
                    counts['commuting']+=1
                    counts['commuting_gains']+=transformed.bit_count()>size
    assert all(counts[k]>0 for k in counts) and set(distances)=={1,2,3}
    out=Path('research/c7/distant-parent-reduction-controls-sep22.json');assert not out.exists()
    d=dict(passed=True,checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),controls=counts,parent_distances=distances,vertices=n,size=size,radius=radius,scope='Constructional lemma only. If earlier P is fully covered at radius r and cache is closed through d, a new target from S must retain at least one word of X=S-P and insert a word conflicting with some Y=P-S. This artifact is not native C7 exhaustion.')
    out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))


if __name__=='__main__':main()
