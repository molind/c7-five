"""Check aligned-parent matchings, full completion domains and native witnesses.

Matching edges certify each saved parent-union upper bound. Native exhausted
statuses are bound to rebuilt graph inputs; this is not a second tree traversal.
"""
import argparse
import hashlib
from itertools import product
import json
from pathlib import Path

import numpy as np


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', required=True, type=Path)
    p.add_argument('--output', required=True, type=Path)
    args = p.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    data = json.loads(args.input.read_text())
    assert data['status'] in ('complete', 'verified_improvement')
    assert data['kernel_sha256'] == sha(Path(__file__).with_name('slice_clique'))
    words = np.array(list(product(range(7), repeat=5)), dtype=np.int16)
    def independent(ids):
        assert len(ids) == len(set(ids)) and all(type(v) is int and 0 <= v < 16807 for v in ids)
        array = words[ids]
        delta = (array[:, None, :]-array[None, :, :]) % 7
        assert not np.any(np.triu(np.all((delta == 0) | (delta == 1) | (delta == 6), axis=2), 1))
        return len(ids)*(len(ids)-1)//2
    alignments = {}
    checked_maps = 0
    for name, expected_hash in data['alignment_sources'].items():
        assert sha(name) == expected_hash
        alignment = json.loads(Path(name).read_text())
        assert sha(alignment['target']) == alignment['target_sha256'] and sha(alignment['source']) == alignment['source_sha256']
        target = sorted(int(w, 7) for w in Path(alignment['target']).read_text().split())
        source = [tuple(map(int, w)) for w in Path(alignment['source']).read_text().split()]
        assert len(target) == len(source) == 367
        independent(target)
        for alignment_index, row in enumerate(alignment['rows']):
            assert sorted(row['permutation']) == list(range(5)) and len(row['signs']) == len(row['shift']) == 5
            assert all(s in (-1, 1) for s in row['signs']) and all(type(t) is int and 0 <= t < 7 for t in row['shift'])
            image = sorted(sum(((row['signs'][j]*w[row['permutation'][j]]+row['shift'][j]) % 7)*7**(4-j) for j in range(5)) for w in source)
            independent(image)
            assert image == sorted(int(w, 7) for w in row['source_words'])
            common = set(target) & set(image)
            assert common == {int(w, 7) for w in row['common']} and len(common) == row['overlap']
            left, right = sorted(set(target)-set(image)), sorted(set(image)-set(target))
            pairs = row['matching']
            assert len({a for a,b in pairs}) == len({b for a,b in pairs}) == len(pairs)
            assert len(left) == row['left_size'] and len(right) == row['right_size']
            for a, b in pairs:
                assert type(a) is int and type(b) is int and 0 <= a < len(left) and 0 <= b < len(right)
                delta = (words[left[a]]-words[right[b]]) % 7
                assert np.all((delta == 0) | (delta == 1) | (delta == 6))
            upper = len(set(target) | set(image))-len(pairs)
            assert upper == row['union_optimum']
            if upper != 367:
                candidates = [c for c in alignment['candidates'] if c['step'] == alignment_index]
                assert len(candidates) == 1
                witness = sorted(int(t, 7) for t in candidates[0]['words'])
                independent(witness)
                assert len(witness) == upper == candidates[0]['size'] and set(witness) <= set(target) | set(image)
            checked_maps += 1
        alignments[name] = (alignment, set(target))
    rows = []
    full_sets = []
    for index, row in enumerate(data['rows']):
        alignment, target = alignments[row['alignment']]
        parent = alignment['rows'][row['alignment_index']]
        source = {int(w, 7) for w in parent['source_words']}
        common = target & source
        assert len(common) == row['common_size']
        released = row['released']
        assert len(released) == len(set(released)) and set(released) <= common
        assert len(released) in data['releases']
        fixed = sorted(common-set(released))
        assert fixed == row['fixed']
        free = []
        for begin in range(0, 16807, 128):
            delta = (words[begin:begin+128, None, :]-words[fixed][None, :, :]) % 7
            blocked = np.any(np.all((delta == 0) | (delta == 1) | (delta == 6), axis=2), axis=1)
            free.extend((begin+np.flatnonzero(~blocked)).tolist())
        assert free == row['pool'] and target-set(fixed) <= set(free) and source-set(fixed) <= set(free)
        assert [free[i] for i in row['hint']] == sorted(target-set(fixed))
        # Rebuild adjacency by coordinate-neighborhood enumeration, rather
        # than the searcher's pairwise difference matrix.
        lookup = {v:i for i,v in enumerate(free)}
        edges = set()
        for i,v in enumerate(free):
            for point in product(*[((int(x)-1) % 7, int(x), (int(x)+1) % 7) for x in words[v]]):
                neighbor = sum(x*7**(4-j) for j,x in enumerate(point))
                j = lookup.get(neighbor)
                if j is not None and i < j:
                    edges.add((i,j))
        assert len(row['edges']) == len(edges) and set(map(tuple, row['edges'])) == edges
        result = row['result']
        assert result['status'] in ('exhausted', 'timeout', 'target_found')
        chosen = result['vertices']
        assert len(chosen) == len(set(chosen)) == result['best_size']
        assert all(type(v) is int and 0 <= v < len(free) for v in chosen)
        full = sorted(set(fixed) | {free[i] for i in chosen})
        assert independent(full) == row['direct_witness_pairs']
        assert len(full) == row['full_size'] and row['target'] == 368-len(fixed)
        assert (result['status'] == 'target_found') == (len(full) >= 368)
        full_sets.append(full)
        rows.append(dict(index=index, fixed=len(fixed), pool=len(free), edges=len(edges),
                         native_status=result['status'], full_size=len(full)))
    for candidate in data['candidates']:
        assert sorted(int(w, 7) for w in candidate['words']) == full_sets[candidate['step']]
        assert candidate['size'] == len(full_sets[candidate['step']])
    report = dict(input_sha256=sha(args.input), checker_sha256=sha(__file__), kernel_sha256=data['kernel_sha256'],
                  exact_aligned_parent_union_certificates=checked_maps, rows=rows,
                  reconstructed_domains=len(rows), scope='Every saved alignment and domain verified; matching proves parent-union optimum367. Native completion bounds retain kernel trust; timeouts remain open.')
    args.output.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(dict(alignments=checked_maps, domains=len(rows))), flush=True)


if __name__ == '__main__':
    main()
