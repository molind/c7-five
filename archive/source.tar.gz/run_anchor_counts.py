"""Bounded same-input ablation or d7 search with verified outside-U2 counts."""
from pathlib import Path
import json,subprocess,sys,time,hashlib
p=Path(__file__).parent;radius=int(sys.argv[1]);variant=sys.argv[2]
assert radius in [6,7] and variant in ['off','base','tight']
limit=int(sys.argv[3]) if len(sys.argv)>3 else (60 if radius==6 else 180)
assert 1<=limit<=180
kind='base' if variant=='off' else variant
input_path=p/f'anchor-count-{kind}-d{radius}.txt'
output=p/f'anchor-count-{variant}-d{radius}-result.json';assert not output.exists(),'Preserve prior results'
cmd=[str((p/'exchange_dfs').resolve()),str(limit),'--subset','--root-prefix','13375','--noncore-limit','308',str(radius-4)]
if variant!='off':cmd+=['--anchor-bounds','13375']
began=time.monotonic()
with input_path.open() as f:
    try:
        r=subprocess.run(cmd,stdin=f,text=True,capture_output=True,check=True,timeout=limit+15)
        result=json.loads(r.stdout)
    except subprocess.TimeoutExpired:result={'status':'parent_timeout'}
result.update(radius=radius,variant=variant,internal_limit=limit,parent_limit=limit+15,wall_seconds=time.monotonic()-began,input_sha256=hashlib.sha256(input_path.read_bytes()).hexdigest(),source_sha256=hashlib.sha256((p/'exchange_dfs.cpp').read_bytes()).hexdigest())
output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
