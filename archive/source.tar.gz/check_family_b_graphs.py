"""Check all serialized Family-B graphs using coordinate-mask intersections."""
import argparse
import hashlib
from itertools import product
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
if not __debug__:
    raise RuntimeError('Run without -O')
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('variant', nargs='?', choices=('seed', 'farthest'), default='seed')
variant = parser.parse_args().variant
prefix = f'family-b-{variant}'
tokens = (HERE/f'{prefix}-words.txt').read_text().split()
assert hashlib.sha256(' '.join(tokens).encode()).hexdigest() == {
    'seed': 'ab9029e1f7074e0c40d3468b2a02d11717498386474194126b2362eb1d1d85ea',
    'farthest': '0964b6078b5132368ecf183f9eb72e8222043721747b3a9766055033bae80d81'}[variant]
seed = [tuple(map(int, w)) for w in tokens]
occupied = set(seed)
coordinates = [[0]*7 for _ in range(5)]
for i, w in enumerate(seed):
    for k, x in enumerate(w):
        coordinates[k][x] |= 1 << i
all_candidates = []
for w in product(range(7), repeat=5):
    if w in occupied:
        continue
    blockers = (1 << 367)-1
    for k, x in enumerate(w):
        blockers &= coordinates[k][(x-1)%7] | coordinates[k][x] | coordinates[k][(x+1)%7]
    all_candidates.append((w, blockers))
assert all(b for _, b in all_candidates), 'Seed admits a free insertion'
rows = []
for radius in range(1, 7):
    pool = sorted((p for p in all_candidates if p[1].bit_count() <= radius),
                  key=lambda p:p[1].bit_count())
    pc = [[0]*7 for _ in range(5)]
    for i, (w, _) in enumerate(pool):
        for k, x in enumerate(w):
            pc[k][x] |= 1 << i
    full = (1 << len(pool))-1
    path = HERE/f'{prefix}-d{radius}.txt'
    with path.open() as f:
        assert list(map(int, f.readline().split())) == [len(pool), 6, radius]
        for w, blockers in pool:
            values = [int(x, 16) for x in f.readline().split()]
            assert len(values) == 6+(len(pool)+63)//64
            assert sum(v << (64*j) for j,v in enumerate(values[:6])) == blockers
            conflicts = full
            for k, x in enumerate(w):
                conflicts &= pc[k][(x-1)%7] | pc[k][x] | pc[k][(x+1)%7]
            actual = sum(v << (64*j) for j,v in enumerate(values[6:]))
            assert actual == full ^ conflicts
        assert not f.read().strip()
    rows.append(dict(radius=radius, checked_rows=len(pool),
                     graph_sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
report = dict(variant=variant, method='Full coordinate-mask reconstruction, compared every blocker and compatibility bit',
              seed_maximal=True, rows=rows)
output = 'family-b-graph-verification.json' if variant == 'seed' else 'family-b-farthest-graph-verification.json'
(HERE/output).write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report))
