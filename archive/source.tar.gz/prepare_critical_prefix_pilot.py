"""Export rooted F state5 for a critical-first insertion DFS experiment.

The known complete F8 component and root10 transfer justify the same frozen
words, atomic pair restriction, and root-blocker cap used by the group scanner.
This is a benchmark input; its existence alone certifies no search interval.
"""
import gzip
import hashlib
import json
from itertools import product
from pathlib import Path

import numpy as np


def main():
    assert __debug__
    r = Path('research/c7')
    output = r / 'component-F-state5-critical-prefix-input-sep22.json'
    graph = r / 'component-F-state5-critical-prefix-input-sep22.txt'
    assert not output.exists() and not graph.exists()
    sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
    dependencies = {}
    def read(p):
        dependencies[str(p)] = sha(p)
        return json.loads(Path(p).read_text())
    audited = read(r / 'component-F-incremental9-joint-count-prefix-sep22.json')
    assert audited['next_state'] == 6 and not audited['outside']
    assert all(sha(p) == h for p, h in audited['dependencies'].items())
    transfer = read(r / 'component-F-root10-transfer-verification-sep22.json')
    manifest = read(r / 'component-F-rooted8-sep22-input.json')
    assert sha(manifest['source']) == manifest['source_sha256']
    dependencies[manifest['source']] = sha(manifest['source'])
    with gzip.open(manifest['source'], 'rt') as f:
        next(f)
        states = [set(json.loads(s)) for s in f]
    index, radius = 5, 9
    state, root = states[index], states[0]
    assert len(state - root) == len(root - state) == 1
    old = sorted(state)
    frozen, parents = set(), []
    for j, other in enumerate(states[:index]):
        if len(state - other) == len(other - state) == 1:
            frozen |= state - other
            parents.append((j, next(iter(other - state))))
    assert len(parents) == 1 and parents[0][0] == 0
    coords = np.array(list(product(range(7), repeat=5)), dtype=np.int16)
    def conflicts(a, b):
        d = (coords[np.asarray(a)[:, None]] - coords[np.asarray(b)[None, :]]) % 7
        return np.all((d == 0) | (d == 1) | (d == 6), axis=2)
    bad = conflicts(list(range(16807)), old)
    degree = bad.sum(axis=1)
    root_degree = conflicts(list(range(16807)), sorted(root)).sum(axis=1)
    pool = (degree >= 2) & (degree <= radius) & (root_degree < 5)
    pool[old] = False
    pool &= ~np.any(bad[:, [old.index(x) for x in frozen]], axis=1)
    ids = np.flatnonzero(pool)
    y = parents[0][1]
    critical = {int(v) for v in ids[conflicts(ids, [y])[:, 0]]}
    ordered = sorted(map(int, ids), key=lambda v: (v not in critical, int(degree[v]), v))
    assert len(ordered) == 4754 and len(critical) == 30
    blocker_masks = [int.from_bytes(b.tobytes(), 'little') for b in np.packbits(bad[ordered], axis=1, bitorder='little')]
    tuples = [tuple(map(int, coords[v])) for v in ordered]
    positions = {v: i for i, v in enumerate(tuples)}
    same_pair = {}
    for i, mask in enumerate(blocker_masks):
        if mask.bit_count() == 2:
            same_pair.setdefault(mask, []).append(i)
    n, prefix = len(ordered), len(critical)
    full, mask64 = (1 << n) - 1, (1 << 64) - 1
    with graph.open('w') as f:
        f.write(f'{n} 6 {radius}\n')
        for i, v in enumerate(tuples):
            excluded = 0
            for neighbor in product(*[((x - 1) % 7, x, (x + 1) % 7) for x in v]):
                j = positions.get(neighbor)
                if j is not None:
                    excluded |= 1 << j
            # Such a pair is a reducible proper subset of a nine-word atom.
            for j in same_pair.get(blocker_masks[i], ()):
                excluded |= 1 << j
            allowed = full ^ excluded
            words = [(blocker_masks[i] >> (64 * j)) & mask64 for j in range(6)]
            words += [(allowed >> (64 * j)) & mask64 for j in range((n + 63) // 64)]
            f.write(' '.join(f'{x:x}' for x in words) + '\n')
    record = dict(status='complete', source_sha256=sha(__file__), dependencies=dependencies,
                  manifest='research/c7/component-F-rooted8-sep22-input.json', state=index,
                  old=old, root=sorted(root), radius=radius, frozen=sorted(frozen), parents=parents,
                  pool=ordered, blockers=blocker_masks, prefix=prefix, graph=str(graph), graph_sha256=sha(graph),
                  scope=__doc__)
    output.write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(dict(pool=n, prefix=prefix, graph_bytes=graph.stat().st_size)))


if __name__ == '__main__':
    main()
