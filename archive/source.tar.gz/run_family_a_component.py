"""Bounded d6 runs for specified, already reconstructed Family-A states."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
SOURCE = HERE/'exchange_dfs_before_core_bound.cpp'
KERNEL_SHA = '26d11e97d747660c8544835ed59bc4800d9775ef4ae1ab6df22f927b01d25337'
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == KERNEL_SHA
component = json.loads((HERE/'family-a-component.json').read_text())
indices = list(map(int, sys.argv[1:]))
assert indices and len(indices) == len(set(indices)) and all(2 <= i <= 6 for i in indices)
for i in indices:
    row = component['states'][i]
    assert row['state'] == i
    graph = HERE/f'family-a-state-{i}-d6.txt'
    with graph.open('w') as out:
        subprocess.run([sys.executable, str(HERE/'export_exchange_graph.py'),
                        row['words_file'], row['sha256'], '6'],
                       stdout=out, timeout=45, check=True)
    start = time.monotonic()
    with graph.open() as inp:
        run = subprocess.run([str(HERE/'exchange_dfs_published_subset'), '120', '--subset'],
                             stdin=inp, capture_output=True, text=True, timeout=135, check=True)
    result = json.loads(run.stdout)
    with graph.open() as inp:
        candidates = int(inp.readline().split()[0])
    result.update(state=i, input_sha256=row['sha256'], kernel_sha256=KERNEL_SHA,
                  candidates=candidates, parent_wall_seconds=time.monotonic()-start,
                  search_limit=120, parent_limit=135)
    (HERE/f'family-a-state-{i}-d6-result.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result), flush=True)
    if result['status'] != 'exhausted':
        raise SystemExit('Incomplete exclusion: retain the explicit status above')
