"""Recombine published seven-family profiles in different downstream roles.

Use all eight published ternary rules, every input order/orientation, and
coordinate ascent over four independently chosen 125-dimensional profiles.
All comparisons are exact. This is a finite heuristic search, not exhaustive
over all four-tuples or over all possible constructions.
"""

import argparse
import itertools
import json
import math
import random
import time

from search_terminal import LABELS, ROOT, load_inputs, verify_code


def make_profiles(bpz, claims):
    inputs = [(key, tuple(claims["cardinality_vectors"][key]))
              for key in ("eq119_n6", "eq142_n11", "eq127_n8")]
    profiles = {}
    for order in itertools.permutations(range(3)):
        for flips in itertools.product((False, True), repeat=3):
            vectors = [bpz.sigma_vector(inputs[j][1]) if flips[i] else inputs[j][1]
                       for i, j in enumerate(order)]
            for name, rule in bpz.RULES.items():
                if not name.startswith("S3"):
                    continue
                vector = bpz.apply_rule(rule, vectors)
                desc = {"rule": name, "ordered_inputs": [inputs[j][0] for j in order],
                        "input_orientation_flips": flips}
                for flip_output in (False, True):
                    v = bpz.sigma_vector(vector) if flip_output else vector
                    profiles.setdefault(v, {**desc, "output_orientation_flip": flip_output})
    return list(profiles), list(profiles.values())


def coefficients(code, inputs, coordinate):
    out = [0] * 7
    for word in code:
        out[LABELS.index(word[coordinate])] += math.prod(
            inputs[j][LABELS.index(c)] for j, c in enumerate(word) if j != coordinate)
    return out


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--starts", type=int, default=40)
    parser.add_argument("--seed", type=int, default=20260915)
    args = parser.parse_args()
    bpz, claims, baseline_profile = load_inputs()
    profiles, recipes = make_profiles(bpz, claims)
    baseline = claims["code_sizes"]["eq164_Mstar_appendix"]
    assert tuple(baseline_profile) in profiles
    for rule in bpz.RULES.values():
        assert not bpz.rule_problems(rule)
    rng = random.Random(args.seed)
    began = time.monotonic()
    best = baseline
    winner = None
    runs = []
    for name in ("K4a", "K4b"):
        code = bpz.CODES[name]
        homogeneous = [verify_code(code, [p] * 4) for p in profiles]
        highest = max(range(len(profiles)), key=lambda i: homogeneous[i])
        starts = [[profiles.index(tuple(baseline_profile))] * 4, [highest] * 4]
        starts += [[rng.randrange(len(profiles)) for _ in range(4)]
                   for _ in range(args.starts)]
        for start in starts:
            chosen = start[:]
            value = verify_code(code, [profiles[i] for i in chosen])
            iterations = 0
            while True:
                changed = False
                coordinates = list(range(4))
                rng.shuffle(coordinates)
                for coordinate in coordinates:
                    coeff = coefficients(code, [profiles[i] for i in chosen], coordinate)
                    values = [sum(a*b for a,b in zip(coeff,p)) for p in profiles]
                    next_id = max(range(len(profiles)), key=values.__getitem__)
                    if values[next_id] > value:
                        chosen[coordinate] = next_id
                        value = values[next_id]
                        changed = True
                iterations += 1
                if not changed:
                    break
            assert value == verify_code(code, [profiles[i] for i in chosen])
            runs.append({"code": name, "start": start, "final": chosen,
                         "iterations": iterations, "cardinality": value})
            if value > best:
                best = value
                winner = {"terminal_code": code, "profiles": [profiles[i] for i in chosen],
                          "recipes": [recipes[i] for i in chosen], "cardinality": value}
                print(json.dumps({"improvement": True, "terminal": name,
                                  "ratio_to_baseline": value / baseline}), flush=True)
    report = {"source": "https://arxiv.org/html/2608.30273",
              "dimension": 500, "seed": args.seed, "unique_profiles": len(profiles),
              "best_cardinality": best, "baseline_cardinality": baseline,
              "improvement": winner, "runs": runs,
              "elapsed_seconds": time.monotonic()-began}
    (ROOT/"composition-results.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps({"unique_profiles": len(profiles), "runs": len(runs),
                      "improved": winner is not None,
                      "elapsed_seconds": report["elapsed_seconds"]}))


if __name__ == "__main__":
    main()
