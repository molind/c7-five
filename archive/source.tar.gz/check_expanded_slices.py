"""Replay a four-slice pilot, its imported exclusions and returned witnesses."""
import argparse
import hashlib
from itertools import combinations
import json
from pathlib import Path

from check_two_slice_covers import HERE, WORDS, closed, conflict
from check_cylinder_covers import check_entries
from probe_rank_branches import CAPACITIES
from search_sparse_cylinders import prepare, check_solution


def verify_candidates(report, fixed, pool):
    candidates = []
    for candidate in report['candidates']:
        words = [int(w, 7) for w in candidate['words']]
        assert len(words) == len(set(words)) == candidate['size'] >= 367
        assert fixed <= set(words) <= fixed|set(pool)
        assert all(not conflict(a,b) for a,b in combinations(words,2))
        assert candidate['verified_pairs'] == len(words)*(len(words)-1)//2
        if candidate['phase'] == 'learned':
            assert all(not set(cut['vertices']) <= set(words) for cut in report['learned_cuts'])
        candidates.append(dict(size=len(words),phase=candidate['phase'],verified_pairs=candidate['verified_pairs']))
    return candidates


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    report = json.loads(args.input.read_text())
    assert report['status'] in ('bounded_search_complete', 'candidate_found')
    assert report['full_target'] == 368 and report['width'] == 4
    seed = {int(w, 7) for w in (HERE/'family-d-seed-words.txt').read_text().split()}
    fixed = {v for v in seed if (WORDS[v][report['axis']]-report['start']) % 7 >= 4}
    assert sorted(fixed) == report['fixed']
    pool = sorted(set(range(7**5))-set().union(*(closed(v) for v in fixed)))
    assert pool == report['pool'] == report['root']['pool']
    total, den = check_entries(report['root']['certificate'], pool, CAPACITIES)
    assert report['root']['full_upper'] == len(fixed)+total//den
    candidates = verify_candidates(report, fixed, pool)
    found = any(c['size'] >= 368 for c in candidates)
    assert (report['status'] == 'candidate_found') == found
    result = dict(input_sha256=hashlib.sha256(args.input.read_bytes()).hexdigest(), fixed=len(fixed),pool=len(pool),
                  exact_cover_full_upper=len(fixed)+total//den, candidates=candidates,
                  target_witness_found=found, source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    if 'model' not in report:
        assert found and not report['searches'] and not report['learned_cuts']
        assert all(c['phase'] == 'root' for c in candidates)
        args.output.write_text(json.dumps(result,indent=2)+'\n')
        print(json.dumps(result),flush=True)
        return
    source = report['root'] | dict(axis=report['axis'], start=report['start'], width=4,
                                  fixed=sorted(fixed), capacity_sequence=CAPACITIES)
    model = json.loads(json.dumps(prepare(source)))
    assert model == report['model']
    local = {v:i for i,v in enumerate(pool)}
    learned = json.loads(json.dumps(model))
    imported = set()
    for cut in report['learned_cuts']:
        path = Path(cut['file'])
        assert path not in imported and hashlib.sha256(path.read_bytes()).hexdigest() == cut['sha256']
        imported.add(path)
        old = json.loads(path.read_text())
        assert old['status'] == 0 and old['width'] == 3 and not old.get('published_cube_dependency')
        old_fixed = {v for v in seed if (WORDS[v][old['axis']]-old['start']) % 7 >= 3}
        old_pool = sorted(set(range(7**5))-set().union(*(closed(v) for v in old_fixed)))
        assert sorted(old_fixed) == old['fixed'] and old_pool == old['pool']
        cost, scale = check_entries(old['certificate'], old_pool, CAPACITIES)
        assert cost < (368-len(old_fixed))*scale
        assert cut['total_units'] == cost and cut['denominator'] == scale and cut['old_fixed_size'] == len(old_fixed)
        vertices = sorted(old_fixed-fixed)
        assert cut['vertices'] == vertices and vertices and set(vertices) <= set(pool)
        assert cut['capacity'] == len(vertices)-1
        learned['members'].append([local[v] for v in vertices])
        learned['capacities'].append(len(vertices)-1)
    removed = report['learned_hint_removed']
    assert len(removed) == len(set(removed)) and set(removed) <= seed-fixed
    learned['hint'] = sorted(set(model['hint'])-{local[v] for v in removed})
    assert report['learned_start_size'] == len(fixed)+len(learned['hint'])
    assert report['original_start_size'] == len(fixed)+len(model['hint']) == 367
    hint = set(learned['hint'])
    assert all(len(hint & set(row)) <= cap for row,cap in zip(learned['members'], learned['capacities']))
    variants = set()
    for query in report['searches']:
        name, query_result = query['variant'], query['result']
        assert name in ('original','learned') and name not in variants
        variants.add(name)
        assert query_result['target'] == 368-len(fixed)
        check_solution(model if name == 'original' else learned, query_result)
    assert report['status'] != 'bounded_search_complete' or variants == {'original','learned'}
    result.update(imported_exclusions=len(imported), preserved_conflict_edges=model['stats']['conflict_edges'])
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result),flush=True)


if __name__ == '__main__':
    main()
