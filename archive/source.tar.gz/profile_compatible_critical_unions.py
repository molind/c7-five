"""Bounded exact covers of critical conditions by compatible atomic insertions.

An unfinished cover enumeration never supplies an exclusion. Dominance is used
only for completed covers, not for partial choices with different compatibility.
These are conditional profiles, not a gap-free scan of the component.
"""
import gzip
import hashlib
import json
import random
import time
from itertools import product
from pathlib import Path

import numpy as np
from profile_joint_critical_unions import minimal


def covers(blockers, flags, compatible, nconditions, radius, limit=300000, seconds=60):
    allflags = (1 << nconditions) - 1
    clauses = [[i for i, f in enumerate(flags) if f >> j & 1] for j in range(nconditions)]
    answers = {}
    seen = set()
    started = time.monotonic()
    complete = True
    nodes = 0

    def visit(selected, covered, union, subsets):
        nonlocal complete, nodes
        if not complete:
            return
        key = tuple(sorted(selected))
        if key in seen:
            return
        seen.add(key)
        nodes += 1
        if nodes > limit or (nodes % 1024 == 0 and time.monotonic() - started > seconds):
            complete = False
            return
        # A completed smaller cover is sufficient for the upward-closed result.
        if any(a & union == a for a in answers):
            return
        if covered == allflags:
            for old in list(answers):
                if old & union == union:
                    del answers[old]
            answers[union] = key
            return
        options = None
        for j, clause in enumerate(clauses):
            if covered >> j & 1:
                continue
            possible = [i for i in clause if (union | blockers[i]).bit_count() <= radius
                        and all(compatible[i][k] for k in selected)]
            if not possible:
                return
            if options is None or len(possible) < len(options):
                options = possible
        for i in options:
            added = [(u | blockers[i], n + 1) for u, n in subsets]
            if any(n < radius and u.bit_count() <= n for u, n in added):
                continue
            visit(selected + (i,), covered | flags[i], union | blockers[i], subsets + added)
            if not complete:
                return

    visit((), 0, 0, [(0, 0)])
    return dict(complete=complete, nodes=nodes, seconds=time.monotonic() - started,
                supports=answers if complete else {})


def controls():
    rng = random.Random(20260922017)
    subsets_checked = 0
    for test in range(250):
        n, old, radius, conditions = 3 + test % 7, 4 + test % 5, 2 + test % 4, test % 5
        blockers = [sum(1 << x for x in rng.sample(range(old), rng.randint(2, min(old, radius)))) for _ in range(n)]
        flags = [rng.randrange(1 << conditions) for _ in range(n)]
        comp = [[False] * n for _ in range(n)]
        for i in range(n):
            for j in range(i):
                comp[i][j] = comp[j][i] = rng.random() < .7
        expected = []
        for mask in range(1 << n):
            subsets_checked += 1
            selected = [i for i in range(n) if mask >> i & 1]
            union, covered = 0, 0
            for i in selected:
                union |= blockers[i]
                covered |= flags[i]
            if union.bit_count() > radius or covered != (1 << conditions) - 1:
                continue
            if any(not comp[i][j] for i in selected for j in selected if i < j):
                continue
            good = True
            for subset in range(1, 1 << len(selected)):
                if subset.bit_count() >= radius:
                    continue
                u = 0
                for j, i in enumerate(selected):
                    if subset >> j & 1:
                        u |= blockers[i]
                if u.bit_count() <= subset.bit_count():
                    good = False
                    break
            if good:
                expected.append(union)
        found = covers(blockers, flags, comp, conditions, radius)
        assert found['complete'] and set(found['supports']) == set(minimal(expected)), test
        limited = covers(blockers, flags, comp, conditions, radius, limit=0)
        assert not limited['complete'] and not limited['supports']
    return dict(cases=250, subsets=subsets_checked, limited_cases=250)


def main():
    assert __debug__
    here = Path('research/c7')
    output = here / 'compatible-critical-union-profile-sep22.json'
    assert not output.exists()
    sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
    profile_path = here / 'joint-critical-union-profile-sep22.json'
    profile = json.loads(profile_path.read_text())
    dependencies = {str(profile_path): sha(profile_path)}
    assert all(sha(p) == h for p, h in profile['dependencies'].items())
    dependencies.update(profile['dependencies'])
    result = dict(status='running', source_sha256=sha(__file__), dependencies=dependencies,
                  controls=controls(), rows=[], candidates=[],
                  scope=__doc__)
    output.write_text(json.dumps(result, indent=2) + '\n')
    coords = np.array(list(product(range(7), repeat=5)), dtype=np.int16)
    loaded = {}
    for record in profile['rows']:
        name, index, radius = record['manifest'], record['state'], record['radius']
        if name not in loaded:
            m = json.loads((here / name).read_text())
            with gzip.open(m['source'], 'rt') as f:
                next(f)
                loaded[name] = [set(json.loads(line)) for line in f]
        states = loaded[name]
        state, frozen, parents = states[index], set(), []
        old = sorted(state)
        for j, other in enumerate(states[:index]):
            if len(state - other) == len(other - state) == 1:
                x, = state - other
                y, = other - state
                frozen.add(x)
                parents.append((j, y))
        delta = (coords[:, None, :] - coords[np.array(old)[None, :], :]) % 7
        bad = np.all((delta == 0) | (delta == 1) | (delta == 6), axis=2)
        degree = bad.sum(axis=1)
        chosen = np.zeros(16807, dtype=bool)
        chosen[old] = True
        pool = (degree >= 2) & (degree <= radius) & ~chosen
        if frozen:
            pool &= ~np.any(bad[:, [old.index(x) for x in frozen]], axis=1)
        ids = np.flatnonzero(pool)
        assert len(ids) == record['pool']
        flags = [0] * len(ids)
        for j, (_, y) in enumerate(parents):
            diff = (coords[ids] - coords[y]) % 7
            for i in np.flatnonzero(np.all((diff == 0) | (diff == 1) | (diff == 6), axis=1)):
                flags[int(i)] |= 1 << j
        useful = [i for i, f in enumerate(flags) if f]
        ids = ids[useful]
        flags = [flags[i] for i in useful]
        blockers = [int.from_bytes(row.tobytes(), 'little') for row in np.packbits(bad[ids], axis=1, bitorder='little')]
        diff = (coords[ids, None, :] - coords[ids[None, :], :]) % 7
        comp = ~np.all((diff == 0) | (diff == 1) | (diff == 6), axis=2)
        found = covers(blockers, flags, comp, len(parents), radius)
        supports = found.pop('supports')
        row = dict(manifest=name, state=index, radius=radius, useful_candidates=len(ids),
                   conditions=len(parents), relaxed_minimal=record['joint_minimal'], **found)
        if found['complete']:
            row.update(compatible_minimal=len(supports), minimum_size=min(map(int.bit_count, supports), default=None),
                       supports=[dict(removed=[old[i] for i in range(367) if union >> i & 1],
                                      inserted=[int(ids[i]) for i in selected]) for union, selected in sorted(supports.items())])
            for union, selected in supports.items():
                if len(selected) >= union.bit_count():
                    words = sorted((state - {old[i] for i in range(367) if union >> i & 1}) | {int(ids[i]) for i in selected})
                    d = (coords[words, None, :] - coords[np.array(words)[None, :], :]) % 7
                    conflicts = np.all((d == 0) | (d == 1) | (d == 6), axis=2)
                    assert np.array_equal(conflicts, np.eye(len(words), dtype=bool))
                    result['candidates'].append(dict(manifest=name, state=index, words=words,
                                                     size=len(words), known=set(words) in states,
                                                     pair_checks=len(words) * (len(words) - 1) // 2))
        result['rows'].append(row)
        output.write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps({k: v for k, v in row.items() if k != 'supports'}), flush=True)
    result['status'] = 'complete'
    output.write_text(json.dumps(result, indent=2) + '\n')


if __name__ == '__main__':
    main()
