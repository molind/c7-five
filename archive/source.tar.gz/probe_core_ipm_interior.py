"""Probe IPM interior solutions without crossover on a fixed solved node list."""
import argparse
import json
from pathlib import Path

import numpy as np

from check_two_slice_covers import closed
from search_core_radius_cut import sha
from search_core_ipm_branches_v2 import propagate
from solve_core_radius_ipm import load_radius_model, model_digest
import time
from scipy.optimize._highspy import _core as high
from solve_core_radius_ipm import build_model


def solve_node(matrix, lower, upper, variable_lo, variable_hi, seconds, basis=None):
    solver = high._Highs()
    for key, value in dict(output_flag=False, solver="ipm", run_crossover="off", time_limit=float(seconds)).items():
        assert solver.setOptionValue(key, value) == high.HighsStatus.kOk
    model = build_model(matrix, lower, upper, variable_hi, False)
    model.col_lower_ = variable_lo
    assert solver.passModel(model) == high.HighsStatus.kOk
    start = time.monotonic();solver.run();elapsed = time.monotonic()-start
    info, solution = solver.getInfo(), solver.getSolution()
    record = dict(status=solver.modelStatusToString(solver.getModelStatus()), seconds=elapsed, objective=info.objective_function_value, ipm_iterations=info.ipm_iteration_count, crossover=False)
    values = None
    if solution.value_valid and info.primal_solution_status == high.kSolutionStatusFeasible:
        values = np.asarray(solution.col_value)
        assert np.all(values >= variable_lo-1e-6) and np.all(values <= variable_hi+1e-6)
        assert np.all(matrix@values >= lower-1e-6) and np.all(matrix@values <= upper+1e-6)
        assert abs(sum(values)+info.objective_function_value)<1e-5
        record["fractional_variables"] = int(np.count_nonzero(np.abs(values-np.rint(values))>1e-6))
    return record, values, None


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--tree', type=Path, required=True)
    p.add_argument('--nodes', type=int, default=12)
    p.add_argument('--seconds', type=float, default=10)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    assert __debug__ and not args.output.exists() and args.nodes > 0 and args.seconds > 0
    tree = json.loads(args.tree.read_text())
    assert tree['status'] == 'bounded_attempt_complete'
    assert all(sha(f) == h for f, h in tree['dependencies'].items())
    data, matrix, lower, upper, variable_upper, initial = load_radius_model(Path(tree['input']), tree['radius'])
    lower[-3] = data['target']
    assert model_digest(matrix, lower, upper, variable_upper) == tree['target_model_sha256']
    pool, old = set(data['pool']), set(data['parent_words']) - set(data['fixed'])
    neighborhoods = {v: closed(v) & pool for v in pool}
    positions = {v: i for i, v in enumerate(data['pool'])}
    out = dict(status='running', tree=str(args.tree), source_sha256=sha(__file__),
               dependencies={str(args.tree): sha(args.tree)}, rows=[])
    for name in ('solve_core_radius_ipm.py', 'search_core_ipm_branches_v2.py'):
        path = Path(__file__).with_name(name)
        out['dependencies'][str(path)] = sha(path)
    basis = None
    for index, node in enumerate(tree['rows'][:args.nodes]):
        forbidden = propagate(pool, old, neighborhoods, node['inside'], node['outside'], tree['radius'])
        assert forbidden is not None
        variable_lo, variable_hi = np.zeros(len(pool)), variable_upper.copy()
        for v in node['inside']:
            variable_lo[positions[v]] = 1
        for v in forbidden:
            variable_hi[positions[v]] = 0
        row, values, basis = solve_node(matrix, lower, upper, variable_lo, variable_hi, args.seconds, basis)
        row.update(node=index, previous_status=node['status'], previous_seconds=node['seconds'],
                   same_numerical_status=row['status'] == node['status'])
        out['rows'].append(row)
        args.output.write_text(json.dumps(out, indent=2) + '\n')
        print(row, flush=True)
    out['status'] = 'complete_attempt'
    args.output.write_text(json.dumps(out, indent=2) + '\n')


if __name__ == '__main__':
    main()
