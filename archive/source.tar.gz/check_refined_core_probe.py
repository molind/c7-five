"""Direct numerical checks of probe points using all torus boxes.

This reconstructs every2x2x2x2x2 box by array shifts, without the solver's sparse
matrix builder. It verifies diagnostic fractional points, not integer solutions.
"""
import argparse
import hashlib
from itertools import product
import json
from pathlib import Path

import numpy as np


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--search', type=Path, required=True)
    p.add_argument('--cuts', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    assert __debug__ and not args.output.exists()
    run, cuts = json.loads(args.search.read_text()), json.loads(args.cuts.read_text())
    assert run['status'] == 'complete_attempt'
    assert all(sha(f) == h for f, h in run['dependencies'].items())
    assert run['dependencies'][str(args.cuts)] == sha(args.cuts)
    assert run['original_model_sha256'] == cuts['target_model_sha256']
    data = json.loads(Path(run['input']).read_text())
    tree = json.loads(Path(cuts['clauses'][0]['tree']).read_text())
    first_path = Path(tree['subtree_cuts'])
    first = json.loads(first_path.read_text())
    assert run['dependencies'][str(first_path)] == sha(first_path)
    core = json.loads(Path(tree['common_core_base']).read_text())['fixed']
    exclusion = json.loads(Path(tree['domain_exclusion']).read_text())
    positions = {v: j for j, v in enumerate(data['pool'])}
    fixed, old = set(data['fixed']), set(data['parent_words'])-set(data['fixed'])
    m = len(old)
    prior_radius = next(r for r in data['rows'] if r['radius'] == run['radius'])
    results = []
    for label in ('before', 'after'):
        x = np.array(run[label]['values'])
        assert x.shape == (len(positions),) and np.all(np.isfinite(x))
        values = np.zeros(16807)
        values[data['pool']] = x
        values[list(fixed)] = 1
        grid = values.reshape((7,)*5)
        boxes = np.zeros_like(grid)
        for offsets in product((0, 1), repeat=5):
            boxes += np.roll(grid, tuple(-v for v in offsets), axis=(0, 1, 2, 3, 4))
        free, retained = float(x.sum()), float(values[list(old)].sum())
        violation = max(0, float(-x.min()), float(x.max()-1), float(boxes.max()-1),
                        abs(free-data['target']), m-run['radius']-retained, retained-m,
                        retained+10*free-11*m, float(values[core].sum()-311),
                        float(values[exclusion['inside']].sum()-exclusion['inequality_upper']))
        if prior_radius['excluded_words']:
            violation = max(violation, float(values[prior_radius['excluded_words']].max()))
        for clause in first['clauses']:
            violation = max(violation, float(values[clause['inside']].sum()-values[clause['outside']].sum()-(len(clause['inside'])-1)))
        assert violation < 1e-6 and abs(values.sum()-368) < 1e-6
        clause_violations = [float(values[c['inside']].sum()-values[c['outside']].sum()-(len(c['inside'])-1))
                             for c in cuts['clauses']]
        if label == 'before':
            assert clause_violations[0] > 0.99
        else:
            assert max(clause_violations) < 1e-6
        results.append(dict(phase=label, boxes_checked=16807,
                            maximum_original_violation=violation,
                            first_clause_violation=clause_violations[0],
                            maximum_added_clause_violation=max(clause_violations)))
    out = dict(passed=True, rows=results, clauses=len(cuts['clauses']),
               checker_sha256=sha(__file__),
               dependencies={str(p): sha(p) for p in (args.search, args.cuts, first_path, Path(run['input']))},
               scope='Numerical fractional-point verification, residual tolerance1e-6. The first valid cut removes a feasible fractional point; no construction or infeasibility proof.')
    args.output.write_text(json.dumps(out, indent=2) + '\n')
    print({k: v for k, v in out.items() if k not in ('dependencies', 'scope')})


if __name__ == '__main__':
    main()
