"""Replay arbitrary additions with coordinate neighborhoods and exhaustive subsets."""
import argparse
from itertools import combinations
import json
from pathlib import Path

from check_two_slice_covers import closed,conflict
from direct_slice_neighbors import sha


def main():
    if not __debug__:raise RuntimeError('Run without -O')
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True)
    p.add_argument('--original',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args()
    if args.output.exists():raise FileExistsError(args.output)
    source=json.loads(args.input.read_text());assert source['input_sha256']==sha(args.original) and source['status']=='complete'
    originals=[json.loads(x)for x in args.original.read_text().splitlines()]
    assert len(originals)==len(source['results'])
    subsets=0;expected=set();maximum_pool=0;counts={}
    for original,row in zip(originals,source['results'],strict=True):
        assert row['root']==original['root'] and row['fixed_size']==len(original['words'])==original['best']
        fixed=set(original['words']);forbidden=set()
        for v in fixed:forbidden.update(closed(v))
        pool=sorted(set(range(16807))-forbidden);assert pool==row['pool']
        assert row['target']==368-len(fixed) and not(fixed & set(pool))
        maximum_pool=max(maximum_pool,len(pool));assert len(pool)<=20,'Exhaustive subset replay too large'
        best=0
        for mask in range(1<<len(pool)):
            subsets+=1;selected=[v for i,v in enumerate(pool)if mask>>i&1]
            if all(not conflict(a,b)for a,b in combinations(selected,2)):best=max(best,len(selected))
        assert row['full_size']==len(fixed)+best<368
        if not pool:assert row['status']=='no_free_words'
        else:
            assert row['status']=='exhausted' and row['result']['best_size']==best
            chosen=row['result']['vertices'];assert len(chosen)==len(set(chosen))==best
            assert all(type(i)is int and 0<=i<len(pool)for i in chosen)
            extra=[pool[i]for i in chosen];assert all(not conflict(a,b)for a,b in combinations(extra,2))
            if len(fixed)+best>=367:expected.add(tuple(sorted(fixed|set(extra))))
        counts[str(row['full_size'])]=counts.get(str(row['full_size']),0)+1
    actual=set()
    for c in source['candidates']:
        words=tuple(sorted(int(w,7)for w in c['words']));assert len(words)==len(set(words))==c['size']>=367
        assert all(not conflict(a,b)for a,b in combinations(words,2))
        assert c['verified_pairs']==len(words)*(len(words)-1)//2
        actual.add(words)
    assert actual==expected and len(actual)==len(source['candidates']) and source['size_histogram']==counts
    result=dict(input_sha256=sha(args.input),original_sha256=sha(args.original),checker_sha256=sha(__file__),
        domains=len(originals),max_pool=maximum_pool,exhaustive_subsets=subsets,candidates367=len(actual),
        best=max(int(x)for x in counts),full_space_domains_checked=True,all_residual_optima_verified=True,
        scope='Exact maximum after adding words to each retained code; no replacement or global exclusion.')
    args.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)


if __name__=='__main__':main()
