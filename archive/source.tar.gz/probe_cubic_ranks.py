"""Try exact search on the C7^3 projections used for cylinder rank cuts.

Reaching the existing layer upper bound proves equality. Exhaustion below it
can strengthen a cut. A timeout preserves the old bound unchanged.
"""
import argparse
from collections import Counter
import hashlib
from itertools import combinations
import json
from pathlib import Path
import subprocess

from lift_cylinder_ranks import lifted_constraints, HERE


def probe(projection, upper, milliseconds):
    words = [(v//49, (v//7) % 7, v % 7) for v in projection]
    edges = {(i, j) for i, j in combinations(range(len(words)), 2)
             if all((a-b) % 7 in (0, 1, 6) for a, b in zip(words[i], words[j]))}
    data = f'{len(words)} {len(edges)} {upper} {milliseconds} 0\n\n'
    data += ''.join(f'{i} {j}\n' for i, j in sorted(edges))
    try:
        run = subprocess.run([str(HERE/'slice_clique')], input=data, text=True,
                             capture_output=True, check=True, timeout=milliseconds/1000+5)
    except subprocess.TimeoutExpired:
        return dict(status='parent_timeout')
    result = json.loads(run.stdout)
    selected = result['vertices']
    assert len(selected) == len(set(selected)) == result['best_size'] <= upper
    assert all(type(i) is int and 0 <= i < len(words) for i in selected)
    assert all(p not in edges for p in combinations(sorted(selected), 2))
    if result['status'] == 'target_found':
        assert result['best_size'] == upper
    assert result['status'] in ('target_found', 'exhausted', 'timeout')
    return result


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--milliseconds', type=int, default=100)
    args = p.parse_args()
    if args.milliseconds < 1:
        p.error('Positive limit required')
    if args.output.exists():
        raise FileExistsError(args.output)
    source = json.loads(args.input.read_text())
    _, desc, _, _ = lifted_constraints(source['pool'])
    targets = {tuple(c['projection']): c['capacity'] for c in desc if c.get('layer_rank_bound')}
    report = dict(status='running', results=[], milliseconds=args.milliseconds,
                  input_sha256=hashlib.sha256(args.input.read_bytes()).hexdigest(),
                  source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  kernel_sha256=hashlib.sha256((HERE/'slice_clique').read_bytes()).hexdigest())
    for projection, upper in sorted(targets.items(), key=lambda kv: (len(kv[0]), kv[0])):
        result = probe(projection, upper, args.milliseconds)
        report['results'].append(dict(projection=list(projection), upper=upper, result=result))
        if len(report['results']) % 25 == 0:
            print(json.dumps(dict(done=len(report['results']), total=len(targets),
                                  statuses=dict(Counter(r['result']['status'] for r in report['results'])))), flush=True)
            args.output.write_text(json.dumps(report, indent=2)+'\n')
    report['status'] = 'complete'
    report['statuses'] = dict(Counter(r['result']['status'] for r in report['results']))
    report['tightened'] = sum(r['result']['status'] == 'exhausted' and r['result']['best_size'] < r['upper']
                              for r in report['results'])
    args.output.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps({k: v for k, v in report.items() if k != 'results'}), flush=True)


if __name__ == '__main__':
    main()
