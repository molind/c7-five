"""Small-graph controls for one-step recovery from an energy-one set."""
from collections import deque
from itertools import combinations
import json
from pathlib import Path
import random

if not __debug__: raise RuntimeError('Run without -O')
rng=random.Random(2026092002)
checked=0;components=0;maximal_components=0
for _ in range(50):
    n=rng.randrange(4,9);universe=set(range(n))
    edges={frozenset((a,b)) for a,b in combinations(range(n),2) if rng.random()<0.35}
    independent=lambda s:not any(edge<=s for edge in edges)
    for k in range(1,n):
        remaining={frozenset(s) for s in combinations(range(n),k) if independent(set(s))}
        while remaining:
            seed=next(iter(remaining));known={seed};queue=deque([seed]);remaining.remove(seed)
            while queue:
                s=queue.popleft()
                for t in list(remaining):
                    if len(s-t)==1:
                        known.add(t);remaining.remove(t);queue.append(t)
            components+=1
            maximal=all(not independent(s|{w}) for s in known for w in universe-s)
            maximal_components+=maximal
            lifts={a|b for a,b in combinations(known,2) if len(a-b)==1}
            for s in lifts:
                if sum(edge<=s for edge in edges)!=1: continue
                for removed in s:
                    for added in universe-s:
                        t=(s-{removed})|{added}
                        for deleted in t:
                            recovered=t-{deleted}
                            if independent(recovered): assert recovered in known
                        if maximal: assert not independent(t)
                        checked+=1
result=dict(random_graphs=50,independent_components=components,maximal_components=maximal_components,
            one_word_neighbors_checked=checked,
            conclusion='Every independent k-subset recovered from a one-word neighbor of an E1 lift remains in the same component. If all component members are maximal, no such neighbor is independent of size k+1.')
(Path(__file__).parent/'e1-neighbor-recovery-controls.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
