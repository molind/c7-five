"""Recompute global restricted bounds by coordinate intersections; sample direct pairs."""
import contextlib,io,json,runpy,random,struct
from pathlib import Path
from itertools import product
p=Path(__file__).parent
with contextlib.redirect_stdout(io.StringIO()):c=runpy.run_path(str(p/'shared_u2_compact_replay.py'))
u=sorted(c['U2']);coords=[[0]*7 for _ in range(5)]
for i,w in enumerate(u):
    for k,x in enumerate(w):coords[k][x]|=1<<i
probe=json.loads((p/'two-anchor-global-results.json').read_text())
assert len(probe['rows'])==7**5-len(u)==14590
boxes=[]
for origin,units in struct.iter_unpack('<HI',c['raw']):
    points=set(product(*[(x,(x+1)%7) for x in c['W'][origin]]))&c['U2']
    mask=sum(1<<i for i,w in enumerate(u) if w in points)
    boxes.append((mask,units,points))
full=(1<<len(u))-1
sample=set(random.Random(180915).sample(range(len(probe['rows'])),30))
sample.add(min(range(len(probe['rows'])),key=lambda i:probe['rows'][i]['cover_units']))
for i,row in enumerate(probe['rows']):
    a=tuple(map(int,row['anchor']));conf=full
    for k,x in enumerate(a):conf&=coords[k][(x-1)%7]|coords[k][x]|coords[k][(x+1)%7]
    allowed=full^conf
    assert allowed.bit_count()==row['remaining_u2']
    assert sum(units for mask,units,_ in boxes if mask&allowed)==row['cover_units']
    if i in sample:
        direct={w for w in u if any((x-y)%7 in (2,3,4,5) for x,y in zip(a,w))}
        assert direct=={w for j,w in enumerate(u) if allowed>>j&1}
        assert sum(units for _,units,points in boxes if points&direct)==row['cover_units']
local=json.loads((p/'two-anchor-cover-probe.json').read_text())
by_word={r['anchor']:r for r in probe['rows']}
assert all(by_word[r['anchor']]==r for r in local['rows'])
assert sum(r['cover_units']<367000000 for r in probe['rows'])==10800
r=dict(all_bounds_recomputed=14590,direct_pair_samples=len(sample),local_rows_matched=13375,single_anchor_excluded=10800,residual=3790,method='Coordinate intersections for all rows; direct pair/set check for31 samples; base integer certificate rerun')
(p/'two-anchor-global-verification.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
