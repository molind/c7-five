"""Exhaustively test the radius-derived cardinality cut on finite graphs.

If every independent(m+1) set removes at least q vertices of independent old
set B (size m), then O+q*X <= (q+1)*m for every independent set with X<=m+1.
The old set remains feasible. Radius caps add O>=m-r without losing any
improving set whose number of removed old vertices is at most r.
"""
import argparse
import hashlib
from itertools import combinations
import json
from pathlib import Path
import random


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();assert __debug__ and not args.output.exists()
    rng=random.Random(2026092272);graphs=checked=capped=positive=too_strong=0
    for trial in range(106):
        if trial<6:
            q=trial+1;n=2*q+1;edges=[(i,j) for i in range(q) for j in range(q,n)]
            old=(1<<q)-1
        else:
            n=6+trial%6;edges=[(i,j) for i,j in combinations(range(n),2) if rng.random()<.35]
            old=0
            order=list(range(n));rng.shuffle(order)
            for v in order:
                if all(not((a==v and old>>b&1) or (b==v and old>>a&1)) for a,b in edges):old|=1<<v
        legal=[s for s in range(1<<n) if all(not(s>>a&1 and s>>b&1) for a,b in edges)]
        assert old in legal;m=old.bit_count()
        improvements=[s for s in legal if s.bit_count()==m+1]
        q=min((old&~s).bit_count() for s in improvements) if improvements else m+1
        assert q>=1
        for s in legal:
            X=s.bit_count();O=(s&old).bit_count()
            if X<=m+1:assert O+q*X<=(q+1)*m;checked+=1
            if X==m+1:
                positive+=1
                if O+(q+1)*X>(q+2)*m:too_strong+=1
                for r in range(m+1):
                    assert (O>=m-r)==((old&~s).bit_count()<=r);capped+=1
        assert m+q*m==(q+1)*m;graphs+=1
    assert positive>0 and too_strong>0
    out=dict(passed=True,graphs=graphs,independent_set_checks=checked,improving_sets=positive,
        capped_preservation_checks=capped,unsupported_stronger_cut_counterexamples=too_strong,
        source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        scope='Generic finite-graph reduction only. Applying q=10 to C7 still requires the exact F radius-nine certificate.')
    args.output.write_text(json.dumps(out,indent=2)+'\n');print(out)


if __name__=='__main__':main()
