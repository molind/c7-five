"""Rebuild pinned367 exchange graphs by dense coordinate comparisons.

A completed width-two component supplies the radius-two premise. Higher radii
are computational exclusions only when the tested native traversal exhausts;
timeouts are retained as partial. All positive outputs receive direct geometry
checks. This is not an independently replayed native proof trace.
"""
import argparse
import gzip
import hashlib
from itertools import product
import json
from pathlib import Path
import struct

import numpy as np

from check_farthest_exchange_inputs import conflict_rows
from check_exchange_dfs import graph_text


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',required=True,nargs='+',type=Path)
    p.add_argument('--component-search',required=True,type=Path)
    p.add_argument('--output',required=True,type=Path)
    a=p.parse_args();assert __debug__ and not a.output.exists()
    here=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    records=[(path,json.loads(path.read_text())) for path in a.input];first=records[0][1]
    seed_path=Path(first['seed_file']);assert sha(seed_path)==first['seed_sha256']
    tokens=seed_path.read_text().split();ids=[int(t,7) for t in tokens]
    assert len(ids)==len(set(ids))==367 and all(len(t)==5 and set(t)<=set('0123456') for t in tokens)
    component_path=Path(first['component_file']);assert sha(component_path)==first['component_file_sha256']
    with gzip.open(component_path,'rt') as f:
        meta=json.loads(next(f));states=sorted(struct.pack('<367H',*json.loads(line)) for line in f)
    digest=hashlib.sha256(b''.join(states)).hexdigest()
    assert len(states)==len(set(states))==meta['states'] and digest==meta['component_sha256']
    assert struct.pack('<367H',*sorted(ids)) in set(states)
    walk=json.loads(a.component_search.read_text())
    assert walk['source_sha256']==sha(here/'search_plateau.py') and walk['input_sha256']==sha(walk['input'])
    assert walk['status']=='exhausted' and walk['initial_size']==367 and walk['neutral_exchange_width']==walk['augmentation_checked_through']==2
    assert walk['improved_words'] is None and walk['component_sha256']==digest and walk['states_visited']==len(states)
    coords=np.array(list(product(range(7),repeat=5)),dtype=np.int16);blockers=[]
    for start,bad in conflict_rows(coords,coords[ids]):
        blockers.extend(int.from_bytes(row.tobytes(),'little') for row in np.packbits(bad,axis=1,bitorder='little'))
    assert all(blockers[v]==1<<i for i,v in enumerate(ids))
    outside=[v for v in range(16807) if v not in set(ids)];assert all(blockers[v] for v in outside)
    checked_graphs={};rows=[];positive_pairs=0;target_sets=[]
    for path,d in records:
        assert d['status'] in ('complete','verified_improvement') and d['improve_only']
        assert d['driver_sha256']==sha(here/'run_seed_exchanges_fast.py') and d['exporter_sha256']==sha(here/'export_exchange_graph.py')
        assert d['kernel_sha256']==sha(here/'exchange_dfs_residual_two') and d['kernel_source_sha256']==sha(here/'exchange_dfs_residual_two.cpp')
        assert d['seed_sha256']==sha(seed_path) and d['component_file_sha256']==sha(component_path)
        returned=[]
        for r in d['rows']:
            radius=r['radius'];assert not r['neutral']
            pool=sorted((v for v in outside if blockers[v].bit_count()<=radius),key=lambda v:blockers[v].bit_count())
            assert len(pool)==r['pool']
            graph=Path(r['input']);assert sha(graph)==r['input_sha256']
            if radius not in checked_graphs:
                comp=[]
                for start,bad in conflict_rows(coords[pool],coords[pool]):
                    comp.extend(int.from_bytes(row.tobytes(),'little') for row in np.packbits(~bad,axis=1,bitorder='little'))
                encoded=graph_text([blockers[v] for v in pool],comp,radius,6)
                assert hashlib.sha256(encoded.encode()).hexdigest()==sha(graph)
                checked_graphs[radius]=sha(graph)
            else:assert checked_graphs[radius]==sha(graph)
            k=r['result'];assert k['status'] in ('exhausted','timeout','witness')
            assert k['budget_bitsets'] and k['binary_budget'] and k['residual_budget']
            assert not k['enumerate_neutral'] and not k['noncore_bound'] and not k['anchor_bounds'] and not k['pair_bounds']
            assert not k['neutral'] and not k['improving'] and k['root_start']==0 and k['root_end']==len(pool) and 0<=k['next_root']<=len(pool)
            if k['status']=='exhausted':assert k['next_root']==len(pool) and k['nodes_started']==k['nodes_completed']
            if k['status']=='witness':
                chosen=k['chosen'];assert len(chosen)==len(set(chosen))==radius+1 and all(type(i) is int and 0<=i<len(pool) for i in chosen)
                paid=0
                for i in chosen:paid|=blockers[pool[i]]
                assert paid.bit_count()<=radius
                words=sorted({v for i,v in enumerate(ids) if not (paid>>i)&1}|{pool[i] for i in chosen})
                assert len(words)==367+radius+1-paid.bit_count()>=368
                for start,bad in conflict_rows(coords[words],coords[words]):assert int(bad.sum())==len(bad)
                positive_pairs+=len(words)*(len(words)-1)//2
                returned.append([''.join(map(str,coords[v])) for v in words]);target_sets.append(words)
            else:assert not k['chosen']
            rows.append(dict(file=str(path),radius=radius,pool=len(pool),graph_sha256=sha(graph),status=k['status'],closed_until=k['next_root'],root_end=len(pool)))
        assert d['improved_words']==(returned[0] if returned else None)
        assert len(d['candidates'])==len(returned) and [c['words'] for c in d['candidates']]==returned
    bound=2
    for row in sorted(rows,key=lambda r:r['radius']):
        if row['radius']==bound+1 and row['status']=='exhausted':bound+=1
    deps={str(p):sha(p) for p in [*a.input,a.component_search,seed_path,component_path,here/'search_plateau.py',here/'run_seed_exchanges_fast.py',here/'exchange_dfs_residual_two',here/'exchange_dfs_residual_two.cpp']}
    out=dict(checker_sha256=sha(__file__),scope=__doc__,dependencies=deps,rows=rows,
             full_local_radius_excluded=bound,minimum_removed_for_368=bound+1,
             positive_pair_checks=positive_pairs,target_sets=target_sets)
    a.output.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(rows=rows,full_local_radius_excluded=bound,targets=len(target_sets))))


if __name__=='__main__':main()
