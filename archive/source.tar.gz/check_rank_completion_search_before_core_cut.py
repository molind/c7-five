"""Check a rank-constrained completion model and its returned integer witness.

Reconstructs the entire compatible universe, all conflict edges, and every
higher-rank row against the checked input certificate. Does not certify a
solver's tree exhaustion or use a time limit as an infeasibility proof.
"""
import argparse
import hashlib
from itertools import combinations, product
import json
from pathlib import Path

import numpy as np
from check_component_core_groups import closed
from check_cylinder_covers import check_entries
from cylinder_bounds import CAPACITY


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', required=True, type=Path)
    p.add_argument('--output', required=True, type=Path)
    args = p.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    data = json.loads(args.input.read_text())
    assert data['status'] in ('bounded_search_complete', 'candidate_found')
    assert sha(data['input']) == data['input_sha256']
    source = json.loads(Path(data['input']).read_text())
    model, result = data['model'], data['result']
    fixed, pool = model['fixed'], model['pool']
    assert fixed == source['fixed'] and pool == source['pool']
    assert len(fixed) == len(set(fixed)) and len(pool) == len(set(pool)) and not set(fixed) & set(pool)
    assert all(type(v) is int and 0 <= v < 16807 for v in fixed+pool)
    universe = np.array(list(product(range(7), repeat=5)), dtype=np.int16)
    allowed = []
    for begin in range(0, 16807, 128):
        delta = (universe[begin:begin+128, None, :]-universe[fixed][None, :, :]) % 7
        blocked = np.any(np.all((delta == 0) | (delta == 1) | (delta == 6), axis=2), axis=1)
        allowed.extend((begin+np.flatnonzero(~blocked)).tolist())
    assert allowed == pool
    total, denominator = check_entries(source['certificate'], pool, CAPACITY)
    assert len(fixed)+total//denominator == source['full_upper']
    ranks = {}
    for entry in source['certificate']['cover']:
        key = tuple(sorted(entry['vertices']))
        ranks[key] = min(ranks.get(key, entry['capacity']), entry['capacity'])
    assert len(model['members']) == len(model['capacities'])
    represented_edges = set()
    high_rank_rows = 0
    for indices, capacity in zip(model['members'], model['capacities']):
        assert len(indices) == len(set(indices)) and all(type(i) is int and 0 <= i < len(pool) for i in indices)
        assert type(capacity) is int and capacity >= 1
        points = sorted(pool[i] for i in indices)
        if capacity == 1:
            for i, j in combinations(indices, 2):
                delta = (universe[pool[i]]-universe[pool[j]]) % 7
                assert np.all((delta == 0) | (delta == 1) | (delta == 6))
                represented_edges.add(tuple(sorted((i, j))))
        else:
            assert ranks.get(tuple(points)) == capacity
            high_rank_rows += 1
    index = {v:i for i,v in enumerate(pool)}
    actual_edges = {(i, index[w]) for i,v in enumerate(pool) for w in closed(v) if w in index and i < index[w]}
    assert actual_edges == represented_edges
    assert [pool[i] for i in model['hint']] == source['hint']
    assert result['target'] == 368-len(fixed) and result['forbidden'] is None
    full_size, pairs = None, 0
    if 'vertices' in result:
        selected = result['vertices']
        assert len(selected) == len(set(selected)) and set(selected) <= set(pool)
        full = fixed+selected
        assert len(full) == len(set(full)) == result['full_size']
        points = universe[full]
        delta = (points[:, None, :]-points[None, :, :]) % 7
        assert not np.any(np.triu(np.all((delta == 0) | (delta == 1) | (delta == 6), axis=2), 1))
        for row, cap in zip(model['members'], model['capacities']):
            assert sum(pool[i] in set(selected) for i in row) <= cap
        full_size, pairs = len(full), len(full)*(len(full)-1)//2
        assert result['verified_pairs'] == pairs
        expected = [dict(step=0, size=len(full), words=[''.join(map(str, universe[v])) for v in sorted(full)], verified_pairs=pairs)] if len(full) >= 367 else []
        assert data['candidates'] == expected
    else:
        assert data['candidates'] == []
    assert (data['status'] == 'candidate_found') == (full_size is not None and full_size >= 368)
    report = dict(input_sha256=sha(args.input), certificate_sha256=sha(data['input']), checker_sha256=sha(__file__),
        fixed=len(fixed), full_pool=len(pool), direct_domain_pairs=16807*len(fixed),
        conflict_edges=len(actual_edges), constraints=len(model['members']), high_rank_rows=high_rank_rows,
        certificate_full_upper=source['full_upper'], returned_full_size=full_size, direct_witness_pairs=pairs,
        solver_status=result.get('solver_status'), target_witness_found=full_size is not None and full_size >= 368,
        scope='Complete domain and integer model checked, plus any returned witness. Solver status is recorded, not independently certified.')
    args.output.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report), flush=True)


if __name__ == '__main__':
    main()
