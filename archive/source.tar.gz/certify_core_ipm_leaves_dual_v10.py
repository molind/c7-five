"""Convert numerical infeasible branch leaves to exact integer contradictions.

For signed row weights y, row bounds imply (yA)x <= sum(y+*upper+y-*lower).
The minimum of (yA)x over the variable box is computed with Python integers.
A strictly larger minimum proves this leaf impossible, independently of HiGHS.
"""
import argparse
import json
import math
from pathlib import Path
import time

import numpy as np
from scipy.optimize import linprog
from scipy.sparse import vstack, eye, csc_matrix

from check_core_subtree_cuts import verify as verify_subtree_cuts
from check_core_subtree_cuts_v2 import verify as verify_refined_cuts
from check_two_slice_covers import closed
from search_core_radius_cut import sha
from search_core_ipm_branches_v2 import propagate
from solve_core_radius_ipm import build_model, load_radius_model, model_digest


def integer_contradiction(matrix, lower, upper, variable_lo, variable_hi, ray):
    csr = matrix.tocsr()
    assert np.all(np.isfinite(ray))
    assert np.all(matrix.data == np.rint(matrix.data))
    for scale in (1000, 1000000, 1000000000):
        for sign in (1, -1):
            weights = [int(round(float(v) * scale)) * sign for v in ray]
            coefficients = [0] * matrix.shape[1]
            rhs = 0
            for row, weight in enumerate(weights):
                if not weight:
                    continue
                bound = upper[row] if weight > 0 else lower[row]
                assert float(bound).is_integer()
                rhs += weight * int(bound)
                for j in range(csr.indptr[row], csr.indptr[row + 1]):
                    coefficients[csr.indices[j]] += weight * int(csr.data[j])
            minimum = sum(c * int(variable_lo[j] if c > 0 else variable_hi[j]) for j, c in enumerate(coefficients))
            if minimum > rhs:
                return dict(multipliers=[[j, w] for j, w in enumerate(weights) if w],
                            minimum_lhs=minimum, rhs=rhs, positive_gap=minimum-rhs,
                            rounding_scale=scale, ray_sign=sign)
    return None


def recheck_certificate(matrix, lower, upper, variable_lo, variable_hi, certificate):
    """Reuse already-integer weights without a floating-point round trip."""
    csr = matrix.tocsr()
    assert np.all(matrix.data == np.rint(matrix.data))
    coefficients, rhs, seen = [0] * matrix.shape[1], 0, set()
    for row, weight in certificate['multipliers']:
        assert type(row) is int and 0 <= row < matrix.shape[0] and row not in seen
        assert type(weight) is int and weight
        seen.add(row)
        bound = upper[row] if weight > 0 else lower[row]
        assert float(bound).is_integer()
        rhs += weight * int(bound)
        for j in range(csr.indptr[row], csr.indptr[row+1]):
            coefficients[csr.indices[j]] += weight * int(csr.data[j])
    minimum = sum(c * int(variable_lo[j] if c > 0 else variable_hi[j]) for j, c in enumerate(coefficients))
    assert minimum == certificate['minimum_lhs'] and rhs == certificate['rhs']
    assert minimum-rhs == certificate['positive_gap'] > 0


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--tree', required=True, type=Path)
    p.add_argument('--seconds', type=float, default=30)
    p.add_argument('--output', required=True, type=Path)
    p.add_argument('--reuse', type=Path, action='append', default=[])
    p.add_argument('--include-unknown', action='store_true')
    p.add_argument('--unknown-only', action='store_true')
    args = p.parse_args()
    assert __debug__ and not args.output.exists() and args.seconds > 0
    tree = json.loads(args.tree.read_text())
    assert tree['status'] == 'bounded_attempt_complete'
    names = ('search_core_ipm_branches.py', 'search_core_ipm_branches_v2.py', 'search_core_ipm_branches_v3.py', 'search_core_ipm_branches_v4.py', 'search_core_ipm_branches_v5.py', 'search_core_ipm_branches_v6.py', 'search_core_ipm_branches_v8.py', 'search_core_ipm_branches_v9.py', 'search_core_ipm_branches_v10.py', 'search_core_ipm_branches_v11.py', 'search_core_ipm_branches_v12.py')
    matches = [name for name in names if sha(Path(__file__).with_name(name)) == tree['source_sha256']]
    assert len(matches) == 1
    assert all(sha(f) == h for f, h in tree['dependencies'].items())
    data, matrix, lower, upper, variable_upper, initial = load_radius_model(Path(tree['input']), tree['radius'])
    if tree.get('domain_exclusion'):
        exclusion_path = Path(tree['domain_exclusion'])
        assert tree['dependencies'][str(exclusion_path)] == sha(exclusion_path)
        exclusion = json.loads(exclusion_path.read_text())
        assert exclusion['passed'] and exclusion['target'] == 368
        assert exclusion['input'] == tree['input'] and exclusion['deletion_radius'] == tree['radius']
        assert exclusion['fixed'] == data['fixed'] and exclusion['exact_parent'] == data['parent_words']
        assert exclusion['checker_sha256'] == sha(Path(__file__).with_name('derive_core_domain_exclusion.py'))
        assert all(sha(f) == h for f, h in exclusion['dependencies'].items())
        words = exclusion['inside']
        assert words and len(words) == len(set(words)) and exclusion['outside'] == []
        assert exclusion['inequality_upper'] == len(words)-1
        positions = {v: j for j, v in enumerate(data['pool'])}
        cut = csc_matrix(([1]*len(words), ([0]*len(words), [positions[v] for v in words])),
                         shape=(1, len(positions)))
        matrix = vstack((matrix[:-3], cut, matrix[-3:]), format='csc')
        lower = np.r_[lower[:-3], 0, lower[-3:]]
        upper = np.r_[upper[:-3], len(words)-1, upper[-3:]]
    if tree.get('common_core_proof'):
        proof_path, base_path = Path(tree['common_core_proof']), Path(tree['common_core_base'])
        assert tree['dependencies'][str(proof_path)] == sha(proof_path)
        assert tree['dependencies'][str(base_path)] == sha(base_path)
        proof, base = json.loads(proof_path.read_text()), json.loads(base_path.read_text())
        assert proof['passed'] and not proof['open_domains']
        assert proof['checker_sha256'] == sha(Path(__file__).with_name('check_common312_covers.py'))
        assert all(sha(f) == h for f, h in proof['dependencies'].items())
        assert proof['dependencies'][str(base_path)] == sha(base_path)
        assert proof['dependencies'][base['input']] == sha(base['input']) == base['input_sha256']
        parents = json.loads(Path(base['input']).read_text())['bases']
        core = set(parents[0]['words']) & set(parents[1]['words'])
        assert core == set(base['fixed']) and len(core) == 315
        assert proof['cases'] == math.comb(315, 3)
        assert proof['implicit'] + proof['explicit_extensions'] + proof['lp_covers'] == proof['cases']
        assert proof['minimum_core_omissions_for368'] == 4
        assert proof['any368_retains_at_most_core_words'] == 311
        assert 0 < proof['denominator'] and proof['maximum_total_units'] < 56*proof['denominator']
        fixed = set(data['fixed'])
        assert fixed <= core and set(data['parent_words']) in [set(p['words']) for p in parents]
        core_words, core_upper = sorted(core-fixed), 311-len(fixed)
        assert data['target'] + len(fixed) == 368
        assert tree['common_core_cut_words'] == core_words
        assert tree['common_core_cut_upper'] == core_upper
        positions = {v: j for j, v in enumerate(data['pool'])}
        assert set(core_words) <= set(positions) and 0 <= core_upper < len(core_words)
        cut = csc_matrix(([1]*len(core_words), ([0]*len(core_words), [positions[v] for v in core_words])),
                         shape=(1, len(positions)))
        matrix = vstack((matrix[:-3], cut, matrix[-3:]), format='csc')
        lower = np.r_[lower[:-3], 0, lower[-3:]]
        upper = np.r_[upper[:-3], core_upper, upper[-3:]]
    for field, count_field, verify_cuts in (('subtree_cuts', 'subtree_cut_count', verify_subtree_cuts),
                                            ('refined_cuts', 'refined_cut_count', verify_refined_cuts)):
        if not tree.get(field):
            continue
        cut_path = Path(tree[field])
        assert tree['dependencies'][str(cut_path)] == sha(cut_path)
        cuts = verify_cuts(cut_path)
        assert cuts['input'] == tree['input'] and cuts['radius'] == tree['radius']
        target_lower = lower.copy()
        target_lower[-3] = data['target']
        assert model_digest(matrix, target_lower, upper, variable_upper) == cuts['target_model_sha256']
        positions = {v: j for j, v in enumerate(data['pool'])}
        ri, ci, coefficients, lows, highs = [], [], [], [], []
        for i, clause in enumerate(cuts['clauses']):
            assert not set(clause['inside']) & set(clause['outside'])
            for word, value in [(v, 1) for v in clause['inside']] + [(v, -1) for v in clause['outside']]:
                ri.append(i); ci.append(positions[word]); coefficients.append(value)
            lows.append(-len(clause['outside']))
            highs.append(len(clause['inside'])-1)
        assert tree[count_field] == len(cuts['clauses'])
        extra = csc_matrix((coefficients, (ri, ci)), shape=(len(cuts['clauses']), len(positions)))
        matrix = vstack((matrix[:-3], extra, matrix[-3:]), format='csc')
        lower = np.r_[lower[:-3], lows, lower[-3:]]
        upper = np.r_[upper[:-3], highs, upper[-3:]]
    assert model_digest(matrix, lower, upper, variable_upper) == tree['original_model_sha256']
    lower[-3] = data['target']
    assert model_digest(matrix, lower, upper, variable_upper) == tree['target_model_sha256']
    pool, old = set(data['pool']), set(data['parent_words']) - set(data['fixed'])
    neighborhoods = {v: closed(v) & pool for v in pool}
    pos = {v: j for j, v in enumerate(data['pool'])}
    out = dict(status='running', tree=str(args.tree), source_sha256=sha(__file__),
               dependencies={str(args.tree): sha(args.tree)}, rows=[],
               scope='Exact arithmetic certificates for recorded numerical leaves; whole-tree coverage requires separate verification.')
    for name in (matches[0], 'search_core_ipm_branches_v2.py', 'solve_core_radius_ipm.py', 'check_two_slice_covers.py'):
        path = Path(__file__).with_name(name)
        out['dependencies'][str(path)] = sha(path)
    for field, suffix in (('subtree_cuts', ''), ('refined_cuts', '_v2')):
        if not tree.get(field):
            continue
        path = Path(tree[field])
        out['dependencies'][str(path)] = sha(path)
        for name in ('check_core_subtree_cuts' + suffix + '.py', 'derive_core_subtree_cuts' + suffix + '.py'):
            path = Path(__file__).with_name(name)
            out['dependencies'][str(path)] = sha(path)
    reusable = {}
    for reuse_path in args.reuse:
        previous = json.loads(reuse_path.read_text())
        assert previous['status'] == 'complete_attempt'
        assert all(sha(f) == h for f, h in previous['dependencies'].items())
        earlier = json.loads(Path(previous['tree']).read_text())
        assert earlier['target_model_sha256'] == tree['target_model_sha256']
        assert earlier['radius'] == tree['radius'] and earlier['input'] == tree['input']
        for record in previous['rows']:
            if record['certificate'] is not None:
                node = earlier['rows'][record['tree_index']]
                key = tuple(node['inside']), tuple(node['outside'])
                assert key not in reusable
                reusable[key] = (record['certificate'], str(reuse_path))
        out['dependencies'][str(reuse_path)] = sha(reuse_path)
    last_save = 0.0
    out['checkpoint_writes'] = 0
    def save(force=False):
        nonlocal last_save
        if not force and time.monotonic() - last_save < 5:
            return
        out['checkpoint_writes'] += 1
        temporary = args.output.with_suffix('.tmp')
        temporary.write_text(json.dumps(out, indent=2) + '\n')
        temporary.replace(args.output)
        last_save = time.monotonic()
    save(force=True)
    unknown = {(tuple(r['inside']), tuple(r['outside'])) for r in tree['unknown_nodes']}
    for index, row in enumerate(tree['rows']):
        if args.unknown_only and (tuple(row['inside']), tuple(row['outside'])) not in unknown:
            continue
        if row['status'] not in ('Infeasible', 'exact_integer_contradiction') and not ((args.include_unknown or args.unknown_only) and (tuple(row['inside']), tuple(row['outside'])) in unknown):
            continue
        forbidden = propagate(pool, old, neighborhoods, row['inside'], row['outside'], tree['radius'])
        assert forbidden is not None
        variable_lo, variable_hi = np.zeros(len(pool)), variable_upper.copy()
        for v in row['inside']:
            variable_lo[pos[v]] = 1
        for v in forbidden:
            variable_hi[pos[v]] = 0
        key = tuple(row['inside']), tuple(row['outside'])
        if key in reusable:
            certificate, reused_from = reusable[key]
            # Re-evaluate the exact combination under THIS leaf's bounds.
            recheck_certificate(matrix, lower, upper, variable_lo, variable_hi, certificate)
            record = dict(tree_index=index, certificate=certificate, reused_from=reused_from, seconds=0.0)
            out['rows'].append(record);save()
            continue
        identity = eye(len(pool), format='csc')
        forced = np.flatnonzero(variable_lo)
        inequalities = vstack((matrix, -matrix, identity, -identity.tocsr()[forced]), format='csc')
        bounds = np.r_[upper, -lower, variable_hi, -variable_lo[forced]]
        began = time.monotonic()
        dual = linprog(bounds, A_ub=-inequalities.T, b_ub=np.zeros(len(pool)),
                       A_eq=csc_matrix(np.ones((1, inequalities.shape[0]))), b_eq=[1],
                       bounds=(0, None), method='highs-ipm', options={'time_limit': args.seconds})
        certificate = None
        if dual.success:
            count = matrix.shape[0]
            ray = dual.x[:count] - dual.x[count:2*count]
            certificate = integer_contradiction(matrix, lower, upper, variable_lo, variable_hi, ray)
        record = dict(tree_index=index, solver_status=int(dual.status), solver_message=dual.message,
                      dual_objective=dual.fun, certificate=certificate, seconds=time.monotonic()-began)
        out['rows'].append(record)
        save()
        print(dict(leaf=index, seconds=record['seconds'], certified=certificate is not None,
                   multipliers=len(certificate['multipliers']) if certificate else None,
                   gap=certificate['positive_gap'] if certificate else None), flush=True)
    out['status'] = 'complete_attempt'
    save(force=True)


if __name__ == '__main__':
    main()
