"""Tighten two-coordinate cylinder rows to their exact projected graph ranks."""
import argparse
import hashlib
from itertools import combinations, product
import json
from pathlib import Path
import time

import numpy as np
from scipy.optimize import linprog
from scipy.sparse import csc_matrix

from cylinder_bounds import HERE, WORDS, constraints, certify
from square_rank import rank


def refined_constraints(pool):
    members, desc, _ = constraints(pool, [0, 1, 2])
    rows = {tuple(c): d for c, d in zip(members, desc)}
    masks = set()
    tightened = 0
    for free in combinations(range(5), 2):
        fixed = [i for i in range(5) if i not in free]
        buckets = {}
        for i, v in enumerate(pool):
            for values in product(*[((WORDS[v][k]-1) % 7, WORDS[v][k]) for k in fixed]):
                buckets.setdefault(values, []).append(i)
        for values, vs in buckets.items():
            projected = {7*WORDS[pool[v]][free[0]]+WORDS[pool[v]][free[1]] for v in vs}
            mask = sum(1 << v for v in projected)
            masks.add(mask)
            capacity = rank(mask)
            key = tuple(vs)
            if len(vs) <= capacity or capacity >= rows.get(key, {'capacity': 10})['capacity']:
                continue
            origin = [-1]*5
            for k, x in zip(fixed, values):
                origin[k] = x
            rows[key] = dict(free=list(free), origin=origin, capacity=capacity,
                             projected_rank=True, projection=sorted(projected))
            tightened += 1
    members = sorted(rows)
    desc = [rows[c] for c in members]
    rr = [i for i, c in enumerate(members) for _ in c]
    cc = [v for c in members for v in c]
    matrix = csc_matrix((np.ones(len(rr)), (rr, cc)), shape=(len(members), len(pool)))
    return members, desc, matrix, {'tightened_rows': tightened, 'distinct_projection_masks': len(masks),
                                 'dp_states': rank.cache_info().currsize}


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path, default=HERE/'three-slice-cylinders012-sep21.json')
    p.add_argument('--seconds', type=float, default=30)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    if args.seconds <= 0:
        p.error('Positive limit required')
    if args.output.exists():
        raise FileExistsError(args.output)
    source = json.loads(args.input.read_text())
    pool = source['pool']
    began = time.monotonic()
    members, desc, matrix, stats = refined_constraints(pool)
    seed = {int(w, 7) for w in (HERE/'family-d-seed-words.txt').read_text().split()}
    hint = np.array([v in seed for v in pool], dtype=float)
    caps = np.array([d['capacity'] for d in desc], dtype=float)
    assert np.max(matrix @ hint-caps) <= 0
    built = time.monotonic()
    result = linprog(-np.ones(len(pool)), A_ub=matrix, b_ub=caps, bounds=(0, None),
                     method='highs-ipm', options={'time_limit': args.seconds})
    report = {k: source[k] for k in ('axis', 'start', 'width', 'fixed', 'pool', 'target', 'capacity_sequence')}
    report.update(status=int(result.status), message=result.message, stats=stats,
                  constraints=len(members), nonzeros=int(matrix.nnz),
                  build_seconds=built-began, solve_seconds=time.monotonic()-built,
                  input_sha256=hashlib.sha256(args.input.read_bytes()).hexdigest(),
                  hashes={n: hashlib.sha256((HERE/n).read_bytes()).hexdigest() for n in
                          (Path(__file__).name, 'cylinder_bounds.py', 'square_rank.py')},
                  scope='Exact projected C7^2 ranks strengthen the whole saved slab domain; no global bound.')
    if result.success:
        report['floating_bound'] = float(-result.fun)
        report['certificate'] = certify(pool, members, desc, -result.ineqlin.marginals)
        report['primal'] = [[v, float(x)] for v, x in zip(pool, result.x) if x > 1e-8]
    args.output.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps({k: v for k, v in report.items() if k not in ('fixed', 'pool', 'primal', 'certificate')} |
                     {'integer_bound': report.get('certificate', {}).get('integer_upper_bound')}), flush=True)


if __name__ == '__main__':
    main()
