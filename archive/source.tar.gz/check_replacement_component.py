"""Check an entire 367-word one-replacement component by coordinate differences.

Every outside word is compared with every selected word in every cached state.
Closure plus connectivity certifies the whole one-for-one component, without
using the search graph, its neighborhood builder, or its fixed-core reduction.
"""
import argparse
from collections import Counter, deque
import gzip
import hashlib
from itertools import product
import json
from pathlib import Path
import struct

import numpy as np


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--component', type=Path, required=True)
    p.add_argument('--seed', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    with gzip.open(args.component, 'rt') as f:
        metadata = json.loads(next(f))
        raw_states = [json.loads(line) for line in f]
    assert metadata['cardinality'] == 367
    assert len(raw_states) == metadata['states'] > 0
    assert all(len(s) == 367 and len(set(s)) == 367 and s == sorted(s)
               and all(type(v) is int and 0 <= v < 16807 for v in s) for s in raw_states)
    keys = sorted(struct.pack('<367H', *s) for s in raw_states)
    assert len(set(keys)) == len(keys)
    assert hashlib.sha256(b''.join(keys)).hexdigest() == metadata['component_sha256']
    states = [frozenset(s) for s in raw_states]
    lookup = {s: i for i, s in enumerate(states)}
    tokens = args.seed.read_text().split()
    assert len(tokens) == 367 and all(len(t) == 5 and set(t) <= set('0123456') for t in tokens)
    seed = frozenset(int(t, 7) for t in tokens)
    assert len(seed) == 367 and seed in lookup
    universe = np.array(list(product(range(7), repeat=5)), dtype=np.int16)
    universe_ids = set(range(16807))
    results = []
    total_pairs = 0
    for index, state in enumerate(states):
        selected = sorted(state)
        points = universe[selected]
        delta = (points[:, None, :]-points[None, :, :]) % 7
        assert not np.any(np.triu(np.all((delta == 0) | (delta == 1) | (delta == 6), axis=2), 1))
        outside = sorted(universe_ids-state)
        moves, histogram = [], Counter()
        for begin in range(0, len(outside), 256):
            batch = outside[begin:begin+256]
            delta = (universe[batch, None, :]-points[None, :, :]) % 7
            blocked = np.all((delta == 0) | (delta == 1) | (delta == 6), axis=2)
            counts = blocked.sum(axis=1)
            histogram.update(map(int, counts))
            if np.any(counts == 0):
                new = batch[int(np.flatnonzero(counts == 0)[0])]
                raise RuntimeError('Independent368 extension: '+str(sorted(state | {new})))
            for row in np.flatnonzero(counts == 1):
                old = selected[int(np.flatnonzero(blocked[int(row)])[0])]
                new = batch[int(row)]
                target = (state-{old}) | {new}
                assert target in lookup and target != state
                moves.append(dict(removed=old, added=new, target=lookup[target]))
            total_pairs += len(batch)*367
        results.append(dict(index=index, moves=moves, blocker_histogram=dict(sorted(histogram.items()))))
    directed = sum(len(row['moves']) for row in results)
    assert directed == metadata['directed_edges']
    seen = {lookup[seed]}
    queue = deque(seen)
    while queue:
        u = queue.popleft()
        for move in results[u]['moves']:
            v = move['target']
            assert dict(removed=move['added'], added=move['removed'], target=u) in results[v]['moves']
            if v not in seen:
                seen.add(v)
                queue.append(v)
    assert len(seen) == len(states)
    core = frozenset.intersection(*states)
    support = frozenset.union(*states)
    result = dict(states=len(states), directed_edges=directed, core_size=len(core), support_size=len(support),
                  component_sha256=metadata['component_sha256'], component_file_sha256=sha(args.component),
                  seed_sha256=sha(args.seed), checker_sha256=sha(__file__),
                  direct_witness_pairs=len(states)*67161, direct_outside_word_pairs=total_pairs,
                  connected=True, closed_under_all_one_for_one_exchanges=True, immediate_augmentation=False,
                  core_words=sorted(core), variable_words=sorted(support-core), results=results,
                  scope='Complete maximal367 one-for-one component, verified locally from coordinate differences. No global bound, external replay, or literature-novelty claim.')
    args.output.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('results', 'core_words', 'variable_words')}), flush=True)


if __name__ == '__main__':
    main()
