"""Retain slices from integral LP repairs, including sub-367 codes, and recombine.

Search and replay use separate graph builders and seven-walk recurrences.
A finite-library optimum is not a global C7^5 upper bound.
"""
import argparse
from collections import Counter
import json
from pathlib import Path
import time

from check_orbit_two_new import digest, check_words
from search_aligned_slice_library import exact_graph
from search_slice_library import cycle_optimum


def build(base_path, screens, verifications, minimum):
    source = json.loads(base_path.read_text())
    slices = [tuple(map(tuple, sl)) for sl in source['slices']]
    library = {sl:i for i, sl in enumerate(slices)}
    assert len(library) == len(slices)
    parents = list(source['parents']); inputs = []; seen = set(); codes = []
    for screen_path, verified_path in zip(screens, verifications, strict=True):
        r = json.loads(screen_path.read_text()); v = json.loads(verified_path.read_text())
        assert r['status'] == 'complete' and v['screen_sha256'] == digest(screen_path)
        assert r['input_sha256'] == v['input_sha256'] == digest(r['input'])
        assert v['complete_projection_pools_checked']
        inputs.append(dict(screen=str(screen_path), sha256=digest(screen_path),
                           verification=str(verified_path), verification_sha256=digest(verified_path)))
        for row in r['results']:
            if row.get('full_size', 0) < minimum:
                continue
            words = tuple(sorted(tuple(map(int, w)) for w in row['words']))
            assert len(words) == row['full_size']
            check_words(words)
            if words in seen:
                continue
            seen.add(words)
            label = f'LP:{screen_path.name}:{row["index"]}'
            codes.append(dict(label=label, size=len(words), screen=str(screen_path), index=row['index']))
            for axis in range(5):
                layers = []
                for value in range(7):
                    sl = tuple(sorted(w[:axis]+w[axis+1:] for w in words if w[axis] == value))
                    assert sl
                    if sl not in library:
                        library[sl] = len(slices); slices.append(sl)
                    layers.append(library[sl])
                parents.append(dict(parent=label, axis=axis, slices=layers))
    return slices, parents, inputs, codes


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--base', type=Path, required=True)
    p.add_argument('--screen', type=Path, nargs='+', required=True)
    p.add_argument('--verification', type=Path, nargs='+', required=True)
    p.add_argument('--minimum', type=int, default=360)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--replay', type=Path)
    args = p.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    if len(args.screen) != len(args.verification) or not 1 <= args.minimum <= 368:
        p.error('Matching screen/verification paths and a valid threshold required')
    began = time.monotonic()
    slices, parents, inputs, codes = build(args.base, args.screen, args.verification, args.minimum)
    weights = list(map(len, slices))
    print(json.dumps(dict(stage='graph', slices=len(slices), repair_codes=len(codes))), flush=True)
    if args.replay:
        from check_aligned_slice_library import geometry, matrix_optimum
        r = json.loads(args.replay.read_text())
        assert r['base_sha256'] == digest(args.base) and r['inputs'] == inputs and r['minimum'] == args.minimum
        assert r['slices'] == [[list(w) for w in sl] for sl in slices]
        assert r['parents'] == parents and r['codes'] == codes and r['weights'] == weights
        adj, pair_count = geometry(r['slices'])
        assert adj == r['adjacency']
        best = matrix_optimum(weights, adj)
        assert best == r['best']
        cycle = r['cycle']; assert len(cycle) == 7
        assert all(cycle[(i+1)%7] in adj[cycle[i]] for i in range(7))
        words = sorted((i, *w) for i, v in enumerate(cycle) for w in slices[v])
        pairs = check_words(words)
        assert len(words) == best
        assert r['witness'] == [''.join(map(str, w)) for w in words]
        result = dict(input_sha256=digest(args.replay), source_sha256=digest(__file__),
            slices=len(slices), edges=sum(map(len, adj))//2, parents=len(parents),
            within_slice_pairs=pair_count, full_witness_pairs=pairs, optimum=best,
            target_witness_found=best >= 368, scope='Saved finite library only.')
    else:
        adj = exact_graph(slices)
        print(json.dumps(dict(stage='cycle', edges=sum(map(len, adj))//2)), flush=True)
        best, cycle = cycle_optimum(weights, adj)
        words = sorted((i, *w) for i, v in enumerate(cycle) for w in slices[v])
        pairs = check_words(words)
        assert len(words) == best >= 367
        result = dict(status='candidate_found' if best >= 368 else 'complete',
            base=str(args.base), base_sha256=digest(args.base), source_sha256=digest(__file__),
            inputs=inputs, minimum=args.minimum, codes=codes, parents=parents,
            slices=slices, weights=weights, adjacency=adj, best=best, cycle=cycle,
            witness=[''.join(map(str, w)) for w in words], verified_pairs=pairs,
            statistics=dict(slices=len(slices), edges=sum(map(len, adj))//2,
                repair_codes=len(codes), repair_sizes=dict(Counter(c['size'] for c in codes))),
            candidates=[dict(step=0, size=best, words=[''.join(map(str, w)) for w in words],
                verified_pairs=pairs)] if best >= 368 else [],
            scope='Only seven-layer assemblies of saved slices, including repairs below367; no global bound.')
    result['elapsed_seconds'] = time.monotonic()-began
    args.output.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('status','statistics','best','optimum','elapsed_seconds') if k in result}), flush=True)


if __name__ == '__main__':
    main()
