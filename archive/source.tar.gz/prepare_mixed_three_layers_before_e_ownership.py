"""Choose mixed four-layer paths and admit every word avoiding their fixed points.

Selection is a heuristic, not an exhaustive exclusion of four-layer exteriors.
Three layers start empty, and compatible additions to other layers are allowed.
All hints are actual seven-layer codes, independently checked in five dimensions.
"""
import argparse
from collections import Counter, defaultdict
from itertools import combinations, product
import json
from pathlib import Path

from search_aligned_slice_library import digest, encode
from search_slice_library import conflicts
from search_slice_orbits import IDENTITY, compose, moved
from search_slice_placements_exact import minus_shift, rotation_data
from search_slice_symmetries import transforms


def prepare(source, count):
    original = json.loads(Path(source['input']).read_text())
    assert digest(Path(source['input'])) == source['input_sha256']
    base, parents = original['slices'], original['parents']
    ts = transforms()
    templates = [[] for _ in base]
    for placement in source['placements']:
        perm, signs = ts[placement['transform']]
        g = (perm, signs, tuple(placement['shift']))
        for left, pos in placement['cross_edges']:
            templates[left].append((parents[placement['parent']]['slices'][pos], g))
    data = rotation_data(4)
    allowed_points = []
    for sl in base:
        forbidden = set()
        for w in sl:
            forbidden.update(product(*[((x-1) % 7, x, (x+1) % 7) for x in w]))
        allowed_points.append([w for w in data[0] if w not in forbidden])
    linear_allowed, candidates = {}, {}
    candidates_seen = 0
    for root in range(175):
        nodes, lookup, neighbors = [], {}, {}

        def node(b, g):
            words = tuple(sorted(moved(w, g) for w in base[b]))
            if words in lookup:
                return lookup[words]
            index = len(nodes)
            lookup[words] = index
            perm, signs, shift = g
            key = (b, perm, signs)
            if key not in linear_allowed:
                linear_allowed[key] = sum(1 << encode(moved(w, (perm, signs, (0, 0, 0, 0)))) for w in allowed_points[b])
            allowed = minus_shift(linear_allowed[key], tuple(-x % 7 for x in shift), data[1], data[2])
            nodes.append(dict(base=b, transform=g, words=words, mask=sum(1 << encode(w) for w in words), allowed=allowed))
            return index

        start = node(root, IDENTITY)
        scores = {start: len(base[root])}
        history = []
        for _ in range(3):
            newer, previous = {}, {}
            for u, score in scores.items():
                if u not in neighbors:
                    item = nodes[u]
                    neighbors[u] = sorted({node(b, compose(item['transform'], g)) for b, g in templates[item['base']]})
                for v in neighbors[u]:
                    value = score+len(nodes[v]['words'])
                    if value > newer.get(v, -1):
                        newer[v], previous[v] = value, u
            scores = newer
            history.append(previous)

        def path(v):
            result = [v]
            for previous in reversed(history):
                result.append(previous[result[-1]])
            return list(reversed(result))

        ordered = sorted(scores, key=lambda v: (-scores[v], v))
        for u in ordered:
            fixed_path = path(u)
            family_path = [parents[nodes[v]['base']//7]['parent'] for v in fixed_path]
            if len(set(family_path)) < 2:
                continue
            partner = next((v for v in ordered if nodes[v]['mask'] & nodes[u]['allowed'] == nodes[v]['mask']), None)
            if partner is None:
                continue
            full_size = scores[u]+scores[partner]-len(base[root])
            assert full_size <= 367
            if full_size < 365:
                continue
            candidates_seen += 1
            fixed = tuple(sorted(layer*2401+encode(w) for layer, v in enumerate(fixed_path) for w in nodes[v]['words']))
            closing_path = list(reversed(path(partner)[1:]))
            hint = sorted((layer+4)*2401+encode(w) for layer, v in enumerate(closing_path) for w in nodes[v]['words'])
            item = dict(root=root, fixed=list(fixed), hint=hint, initial_size=full_size,
                fixed_size=len(fixed), family_path=family_path,
                fixed_slices=[dict(base=nodes[v]['base'], transform=nodes[v]['transform']) for v in fixed_path],
                hint_slices=[dict(base=nodes[v]['base'], transform=nodes[v]['transform']) for v in closing_path])
            if fixed not in candidates or candidates[fixed]['initial_size'] < full_size:
                candidates[fixed] = item
        if root % 35 == 34:
            print(json.dumps(dict(roots=root+1, eligible_paths=candidates_seen, distinct_fixed_sets=len(candidates))), flush=True)
    # Round-robin by family mix, retained size, and first cut axis. This avoids
    # spending every slot on differently labelled copies of one high-weight path.
    groups = defaultdict(list)
    for row in candidates.values():
        key = (tuple(sorted(set(row['family_path']))), row['fixed_size'], parents[row['root']//7]['axis'])
        groups[key].append(row)
    for values in groups.values():
        values.sort(key=lambda row: (-row['initial_size'], row['fixed']))
    keys = sorted(groups, key=lambda key: (-groups[key][0]['initial_size'], -key[1], key))
    chosen = []
    depth = 0
    while len(chosen) < min(count, len(candidates)):
        for key in keys:
            if depth < len(groups[key]):
                chosen.append(groups[key][depth])
                if len(chosen) == count:
                    break
        depth += 1
    for index, row in enumerate(chosen):
        fixed_words = [tuple(v//7**i % 7 for i in range(4, -1, -1)) for v in row['fixed']]
        forbidden = set()
        for w in fixed_words:
            forbidden.update(sum(x*7**(4-i) for i, x in enumerate(u)) for u in product(*[((x-1) % 7, x, (x+1) % 7) for x in w]))
        row['pool'] = sorted(set(range(16807))-forbidden)
        full = row['fixed']+row['hint']
        words = [tuple(v//7**i % 7 for i in range(4, -1, -1)) for v in full]
        assert len(full) == len(set(full)) == row['initial_size'] and set(row['hint']) <= set(row['pool'])
        assert all(not conflicts(a, b) for a, b in combinations(words, 2))
        row.update(index=index, target=368-len(row['fixed']), verified_hint_pairs=len(full)*(len(full)-1)//2,
                   extra_candidates_in_fixed_layers=sum(v//2401 < 4 for v in row['pool']))
    stats = dict(roots=175, eligible_paths=candidates_seen, distinct_fixed_sets=len(candidates), selected=len(chosen),
        selection_groups=len(groups), selected_initial_sizes=dict(Counter(r['initial_size'] for r in chosen)))
    return chosen, stats


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path, required=True)
    p.add_argument('--coverage', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--count', type=int, default=24)
    args = p.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    if args.count < 1:
        p.error('Positive count required')
    source, coverage = json.loads(args.input.read_text()), json.loads(args.coverage.read_text())
    assert coverage['input_sha256'] == digest(args.input) and coverage['complete_relative_placement_coverage']
    assert coverage['transforms'] == source['count'] == 384
    jobs, stats = prepare(source, args.count)
    report = dict(status='prepared', input=str(args.input), input_sha256=digest(args.input),
        coverage=str(args.coverage), coverage_sha256=digest(args.coverage), source_sha256=digest(Path(__file__)),
        jobs=jobs, statistics=stats,
        scope='Selected mixed four-layer fixed sets; pool contains every compatible five-dimensional word, including additions to fixed layers. Selection is not exhaustive.')
    args.output.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(stats), flush=True)


if __name__ == '__main__':
    main()
