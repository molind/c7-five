"""Hinted core-domain search with a certified minimum improving radius.

For old free cardinality m, cap X at m+1 and use O+q*X<=(q+1)*m.
Here X is free cardinality and O is old free cardinality retained. The exact
parent must belong to the verified F component closed through radius q-1.
Additional O>=m-r caps the deletion radius; it preserves the old367 hint.
"""
import argparse
import gzip
import hashlib
from itertools import product
import json
from pathlib import Path
import struct
import time

import numpy as np
from scipy.sparse import csc_matrix, vstack

from check_two_slice_covers import closed
from search_core_regions import box_constraints, independence
from solve_hinted_blocker_trades import solve_binary_trade


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def bind_f9(proof_path,manifest_path,old):
    proof=json.loads(proof_path.read_text())
    assert proof['complete_atomic9'] and proof['nine_removal_augmentations_excluded']
    assert proof['width9_component_equals_width8'] and not proof['outside'] and not proof['improving']
    assert proof['next_state']==proof['states']==36
    checkers=list(Path(__file__).parent.glob('check_component_atomic9_incremental*.py'))
    assert any(sha(p)==proof['checker_sha256'] for p in checkers)
    visited=set()
    def validate(path):
        path=Path(path)
        if path in visited:return
        visited.add(path)
        if path.suffix!='.json':return
        data=json.loads(path.read_text())
        dependencies=data.get('dependencies',{}) if isinstance(data,dict) else {}
        if isinstance(dependencies,list):
            entries=dependencies
            dependencies={entry['path']:entry['sha256'] for entry in entries}
            assert len(dependencies)==len(entries)
        assert isinstance(dependencies,dict)
        for file,digest in dependencies.items():
            assert sha(file)==digest,file
            validate(Path(file))
    validate(proof_path)
    assert proof['dependencies'][str(manifest_path)]==sha(manifest_path)
    manifest=json.loads(manifest_path.read_text());source=Path(manifest['source'])
    assert proof['dependencies'][str(source)]==manifest['source_sha256']==sha(source)
    with gzip.open(source,'rt') as stream:
        header=json.loads(next(stream));states=[tuple(json.loads(line)) for line in stream]
    assert len(states)==len(set(states))==header['states']==manifest['states']==proof['states']
    assert all(s==tuple(sorted(set(s))) and len(s)==367 for s in states)
    digest=hashlib.sha256(b''.join(sorted(struct.pack('<367H',*s) for s in states))).hexdigest()
    assert digest==header['component_sha256']==manifest['component_sha256']
    parent_index=states.index(tuple(sorted(old)))
    return dict(minimum_improving_deletions=10,parent_component_index=parent_index,
        component_sha256=digest,transitively_checked_json_files=len([p for p in visited if p.suffix=='.json']),
        proof=str(proof_path),proof_sha256=sha(proof_path),manifest=str(manifest_path),manifest_sha256=sha(manifest_path),
        cache=str(source),cache_sha256=sha(source))


def radius_rows(initial,q,radius):
    initial=np.asarray(initial,dtype=float);assert np.all((initial==0)|(initial==1))
    m=int(initial.sum());assert 1<=q<=m+1 and 0<=radius<=m
    rows=csc_matrix(np.vstack((np.ones(len(initial)),initial,q*np.ones(len(initial))+initial)))
    lower=np.array([0,m-radius,0],dtype=float)
    upper=np.array([m+1,m,(q+1)*m],dtype=float)
    assert np.all(rows@initial>=lower) and np.all(rows@initial<=upper)
    return rows,lower,upper


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--domains',type=Path,required=True)
    p.add_argument('--case',type=int,required=True)
    p.add_argument('--base',type=Path,required=True)
    p.add_argument('--f9-proof',type=Path,required=True)
    p.add_argument('--f-manifest',type=Path,required=True)
    p.add_argument('--radii',type=int,nargs='+',default=[10,12,16,24])
    p.add_argument('--seconds',type=float,default=60)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();assert __debug__ and not args.output.exists() and args.seconds>0
    assert len(args.radii)==len(set(args.radii)) and all(r>=10 for r in args.radii)
    data=json.loads(args.domains.read_text());assert all(sha(f)==h for f,h in data['dependencies'].items())
    region=data['rows'][args.case];assert region['ordinal']==args.case
    base=json.loads(args.base.read_text());assert sha(base['input'])==base['input_sha256']
    parents=json.loads(Path(base['input']).read_text())['bases']
    core=set(parents[0]['words'])&set(parents[1]['words']);assert len(core)==315 and core==set(base['fixed'])
    old=set(parents[1]['words']);assert independence(sorted(old))==67161
    binding=bind_f9(args.f9_proof,args.f_manifest,old);q=binding['minimum_improving_deletions']
    omitted=set(region['omitted']);assert omitted<=core and len(omitted)==len(region['omitted'])
    fixed=sorted(core-omitted);pool=sorted(set(range(16807))-set().union(*(closed(v) for v in fixed)))
    assert pool==region['pool'] and set(fixed)<=old<=set(fixed)|set(pool)
    initial=np.array([float(v in old) for v in pool]);m=int(initial.sum());target=m+1
    assert m+len(fixed)==367 and target==region['target'] and max(args.radii)<=m
    coords=np.array(list(product(range(7),repeat=5)),dtype=np.int16)
    corners=np.array(list(product((0,1),repeat=5)));powers=np.array([2401,343,49,7,1])
    boxes=box_constraints(pool,coords,corners,powers).tocsc()
    blocker_counts=np.array([len((closed(v)&old)-{v}) for v in pool])
    dependencies={str(args.domains):sha(args.domains),str(args.base):sha(args.base),base['input']:sha(base['input']),
        str(args.f9_proof):sha(args.f9_proof),str(args.f_manifest):sha(args.f_manifest),binding['cache']:binding['cache_sha256']}
    for name in ('check_two_slice_covers.py','search_core_regions.py','solve_hinted_blocker_trades.py'):
        path=Path(__file__).with_name(name);dependencies[str(path)]=sha(path)
    out=dict(status='running',case=args.case,fixed=fixed,pool=pool,parent_words=sorted(old),target=target,
        radius_binding=binding,requested_radii=args.radii,seconds_per_query=args.seconds,rows=[],candidates=[],
        source_sha256=sha(__file__),dependencies=dependencies,
        scope='Recorded complete core domain and specified deletion radii. F9 authorizes q10; timeout is unknown, solver optimality is not a proof log.')
    began=time.monotonic()
    def save():
        out['seconds']=time.monotonic()-began;args.output.write_text(json.dumps(out,indent=2)+'\n')
    save()
    for radius in args.radii:
        extra,lo,hi=radius_rows(initial,q,radius)
        matrix=vstack((boxes,extra),format='csc')
        lower=np.r_[np.zeros(boxes.shape[0]),lo];upper=np.r_[np.ones(boxes.shape[0]),hi]
        variable_upper=(blocker_counts<=radius).astype(float)
        result,values=solve_binary_trade(matrix,lower,upper,-np.ones(len(pool)),initial,args.seconds,-target,variable_upper)
        row=dict(radius=radius,extra_lower=lo.tolist(),extra_upper=hi.tolist(),
            excluded_words=[v for v,x in zip(pool,variable_upper) if not x],solver=result)
        if values is not None:
            words=sorted(fixed+[v for v,x in zip(pool,values) if x]);checks=independence(words)
            removed=sorted(old-set(words));added=sorted(set(words)-old)
            assert 367<=len(words)<=368 and len(removed)<=radius
            assert len(words)==367 or len(removed)>=q
            row.update(words=words,size=len(words),pair_checks=checks,removed=removed,added=added)
            out['candidates'].append(dict(step=radius,size=len(words),words=coords[words].tolist(),pair_checks=checks))
            if len(words)==368:
                assert checks==67528;out['verified368']=words;out['status']='verified_improvement'
        out['rows'].append(row);save()
        print(dict(radius=radius,pruned_words=len(row['excluded_words']),size=row.get('size'),solver=result),flush=True)
        if out['status']=='verified_improvement':break
    else:out['status']='complete_bounded_queries'
    save()


if __name__=='__main__':main()
