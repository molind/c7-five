"""Check the posted DFS against exhaustive subsets on small abstract graphs.

This tests the DFS only; it does not replay the 367-word d=5 exhaustion.
"""
import ast
import hashlib
import itertools
import json
from pathlib import Path
import random
import time


SOURCE = Path(__file__).parent / 'sources/fabius-43487-d5-posted.py'
EXPECTED = '08e23b05574aaff4fd50f86c406b95ea5eb774fa6bc8428524d9e341c46c0c18'


def main():
    raw = SOURCE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == EXPECTED
    parsed = ast.parse(raw)
    dfs = next(n for n in parsed.body if isinstance(n, ast.FunctionDef) and n.name == 'dfs')
    kernel = compile(ast.Module(body=[dfs], type_ignores=[]), str(SOURCE), 'exec')
    rng = random.Random(43487)
    sat = unsat = 0
    for case in range(600):
        n = rng.randrange(1, 11)
        d = rng.randrange(1, 5)
        blockers = [rng.randrange(1 << 6) for _ in range(n)]
        compatible = [[False] * n for _ in range(n)]
        for i in range(n):
            for j in range(i):
                compatible[i][j] = compatible[j][i] = bool(rng.randrange(2))
        # Independent oracle uses explicit sets and pair predicates, not DFS masks.
        expected = False
        for subset in itertools.combinations(range(n), d + 1):
            union = set()
            for i in subset:
                union.update(j for j in range(6) if blockers[i] & (1 << j))
            if len(union) <= d and all(compatible[i][j] for i, j in itertools.combinations(subset, 2)):
                expected = True
                break
        ns = dict(D=d, CB=blockers,
                  COMP=[sum(1 << j for j in range(n) if compatible[i][j]) for i in range(n)],
                  nodes_started=0, nodes_completed=0, last_branch=(),
                  next_ckpt=float('inf'), deadline=float('inf'), time=time,
                  ckpt=lambda tag: None, Deadline=TimeoutError)
        exec(kernel, ns)
        result = ns['dfs'](0, [], 0, (1 << n) - 1)
        assert (result is not None) == expected, case
        if result is not None:
            assert len(result) == d + 1 and len(set(result)) == d + 1
            assert all(compatible[i][j] for i, j in itertools.combinations(result, 2))
            union = set()
            for i in result:
                union.update(j for j in range(6) if blockers[i] & (1 << j))
            assert len(union) <= d
            sat += 1
        else:
            assert ns['nodes_started'] == ns['nodes_completed']
            unsat += 1
    report = dict(source_bytes=len(raw), source_sha256=EXPECTED, seed=43487,
                  controls=600, witness_cases=sat, exhausted_cases=unsat,
                  scope='Posted DFS only, versus exhaustive subsets on small abstract graphs; not full C7 d5 exhaustion')
    target = Path(__file__).with_name('fabius-dfs-controls.json')
    target.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report))


if __name__ == '__main__':
    main()
