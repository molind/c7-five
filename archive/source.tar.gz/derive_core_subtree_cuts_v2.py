"""Derive binary exclusion clauses from already verified, closed subtrees.

Version 2 accepts the checked v7 leaf proofs, including a model that already
contains earlier subtree clauses. The input model digest remains an exact premise.

Every clause excludes inside=1/outside=0 in the same fixed-core/radius/target
domain as its input proof. Unknown and unvisited children never count as closed.
Resolution removes an outside word only when an earlier positive clause proves
that word must already be absent under the current inside assumptions.
"""
import argparse
import hashlib
import json
from pathlib import Path


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def key(row):
    return tuple(row['inside']), tuple(row['outside'])


def maximal_closed(tree, certified):
    rows = tree['rows']
    positions = {key(row): i for i, row in enumerate(rows)}
    assert len(positions) == len(rows) and key(rows[0]) == ((), ())
    closed, parents, leaves = set(), {}, {}
    for i in reversed(range(len(rows))):
        row = rows[i]
        inside, outside = key(row)
        if 'branch' in row:
            v = row['branch']
            children = [positions.get((inside + (v,), outside)),
                        positions.get((inside, outside + (v,)))]
            for child in children:
                if child is not None:
                    assert child > i and child not in parents
                    parents[child] = i
            if all(child in closed for child in children):
                closed.add(i)
                leaves[i] = sorted(leaves[children[0]] + leaves[children[1]])
        elif i in certified or row['status'] == 'exact_conflict_or_radius':
            closed.add(i)
            leaves[i] = [i]
    roots = sorted(i for i in closed if parents.get(i) not in closed)
    covered = [v for i in roots for v in leaves[i]]
    assert len(covered) == len(set(covered))
    assert set(certified) <= set(covered)
    return [(i, leaves[i]) for i in roots]


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--verification', type=Path, action='append', required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    assert __debug__ and not args.output.exists()
    clauses, dependencies, identity = [], {}, None
    checker = Path(__file__).with_name('check_core_branch_certificates_v7.py')
    for path in args.verification:
        proof = json.loads(path.read_text())
        assert proof['passed'] and proof['checker_sha256'] == sha(checker)
        assert proof['root_partition_replayed']
        assert all(sha(f) == h for f, h in proof['dependencies'].items())
        bundles = []
        for f in proof['dependencies']:
            if Path(f).suffix == '.json':
                d = json.loads(Path(f).read_text())
                if isinstance(d, dict) and d.get('status') == 'complete_attempt' and 'tree' in d:
                    bundles.append((f, d))
        assert len(bundles) == 1
        bundle_path, bundle = bundles[0]
        assert all(sha(f) == h for f, h in bundle['dependencies'].items())
        tree_path = bundle['tree']
        assert proof['dependencies'][tree_path] == sha(tree_path)
        tree = json.loads(Path(tree_path).read_text())
        assert tree['status'] == 'bounded_attempt_complete'
        assert len(tree['rows']) == proof['nodes']
        assert all(sha(f) == h for f, h in tree['dependencies'].items())
        current = {k: tree[k] for k in ('input', 'radius', 'target_model_sha256')}
        if identity is None:
            identity = current
        assert current == identity
        certified = {r['tree_index'] for r in bundle['rows'] if r['certificate'] is not None}
        assert len(certified) == proof['integer_certified_leaves']
        for index, leaves in maximal_closed(tree, certified):
            node = tree['rows'][index]
            clauses.append(dict(verification=str(path), tree=tree_path, root_index=index,
                                checked_leaves=leaves, inside=sorted(node['inside']),
                                original_outside=sorted(node['outside']), outside=sorted(node['outside']),
                                resolutions=[]))
        dependencies.update({str(path): sha(path), tree_path: sha(tree_path), bundle_path: sha(bundle_path)})
    changed = True
    while changed:
        changed = False
        positive = [(i, set(c['inside'])) for i, c in enumerate(clauses) if not c['outside']]
        for c in clauses:
            inside = set(c['inside'])
            for word in c['outside'][:]:
                parents = [i for i, words in positive if word in words and words <= inside | {word}]
                if parents:
                    c['outside'].remove(word)
                    c['resolutions'].append(dict(removed=word, positive_clause=parents[0]))
                    changed = True
    dependencies[str(checker)] = sha(checker)
    out = dict(status='derived', **identity, target=368, clauses=clauses,
               positive_clauses=sum(not c['outside'] for c in clauses),
               removed_outside_literals=sum(len(c['resolutions']) for c in clauses),
               source_sha256=sha(__file__), dependencies=dependencies,
               scope='Binary clauses for this exact fixed-core/radius/target model only. Conditional on the listed checked partial-tree proofs; no global bound.')
    args.output.write_text(json.dumps(out, indent=2) + '\n')
    print({k: v for k, v in out.items() if k not in ('clauses', 'dependencies', 'scope')})


if __name__ == '__main__':
    main()
