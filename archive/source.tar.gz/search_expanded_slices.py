"""Search a four-slice exterior with learned exclusions from closed three-slice domains.

If a verified old exterior E forbids size368, a size368 set retaining the new
exterior F must omit a word in E-F. These rows preserve every target witness,
but need not preserve367-word sets. Compare both models with bounded native MIP.
"""
import argparse
import copy
import hashlib
from itertools import combinations
import json
from pathlib import Path
import time

from check_two_slice_covers import HERE, WORDS, closed, conflict
from check_cylinder_covers import check_entries
from probe_rank_branches import bound, characterize, CAPACITIES
from search_sparse_cylinders import prepare, solve_native, check_solution


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--axis', type=int, choices=range(5), default=4)
    parser.add_argument('--start', type=int, choices=range(7), default=3)
    parser.add_argument('--lp-seconds', type=float, default=20)
    parser.add_argument('--mip-seconds', type=float, default=90)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    if min(args.lp_seconds, args.mip_seconds) <= 0:
        parser.error('Positive limits required')
    began = time.monotonic()
    seed = {int(w, 7) for w in (HERE/'family-d-seed-words.txt').read_text().split()}
    assert len(seed) == 367 and all(not conflict(a, b) for a, b in combinations(seed, 2))
    fixed = sorted(v for v in seed if (WORDS[v][args.axis]-args.start) % 7 >= 4)
    pool = sorted(set(range(7**5))-set().union(*(closed(v) for v in fixed)))
    # Check the full domain through coordinate differences, separately from closed().
    import numpy as np
    words = np.array(WORDS)
    available = np.ones(len(words), dtype=bool)
    for v in fixed:
        delta = (words-words[v]) % 7
        available &= ~np.all((delta == 0) | (delta == 1) | (delta == 6), axis=1)
    assert np.flatnonzero(available).tolist() == pool
    report = dict(status='building', axis=args.axis, start=args.start, width=4, fixed=fixed, pool=pool,
                  full_target=368, candidates=[], searches=[], learned_cuts=[],
                  source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  scope='One complete four-slice fixed-exterior domain. Only directly checked constructions are success; bounded MIP failures exclude nothing.')

    def save():
        report['elapsed_seconds'] = time.monotonic()-began
        temporary = args.output.with_name(args.output.name+'.tmp')
        temporary.write_text(json.dumps(report, indent=2)+'\n')
        temporary.replace(args.output)

    save()
    cache = {tuple(r['projection']): r for r in json.loads((HERE/'three-slice-screen-sep21/cubic-probes.json').read_text())['results']}
    root = bound(pool, cache, args.lp_seconds, 50)
    report['root'] = root
    if 'certificate' not in root:
        report['status'] = 'root_unresolved'
        save()
        return
    candidate = characterize(root, fixed, 368)
    if candidate:
        report['candidates'].append(candidate | {'phase':'root'})
        if candidate['size'] >= 368:
            report['status'] = 'candidate_found'
            save()
            return
    source = root | dict(axis=args.axis, start=args.start, width=4, fixed=fixed,
                         target=367-len(fixed), capacity_sequence=CAPACITIES)
    model = prepare(source)
    learned_model = copy.deepcopy(model)
    local = {v:i for i,v in enumerate(pool)}
    # Import only root certificates, freshly replayed here. No numerical bound
    # or unverified saved Boolean is sufficient to derive a learned clause.
    for path in sorted((HERE/'three-slice-screen-sep21').glob('axis*-start*.json')):
        old = json.loads(path.read_text())
        if old['status'] != 0:
            continue
        cert = old['certificate']
        if len(old['fixed'])+cert['total_units']//cert['denominator'] >= 368:
            continue
        old_fixed = {v for v in seed if (WORDS[v][old['axis']]-old['start']) % 7 >= 3}
        assert old['width'] == 3 and sorted(old_fixed) == old['fixed']
        old_pool = sorted(set(range(7**5))-set().union(*(closed(v) for v in old_fixed)))
        assert old_pool == old['pool'] and not old.get('published_cube_dependency')
        total, den = check_entries(cert, old_pool, CAPACITIES)
        assert total < (368-len(old_fixed))*den
        remaining = sorted(old_fixed-set(fixed))
        assert remaining and set(remaining) <= set(pool)
        members = [local[v] for v in remaining]
        learned_model['members'].append(members)
        learned_model['capacities'].append(len(members)-1)
        report['learned_cuts'].append(dict(file=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                                           vertices=remaining, capacity=len(remaining)-1,
                                           old_fixed_size=len(old_fixed), total_units=total, denominator=den))
    assert len(report['learned_cuts']) == 27
    hint = set(model['hint'])
    missed = [set(row['vertices']) for row in report['learned_cuts']]
    removed = []
    while missed:
        choices = set().union(*missed)
        vertex = min(choices, key=lambda v:(-sum(v in c for c in missed), v))
        hint.remove(local[vertex])
        removed.append(vertex)
        missed = [c for c in missed if vertex not in c]
    learned_model['hint'] = sorted(hint)
    for row, cap in zip(learned_model['members'], learned_model['capacities']):
        assert len(hint & set(row)) <= cap
    report.update(status='searching', model=model, learned_hint_removed=removed,
                  learned_start_size=len(fixed)+len(hint), original_start_size=367)
    save()
    print(json.dumps(dict(axis=args.axis, start=args.start, width=4, fixed=len(fixed), pool=len(pool),
                          full_upper=root['full_upper'], learned_cuts=len(report['learned_cuts']),
                          learned_start_size=report['learned_start_size'])), flush=True)
    for name, current in [('learned', learned_model), ('original', model)]:
        result = solve_native(current, 368-len(fixed), args.mip_seconds)
        check_solution(current, result)
        report['searches'].append(dict(variant=name, result=result))
        if result.get('full_size',0) >= 367:
            chosen = sorted(fixed+result['vertices'])
            candidate = dict(words=[''.join(map(str,WORDS[v])) for v in chosen], size=len(chosen),
                             verified_pairs=len(chosen)*(len(chosen)-1)//2, phase=name)
            report['candidates'].append(candidate)
        save()
        print(json.dumps(dict(variant=name, status=result['status'], full_size=result.get('full_size'),
                              nodes=result.get('nodes'), seconds=result['seconds'])), flush=True)
        if result.get('full_size',0) >= 368:
            report['status'] = 'candidate_found'
            save()
            return
    report['status'] = 'bounded_search_complete'
    save()


if __name__ == '__main__':
    main()
