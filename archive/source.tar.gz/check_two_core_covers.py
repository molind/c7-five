"""Stdlib replay of inherited and fresh two-core cover certificates."""
import hashlib,json
from fractions import Fraction
from itertools import product,combinations
from pathlib import Path
from check_one_core_covers import check
ROOT=Path(__file__).resolve().parent

def main():
    source=ROOT/'one-core-fractional-results.json';old=json.loads(source.read_text())
    data=json.loads((ROOT/'two-core-cover-results.json').read_text())
    assert hashlib.sha256(source.read_bytes()).hexdigest()==data['one_core_sha256']
    assert data['core']==old['core'];core=list(map(tuple,data['core']));assert len(core)==308
    for a,b in combinations(core,2):assert any((x-y)%7 in (2,3,4,5) for x,y in zip(a,b))
    blockers={w:0 for w in product(range(7),repeat=5)}
    for i,w in enumerate(core):
        for v in product(*[((x-1)%7,x,(x+1)%7) for x in w]):blockers[v]|=1<<i
    buckets={}
    for w,m in blockers.items():
        if m.bit_count()<=2:buckets.setdefault(m,set()).add(w)
    free=buckets[0];totals={}
    for row in old['cases']:
        i=row['core_index'];totals[i]=check(row['direct']['certificate'],free|buckets[1<<i],61)
    fresh={tuple(r['pair']):r['cover'] for r in data['fresh_covers']};seen=set();maximum=Fraction(0)
    for row in data['screen']:
        i,j=row['pair'];assert 0<=i<j<308 and (i,j) not in seen;seen.add((i,j))
        base=row['base'];assert base in (i,j);other=j if base==i else i
        additional=buckets[1<<other]|buckets.get((1<<i)|(1<<j),set())
        origin=row['origin'];assert len(origin)==5 and all(type(x) is int and 0<=x<7 for x in origin)
        box=set(product(*[(x,(x+1)%7) for x in origin]));assert additional<=box
        assert totals[base]+1<62;maximum=max(maximum,totals[base]+1)
    for row in data['residual']:
        i,j=row['pair'];assert 0<=i<j<308 and (i,j) not in seen;seen.add((i,j))
        allowed=free|buckets[1<<i]|buckets[1<<j]|buckets.get((1<<i)|(1<<j),set())
        assert core[i] in allowed and core[j] in allowed and len(allowed)==row['candidates']
        bound=check(fresh[(i,j)]['certificate'],allowed,62);maximum=max(maximum,bound)
    assert seen==set(combinations(range(308),2)) and len(fresh)==len(data['residual'])
    # Also verify the replacement quarter-weight certificate in a separate reader.
    probe=json.loads((ROOT/'one-core-denominator-probe.json').read_text());i=probe['core_index']
    quarter=probe['probes'][0]['certificate'];bound=check(quarter,free|buckets[1<<i],61)
    assert bound==Fraction(241,4) and all(4%Fraction(x['weight']).denominator==0 for x in quarter)
    result={'pairs_checked':len(seen),'inherited':len(data['screen']),'fresh':len(fresh),
            'max_bound':str(maximum),'all_bounds_below_62':True,'quarter_replacement_verified':True,
            'certificate_sha256':hashlib.sha256((ROOT/'two-core-cover-results.json').read_bytes()).hexdigest()}
    (ROOT/'two-core-cover-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
