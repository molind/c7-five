"""Exactly complete366 backbones extracted from selected two-edge points.

Try all four endpoint removals and then zero or one further nonfixed omission.
Search every independent pair/triple in the resulting full compatible pool.
This is a finite neighborhood check, not a global upper bound.
"""
import argparse
import hashlib
from itertools import combinations,product
import json
from pathlib import Path
import time

import numpy as np
from check_two_slice_covers import closed,conflict,WORDS
from check_cardinality_projection import conflicts
from search_cardinality_projection import pair_edges


def cavity_search(args,bases,origins,report):
    """Solve selected whole-space replacement cavities; retain no old fixed cap."""
    from probe_local_rank_cuts import query
    report['scope']='Selected geometric cavities of full366 backbones. Each pool contains every word compatible with its retained exterior. No old fixed words or overlap cap are imposed. Native exhausted results cover only their listed cavities; timeouts remain open.'
    report['original_fixed']=report.pop('fixed')
    report['cavity_sizes']=sorted(set(args.cavity_sizes));report['milliseconds']=args.milliseconds
    report['kernel_sha256']=hashlib.sha256((Path(__file__).parent/'slice_clique').read_bytes()).hexdigest()
    report['query_source_sha256']=hashlib.sha256((Path(__file__).parent/'probe_local_rank_cuts.py').read_bytes()).hexdigest()
    report['queries']=[];began=time.monotonic();seen=set();candidates={}
    coordinates=np.array(WORDS)
    for bi,base in enumerate(sorted(bases)):
        points=coordinates[list(base)];centers=coordinates[origins[base]]
        delta=(points[:,None,:]-centers[None,:,:])%7
        distances=np.square(np.minimum(delta,7-delta)).sum(axis=2)
        counts=np.zeros(16807,dtype=np.int16)
        for v in base:counts[list(closed(v))]+=1
        report['bases'].append(dict(words=list(base),centers=origins[base]))
        for mode,priority in [('nearest',distances.min(axis=1)),('bridge',distances.sum(axis=1))]:
            order=sorted(range(366),key=lambda i:(int(priority[i]),base[i]))
            for k in report['cavity_sizes']:
                omitted=sorted(base[i] for i in order[:k]);retained=sorted(set(base)-set(omitted))
                if tuple(retained) in seen:continue
                seen.add(tuple(retained));remaining=counts.copy()
                for v in omitted:remaining[list(closed(v))]-=1
                pool=np.flatnonzero(remaining==0).tolist()
                assert set(omitted)<=set(pool)
                result,edges=query(pool,k+2,args.milliseconds,set(omitted))
                full=sorted(retained+[pool[i] for i in result['vertices']])
                assert len(full)==len(set(full)) and not conflicts(full)
                row=dict(base=bi,mode=mode,omitted=omitted,pool=pool,target=k+2,edges=edges,result=result,full_words=full)
                report['queries'].append(row)
                if len(full)>=367:candidates[tuple(full)]=dict(size=len(full),vertices=full,query=len(report['queries'])-1)
                report['candidates']=list(candidates.values());report['seconds']=time.monotonic()-began
                report['status']='verified_target' if len(full)>=368 else 'running'
                temp=args.output.with_suffix('.tmp');temp.write_text(json.dumps(report,separators=(',',':'))+'\n');temp.replace(args.output)
                print(json.dumps(dict(base=bi,mode=mode,omissions=k,pool=len(pool),full_size=len(full),status=result['status'],nodes=result['nodes'])),flush=True)
                if len(full)>=368:return
    report['status']='bounded_cavity_search_complete';report['seconds']=time.monotonic()-began
    args.output.write_text(json.dumps(report,separators=(',',':'))+'\n')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--cavity-sizes',type=int,nargs='+',help='Selected geometric omissions from each full366 backbone')
    p.add_argument('--milliseconds',type=int,default=250)
    a=p.parse_args();assert __debug__ and not a.output.exists()
    assert a.milliseconds>0
    assert a.cavity_sizes is None or all(1<=k<366 for k in a.cavity_sizes)
    source=json.loads(a.input.read_text());fixed=set(source['fixed']);bases=set();origins={}
    for run in source['runs']:
        words=run['best_words'];edges=pair_edges(words)
        assert len(words)==len(set(words))==368 and len(edges)==run['best_conflicts']
        if len(edges)!=2 or set(edges[0])&set(edges[1]):continue
        for endpoints in product(*edges):
            omitted={words[i] for i in endpoints}
            assert not omitted&fixed
            base=tuple(v for v in words if v not in omitted)
            assert len(base)==366 and not conflicts(list(base));bases.add(base)
            origins.setdefault(base,sorted(omitted))
    report=dict(status='running',input=str(a.input),input_sha256=hashlib.sha256(a.input.read_bytes()).hexdigest(),
                source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),fixed=sorted(fixed),
                bases=[],candidates=[],scope=__doc__)
    began=time.monotonic();total_tests=0;total_domains=0
    def save():
        report['seconds']=time.monotonic()-began;report['subset_tests']=total_tests;report['domains']=total_domains
        temp=a.output.with_suffix('.tmp');temp.write_text(json.dumps(report,indent=2)+'\n');temp.replace(a.output)
    if a.cavity_sizes is not None:
        cavity_search(a,bases,origins,report)
        return
    for base in sorted(bases):
        counts=np.zeros(16807,dtype=np.int16)
        for v in base:counts[list(closed(v))]+=1
        free=set(np.flatnonzero(counts==0).tolist())
        record=dict(words=list(base),free=sorted(free),queries=[]);report['bases'].append(record)
        for omitted in [None]+sorted(set(base)-fixed):
            available=sorted(free if omitted is None else free|{v for v in closed(omitted) if counts[v]==1})
            need=2+int(omitted is not None);tests=0;found=None
            for selected in combinations(available,need):
                tests+=1
                if all(not conflict(u,v) for u,v in combinations(selected,2)):
                    found=selected;break
            record['queries'].append(dict(omitted=omitted,pool=available,target=need,subsets_tested=tests,found=list(found) if found else None))
            total_domains+=1;total_tests+=tests
            if found:
                full=sorted((set(base)-({omitted} if omitted is not None else set()))|set(found))
                assert len(full)==368 and fixed<=set(full) and not conflicts(full)
                report['candidates'].append(dict(size=368,vertices=full,pair_checks=67528))
                report['status']='verified_target';save();print(json.dumps(dict(status=report['status'],domains=total_domains)),flush=True);return
        save()
    report['status']='complete';save()
    print(json.dumps(dict(status=report['status'],bases=len(bases),domains=total_domains,subset_tests=total_tests,seconds=report['seconds'])),flush=True)


if __name__=='__main__':main()
