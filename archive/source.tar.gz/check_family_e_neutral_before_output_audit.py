"""Replay pinned E neutral searches, with a separate exhaustive pair check."""
import hashlib
from itertools import combinations, product
import json
from pathlib import Path
import subprocess

import numpy as np

from check_exchange_dfs import graph_text
from neutral_exchanges import enumerate_exchanges

HERE = Path(__file__).parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    output = HERE/'family-e-neutral-verification-sep21.json'
    if output.exists():
        raise FileExistsError(output)
    prior_path = HERE/'family-e-exchange-verification-sep21.json'
    prior = json.loads(prior_path.read_text())
    seed_path = HERE/'family-e-seed-words.txt'
    assert sha(seed_path) == prior['seed_sha256']
    assert sha(HERE/'exchange_dfs') == prior['kernel_sha256']
    seed = np.array([list(map(int, w)) for w in seed_path.read_text().split()], dtype=np.int16)
    occupied = set(map(tuple, seed.tolist()))
    outside = np.array([w for w in product(range(7), repeat=5) if w not in occupied], dtype=np.int16)
    masks = []
    for begin in range(0, len(outside), 128):
        d = (outside[begin:begin+128, None, :]-seed[None, :, :]) % 7
        blocked = np.all((d == 0) | (d == 1) | (d == 6), axis=2)
        masks.extend(sum(1 << int(j) for j in np.flatnonzero(row)) for row in blocked)
    assert all(masks)
    rows = []
    candidates = []
    for radius in range(2, 7):
        path = HERE/f'family-e-neutral{radius}-sep21-raw.json'
        raw = json.loads(path.read_text())
        graph_path = HERE/f'family-e-exchange-d{radius}-sep21.txt'
        verified = next(row for row in prior['results'] if row['radius'] == radius)
        assert sha(graph_path) == verified['graph_sha256']
        assert raw['status'] == 'exhausted' and raw['nodes_started'] == raw['nodes_completed']
        assert raw['enumerate_neutral'] and raw['subset_index'] and raw['root_prefix'] == -1
        assert not any(raw[k] for k in ('noncore_bound', 'anchor_bounds', 'pair_bounds'))
        order = sorted((i for i, mask in enumerate(masks) if mask.bit_count() <= radius),
                       key=lambda i: masks[i].bit_count())
        pool, blockers = outside[order], [masks[i] for i in order]
        assert len(pool) == verified['pool']
        compatible = []
        with graph_path.open() as f:
            n, bw, d = map(int, next(f).split())
            assert n == len(pool) and bw == 6 and d == radius
            for i, line in enumerate(f):
                values = [int(v, 16) for v in line.split()]
                assert len(values) == bw+(n+63)//64
                assert sum(v << (64*j) for j, v in enumerate(values[:bw])) == blockers[i]
                compatible.append(sum(v << (64*j) for j, v in enumerate(values[bw:])))
        assert len(compatible) == n
        reference = None
        if radius == 2:
            expected = dict(neutral=[], improving=[])
            for i, j in combinations(range(n), 2):
                delta = (pool[i]-pool[j]) % 7
                independent = bool(np.any((delta >= 2) & (delta <= 5)))
                assert bool(compatible[i] >> j & 1) == independent
                size = (blockers[i] | blockers[j]).bit_count()
                if size <= radius and independent:
                    expected['neutral' if size == radius else 'improving'].append([i, j])
            assert all(raw[k] == expected[k] for k in expected)
            reference = dict(method='All unordered pairs, direct coordinate differences', pairs=n*(n-1)//2)
        elif radius <= 4:
            expected = enumerate_exchanges(blockers, compatible, radius, seconds=60)
            assert expected['status'] == 'exhausted'
            assert all(raw[k] == list(map(list, expected[k])) for k in ('neutral', 'improving'))
            reference = dict(method='Existing Python traversal', visits=expected['candidate_visits'])
        for kind in ('neutral', 'improving'):
            assert len(raw[kind]) == len(set(map(tuple, raw[kind])))
            for chosen in raw[kind]:
                assert len(chosen) == len(set(chosen)) == radius
                mask = 0
                for i in chosen:
                    mask |= blockers[i]
                assert (mask.bit_count() == radius) == (kind == 'neutral')
                removed = {tuple(w) for j, w in enumerate(seed.tolist()) if mask >> j & 1}
                target = sorted((occupied-removed) | {tuple(pool[i].tolist()) for i in chosen})
                assert len(target) == 367+radius-len(removed)
                assert all(any((x-y) % 7 in (2, 3, 4, 5) for x, y in zip(a, b))
                           for a, b in combinations(target, 2))
                candidates.append(dict(step=len(candidates), radius=radius, kind=kind,
                    size=len(target), words=[''.join(map(str, w)) for w in target],
                    verified_pairs=len(target)*(len(target)-1)//2))
        rows.append(dict(radius=radius, pool=n, neutral=len(raw['neutral']), improving=len(raw['improving']),
            nodes_completed=raw['nodes_completed'], seconds=raw['seconds'], reference=reference,
            result_sha256=sha(path), graph_sha256=sha(graph_path)))
        print(json.dumps(rows[-1]), flush=True)
    # Positive witnesses across the entire supported radius range exercise
    # neutral and improving output; this is not evidence about the C7 universe.
    controls = []
    for radius in range(1, 9):
        for improvement in (False, True):
            blockers = [1 << (64*i) for i in range(radius)]
            if improvement:
                blockers[-1] = 0
            compatible = [((1 << radius)-1) ^ (1 << i) for i in range(radius)]
            run = subprocess.run([str((HERE/'exchange_dfs').resolve()), '5', '--subset', '--neutral'],
                input=graph_text(blockers, compatible, radius, 8), capture_output=True,
                text=True, check=True, timeout=7)
            r = json.loads(run.stdout)
            kind = 'improving' if improvement else 'neutral'
            assert r['status'] == 'exhausted' and r[kind] == [list(range(radius))]
            assert r['neutral' if improvement else 'improving'] == []
            controls.append(dict(radius=radius, kind=kind, passed=True))
    report = dict(seed_sha256=sha(seed_path), kernel_sha256=sha(HERE/'exchange_dfs'),
        kernel_source_sha256=sha(HERE/'exchange_dfs.cpp'), checker_sha256=sha(Path(__file__)),
        prior_graph_verification_sha256=sha(prior_path), results=rows, candidates=candidates,
        positive_controls=controls,
        scope='Complete pinned-seed neutral/improving enumerations for radii2..6. Graph compatibility rows inherit the separately rebuilt, hash-bound graph check. Direct pair replay at radius2; separate Python traversal at radii3/4. No global bound.')
    output.write_text(json.dumps(report, indent=2)+'\n')


if __name__ == '__main__':
    main()
