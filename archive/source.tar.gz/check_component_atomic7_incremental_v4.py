"""Replay incremental seven-removal scans and the one-word-parent reduction.

Roots are scanned in full. Every other state has an earlier one-word parent,
whose complete radius-seven coverage is obtained inductively. Novel results must
retain the parent's inserted word and insert a word conflicting with its deleted
word. The exact known cache is separately certified closed through width six.
The multi-parent variant applies the same necessary conditions for every
earlier one-word neighbor. Their coverage follows from the same gap-free
induction; all of these conditions must hold for an unaccounted target.
The joint variant precomputes inclusion-minimal unions satisfying all critical
conditions. A bounded preprocessing fallback keeps the complete independent
conditions; neither mode changes the per-trade critical requirements.
The compatible variant strengthens joint requirements using compatible atomic
critical covers, with bounded fallback to the original necessary relaxation.
Native exhaustion remains tested computation, not formal proof-tree replay.
"""
import argparse
import gzip
import hashlib
from itertools import combinations, product
import json
from pathlib import Path
import struct

import numpy as np


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--runs', required=True, nargs='+', type=Path)
    p.add_argument('--width-six-proof', required=True, type=Path)
    p.add_argument('--output', required=True, type=Path)
    args = p.parse_args()
    assert __debug__ and not args.output.exists()
    here = Path(__file__).resolve().parent
    sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
    dependencies = {}

    def read(path):
        dependencies[str(path)] = sha(path)
        return json.loads(Path(path).read_text())

    records = [(path, read(path)) for path in args.runs]
    first = records[0][1]
    manifest = read(first['input_manifest'])
    assert manifest['source_sha256'] == sha(manifest['source'])
    assert manifest['input_sha256'] == sha(manifest['input'])
    with gzip.open(manifest['source'], 'rt') as f:
        meta = json.loads(next(f))
        states = [json.loads(line) for line in f]
    assert all(len(s) == 367 and s == sorted(set(s)) and all(type(v) is int and 0 <= v < 16807 for v in s) for s in states)
    keys = [struct.pack('<367H', *s) for s in states]
    assert len(keys) == len(set(keys)) == manifest['states'] == meta['states']
    assert hashlib.sha256(b''.join(sorted(keys))).hexdigest() == manifest['component_sha256'] == meta['component_sha256']
    reference = read(manifest['reference_manifest'])
    assert sha(manifest['reference_manifest']) == manifest['reference_manifest_sha256']
    assert sha(reference['source']) == reference['source_sha256']
    assert manifest['preparer_sha256'] == sha(here/'prepare_component_forest.py')
    with gzip.open(reference['source'], 'rt') as f:
        reference_meta = json.loads(next(f))
        reference_states = [json.loads(line) for line in f]
    assert reference_meta['states'] == reference['states'] == len(states)
    assert reference_meta['component_sha256'] == reference['component_sha256'] == manifest['component_sha256']
    assert sorted(manifest['source_indices']) == list(range(len(states)))
    assert states == [reference_states[i] for i in manifest['source_indices']]
    parents = manifest['parents']
    assert len(parents) == len(states)
    for i, parent in enumerate(parents):
        assert type(parent) is int and -1 <= parent < i
        if parent >= 0:
            assert len(set(states[i])-set(states[parent])) == len(set(states[parent])-set(states[i])) == 1
    assert parents.count(-1) == manifest['roots']
    expected = f'{len(states)} 367\n' + '\n'.join(' '.join(map(str, s)) for s in states) + '\nparents\n' + ' '.join(map(str, parents)) + '\n' 
    assert Path(manifest['input']).read_text() == expected
    known = set(keys)
    state_masks = [sum(1 << word for word in state) for state in states]
    previous = read(args.width_six_proof)
    checkers = ['check_component_atomic6.py', 'check_component_atomic6_incremental.py', 'check_component_atomic6_incremental_v2.py']
    matching = [name for name in checkers if sha(here/name) == previous['checker_sha256']]
    assert len(matching) == 1
    checker = matching[0]
    assert all(sha(p) == h for p, h in previous['dependencies'].items())
    assert previous['dependencies'][reference['source']] == reference['source_sha256']
    assert previous['states'] == len(states) and not previous['outside']
    assert previous['complete_atomic6'] and previous['six_removal_augmentations_excluded']
    assert previous['width6_component_equals_width5']
    dependencies[str(here/checker)] = sha(here/checker)
    coords = np.array(list(product(range(7), repeat=5)), dtype=np.int16)
    neutral = internal = improving = pairs = 0
    seen = set()
    outside = []
    cursor = 0
    full_states = anchored_states = 0
    intervals = []
    for path, run in records:
        assert not outside, 'Do not silently continue after a reported escape or improvement'
        assert run['status'] == 'complete'
        kernel = Path(run['kernel']).resolve()
        assert kernel.parent == here and kernel.name in ('scan_component_atomic7_incremental', 'scan_component_atomic7_incremental_stack', 'scan_component_atomic7_incremental_multi', 'scan_component_atomic7_incremental_joint','scan_component_atomic7_incremental_compatible')
        assert run['kernel_sha256'] == sha(kernel)
        assert run['kernel_source_sha256'] == sha(kernel.with_suffix('.cpp'))
        dependencies[str(kernel)] = sha(kernel)
        dependencies[str(kernel.with_suffix('.cpp'))] = sha(kernel.with_suffix('.cpp'))
        assert run['manifest_sha256'] == sha(first['input_manifest']) == sha(run['input_manifest'])
        assert run['input_sha256'] == manifest['input_sha256']
        assert run['native_sha256'] == sha(run['native_file'])
        dependencies[run['native_file']] = sha(run['native_file'])
        rows = [json.loads(line) for line in Path(run['native_file']).read_text().splitlines()]
        assert rows == run['rows']
        footer = rows[-1]
        assert footer['status'] in ('timeout', 'exhausted', 'escape', 'witness')
        assert all(type(footer[k]) is int for k in ('start_state', 'next_state', 'total_states'))
        assert footer['start_state'] == cursor and cursor <= footer['next_state'] <= len(states) == footer['total_states']
        assert int(run['command'][2]) == cursor
        expected_roots = sum(parents[i] < 0 for i in range(cursor, footer['next_state']))
        assert footer['full_states'] == expected_roots
        assert footer['anchored_states'] == footer['next_state'] - cursor - expected_roots
        full_states += footer['full_states']
        anchored_states += footer['anchored_states']
        if footer['status'] == 'exhausted':
            assert footer['next_state'] == len(states)
        count = dict(neutral=0, internal_neutral=0, improving=0)
        emitted = []
        for row in rows[:-1]:
            index = row['state']
            assert type(index) is int and cursor <= index < footer['next_state']
            if row['event'] == 'candidate':
                emitted.append(row)
                continue
            assert row['event'] == 'trade'
            old = states[index]
            removed, added = row['removed'], row['added']
            assert len(removed) == len(set(removed)) == 7 and set(removed) <= set(old)
            assert len(added) == len(set(added)) in (7, 8) and not set(added) & set(old)
            assert all(type(v) is int and 0 <= v < 16807 for v in added)
            identity = index, tuple(sorted(added))
            assert identity not in seen
            seen.add(identity)
            delta = (coords[added, None, :] - coords[np.array(old)[None, :], :]) % 7
            bad = np.all((delta == 0) | (delta == 1) | (delta == 6), axis=2)
            blockers = [set(old[i] for i in np.flatnonzero(r)) for r in bad]
            assert all(2 <= len(b) <= 7 for b in blockers)
            assert set.union(*blockers) == set(removed)
            if parents[index] >= 0:
                # The parent has smaller index and is already covered by this
                # gap-free prefix; an earlier escape would have stopped it.
                parent = states[parents[index]]
                inserted = (set(old)-set(parent)).pop()
                deleted = (set(parent)-set(old)).pop()
                assert inserted not in removed
                changes = (coords[added] - coords[deleted]) % 7
                assert np.any(np.all((changes == 0) | (changes == 1) | (changes == 6), axis=1))
            if kernel.name in ('scan_component_atomic7_incremental_multi','scan_component_atomic7_incremental_joint','scan_component_atomic7_incremental_compatible'):
                for j in range(index):
                    if (state_masks[j] ^ state_masks[index]).bit_count() != 2:
                        continue
                    parent = states[j]
                    inserted = (set(old)-set(parent)).pop()
                    deleted = (set(parent)-set(old)).pop()
                    assert inserted not in removed
                    changes = (coords[added] - coords[deleted]) % 7
                    assert np.any(np.all((changes == 0) | (changes == 1) | (changes == 6), axis=1))
            for size in range(2, 7):
                assert all(len(set.union(*subset)) > size for subset in combinations(blockers, size))
            words = sorted((set(old) - set(removed)) | set(added))
            points = coords[words]
            diff = (points[:, None, :] - points[None, :, :]) % 7
            conflicts = np.all((diff == 0) | (diff == 1) | (diff == 6), axis=2)
            assert np.array_equal(conflicts, np.eye(len(words), dtype=bool))
            pairs += len(words)*(len(words)-1)//2
            if len(words) == 367:
                count['neutral'] += 1
                if struct.pack('<367H', *words) in known:
                    count['internal_neutral'] += 1
                else:
                    outside.append(dict(state=index, words=words))
            else:
                assert len(words) == 368
                count['improving'] += 1
                outside.append(dict(state=index, words=words))
        assert all(count[k] == footer[k] for k in count)
        assert bool(outside) == bool(emitted)
        for row in emitted:
            assert row['size'] == len(row['words'])
            assert dict(state=row['state'], words=row['words']) in outside
        if footer['status'] in ('escape', 'witness'):
            assert outside and (footer['status'] == 'witness') == bool(count['improving'])
        else:
            assert not outside
        neutral += count['neutral']
        internal += count['internal_neutral']
        improving += count['improving']
        intervals.append(dict(file=str(path), start=cursor, end=footer['next_state'], status=footer['status']))
        cursor = footer['next_state']

    for file in [manifest['source'], manifest['input'], reference['source'], here/'prepare_component_forest.py']:
        dependencies[str(file)] = sha(file)
    complete = cursor == len(states) and intervals[-1]['status'] == 'exhausted' and not outside
    out = dict(checker_sha256=sha(__file__), scope=__doc__, dependencies=dependencies,
               states=len(states), intervals=intervals, next_state=cursor, checked_trades=len(seen),
               pair_checks=pairs, neutral=neutral, internal_neutral=internal, improving=improving, outside=outside,
               start_state=0, full_states=full_states, anchored_states=anchored_states, complete_atomic7=complete, width7_component_equals_width6=complete,
               seven_removal_augmentations_excluded=complete)
    args.output.write_text(json.dumps(out, indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k not in ('scope','dependencies','outside','intervals')}))


if __name__ == '__main__':
    main()
