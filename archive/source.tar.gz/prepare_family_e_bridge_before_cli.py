"""Release a growing region around the 21-word C/E exchange.

This is a constructive heuristic, not exhaustive neighborhood coverage.
Each job admits all words compatible with its retained common-core points.
"""
import hashlib
from itertools import combinations
import json
from pathlib import Path

import numpy as np

from check_two_slice_covers import WORDS, closed, conflict

HERE = Path(__file__).parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    output = HERE/'family-e-bridge-domains-sep21.json'
    if output.exists():
        raise FileExistsError(output)
    source_path = HERE/'mixed-three-layer-search02-sep21.json'
    source = json.loads(source_path.read_text())
    m = source['model']
    parent = set(m['fixed']) | {m['pool'][i] for i in m['hint']}
    seed_path = HERE/'family-e-seed-words.txt'
    seed = {int(w, 7) for w in seed_path.read_text().split()}
    assert seed == {int(w, 7) for w in source['candidates'][0]['words']}
    for s in (parent, seed):
        assert len(s) == 367 and all(not conflict(a, b) for a, b in combinations(s, 2))
    common = sorted(parent & seed)
    assert len(common) == 346
    neighborhoods = {v: np.array(list(closed(v)), dtype=int) for v in common}
    counts = np.zeros(16807, dtype=np.int16)
    for ns in neighborhoods.values():
        counts[ns] += 1
    fixed = set(common)
    schedule = [0, 4, 8, 16, 32, 64, 96]
    jobs, removals = [], []
    for removed in range(max(schedule)+1):
        if removed in schedule:
            pool = np.flatnonzero(counts == 0).tolist()
            hint = sorted(seed-fixed)
            assert set(hint) <= set(pool) and parent-fixed <= set(pool)
            jobs.append(dict(index=len(jobs), released_common_points=removed,
                fixed=sorted(fixed), fixed_size=len(fixed), pool=pool, hint=hint,
                initial_size=367, target=368-len(fixed), verified_hint_pairs=67161))
        if removed == max(schedule):
            break
        # First maximize newly released words. Then prefer words one further
        # deletion away. Vertex ID only breaks exact ties reproducibly.
        scores = {v: (int(np.count_nonzero(counts[neighborhoods[v]] == 1)),
                      int(np.count_nonzero(counts[neighborhoods[v]] == 2))) for v in fixed}
        chosen = max(fixed, key=lambda v: (*scores[v], -v))
        removals.append(dict(vertex=chosen, newly_released=scores[chosen][0],
                             one_more_deletion=scores[chosen][1]))
        fixed.remove(chosen)
        counts[neighborhoods[chosen]] -= 1
        assert counts.min() >= 0
    report = dict(status='prepared', source=str(source_path), source_sha256=sha(source_path),
        seed_sha256=sha(seed_path), generator_sha256=sha(Path(__file__)),
        parent=sorted(parent), seed=sorted(seed), common=common, schedule=schedule,
        removals=removals, jobs=jobs,
        scope='Seven heuristic nested fixed exteriors, each with the entire compatible universe. Not an exhaustive search over exteriors.')
    output.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps([dict(index=j['index'], released=j['released_common_points'],
                          fixed=j['fixed_size'], pool=len(j['pool'])) for j in jobs]), flush=True)


if __name__ == '__main__':
    main()
