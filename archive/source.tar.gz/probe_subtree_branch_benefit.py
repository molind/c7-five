"""Re-solve recorded stronger-model leaves in the preceding relaxation.

A feasible fractional point is diagnostic, not an integer construction. Join
these paths to exact stronger-model leaf certificates before claiming pruning.
"""
import argparse
import json
from pathlib import Path
import time

import numpy as np
from scipy.optimize._highspy import _core as high

from search_core_with_subtree_cuts import append_before_radius
from solve_core_radius_ipm import load_radius_model, model_digest, build_model
from search_core_ipm_branches_v2 import propagate
from check_core_subtree_cuts import verify, sha
from check_two_slice_covers import closed


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--tree', type=Path, required=True)
    p.add_argument('--count', type=int, default=8)
    p.add_argument('--seconds', type=float, default=15)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    assert __debug__ and not args.output.exists() and args.count > 0 and args.seconds > 0
    tree = json.loads(args.tree.read_text())
    assert tree['status'] == 'bounded_attempt_complete'
    assert all(sha(f) == h for f, h in tree['dependencies'].items())
    cuts = verify(tree['subtree_cuts'])
    data, matrix, lower, upper, variable_upper, _ = load_radius_model(Path(tree['input']), tree['radius'])
    pos = {v: j for j, v in enumerate(data['pool'])}
    exclusion = json.loads(Path(tree['domain_exclusion']).read_text())
    matrix, lower, upper = append_before_radius(matrix, lower, upper,
        [[(pos[v], 1) for v in exclusion['inside']], [(pos[v], 1) for v in tree['common_core_cut_words']]],
        [0, 0], [exclusion['inequality_upper'], tree['common_core_cut_upper']])
    lower[-3] = data['target']
    assert model_digest(matrix, lower, upper, variable_upper) == cuts['target_model_sha256']
    pool, old = set(data['pool']), set(data['parent_words'])-set(data['fixed'])
    neighborhoods = {v: closed(v) & pool for v in pool}
    selected = [(i, row) for i, row in enumerate(tree['rows']) if row['status'] == 'Infeasible'][:args.count]
    out = dict(status='running', tree=str(args.tree), old_model_sha256=cuts['target_model_sha256'],
               source_sha256=sha(__file__), dependencies={str(args.tree): sha(args.tree)}, rows=[])
    for name in ('search_core_with_subtree_cuts.py', 'solve_core_radius_ipm.py',
                 'search_core_ipm_branches_v2.py', 'check_core_subtree_cuts.py', 'check_two_slice_covers.py'):
        path = Path(__file__).with_name(name)
        out['dependencies'][str(path)] = sha(path)
    def save():
        args.output.write_text(json.dumps(out, indent=2) + '\n')
    save()
    for index, row in selected:
        forbidden = propagate(pool, old, neighborhoods, row['inside'], row['outside'], tree['radius'])
        assert forbidden is not None
        lo, hi = np.zeros(len(pos)), variable_upper.copy()
        for v in row['inside']:
            lo[pos[v]] = 1
        for v in forbidden:
            hi[pos[v]] = 0
        solver = high._Highs()
        for k, v in dict(output_flag=False, solver='ipm', run_crossover='off', time_limit=args.seconds).items():
            assert solver.setOptionValue(k, v) == high.HighsStatus.kOk
        model = build_model(matrix, lower, upper, hi, False)
        model.col_lower_ = lo
        assert solver.passModel(model) == high.HighsStatus.kOk
        began = time.monotonic()
        solver.run()
        info, solution = solver.getInfo(), solver.getSolution()
        result = dict(tree_index=index, inside=row['inside'], outside=row['outside'],
                      status=solver.modelStatusToString(solver.getModelStatus()),
                      seconds=time.monotonic()-began, feasible_fractional_point=False)
        if solution.value_valid and info.primal_solution_status == high.kSolutionStatusFeasible:
            x = np.asarray(solution.col_value)
            activity = matrix @ x
            if np.all(np.isfinite(x)) and np.all(np.isfinite(activity)):
                violation = float(max(0, np.max(lo-x), np.max(x-hi), np.max(lower-activity), np.max(activity-upper)))
                result['maximum_violation'] = violation
                if violation <= 1e-6:
                    result.update(feasible_fractional_point=True, values=x.tolist(),
                                  fractional_variables=int(np.count_nonzero(np.abs(x-np.rint(x)) > 1e-6)))
        out['rows'].append(result)
        save()
        print({k: v for k, v in result.items() if k not in ('inside', 'outside', 'values')}, flush=True)
    out['status'] = 'complete_attempt'
    out['scope'] = __doc__
    save()


if __name__ == '__main__':
    main()
