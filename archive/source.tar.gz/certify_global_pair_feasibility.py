"""An exact rational feasible point at target368 for the global pair relaxation.

This is an obstruction to proving no368 with these particular constraints;
it is NOT a code, a lower bound on alpha, or evidence that368 exists.
Fourier eigenvalues lie in Q(t), t=2cos(2pi/7), t^3+t^2-2t-1=0.
"""
import hashlib
import json
from fractions import Fraction as Q
from pathlib import Path

import numpy as np
from probe_global_pair_lp import model,cylinder_rows
from probe_global_pair_triangles import triangle_matrix


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    r=Path(__file__).parent; source=r/'global-pair-triangle-lp-sep22.json';p=r/'global-pair-target368-rational-sep22.json';assert not p.exists()
    saved=json.loads(source.read_text());row=next(x for x in saved['rows'] if x['dimension']==5)
    coords,profiles,index,weights,F,bounds=model(5);assert row['profiles_order']==[list(v) for v in profiles]
    x=np.array(row['values']);zero=profiles.index((5,0,0,0));alpha=367/(float(weights@x)-1)
    x*=alpha;x[zero]=1
    f=[Q(int(round(v*10**12)),10**12) for v in x]
    slack=Q(368)-sum(int(w)*v for w,v in zip(weights,f))
    adjustable=next(i for i,v in enumerate(f) if Q(1,10)<v<Q(9,10) and i!=zero)
    f[adjustable]+=slack/int(weights[adjustable])
    assert sum(int(w)*v for w,v in zip(weights,f))==368
    assert all(Q(lo)<=v<=Q(hi) for v,(lo,hi) in zip(f,bounds))
    cyl,cup,labels=cylinder_rows(5,coords,index,len(profiles));tri,keys=triangle_matrix(5,profiles)
    assert all(sum(int(a)*v for a,v in zip(line,f))<=int(b) for line,b in zip(cyl,cup))
    assert all(f[i]+f[j]-f[k]<=1 for i,j,k in keys)
    low,high=Q(1),Q(2)
    poly=lambda z:z**3+z**2-2*z-1
    for _ in range(80):
        mid=(low+high)/2
        if poly(mid)<0:low=mid
        else:high=mid
    assert poly(low)<0<poly(high)
    eigen=[]
    for counts in profiles:
        frequency=np.repeat(np.arange(4),counts);phase=(coords@frequency)%7
        sums=[sum((f[int(i)] for i in index[phase==k]),Q(0)) for k in range(7)]
        assert sums[1]==sums[6] and sums[2]==sums[5] and sums[3]==sums[4]
        a=sums[0]-2*sums[2]+sums[3];b=sums[1]-sums[3];c=sums[2]-sums[3]
        lower=a+b*(low if b>=0 else high)+c*(low*low if c>=0 else high*high)
        assert lower>0
        eigen.append(dict(coefficients=[str(a),str(b),str(c)],lower=str(lower)))
    out=dict(passed=True,target=368,dimension=5,profiles=[list(v) for v in profiles],values=[str(v) for v in f],root_interval=[str(low),str(high)],eigenvalues=eigen,minimum_eigenvalue_lower_approx=float(min(Q(x['lower']) for x in eigen)),triangle_rows=len(keys),cylinder_rows=len(cup),source_sha256=sha(__file__),dependencies={str(r/n):sha(r/n) for n in ['global-pair-triangle-lp-sep22.json','probe_global_pair_lp.py','probe_global_pair_triangles.py']},scope=__doc__)
    p.write_text(json.dumps(out,indent=2)+'\n');print({k:v for k,v in out.items() if k not in ['profiles','values','root_interval','eigenvalues','dependencies','scope']})


if __name__=='__main__':main()
