"""Direct checks of orbit independence and the projected-clique encoding."""

import itertools
import json
import random

from search_exchanges import verify
from search_translation_orbits import ROOT, directions, solve


def main():
    rng = random.Random(20260915)
    # Enumerate every one-dimensional subgroup independently: normalize its
    # first nonzero coordinate to 1, without reducing by graph symmetries.
    def canonical(v):
        return min(tuple(sorted(min(k*x%7,(-k*x)%7) for x in v))
                   for k in range(1,7))
    valid_classes = set()
    subgroup_count = 0
    for pivot in range(5):
        for suffix in itertools.product(range(7),repeat=4-pivot):
            v = (0,)*pivot+(1,)+suffix
            if all(any(t*x%7 in (2,3,4,5) for x in v) for t in range(1,7)):
                subgroup_count += 1
                valid_classes.add(canonical(v))
    assert subgroup_count == 2680
    assert valid_classes == {canonical(v) for v in directions()}
    cases = []
    for direction in directions():
        orbit = [[(t*x)%7 for x in direction] for t in range(7)]
        verify(orbit)
        project = lambda w: tuple((w[j]-direction[j]*w[0])%7 for j in range(1,5))
        differences = {project(w) for w in itertools.product((-1,0,1),repeat=5)}
        corners = [project(w) for w in itertools.product((0,1),repeat=5)]
        clique_differences = {tuple((a-b)%7 for a,b in zip(u,v))
                              for u in corners for v in corners}
        assert differences == clique_differences
        assert len(corners) == len(set(corners)) == 32
        for _ in range(100):
            u = [0]+[rng.randrange(7) for _ in range(4)]
            v = [0]+[rng.randrange(7) for _ in range(4)]
            # Test actual confusability with all seven words of the other
            # orbit; translation permits fixing this orbit's representative.
            actual = any(all((x-y-t*d)%7 in (0,1,6)
                             for x,y,d in zip(u,v,direction)) for t in range(7))
            projected = tuple((x-y)%7 for x,y in zip(u[1:],v[1:])) in differences
            assert actual == projected
        positive = solve(direction,3,2)
        assert positive['status']=='sat',positive
        verify(positive['words'])
        cases.append({'direction':direction,'orbit_size':7,
                      'quotient_vertices':2401,'conflict_degree':len(differences)-1,
                      'direct_pair_comparisons':100,
                      'positive_control_words':positive['word_count']})
    impossible = solve(next(directions()),2402,2)
    assert impossible['status']=='unsat',impossible
    report = {'passed':True,'classes':len(cases),'cases':cases,
              'independent_cyclic_subgroups':subgroup_count,
              'classification_exhaustively_checked':True,
              'impossible_cardinality_control':impossible['status']}
    (ROOT/'orbit-control-results.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__':
    main()
