"""Certify fractional clique-cover bounds for saved forbidden-core slice pools.

Run with .venv-lp/bin/python. Floating-point LP output is never an exclusion:
each accepted cover is rounded to integer units, repaired, and checked exactly.
The domain and conflicts are reconstructed directly from the word coordinates.
"""
import argparse
from collections import Counter
import hashlib
from itertools import combinations, product
import json
from pathlib import Path
import time

import numpy as np
import scipy
from scipy.optimize import linprog
from scipy.sparse import csc_matrix

HERE = Path(__file__).resolve().parent
DENOMINATOR = 1_000_000


def word(v):
    return tuple((v//(7**i)) % 7 for i in range(4, -1, -1))


def conflict(a, b):
    return all((x-y) % 7 in (0, 1, 6) for x, y in zip(a, b))


def build_cliques(pool):
    """Each word lies in 32 adjacent-pair boxes. Keep duplicate boxes once."""
    origins = {}
    for i, v in enumerate(pool):
        for origin in product(*[((x-1) % 7, x) for x in word(v)]):
            origins.setdefault(origin, []).append(i)
    unique = sorted(set(tuple(vs) for vs in origins.values()))
    covered = {pair for clique in unique for pair in combinations(clique, 2)}
    words = [word(v) for v in pool]
    actual = {(i, j) for i, j in combinations(range(len(pool)), 2) if conflict(words[i], words[j])}
    assert covered == actual
    return unique


def solve_cover(pool, cliques, forbidden, seconds):
    banned = pool.index(forbidden)
    order = [i for i in range(len(pool)) if i != banned]
    local = {v: i for i, v in enumerate(order)}
    cs = sorted({tuple(local[v] for v in c if v != banned) for c in cliques} - {()})
    rows = [i for i, c in enumerate(cs) for _ in c]
    cols = [v for c in cs for v in c]
    matrix = csc_matrix((np.ones(len(rows)), (rows, cols)), shape=(len(cs), len(order)))
    began = time.monotonic()
    result = linprog(-np.ones(len(order)), A_ub=matrix, b_ub=np.ones(len(cs)),
                     bounds=(0, None), method='highs', options={'time_limit': seconds})
    row = dict(lp_status=int(result.status), message=result.message, seconds=time.monotonic()-began)
    if not result.success:
        row['status'] = 'unresolved'
        return row
    floating = np.maximum(0, -result.ineqlin.marginals)
    units = np.ceil(floating*DENOMINATOR).astype(np.int64)
    coverage = [0]*len(order)
    incident = [[] for _ in order]
    for i, c in enumerate(cs):
        for v in c:
            coverage[v] += int(units[i])
            incident[v].append(i)
    # Repair any numerical deficit using an actual clique containing the word.
    for v in range(len(order)):
        if coverage[v] < DENOMINATOR:
            c = incident[v][0]
            delta = DENOMINATOR-coverage[v]
            units[c] += delta
            for u in cs[c]:
                coverage[u] += delta
    total = sum(map(int, units))
    # Integer certificate, using global vertex IDs so verification is standalone.
    cover = [{'vertices': [pool[order[v]] for v in c], 'units': int(n)}
             for c, n in zip(cs, units) if n]
    exact = {pool[v]: 0 for v in order}
    for entry in cover:
        assert entry['units'] > 0
        ws = [word(v) for v in entry['vertices']]
        assert all(conflict(a, b) for a, b in combinations(ws, 2))
        for v in entry['vertices']:
            exact[v] += entry['units']
    assert min(exact.values()) >= DENOMINATOR and sum(e['units'] for e in cover) == total
    row.update(status='certified_cover', floating_bound=float(-result.fun), denominator=DENOMINATOR,
               total_units=total, integer_upper_bound=total//DENOMINATOR, cover=cover)
    return row


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--seconds', type=float, default=2)
    parser.add_argument('--limit', type=int, default=35)
    args = parser.parse_args()
    if args.seconds <= 0 or args.limit < 1:
        parser.error('Positive limits required')
    if args.output.exists():
        raise FileExistsError(args.output)
    source = json.loads(args.input.read_text())
    seed_path = HERE/'family-d-seed-words.txt'
    assert hashlib.sha256(seed_path.read_bytes()).hexdigest() == source['hashes'][seed_path.name]
    seed = [tuple(map(int, w)) for w in seed_path.read_text().split()]
    assert len(seed) == len(set(seed)) == 367 and all(not conflict(a, b) for a, b in combinations(seed, 2))
    loaded = {}
    report = dict(status='running', results=[], pools={}, scipy_version=scipy.__version__,
                  input_sha256=hashlib.sha256(args.input.read_bytes()).hexdigest(),
                  source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  scope='Integer clique covers bound only the exact saved allowed domains; no global bound.')
    began = time.monotonic()

    def save():
        report['elapsed_seconds'] = time.monotonic()-began
        report['statuses'] = dict(Counter(r['status'] for r in report['results']))
        tmp = args.output.with_name(args.output.name+'.tmp')
        tmp.write_text(json.dumps(report, indent=2)+'\n')
        tmp.replace(args.output)

    for job in source['results'][:args.limit]:
        key = job['pool_key']
        if key not in loaded:
            fixed = [w for w in seed if (w[job['axis']]-job['start']) % 7 >= 2]
            pool = source['pools'][key]['pool']
            assert fixed == list(map(tuple, source['pools'][key]['fixed']))
            # Check the entire universe, not only listed vertices.
            candidates = np.array(list(product(range(7), repeat=5)))
            allowed = np.ones(7**5, dtype=bool)
            for w in fixed:
                d = (candidates-np.array(w)) % 7
                allowed &= ~np.all((d == 0) | (d == 1) | (d == 6), axis=1)
            assert np.flatnonzero(allowed).tolist() == pool
            cs = build_cliques(pool)
            loaded[key] = pool, cs
            report['pools'][key] = dict(pool=pool, fixed_size=len(fixed), domain_verified=True, graph_verified=True)
        pool, cs = loaded[key]
        row = solve_cover(pool, cs, job['forbidden'], args.seconds)
        row.update(index=job['index'], pool_key=key, forbidden=job['forbidden'], target=job['target'],
                   prior_status=job['result']['status'])
        row['excludes_target'] = row['status'] == 'certified_cover' and row['total_units'] < job['target']*DENOMINATOR
        report['results'].append(row)
        save()
        print(json.dumps({k: v for k, v in row.items() if k != 'cover'}), flush=True)
    report['status'] = 'queries_complete'
    save()


if __name__ == '__main__':
    main()
