"""Integer replay of all full domains after three exact-core omissions.

Rebuilds all core blockers and all preceding covers. Enumerates every triple
to verify that the implicit rule plus explicit certificates leave no gap.
Does not invoke the generator, SciPy, or its containing-box routine.
"""
import argparse
import hashlib
from itertools import combinations, product
import json
from pathlib import Path

from check_common314_covers import decode, encode
from check_common313_covers import box_words, verify_cover


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();assert __debug__ and not args.output.exists()
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    d=json.loads(args.input.read_text());assert d['status']=='complete'
    assert all(sha(f)==h for f,h in d['dependencies'].items())
    pair=json.loads(Path(d['pair_covers']).read_text())
    single=json.loads(Path(pair['single_covers']).read_text())
    base=json.loads(Path(single['base_certificate']).read_text())
    assert all(sha(f)==h for f,h in pair['dependencies'].items())
    assert sha(single['base_certificate'])==single['base_sha256']
    assert sha(base['input'])==base['input_sha256']
    parents=json.loads(Path(base['input']).read_text())['bases']
    core=sorted(set(parents[0]['words'])&set(parents[1]['words']))
    assert core==sorted(base['fixed']) and len(core)==315
    blockers=[set() for _ in range(16807)]
    for v in core:
        for w in product(*[((x-1)%7,x,(x+1)%7) for x in decode(v)]):
            blockers[encode(w)].add(v)
    buckets={}
    for v,bk in enumerate(blockers):
        if len(bk)<=3:buckets.setdefault(tuple(sorted(bk)),set()).add(v)
    D=d['denominator'];assert type(D) is int and D==pair['denominator']==single['denominator']>0
    empty=buckets[()]
    single_totals={}
    assert [r['omitted'] for r in single['rows']]==core
    for r in single['rows']:
        i=r['omitted'];pool=empty|buckets[(i,)]
        assert pool==set(r['pool']) and len(pool)==len(r['pool'])
        total=verify_cover(pool,r['cover'],D);assert total==r['total_units']<54*D
        single_totals[i]=total
    pair_totals={}
    assert [tuple(r['omitted']) for r in pair['rows']]==list(combinations(core,2))
    for r in pair['rows']:
        i,j=r['omitted'];joint=buckets.get((i,j),set())
        if r['kind']=='extension':
            parent=r['parent_omission'];assert parent in (i,j)
            new=j if parent==i else i
            assert buckets[(new,)]|joint<=box_words(r['extra_box_origin'])
            total=single_totals[parent]+D
        else:
            assert r['kind']=='lp';pool=empty|buckets[(i,)]|buckets[(j,)]|joint
            assert pool==set(r['pool']) and len(pool)==len(r['pool'])
            total=verify_cover(pool,r['cover'],D)
        assert total==r['total_units']<55*D
        pair_totals[(i,j)]=total
    assert [r['word'] for r in d['singleton_boxes']]==core
    good=set()
    for r in d['singleton_boxes']:
        if r['origin'] is not None:
            assert buckets[(r['word'],)]<=box_words(r['origin'])
            good.add(r['word'])
    neighbors={i:set() for i in core}
    for key in buckets:
        if len(key)==2:
            i,j=key;neighbors[i].add(j);neighbors[j].add(i)
    hard=[];implicit=cases=0
    for i,j,k in combinations(core,3):
        cases+=1
        singleton_extension=(i in good and j not in neighbors[i] and k not in neighbors[i]) or \
            (j in good and i not in neighbors[j] and k not in neighbors[j]) or \
            (k in good and i not in neighbors[k] and j not in neighbors[k])
        if singleton_extension and (i,j,k) not in buckets:implicit+=1
        else:hard.append((i,j,k))
    assert cases==d['total_cases'] and implicit==d['implicit_cases']
    assert [tuple(r['omitted']) for r in d['rows']]==hard
    maximum=max(pair_totals.values())+D;extensions=lps=0;opened=[]
    for r in d['rows']:
        triple=tuple(r['omitted'])
        if r['kind']=='extension':
            parent=tuple(r['parent_omission'])
            assert parent in list(combinations(triple,2))
            new=(set(triple)-set(parent)).pop()
            admitted=set().union(*(buckets.get(key,set()) for size in range(1,4)
                for key in combinations(triple,size) if new in key))
            assert admitted<=box_words(r['extra_box_origin'])
            total=pair_totals[parent]+D;extensions+=1
        else:
            assert r['kind']=='lp'
            pool=set().union(*(buckets.get(key,set()) for size in range(4)
                for key in combinations(triple,size)))
            assert pool==set(r['pool']) and len(pool)==len(r['pool'])
            total=verify_cover(pool,r['cover'],D);lps+=1
        assert total==r['total_units']
        maximum=max(maximum,total)
        if total>=56*D:opened.append(triple)
    assert opened==[tuple(r['omitted']) for r in d['open_domains']]
    witness=base['witness'];assert len(witness)==len(set(witness))==367 and set(core)<=set(witness)
    pair_checks=0
    for a,b in combinations(witness,2):
        assert any((x-y)%7 in (2,3,4,5) for x,y in zip(decode(a),decode(b)))
        pair_checks+=1
    dependencies={str(args.input):sha(args.input),d['pair_covers']:sha(d['pair_covers']),
        pair['single_covers']:sha(pair['single_covers']),single['base_certificate']:sha(single['base_certificate']),
        base['input']:sha(base['input'])}
    for helper in ('check_common314_covers.py','check_common313_covers.py'):
        path=Path(__file__).with_name(helper);dependencies[str(path)]=sha(path)
    out=dict(passed=True,cases=cases,implicit=implicit,explicit_extensions=extensions,lp_covers=lps,
             open_domains=opened,maximum_total_units=maximum,denominator=D,witness_pair_checks=pair_checks,
             minimum_core_omissions_for368=4 if not opened else None,
             any368_retains_at_most_core_words=311 if not opened else None,
             checker_sha256=sha(__file__),dependencies=dependencies,
             scope='Exact315core only. If no open domain, every independent368set omits>=4corewords; no global bound.')
    args.output.write_text(json.dumps(out,indent=2)+'\n');print(out)


if __name__=='__main__':main()
