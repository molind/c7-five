"""Assemble a shared library from every screened placement touching an anchor.

Unlike the pair-cycle screen, one cross-edge is enough and all actual placements
are retained, including placements with the same anchor edge pattern. Seven-walk
optimization may combine any number of parents. FFT is only a discovery filter;
the resulting finite library and its compatibility graph are exact.
"""
import argparse
from collections import Counter
import hashlib
from itertools import combinations, product
import json
from pathlib import Path
import time

import numpy as np

from search_slice_library import conflicts, cycle_optimum
from search_slice_symmetries import transforms


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def encode(w):
    return sum(x * 7 ** (3-i) for i, x in enumerate(w))


def exact_graph(slices):
    points = list(product(range(7), repeat=4))
    neighborhoods = [sum(1 << encode(u) for u in product(
        *[((x-1) % 7, x, (x+1) % 7) for x in w])) for w in points]
    masks = [sum(1 << encode(w) for w in sl) for sl in slices]
    blocked = []
    for sl in slices:
        mask = 0
        for w in sl:
            mask |= neighborhoods[encode(w)]
        blocked.append(mask)
    adj = [[] for _ in slices]
    for i in range(len(slices)):
        for j in range(i):
            if not blocked[i] & masks[j]:
                adj[i].append(j)
                adj[j].append(i)
    return adj


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--verification', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--anchor', type=int, default=19)
    parser.add_argument('--count', type=int, default=384)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    if not 0 <= args.anchor < 25 or not 1 <= args.count <= 384:
        parser.error('Invalid anchor or transform count')
    source = json.loads(args.input.read_text())
    checked = json.loads(args.verification.read_text())
    assert checked['input_sha256'] == digest(args.input)
    assert source['best'] == 367 and not checked['target_witness_found']
    base = source['slices']
    parents = source['parents']
    assert len(base) == 175 and len(parents) == 25
    anchor = parents[args.anchor]['slices']
    shape = (7,) * 4
    blocked_spectra = []
    for v in anchor:
        mask = np.zeros(shape, dtype=np.int8)
        for w in base[v]:
            for u in product(*[((x-1) % 7, x, (x+1) % 7) for x in w]):
                mask[u] = 1
        blocked_spectra.append(np.fft.fftn(mask))
    shifts = list(product(range(7), repeat=4))
    library = {tuple(map(tuple, sl)): i for i, sl in enumerate(base)}
    assert len(library) == 175
    report = dict(status='running', input=str(args.input), input_sha256=digest(args.input),
        verification=str(args.verification), verification_sha256=digest(args.verification),
        source_sha256=digest(Path(__file__)), anchor=args.anchor, count=args.count,
        numpy_version=np.__version__, transforms=[], placements=[],
        scope='Exact finite-library optimum after numerical placement discovery; omitted placements are not excluded.')
    began = time.monotonic()

    def save():
        report['elapsed_seconds'] = time.monotonic() - began
        report['slices'] = list(library)
        temp = args.output.with_suffix('.tmp')
        temp.write_text(json.dumps(report, separators=(',', ':')) + '\n')
        temp.replace(args.output)

    save()
    for ti, (perm, signs) in enumerate(transforms()[:args.count]):
        moved = [np.array([[(signs[i]*w[perm[i]]) % 7 for i in range(4)]
                          for w in sl], dtype=np.int16) for sl in base]
        spectra = []
        for sl in moved:
            mask = np.zeros(shape, dtype=np.int8)
            mask[tuple(sl.T)] = 1
            spectra.append(np.fft.fftn(mask))
        row = dict(index=ti, pairs=25, placements=0, checked_edges=0, max_rounding_residual=0.0)
        for pi, parent in enumerate(parents):
            good = np.empty((7, 7, 2401), dtype=bool)
            for i in range(7):
                for j, v in enumerate(parent['slices']):
                    raw = np.fft.ifftn(blocked_spectra[i] * np.conj(spectra[v]))
                    rounded = np.rint(raw.real)
                    error = max(float(np.max(np.abs(raw.imag))), float(np.max(np.abs(raw.real-rounded))))
                    assert error < 1e-7 and np.min(rounded) >= 0
                    row['max_rounding_residual'] = max(row['max_rounding_residual'], error)
                    good[i, j] = rounded.reshape(-1) == 0
            for si in np.flatnonzero(np.any(good, axis=(0, 1))):
                shift = shifts[si]
                actual = [(moved[v] + np.array(shift, dtype=np.int16)) % 7 for v in parent['slices']]
                cross = np.argwhere(good[:, :, si]).tolist()
                for i, j in cross:
                    d = (np.array(base[anchor[i]], dtype=np.int16)[:, None, :] - actual[j][None, :, :]) % 7
                    assert not np.any(np.all((d == 0) | (d == 1) | (d == 6), axis=2))
                ids = []
                for sl in actual:
                    key = tuple(sorted(tuple(map(int, w)) for w in sl))
                    library.setdefault(key, len(library))
                    ids.append(library[key])
                report['placements'].append(dict(transform=ti, parent=pi, shift=list(shift),
                                                  cross_edges=cross, slices=ids))
                row['placements'] += 1
                row['checked_edges'] += len(cross)
        report['transforms'].append(row)
        if ti % 32 == 31:
            save()
            print(json.dumps(dict(transforms=ti+1, placements=len(report['placements']), slices=len(library))), flush=True)
    slices = list(library)
    report['adjacency'] = adj = exact_graph(slices)
    weights = list(map(len, slices))
    print(json.dumps(dict(stage='optimize', slices=len(slices), edges=sum(map(len, adj))//2)), flush=True)
    best, cycle = cycle_optimum(weights, adj)
    words = sorted((layer, *w) for layer, v in enumerate(cycle) for w in slices[v])
    assert len(words) == len(set(words)) == best >= 367
    assert all(not conflicts(a, b) for a, b in combinations(words, 2))
    report.update(best=best, cycle=cycle, weights=weights,
        candidates=[dict(size=best, words=[''.join(map(str, w)) for w in words],
                         verified_pairs=best*(best-1)//2)],
        statistics=dict(transforms=args.count, cycle_pairs=25*args.count,
            parameter_combinations=2401*25*args.count, retained_placements=len(report['placements']),
            unique_placed_cycles=len({tuple(sorted(p['slices'])) for p in report['placements']}),
            slices=len(slices), edges=sum(map(len, adj))//2, degree_histogram=dict(Counter(map(len, adj)))),
        status='candidate_found' if best >= 368 else 'complete')
    save()
    print(json.dumps(dict(status=report['status'], best=best, statistics=report['statistics'])), flush=True)


if __name__ == '__main__':
    main()
