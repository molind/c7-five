"""Replay mixed exteriors, complete domains, integer covers and returned searches.

Uses direct coordinate tests and existing integer rank-certificate verification.
Does not infer infeasibility from solver limits or claim the selected domains
exhaust all mixed four-layer paths.
"""
import argparse
import hashlib
from itertools import combinations
import json
from pathlib import Path

import numpy as np

from check_two_slice_covers import WORDS
from check_cylinder_covers import check_entries


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_words(ids):
    assert len(ids) == len(set(ids)) and all(type(v) is int and 0 <= v < 16807 for v in ids)
    assert all(any((x-y) % 7 in (2, 3, 4, 5) for x, y in zip(WORDS[a], WORDS[b])) for a, b in combinations(ids, 2))
    return len(ids)*(len(ids)-1)//2


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--domains', type=Path, required=True)
    p.add_argument('--screen', type=Path, required=True)
    p.add_argument('--isometries', type=Path)
    p.add_argument('--searches', type=Path, nargs='*', default=[])
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    domains, screen = json.loads(args.domains.read_text()), json.loads(args.screen.read_text())
    assert domains['status'] == 'prepared' and screen['status'] in ('complete', 'candidate_found')
    assert screen['input_sha256'] == digest(args.domains)
    source_path = Path(domains['input'])
    assert digest(source_path) == domains['input_sha256']
    orbit_source = json.loads(source_path.read_text())
    base_path = Path(orbit_source['input'])
    assert digest(base_path) == orbit_source['input_sha256']
    base = json.loads(base_path.read_text())['slices']
    capacity = [1]
    for _ in range(5):
        capacity.append(7*capacity[-1]//2)
    universe = np.array(WORDS, dtype=np.int16)
    jobs = {j['index']:j for j in domains['jobs']}
    assert len(jobs) == len(domains['jobs']) == domains['statistics']['selected']
    assert list(jobs) == list(range(len(jobs)))
    expected_indices = list(range(min(screen['limit'], len(jobs))))
    if screen['status'] == 'complete':
        assert [r['index'] for r in screen['results']] == expected_indices
    results, loaded = [], {}
    for summary in screen['results']:
        path = Path(summary['file'])
        assert digest(path) == summary['sha256']
        row, job = json.loads(path.read_text()), jobs[summary['index']]
        assert row['index'] == job['index']
        frames = job['fixed_slices']+job['hint_slices']
        assert len(job['fixed_slices']) == 4 and len(job['hint_slices']) == 3
        reconstructed = []
        for layer, frame in enumerate(frames):
            perm, signs, shift = frame['transform']
            assert sorted(perm) == list(range(4)) and len(signs) == len(shift) == 4
            assert all(x in (-1, 1) for x in signs) and all(type(x) is int and 0 <= x < 7 for x in shift)
            assert 0 <= frame['base'] < 175
            for w in base[frame['base']]:
                moved = [(signs[k]*w[perm[k]]+shift[k]) % 7 for k in range(4)]
                reconstructed.append(layer*2401+sum(x*7**(3-k) for k, x in enumerate(moved)))
        assert sorted(v for v in reconstructed if v//2401 < 4) == row['fixed'] == job['fixed']
        assert sorted(v for v in reconstructed if v//2401 >= 4) == row['hint'] == job['hint']
        full = row['fixed']+row['hint']
        pairs = verify_words(full)
        assert len(full) == row['initial_size'] == job['initial_size']
        assert pairs == job['verified_hint_pairs'] and job['fixed_size'] == len(row['fixed'])
        assert job['target'] == row['target'] == 368-len(row['fixed'])
        free = np.ones(16807, dtype=bool)
        for v in row['fixed']:
            delta = (universe-universe[v]) % 7
            free &= ~np.all((delta == 0) | (delta == 1) | (delta == 6), axis=1)
        assert np.flatnonzero(free).tolist() == row['pool'] == job['pool']
        assert set(row['hint']) <= set(row['pool'])
        assert job['extra_candidates_in_fixed_layers'] == sum(v//2401 < 4 for v in row['pool'])
        assert summary['fixed'] == len(row['fixed']) and summary['pool'] == len(row['pool'])
        assert summary['status'] == row['status'] and summary['initial_size'] == row['initial_size']
        upper = None
        if 'certificate' in row:
            assert row['status'] == 0 and row['capacity_sequence'] == capacity
            total, den = check_entries(row['certificate'], row['pool'], capacity)
            upper = len(row['fixed'])+total//den
            assert upper == row['full_upper'] == summary['full_upper'] >= len(full)
            assert row['excludes368'] == summary['excludes368'] == (upper < 368)
        if 'integral_vertices' in row:
            verify_words(row['integral_vertices'])
            assert set(row['fixed']) <= set(row['integral_vertices']) <= set(row['fixed']+row['pool'])
            assert len(row['integral_vertices']) <= upper
        loaded[str(path)] = row
        results.append(dict(index=row['index'], file=str(path), sha256=digest(path), fixed=len(row['fixed']),
            pool=len(row['pool']), full_upper=upper, hint_size=len(full), hint_pairs=pairs, excludes368=upper is not None and upper < 368))
    for candidate in screen['candidates']:
        ids = [int(w, 7) for w in candidate['words']]
        assert len(ids) == candidate['size'] >= 368 and verify_words(ids) == candidate['verified_pairs']
        assert set(jobs[candidate['index']]['fixed']) <= set(ids)
    isometries = []
    if args.isometries:
        mappings = json.loads(args.isometries.read_text())
        assert mappings['input_sha256'] == digest(args.domains)
        seed_path = Path(__file__).parent/'family-d-seed-words.txt'
        seed = {int(w, 7) for w in seed_path.read_text().split()}
        for entry in mappings['results']:
            job = jobs[entry['index']]
            for key in ('equivalent_domain', 'pinned_D'):
                m = entry[key]
                if m is None:
                    continue
                perm, signs, shift = m['permutation'], m['signs'], m['shift']
                assert sorted(perm) == list(range(5)) and len(signs) == len(shift) == 5
                assert all(s in (-1, 1) for s in signs) and all(type(t) is int and 0 <= t < 7 for t in shift)
                transform = lambda v: sum(((signs[k]*WORDS[v][perm[k]]+shift[k]) % 7)*7**(4-k) for k in range(5))
                if key == 'equivalent_domain':
                    target = set(jobs[m['index']]['fixed'])
                    pool = set(jobs[m['index']]['pool'])
                    assert entry['representative'] == m['index']
                else:
                    assert 0 <= m['axis'] < 5 and 0 <= m['start'] < 7
                    target = {v for v in seed if (WORDS[v][m['axis']]-m['start']) % 7 >= 3}
                    free = np.ones(16807, dtype=bool)
                    for v in target:
                        delta = (universe-universe[v]) % 7
                        free &= ~np.all((delta == 0) | (delta == 1) | (delta == 6), axis=1)
                    pool = set(map(int, np.flatnonzero(free)))
                assert {transform(v) for v in job['fixed']} == target
                assert {transform(v) for v in job['pool']} == pool
                isometries.append(dict(index=entry['index'], kind=key, fixed_and_pool_exact=True))
    searches = []
    for path in args.searches:
        r = json.loads(path.read_text())
        sp = Path(r['input'])
        assert digest(sp) == r['input_sha256'] and str(sp) in loaded
        row = loaded[str(sp)]
        model = r['model']
        assert model['fixed'] == row['fixed'] and model['pool'] == row['pool']
        pool = model['pool']
        assert [pool[v] for v in model['hint']] == row['hint']
        provenance = {tuple(sorted(e['vertices'])): e['capacity'] for e in row['certificate']['cover']}
        edges = set()
        assert len(model['members']) == len(model['capacities'])
        for indices, cap in zip(model['members'], model['capacities']):
            assert len(indices) == len(set(indices)) and all(type(v) is int and 0 <= v < len(pool) for v in indices)
            values = tuple(sorted(pool[i] for i in indices))
            if cap == 1:
                assert all(all((x-y) % 7 in (0, 1, 6) for x, y in zip(WORDS[a], WORDS[b])) for a, b in combinations(values, 2))
                edges.update(tuple(sorted(pair)) for pair in combinations(indices, 2))
            else:
                assert type(cap) is int and cap > 1 and provenance.get(values) == cap
        points = universe[pool]
        actual_edges = set()
        for i, a in enumerate(points):
            d = (points[i+1:]-a) % 7
            actual_edges.update((i, i+1+int(j)) for j in np.flatnonzero(np.all((d == 0) | (d == 1) | (d == 6), axis=1)))
        assert actual_edges == edges
        result = r['result']
        assert result['target'] == 368-len(model['fixed']) and result['initial_size'] == len(row['hint']) and result['forbidden'] is None
        assert r['status'] in ('bounded_search_complete', 'candidate_found')
        full_size, pairs = None, 0
        if 'vertices' in result:
            assert set(result['vertices']) <= set(pool)
            chosen = model['fixed']+result['vertices']
            pairs = verify_words(chosen)
            full_size = len(chosen)
            assert full_size == result['full_size'] >= row['initial_size'] and pairs == result['verified_pairs']
            expected = [dict(step=0, size=full_size, words=[''.join(map(str, WORDS[v])) for v in sorted(chosen)], verified_pairs=pairs)] if full_size >= 367 else []
            assert r['candidates'] == expected
        assert (r['status'] == 'candidate_found') == (full_size is not None and full_size >= 368)
        searches.append(dict(file=str(path), sha256=digest(path), index=row['index'], full_size=full_size,
            verified_pairs=pairs, conflict_edges=len(edges), returned_hint=set(result.get('vertices', [])) == set(row['hint']), solver_status=result['solver_status']))
    result = dict(domains_sha256=digest(args.domains), screen_sha256=digest(args.screen),
        checker_sha256=digest(Path(__file__)), kernel_sha256=digest(Path(__file__).parent/'slice_clique'),
        results=results, checked_isometries=isometries, searches=searches,
        direct_cover_closures=sum(r['excludes368'] for r in results),
        target_witness_found=bool(screen['candidates']) or any((r['full_size'] or 0) >= 368 for r in searches),
        scope='Recorded fixed sets, complete compatible domains, rank covers, supplied isometries and returned search witnesses; no global conclusion.')
    args.output.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(dict(domains=len(results), cover_closed=result['direct_cover_closures'], isometries=len(isometries),
        searches=len(searches), target_witness_found=result['target_witness_found'])), flush=True)


if __name__ == '__main__':
    main()
