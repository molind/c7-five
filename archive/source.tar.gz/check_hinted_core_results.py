"""Rebuild hinted core-search domains, objectives, clique rows and witnesses.

Solver optimality remains a computational report, not a formal proof log.
Direct cache matches classify exact labeled states only.
"""
import argparse
import gzip
import hashlib
from itertools import combinations, product
import json
from pathlib import Path

import numpy as np

from check_common314_covers import decode, encode


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--runs',type=Path,nargs='+',required=True)
    p.add_argument('--base',type=Path,required=True)
    p.add_argument('--cache',type=Path,nargs='+',required=True)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();assert __debug__ and not args.output.exists()
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    base=json.loads(args.base.read_text());assert sha(base['input'])==base['input_sha256']
    parents=json.loads(Path(base['input']).read_text())['bases']
    core=set(parents[0]['words'])&set(parents[1]['words']);assert len(core)==315 and core==set(base['fixed'])
    coords=np.array(list(product(range(7),repeat=5)),dtype=np.int16)
    dependencies={str(args.base):sha(args.base),base['input']:sha(base['input'])};known={};cache_unions={}
    for path in args.cache:
        with gzip.open(path,'rt') as stream:
            header=json.loads(next(stream));states=[tuple(json.loads(line)) for line in stream]
        assert len(states)==header['states'] and len(set(states))==len(states)
        assert all(s==tuple(sorted(set(s))) and len(s)==367 for s in states)
        for index,state in enumerate(states):known.setdefault(state,[]).append(dict(file=str(path),index=index))
        cache_unions[str(path)]=set().union(*(set(s) for s in states));dependencies[str(path)]=sha(path)
    rows=[];pair_checks=0
    def check_words(words):
        nonlocal pair_checks
        assert words==sorted(set(words)) and all(type(v) is int and 0<=v<16807 for v in words)
        for a,b in combinations(words,2):
            assert any((x-y)%7 in (2,3,4,5) for x,y in zip(decode(a),decode(b)))
            pair_checks+=1
    for path in args.runs:
        d=json.loads(path.read_text());assert d['status'] in ('complete_attempt','verified_improvement')
        assert all(sha(f)==h for f,h in d['dependencies'].items());dependencies[str(path)]=sha(path)
        fixed=d['fixed'];assert fixed==sorted(set(fixed)) and set(fixed)<=core
        allowed=np.ones(16807,dtype=bool)
        for v in fixed:
            delta=(coords-coords[v])%7;allowed &= ~np.all((delta==0)|(delta==1)|(delta==6),axis=1)
        pool=np.flatnonzero(allowed).tolist();assert pool==d['pool'];domain=set(pool)
        assert d['target']==368-len(fixed)
        # All rows are intersections with32-word boxes; reconstruct the exact
        # number of distinct rows, including singleton rows, without search code.
        origins=set()
        for v in pool:origins.update(encode(w) for w in product(*[((x-1)%7,x) for x in decode(v)]))
        memberships=set()
        for origin in origins:
            box={encode(w) for w in product(*[(x,(x+1)%7) for x in decode(origin)])}
            memberships.add(tuple(sorted(box&domain)))
        assert all(memberships) and len(memberships)==d['solver']['constraints']
        n=len(pool);assert d['solver']['variables']==n
        union=set()
        scale=d.get('objective_scale',1)
        if scale!=1:
            assert scale==n+1
            caches=[f for f in d['dependencies'] if f.endswith('.jsonl.gz')]
            assert caches and all(f in cache_unions for f in caches)
            union=set().union(*(cache_unions[f] for f in caches))
            assert len(union)==d['preferred_union_size']
        old=d['initial_words'];check_words(old);assert len(old)==367 and set(old) in [set(p['words']) for p in parents]
        assert set(fixed)<=set(old)<=set(fixed)|domain
        def objective(words):
            free=set(words)-set(fixed)
            return -scale*len(free)-(len(free-union) if scale!=1 else 0)
        assert d['solver']['initial_objective']==objective(old)
        assert d['solver']['objective_target']==-scale*d['target']
        words=d['words'];check_words(words)
        assert set(fixed)<=set(words)<=set(fixed)|domain and len(words)==d['size']>=367
        assert d['pair_checks']==len(words)*(len(words)-1)//2
        value=objective(words);assert abs(d['solver']['objective']-value)<1e-4
        assert value<=objective(old)
        if scale!=1:assert d['preferred_outside_words']==sorted(set(words)-set(fixed)-union)
        optimal=d['solver']['solver_status']=='Optimal'
        if optimal:assert abs(d['solver']['dual_bound']-value)<1e-4
        if d['status']=='verified_improvement':
            assert len(d['verified368'])==368 and set(d['verified368'])<=set(words)
            check_words(d['verified368'])
        rows.append(dict(file=str(path),fixed=len(fixed),pool=n,solver_status=d['solver']['solver_status'],
            size=len(words),objective=value,objective_scale=scale,primary_optimum_reported=len(words) if optimal else None,
            exact_cache_matches=known.get(tuple(words),[]),classification_pending=len(words)==367 and tuple(words) not in known,
            parent_distances=[len(set(words)-set(p['words'])) for p in parents]))
    out=dict(passed=True,rows=rows,direct_pair_checks=pair_checks,checker_sha256=sha(__file__),dependencies=dependencies,
        scope='Full domains and all constructed clique rows rebuilt; objective and witnesses independently checked. Native optimality is not a proof log.')
    args.output.write_text(json.dumps(out,indent=2)+'\n');print(out)


if __name__=='__main__':main()
