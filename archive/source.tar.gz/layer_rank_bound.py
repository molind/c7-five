"""Exact seven-layer count optimization gives a valid C7^3 rank bound.

The graph rank itself is not claimed exact. Every independent set induces
counts t[i] bounded by the exact C7^2 ranks of layer i and of adjacent layers
i,i+1 projected onto the other coordinates. Optimize only those seven counts.
"""
from functools import lru_cache
from square_rank import rank


def cycle_capacity(singles, pairs):
    assert len(singles) == len(pairs) == 7
    assert all(type(x) is int and x >= 0 for x in singles+pairs)
    best = 0
    for first in range(singles[0]+1):
        values = {first: first}
        for i in range(1, 7):
            values = {current: max((total+current for previous, total in values.items()
                                   if previous+current <= pairs[i-1]), default=-1000000)
                      for current in range(singles[i]+1)}
            values = {last: total for last, total in values.items() if total >= 0}
        best = max([best]+[total for last, total in values.items() if last+first <= pairs[6]])
    return best


def projected_masks(projection, axis):
    assert axis in range(3)
    masks = [0]*7
    other = [i for i in range(3) if i != axis]
    for v in projection:
        assert type(v) is int and 0 <= v < 343
        w = (v//49, (v//7) % 7, v % 7)
        masks[w[axis]] |= 1 << (7*w[other[0]]+w[other[1]])
    return masks


@lru_cache(None)
def rank3_bound(projection):
    choices = []
    for axis in range(3):
        masks = projected_masks(projection, axis)
        singles = [rank(m) for m in masks]
        pairs = [rank(masks[i] | masks[(i+1) % 7]) for i in range(7)]
        choices.append((cycle_capacity(singles, pairs), axis, singles, pairs))
    capacity, axis, singles, pairs = min(choices)
    return dict(capacity=capacity, axis=axis, single_ranks=singles, pair_ranks=pairs)
