"""Direct-coordinate path replay and exact component identification of escapes."""
from collections import Counter
import hashlib
from itertools import combinations, permutations, product
import json
from pathlib import Path

from search_plateau import search

HERE = Path(__file__).resolve().parent
WORDS = list(product(range(7), repeat=5))


def conflict(a, b):
    return all((x-y) % 7 in (0, 1, 6) for x, y in zip(WORDS[a], WORDS[b]))


def map_core(source, target):
    sc = [Counter(w[i] for w in source) for i in range(5)]
    tc = [Counter(w[i] for w in target) for i in range(5)]
    for p in permutations(range(5)):
        for signs in product((-1, 1), repeat=5):
            shifts = [[t for t in range(7) if all(tc[i][(signs[i]*x+t) % 7] == sc[p[i]][x]
                       for x in range(7))] for i in range(5)]
            for shift in product(*shifts):
                transform = lambda w: tuple((signs[i]*w[p[i]]+shift[i]) % 7 for i in range(5))
                if {transform(w) for w in source} == target:
                    return p, signs, shift
    return None


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    target = json.loads((HERE/'valley-floor365-plateau.json').read_text())
    target_core = set(map(tuple, target['fixed_across_visited_words']))
    results = []
    for name in ('breakout-unweighted-certificate.json', 'breakout-learn512-repair.json'):
        source = HERE/name
        data = json.loads(source.read_text())
        start = {int(w, 7) for w in data['start_words']}
        state = set(start)
        assert len(state) == 368
        energy = sum(conflict(a, b) for a, b in combinations(state, 2))
        seen = {frozenset(state): 0}
        states = [frozenset(state)]
        simple_path = []
        pair_checks = 368*367//2
        for removed, added, expected_energy in data['moves']:
            assert removed in state and added not in state and 0 <= added < len(WORDS)
            state.remove(removed)
            energy += sum(conflict(added, v)-conflict(removed, v) for v in state)
            pair_checks += 2*len(state)
            state.add(added)
            assert len(state) == 368 and energy == expected_energy
            key = frozenset(state)
            if key in seen:
                index = seen[key]
                for old in states[index+1:]:
                    del seen[old]
                del states[index+1:]
                del simple_path[index:]
            else:
                seen[key] = len(states)
                states.append(key)
                simple_path.append([removed, added, energy])
        assert state == {int(w, 7) for w in data['final_words']}
        independent = {int(w, 7) for w in data['independent_words']}
        assert len(independent) == 367 and independent <= state
        assert not any(conflict(a, b) for a, b in combinations(independent, 2))
        words = [WORDS[v] for v in sorted(independent)]
        component = search(words, 45, 100000)
        (HERE/name.replace('.json', '-component.json')).write_text(json.dumps(component, indent=2)+'\n')
        assert component['status'] == 'exhausted'
        mapping = map_core(set(map(tuple, component['fixed_across_visited_words'])), target_core)
        classification = None
        if mapping is not None:
            p, signs, shift = mapping
            mapped = [tuple((signs[i]*w[p[i]]+shift[i]) % 7 for i in range(5)) for w in words]
            replay = search(mapped, 45, 100000)
            assert replay['status'] == 'exhausted'
            assert replay['component_sha256'] == target['component_sha256']
            classification = dict(family='C', permutation=p, signs=signs, shift=shift,
                                  mapped_component_sha256=replay['component_sha256'])
        result = dict(input=name, input_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                      direct_replayed_steps=len(data['moves']), direct_pair_checks=pair_checks+367*366//2,
                      loop_erased_steps=len(simple_path), loop_erased_max_energy=max([1]+[m[2] for m in simple_path]),
                      loop_erased_path=simple_path, component_states=component['states_visited'],
                      component_sha256=component['component_sha256'], classification=classification,
                      scope='Direct replay and complete mapped-state hash identify known C. Not a new family or368 set; no external replay.')
        results.append(result)
        print(json.dumps({k:v for k,v in result.items() if k != 'loop_erased_path'}), flush=True)
    (HERE/'breakout-path-verification.json').write_text(json.dumps(results, indent=2)+'\n')


if __name__ == '__main__':
    main()
