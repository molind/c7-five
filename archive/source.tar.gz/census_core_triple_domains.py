"""Cover every triple omission by its exact residual noncore domain.

Two modes provide separate checks: direct visits every triple; events aggregates
third indices with no new blocker group. Events also rebuilds inputs from closed
coordinate neighborhoods and uses a different MIS branching order.
"""
import argparse
from collections import defaultdict
from functools import lru_cache
import gzip
import hashlib
from itertools import combinations, product
import json
import math
from pathlib import Path
import random
import time

import numpy as np
from search_family_d_core_groups import make_solver


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def bits(mask):
    while mask:
        bit = mask & -mask
        yield bit.bit_length()-1
        mask ^= bit


def closed(v):
    digits = [v//7**i % 7 for i in range(4, -1, -1)]
    for point in product(*[((x-1) % 7, x, (x+1) % 7) for x in digits]):
        yield sum(x*7**(4-i) for i, x in enumerate(point))


def census(n, blockers, method):
    base = 0
    singles = [0]*n
    pairs, triples = {}, {}
    for i, mask in enumerate(blockers):
        owner = tuple(bits(mask))
        assert len(owner) <= 3 and all(v < n for v in owner)
        if not owner:
            base |= 1 << i
        elif len(owner) == 1:
            singles[owner[0]] |= 1 << i
        else:
            table = pairs if len(owner) == 2 else triples
            table[owner] = table.get(owner, 0) | (1 << i)
    # domain -> [multiplicity, lexicographically first core-index triple]
    counts = {}
    def add(domain, number, example):
        if number:
            if domain not in counts:
                counts[domain] = [number, example]
            else:
                row = counts[domain]
                row[0] += number
                row[1] = min(row[1], example)
    if method == 'direct':
        for a, b, c in combinations(range(n), 3):
            domain = (base | singles[a] | singles[b] | singles[c] |
                      pairs.get((a, b), 0) | pairs.get((a, c), 0) |
                      pairs.get((b, c), 0) | triples.get((a, b, c), 0))
            add(domain, 1, (a, b, c))
    else:
        active_singles = {i for i, mask in enumerate(singles) if mask}
        neighbors = [set() for _ in range(n)]
        last = defaultdict(set)
        for a, b in pairs:
            neighbors[a].add(b)
            neighbors[b].add(a)
        for a, b, c in triples:
            last[a, b].add(c)
        for a in range(n-2):
            for b in range(a+1, n-1):
                base_ab = base | singles[a] | singles[b] | pairs.get((a, b), 0)
                affected = {c for c in active_singles | neighbors[a] | neighbors[b] | last[a, b] if c > b}
                unchanged = n-b-1-len(affected)
                if unchanged:
                    first = b+1
                    while first in affected:
                        first += 1
                    add(base_ab, unchanged, (a, b, first))
                for c in sorted(affected):
                    domain = base_ab | singles[c] | pairs.get((a, c), 0) | pairs.get((b, c), 0) | triples.get((a, b, c), 0)
                    add(domain, 1, (a, b, c))
    assert sum(row[0] for row in counts.values()) == math.comb(n, 3)
    return counts


def controls():
    rng = random.Random(2026092113)
    for n in range(3, 13):
        for _ in range(8):
            blockers = [sum(1 << i for i in rng.sample(range(n), rng.randrange(4))) for _ in range(30)]
            assert census(n, blockers, 'direct') == census(n, blockers, 'events')
    return dict(random_domain_partitions=80)


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--model', type=Path, required=True)
    p.add_argument('--method', choices=('direct', 'events'), required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    with (gzip.open if args.model.suffix == '.gz' else open)(args.model, 'rt') as f:
        model = json.load(f)
    verification = json.loads(Path(model['verification']).read_text())
    assert sha(model['verification']) == model['verification_sha256']
    assert sha(model['component']) == model['component_file_sha256'] == verification['component_file_sha256']
    core, pool = model['core'], model['pool']
    assert core == verification['core_words'] and model['release_size'] == 3
    assert len(pool) == len(set(pool)) and all(type(v) is int and 0 <= v < 16807 for v in pool)
    assert not set(pool) & set(core)
    blockers = model['blockers']
    assert len(blockers) == len(pool) and all(type(b) is int and b >= 0 and b.bit_length() <= len(core) for b in blockers)
    checked = controls()
    began = time.monotonic()
    if args.method == 'events':
        owners = [0]*16807
        for i, v in enumerate(core):
            for w in closed(v):
                owners[w] |= 1 << i
        expected = [v for v in range(16807) if v not in set(core) and owners[v].bit_count() <= 3]
        assert expected == pool and [owners[v] for v in pool] == blockers
    counts = census(len(core), blockers, args.method)
    census_seconds = time.monotonic()-began
    print(json.dumps(dict(method=args.method, groups=math.comb(len(core), 3), distinct_domains=len(counts), census_seconds=census_seconds)), flush=True)
    words = np.array(list(product(range(7), repeat=5)), dtype=np.int16)
    adjacency = []
    if args.method == 'events':
        index = {v:i for i, v in enumerate(pool)}
        for v in pool:
            adjacency.append(sum(1 << index[w] for w in closed(v) if w != v and w in index))
        @lru_cache(maxsize=500000)
        def solve(mask):
            if not mask:
                return 0, 0
            bit = mask & -mask
            i = bit.bit_length()-1
            rest = mask ^ bit
            a, aa = solve(rest)
            b, bb = solve(rest & ~adjacency[i])
            return (a, aa) if a >= b+1 else (b+1, bb | bit)
    else:
        for i, v in enumerate(pool):
            delta = (words[pool]-words[v]) % 7
            row = np.all((delta == 0) | (delta == 1) | (delta == 6), axis=1)
            row[i] = False
            adjacency.append(int.from_bytes(np.packbits(row, bitorder='little').tobytes(), 'little'))
        solve = make_solver(adjacency, float('inf'))
    rows, candidates = [], []
    for mask, (count, example) in sorted(counts.items()):
        optimum, chosen = solve(mask)
        assert chosen & ~mask == 0 and chosen.bit_count() == optimum
        assert all(not (adjacency[i] & chosen) for i in bits(chosen))
        omitted = [core[i] for i in example]
        row = dict(domain=[pool[i] for i in bits(mask)], groups=count, first_omitted=omitted, alpha=optimum,
                   residual=[pool[i] for i in bits(chosen)])
        rows.append(row)
        if len(core)-3+optimum >= 367:
            full = sorted((set(core)-set(omitted)) | set(row['residual']))
            points = words[full]
            delta = (points[:, None, :]-points[None, :, :]) % 7
            assert not np.any(np.triu(np.all((delta == 0) | (delta == 1) | (delta == 6), axis=2), 1))
            candidates.append(dict(step=len(rows)-1, words=[''.join(map(str, words[v])) for v in full], size=len(full), omitted=omitted))
    result = dict(status='exhausted', method=args.method, model=str(args.model), model_sha256=sha(args.model),
                  source_sha256=sha(__file__), core_size=len(core), pool_size=len(pool),
                  all_groups=math.comb(len(core), 3), distinct_domains=len(counts), rows=rows, candidates=candidates,
                  max_alpha=max(row['alpha'] for row in rows), best_full_size=len(core)-3+max(row['alpha'] for row in rows),
                  controls=checked, census_seconds=census_seconds, seconds=time.monotonic()-began,
                  scope='All exact triple omissions of this fixed core; omitted core words are forbidden, remaining noncore choices unrestricted. No global bound.')
    with (gzip.open if args.output.suffix == '.gz' else open)(args.output, 'wt') as f:
        json.dump(result, f, separators=(',', ':'))
        f.write('\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('rows', 'candidates')} | dict(candidates=len(candidates))), flush=True)


if __name__ == '__main__':
    main()
