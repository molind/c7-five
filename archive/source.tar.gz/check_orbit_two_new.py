"""Direct-coordinate replay of selected transformed five-layer repair domains.

No orbit enumeration, bit rotations, or transform composition is imported.
The scope is the explicitly saved exteriors, not all paths of the orbit graph.
"""
import argparse
import hashlib
from itertools import product
import json
from pathlib import Path

import numpy as np
from check_two_slice_covers import check_cover

POINTS = np.array(list(product(range(7), repeat=4)), dtype=np.int16)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def check_words(words):
    assert words and len(words) == len(set(map(tuple, words)))
    assert all(len(w) == 5 and all(type(x) is int and 0 <= x < 7 for x in w) for w in words)
    arr = np.array(words, dtype=np.int16)
    delta = (arr[:, None, :] - arr[None, :, :]) % 7
    assert not np.any(np.triu(np.all((delta == 0) | (delta == 1) | (delta == 6), axis=2), k=1))
    return len(words)*(len(words)-1)//2


def load_base(source):
    path = Path(source['input'])
    assert digest(path) == source['input_sha256']
    placements = json.loads(path.read_text())
    original = Path(placements['input'])
    assert digest(original) == placements['input_sha256']
    return json.loads(original.read_text())['slices']


def reconstruct(job, base):
    slices = []
    for frame in job['frames'] + job['hint_frames']:
        index = frame['base']
        assert type(index) is int and 0 <= index < len(base)
        perm, signs, shift = frame['transform']
        assert sorted(perm) == list(range(4)) and all(type(v) is int for v in perm)
        assert len(signs) == len(shift) == 4 and all(v in (-1, 1) for v in signs)
        assert all(type(v) is int and 0 <= v < 7 for v in shift)
        original = np.array(base[index], dtype=np.int16)
        slices.append((original[:, perm]*np.array(signs)+np.array(shift)) % 7)
    assert len(job['frames']) == 5 and len(job['hint_frames']) in (0, 2)
    fixed = [(i, *w) for i, sl in enumerate(slices[:5]) for w in sl.tolist()]
    assert len(fixed) == job['path_size'] and job['target'] == 368-len(fixed) > 0
    check_words(fixed)
    allowed = []
    for sl in (slices[0], slices[4]):
        d = (POINTS[:, None, :] - sl[None, :, :]) % 7
        allowed.append(~np.any(np.all((d == 0) | (d == 1) | (d == 6), axis=2), axis=1))
    assert job['pool'] == np.flatnonzero(allowed[0] | allowed[1]).tolist()
    assert job['endpoint_words'] == sorted(slices[4].tolist())
    full = [(i, *w) for i, sl in enumerate(slices) for w in sl.tolist()]
    pairs = check_words(full)
    assert len(full) == job['initial_size'] and pairs == job['verified_hint_pairs']
    assert [''.join(map(str, w)) for w in sorted(full)] == job['hint_words']
    projection = sorted(sum(x*7**(3-i) for i, x in enumerate(w)) for sl in slices[5:] for w in sl.tolist())
    assert job['hint'] == projection and len(projection) == len(set(projection))
    assert set(projection) <= set(job['pool'])
    return fixed, allowed, pairs


def extend(job, fixed, allowed, selected):
    assert len(selected) == len(set(selected)) and set(selected) <= set(job['pool'])
    assert all(type(v) is int and 0 <= v < 2401 for v in selected)
    full = list(fixed)
    for v in selected:
        layer = 5 if allowed[1][v] else 6
        assert allowed[1 if layer == 5 else 0][v]
        full.append((layer, *POINTS[v].tolist()))
    full.sort()
    check_words(full)
    return [''.join(map(str, w)) for w in full]


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path, required=True)
    p.add_argument('--screen', type=Path)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    source = json.loads(args.input.read_text())
    base = load_base(source)
    pairs = 0
    domains = {}
    for i, job in enumerate(source['jobs']):
        assert job['index'] == i
        fixed, allowed, n = reconstruct(job, base)
        pairs += n
        extend(job, fixed, allowed, job['hint'])
        domains[i] = fixed, allowed
    closed = []
    candidates = []
    if args.screen:
        screen = json.loads(args.screen.read_text())
        assert screen['input_sha256'] == digest(args.input)
        assert screen['status'] in ('complete', 'candidate_found')
        assert [r['index'] for r in screen['results']] == list(range(len(screen['results'])))
        if screen['status'] == 'complete':
            assert len(screen['results']) == len(source['jobs'])
        for row in screen['results']:
            i = row['index']; job = source['jobs'][i]; pool = job['pool']
            cover = row['cover']
            if cover['status'] == 'certified_cover':
                total, den = check_cover(cover, set(pool), {v:1 for v in pool})
                assert row['full_upper'] == job['path_size']+total//den
                assert row['excludes368'] == (total < job['target']*den)
                if row['excludes368']:
                    closed.append(i)
            else:
                assert cover['status'] == 'unresolved' and not row['excludes368']
            if 'selected' in row:
                words = extend(job, *domains[i], row['selected'])
                assert row['words'] == words and row['full_size'] == len(words)
                pairs += len(words)*(len(words)-1)//2
                if len(words) >= 368:
                    candidates.append(dict(step=i, words=words, size=len(words), verified_pairs=len(words)*(len(words)-1)//2))
        assert candidates == screen['candidates']
        assert (screen['status'] == 'candidate_found') == bool(candidates)
    result = dict(input_sha256=digest(args.input), checker_sha256=digest(__file__), domains=len(domains),
        complete_projection_pools_checked=True, full_pair_checks=pairs, closed_indices=closed,
        open_indices=sorted(set(domains)-set(closed)), target_witness_found=bool(candidates),
        candidates=candidates, scope='Only the explicit saved five-layer exteriors; no global bound.')
    if args.screen:
        result['screen_sha256'] = digest(args.screen)
    args.output.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k != 'candidates'}), flush=True)


if __name__ == '__main__':
    main()
