"""Certify fractional clique-cover bounds for saved forbidden-core slice pools.

Run with .venv-lp/bin/python. Floating-point LP output is never an exclusion:
each accepted cover is rounded to integer units, repaired, and checked exactly.
The domain and conflicts are reconstructed directly from the word coordinates.
"""
import argparse
from collections import Counter
import gzip
import hashlib
from itertools import combinations, product
import json
from pathlib import Path
import struct
import time

import numpy as np
import scipy
from scipy.optimize import linprog
from scipy.sparse import csc_matrix

HERE = Path(__file__).resolve().parent
DENOMINATOR = 1_000_000


def word(v):
    return tuple((v//(7**i)) % 7 for i in range(4, -1, -1))


def conflict(a, b):
    return all((x-y) % 7 in (0, 1, 6) for x, y in zip(a, b))


def build_cliques(pool):
    """Each word lies in 32 adjacent-pair boxes. Keep duplicate boxes once."""
    origins = {}
    for i, v in enumerate(pool):
        for origin in product(*[((x-1) % 7, x) for x in word(v)]):
            origins.setdefault(origin, []).append(i)
    unique = sorted(set(tuple(vs) for vs in origins.values()))
    covered = {pair for clique in unique for pair in combinations(clique, 2)}
    words = [word(v) for v in pool]
    actual = {(i, j) for i, j in combinations(range(len(pool)), 2) if conflict(words[i], words[j])}
    assert covered == actual
    return unique


def solve_cover(pool, cliques, forbidden, seconds, demands=None, method='highs', keep_primal=False):
    banned = None if forbidden is None else pool.index(forbidden)
    order = [i for i in range(len(pool)) if i != banned]
    demands = [1]*len(pool) if demands is None else demands
    assert len(demands) == len(pool) and all(type(v) is int and v > 0 for v in demands)
    local = {v: i for i, v in enumerate(order)}
    cs = sorted({tuple(local[v] for v in c if v != banned) for c in cliques} - {()})
    rows = [i for i, c in enumerate(cs) for _ in c]
    cols = [v for c in cs for v in c]
    matrix = csc_matrix((np.ones(len(rows)), (rows, cols)), shape=(len(cs), len(order)))
    began = time.monotonic()
    result = linprog(-np.array([demands[v] for v in order], dtype=float), A_ub=matrix, b_ub=np.ones(len(cs)),
                     bounds=(0, None), method=method, options={'time_limit': seconds})
    row = dict(lp_status=int(result.status), message=result.message, seconds=time.monotonic()-began)
    if not result.success:
        row['status'] = 'unresolved'
        return row
    floating = np.maximum(0, -result.ineqlin.marginals)
    units = np.ceil(floating*DENOMINATOR).astype(np.int64)
    coverage = [0]*len(order)
    incident = [[] for _ in order]
    for i, c in enumerate(cs):
        for v in c:
            coverage[v] += int(units[i])
            incident[v].append(i)
    # Repair any numerical deficit using an actual clique containing the word.
    for v in range(len(order)):
        demand = demands[order[v]]*DENOMINATOR
        if coverage[v] < demand:
            c = incident[v][0]
            delta = demand-coverage[v]
            units[c] += delta
            for u in cs[c]:
                coverage[u] += delta
    total = sum(map(int, units))
    # Integer certificate, using global vertex IDs so verification is standalone.
    cover = [{'vertices': [pool[order[v]] for v in c], 'units': int(n)}
             for c, n in zip(cs, units) if n]
    exact = {pool[v]: 0 for v in order}
    for entry in cover:
        assert entry['units'] > 0
        ws = [word(v) for v in entry['vertices']]
        assert all(conflict(a, b) for a, b in combinations(ws, 2))
        for v in entry['vertices']:
            exact[v] += entry['units']
    assert all(exact[pool[v]] >= demands[v]*DENOMINATOR for v in order)
    assert sum(e['units'] for e in cover) == total
    row.update(status='certified_cover', floating_bound=float(-result.fun), denominator=DENOMINATOR,
               total_units=total, integer_upper_bound=total//DENOMINATOR, cover=cover,
               demands=[{'vertex':pool[v], 'weight':demands[v]} for v in order])
    if keep_primal:
        row['primal'] = [{'vertex': pool[order[v]], 'value': float(x)} for v, x in enumerate(result.x) if x > 1e-8]
        row['primal_role'] = 'Heuristic support only; fractional coordinates are not an independent-set construction.'
    return row


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--seconds', type=float, default=2)
    parser.add_argument('--limit', type=int, default=35)
    parser.add_argument('--core-barrier', action='store_true',
                        help='One weighted cover per slab to test whether every original core word is forced')
    args = parser.parse_args()
    if args.seconds <= 0 or args.limit < 1:
        parser.error('Positive limits required')
    if args.output.exists():
        raise FileExistsError(args.output)
    source = json.loads(args.input.read_text())
    seed_path = HERE/'family-d-seed-words.txt'
    assert hashlib.sha256(seed_path.read_bytes()).hexdigest() == source['hashes'][seed_path.name]
    seed = [tuple(map(int, w)) for w in seed_path.read_text().split()]
    assert len(seed) == len(set(seed)) == 367 and all(not conflict(a, b) for a, b in combinations(seed, 2))
    loaded = {}
    core = set()
    if args.core_barrier:
        with gzip.open(HERE/'breakout-perturb64-sep20-2049-component-0.jsonl.gz', 'rt') as f:
            metadata = json.loads(next(f))
            states = [set(json.loads(line)) for line in f]
        packed = sorted(struct.pack('<367H', *sorted(s)) for s in states)
        assert len(set(packed)) == 384
        assert hashlib.sha256(b''.join(packed)).hexdigest() == metadata['component_sha256'] == source['core_component_sha256']
        core = set.intersection(*states)
        assert len(core) == 356 and core <= {int(''.join(map(str, w)), 7) for w in seed}
    report = dict(status='running', results=[], pools={}, scipy_version=scipy.__version__,
                  input_sha256=hashlib.sha256(args.input.read_bytes()).hexdigest(),
                  source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  core_barrier=args.core_barrier,
                  scope='Integer clique covers bound only the exact saved allowed domains; no global bound.')
    began = time.monotonic()

    def save():
        report['elapsed_seconds'] = time.monotonic()-began
        report['statuses'] = dict(Counter(r['status'] for r in report['results']))
        tmp = args.output.with_name(args.output.name+'.tmp')
        tmp.write_text(json.dumps(report, indent=2)+'\n')
        tmp.replace(args.output)

    jobs = list({j['pool_key']: j for j in reversed(source['results'])}.values()) if args.core_barrier else source['results']
    jobs = sorted(jobs, key=lambda j: j['index'])
    for job in jobs[:args.limit]:
        key = job['pool_key']
        if key not in loaded:
            fixed = [w for w in seed if (w[job['axis']]-job['start']) % 7 >= 2]
            pool = source['pools'][key]['pool']
            assert fixed == list(map(tuple, source['pools'][key]['fixed']))
            # Check the entire universe, not only listed vertices.
            candidates = np.array(list(product(range(7), repeat=5)))
            allowed = np.ones(7**5, dtype=bool)
            for w in fixed:
                d = (candidates-np.array(w)) % 7
                allowed &= ~np.all((d == 0) | (d == 1) | (d == 6), axis=1)
            assert np.flatnonzero(allowed).tolist() == pool
            cs = build_cliques(pool)
            loaded[key] = pool, cs
            report['pools'][key] = dict(pool=pool, fixed_size=len(fixed), domain_verified=True, graph_verified=True)
        pool, cs = loaded[key]
        if args.core_barrier:
            m = len(core & set(pool))
            multiplier = m+1
            demands = [multiplier-int(v in core) for v in pool]
            row = solve_cover(pool, cs, None, args.seconds, demands)
            # For any target-size set omitting at least one of the m core words:
            # weighted size >= multiplier*target - (m-1).
            threshold = multiplier*job['target']-m+1
            row.update(core_in_pool=sorted(core & set(pool)), multiplier=multiplier,
                       weighted_escape_threshold=threshold)
            row['forces_all_core'] = row['status'] == 'certified_cover' and row['total_units'] < threshold*DENOMINATOR
        else:
            row = solve_cover(pool, cs, job['forbidden'], args.seconds)
        row.update(index=job['index'], pool_key=key, forbidden=job['forbidden'], target=job['target'],
                   prior_status=job['result']['status'])
        if not args.core_barrier:
            row['excludes_target'] = row['status'] == 'certified_cover' and row['total_units'] < job['target']*DENOMINATOR
        report['results'].append(row)
        if len(report['results']) % 10 == 0:
            save()
        print(json.dumps({k: v for k, v in row.items() if k not in ('cover', 'demands', 'core_in_pool')}), flush=True)
    report['status'] = 'queries_complete'
    save()


if __name__ == '__main__':
    main()
