"""Rebuild every critical-prefix graph row with integer neighbor enumeration."""
import gzip
import hashlib
import json
from itertools import product
from pathlib import Path


def main():
    assert __debug__
    r = Path('research/c7')
    p = r / 'component-F-state5-critical-prefix-input-sep22.json'
    output = r / 'component-F-state5-critical-prefix-graph-verification-sep22.json'
    assert not output.exists()
    d = json.loads(p.read_text())
    sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
    assert d['source_sha256'] == sha(r / 'prepare_critical_prefix_pilot.py')
    assert all(sha(p) == h for p, h in d['dependencies'].items())
    m = json.loads(Path(d['manifest']).read_text())
    with gzip.open(m['source'], 'rt') as f:
        next(f)
        states = [set(json.loads(s)) for s in f]
    assert d['old'] == sorted(states[5]) and d['root'] == sorted(states[0])
    old, root = set(d['old']), set(d['root'])
    assert len(old) == len(root) == 367
    assert d['frozen'] == sorted(old - root) and d['parents'] == [[0, next(iter(root - old))]]
    position = {v: i for i, v in enumerate(d['old'])}
    def neighbors(v):
        c = [(v // power) % 7 for power in [2401, 343, 49, 7, 1]]
        for a, b, c, e, f in product(*[((x - 1) % 7, x, (x + 1) % 7) for x in c]):
            yield 2401 * a + 343 * b + 49 * c + 7 * e + f
    for v in old:
        assert old.intersection(neighbors(v)) == {v}
    pool, blocked, critical = [], {}, set()
    y = d['parents'][0][1]
    for v in range(16807):
        if v in old:
            continue
        adjacent = set(neighbors(v))
        b = adjacent & old
        if 2 <= len(b) <= 9 and len(adjacent & root) < 5 and not b.intersection(d['frozen']):
            pool.append(v)
            blocked[v] = sum(1 << position[x] for x in b)
            if y in adjacent:
                critical.add(v)
    pool.sort(key=lambda v: (v not in critical, blocked[v].bit_count(), v))
    assert d['pool'] == pool and d['blockers'] == [blocked[v] for v in pool]
    assert d['prefix'] == len(critical) == 30 and set(pool[:30]) == critical
    inverse = {v: i for i, v in enumerate(pool)}
    pairs = {}
    for i, v in enumerate(pool):
        if blocked[v].bit_count() == 2:
            pairs.setdefault(blocked[v], set()).add(i)
    full = (1 << len(pool)) - 1
    assert sha(d['graph']) == d['graph_sha256']
    with Path(d['graph']).open() as f:
        assert list(map(int, next(f).split())) == [len(pool), 6, 9]
        for i, v in enumerate(pool):
            row = [int(x, 16) for x in next(f).split()]
            assert len(row) == 6 + (len(pool) + 63) // 64 and all(0 <= x < 1 << 64 for x in row)
            assert sum(x << (64 * j) for j, x in enumerate(row[:6])) == blocked[v]
            excluded = {inverse[x] for x in neighbors(v) if x in inverse}
            excluded |= pairs.get(blocked[v], set())
            expected = full ^ sum(1 << x for x in excluded)
            assert sum(x << (64 * j) for j, x in enumerate(row[6:])) == expected
        assert not f.read().strip()
    deps = dict(d['dependencies'])
    for path in [p, Path(d['graph']), r / 'prepare_critical_prefix_pilot.py']:
        deps[str(path)] = sha(path)
    result = dict(passed=True, checker_sha256=sha(__file__), dependencies=deps, rows=len(pool),
                  critical_prefix=len(critical), old_words_checked=367, neighbor_checks_per_old_word=243, scope=__doc__)
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('dependencies', 'scope')}))


if __name__ == '__main__':
    main()
