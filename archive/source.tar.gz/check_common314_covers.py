"""Verify exact box covers after each possible one-word core omission."""
import argparse
from collections import Counter
import hashlib
from itertools import combinations, product
import json
from pathlib import Path


def decode(v):
    return tuple(v//7**i%7 for i in range(4,-1,-1))


def encode(w):
    return sum(v*7**(4-i) for i,v in enumerate(w))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();assert __debug__ and not args.output.exists()
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    d=json.loads(args.input.read_text());base=json.loads(Path(d['base_certificate']).read_text())
    assert d['status']=='complete' and sha(d['base_certificate'])==d['base_sha256']
    assert sha(base['input'])==base['input_sha256']
    parents=json.loads(Path(base['input']).read_text())['bases']
    core=set(parents[0]['words'])&set(parents[1]['words'])
    assert core==set(base['fixed']) and len(core)==315
    witness=base['witness'];assert len(witness)==len(set(witness))==367 and core<=set(witness)
    checks=0
    for a,b in combinations(witness,2):
        assert any((x-y)%7 in (2,3,4,5) for x,y in zip(decode(a),decode(b)));checks+=1
    neighborhoods={v:{encode(w) for w in product(*[((x-1)%7,x,(x+1)%7) for x in decode(v)])} for v in core}
    counts=Counter(w for n in neighborhoods.values() for w in n)
    assert sorted(r['omitted'] for r in d['rows'])==sorted(core)
    D=d['denominator'];assert type(D) is int and D>0
    rows=[]
    for r in d['rows']:
        omitted=r['omitted'];fixed=core-{omitted}
        pool={v for v in range(16807) if counts[v]-(v in neighborhoods[omitted])==0}
        assert pool==set(r['pool']) and len(pool)==len(r['pool'])
        assert set(witness)-fixed<=pool
        coverage={v:0 for v in pool};total=0
        for c in r['cover']:
            origin,units=c['origin'],c['units']
            assert type(origin) is int and 0<=origin<16807 and type(units) is int and units>0
            # Every such adjacent-pair box is a clique in C7^5.
            for w in product(*[(x,(x+1)%7) for x in decode(origin)]):
                v=encode(w)
                if v in coverage:coverage[v]+=units
            total+=units
        assert min(coverage.values())>=D and total==r['total_units']<54*D
        assert total//D==53 and r['certified_no368']
        rows.append(dict(omitted=omitted,pool=len(pool),total_units=total,integer_upper=367))
    out=dict(passed=True,covered_core_omissions=len(rows),core_size=315,
             any368_retains_at_most_core_words=313,minimum_core_omissions_for368=2,
             witness_pair_checks=checks,maximum_cover_units=max(r['total_units'] for r in rows),denominator=D,
             rows=rows,checker_sha256=sha(__file__),dependencies={str(args.input):sha(args.input),d['base_certificate']:sha(d['base_certificate']),base['input']:sha(base['input'])},
             scope='Exact specified315-word core. Any independent368-word set must omit at least two of these words; no global cardinality upper bound.')
    args.output.write_text(json.dumps(out,indent=2)+'\n');print({k:v for k,v in out.items() if k not in ('rows','dependencies')})


if __name__=='__main__':main()
