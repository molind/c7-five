"""Screen all three-omission domains of the exact C/F common315 core.

Every pair omission already has a strict <55 box cover. A third omission is
closed if its newly admitted words fit one additional box. Most triples admit
only the singleton bucket for some omitted word; certify those implicitly.
Save an explicit extension or integer LP cover for every remaining triple.
An LP cover >=56 is an open case, never evidence of a368 construction.
"""
import argparse
import hashlib
from itertools import combinations, product
import json
import math
from pathlib import Path
import time

import numpy as np
from scipy.optimize import linprog
from scipy.sparse import csc_matrix

from cover_two_core_omissions import containing_box
from check_common314_covers import decode, encode


def fractional_cover(pool, denominator, coords, corners, powers):
    index = {v: i for i, v in enumerate(pool)}
    boxes = {}
    for v in pool:
        for origin in (((coords[v] - corners) % 7) @ powers).tolist():
            if origin not in boxes:
                boxes[origin] = tuple(sorted(index[x] for x in
                    (((coords[origin] + corners) % 7) @ powers).tolist() if x in index))
    distinct = {}
    for origin, members in boxes.items():
        distinct.setdefault(members, origin)
    items = list(distinct.items())
    rr, cc = [], []
    for i, (members, _) in enumerate(items):
        rr.extend(members)
        cc.extend([i] * len(members))
    matrix = csc_matrix((np.ones(len(rr)), (rr, cc)), shape=(len(pool), len(items)))
    result = linprog(np.ones(len(items)), A_ub=-matrix, b_ub=-np.ones(len(pool)),
                     bounds=(0, None), method='highs')
    assert result.success, result.message
    coverage = [0] * len(pool)
    cover = []
    for (members, origin), value in zip(items, result.x):
        units = math.ceil(max(0, float(value)) * denominator)
        if units:
            cover.append(dict(origin=origin, units=units))
            for i in members:
                coverage[i] += units
    assert min(coverage) >= denominator
    return dict(pool=pool, cover=cover, total_units=sum(c['units'] for c in cover),
                floating_cover=float(result.fun))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--pair-covers', type=Path, required=True)
    p.add_argument('--verification', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    assert __debug__ and not args.output.exists()
    sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
    pair = json.loads(args.pair_covers.read_text())
    proof = json.loads(args.verification.read_text())
    assert proof['passed'] and not proof['open_domains']
    assert proof['dependencies'][str(args.pair_covers)] == sha(args.pair_covers)
    assert all(sha(f) == h for f, h in proof['dependencies'].items())
    single = json.loads(Path(pair['single_covers']).read_text())
    base = json.loads(Path(single['base_certificate']).read_text())
    core = sorted(base['fixed'])
    assert len(core) == len(set(core)) == 315
    blockers = [[] for _ in range(16807)]
    for v in core:
        for w in product(*[((x-1)%7, x, (x+1)%7) for x in decode(v)]):
            blockers[encode(w)].append(v)
    buckets = {}
    for v, bk in enumerate(blockers):
        if len(bk) <= 3:
            buckets.setdefault(tuple(bk), []).append(v)
    singleton_boxes = {v: containing_box(buckets[(v,)]) for v in core}
    prior = {tuple(r['omitted']): r for r in pair['rows']}
    D = pair['denominator']
    assert D == 1000000 and all(r['total_units'] < 55*D for r in prior.values())
    coords = np.array(list(product(range(7), repeat=5)), dtype=np.int16)
    powers = np.array([2401,343,49,7,1])
    corners = np.array(list(product((0,1), repeat=5)))
    rows, opened = [], []
    implicit = lp_count = total_cases = 0
    began = time.monotonic()
    for triple in combinations(core, 3):
        total_cases += 1
        i,j,k = triple
        pairs = [(i,j), (i,k), (j,k)]
        triple_bucket = buckets.get(triple, [])
        # For such a vertex v, the domain extension consists exactly of S_v.
        if not triple_bucket and any(singleton_boxes[v] is not None and
                all(v not in edge or edge not in buckets for edge in pairs) for v in triple):
            implicit += 1
            continue
        row = None
        for v in triple:
            parent = tuple(w for w in triple if w != v)
            extra = buckets[(v,)] + triple_bucket
            for edge in pairs:
                if v in edge:
                    extra = extra + buckets.get(edge, [])
            origin = containing_box(extra)
            if origin is not None:
                row = dict(omitted=list(triple), kind='extension', parent_omission=list(parent),
                           extra_box_origin=origin, total_units=prior[parent]['total_units']+D)
                assert row['total_units'] < 56*D
                break
        if row is None:
            pool = sorted(v for r in range(4) for key in combinations(triple, r)
                          for v in buckets.get(key, []))
            row = dict(omitted=list(triple), kind='lp', **fractional_cover(pool,D,coords,corners,powers))
            lp_count += 1
            if row['total_units'] >= 56*D:
                opened.append(dict(omitted=list(triple), pool=pool, total_units=row['total_units']))
            if lp_count % 500 == 0:
                print(dict(processed=total_cases, explicit=len(rows)+1, lp=lp_count,
                           open=len(opened), seconds=time.monotonic()-began), flush=True)
        rows.append(row)
    out = dict(status='complete', denominator=D, total_cases=total_cases,
               implicit_cases=implicit, singleton_boxes=[dict(word=v,origin=o) for v,o in singleton_boxes.items()],
               rows=rows, open_domains=opened, seconds=time.monotonic()-began,
               pair_covers=str(args.pair_covers), pair_verification=str(args.verification),
               dependencies={str(args.pair_covers):sha(args.pair_covers),str(args.verification):sha(args.verification)},
               source_sha256=sha(__file__), helper_sha256=sha(Path(__file__).with_name('cover_two_core_omissions.py')),
               scope='All completions retaining312 of the exact315 core words. Only closed if every cover is below56.')
    args.output.write_text(json.dumps(out,indent=2)+'\n')
    print(dict(cases=total_cases,implicit=implicit,explicit=len(rows),lp=lp_count,open=len(opened),seconds=out['seconds']))


if __name__ == '__main__':
    main()
