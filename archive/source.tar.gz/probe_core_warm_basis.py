"""Compare warm continuous-LP bases with a fixed, previously solved node list."""
import argparse
import json
from pathlib import Path

import numpy as np

from check_two_slice_covers import closed
from search_core_radius_cut import sha
from search_core_ipm_branches_v2 import propagate
from solve_core_radius_ipm import load_radius_model, model_digest
from warm_core_lp import solve_node


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--tree', type=Path, required=True)
    p.add_argument('--nodes', type=int, default=12)
    p.add_argument('--seconds', type=float, default=10)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    assert __debug__ and not args.output.exists() and args.nodes > 0 and args.seconds > 0
    tree = json.loads(args.tree.read_text())
    assert tree['status'] == 'bounded_attempt_complete'
    assert all(sha(f) == h for f, h in tree['dependencies'].items())
    data, matrix, lower, upper, variable_upper, initial = load_radius_model(Path(tree['input']), tree['radius'])
    lower[-3] = data['target']
    assert model_digest(matrix, lower, upper, variable_upper) == tree['target_model_sha256']
    pool, old = set(data['pool']), set(data['parent_words']) - set(data['fixed'])
    neighborhoods = {v: closed(v) & pool for v in pool}
    positions = {v: i for i, v in enumerate(data['pool'])}
    out = dict(status='running', tree=str(args.tree), source_sha256=sha(__file__),
               dependencies={str(args.tree): sha(args.tree)}, rows=[])
    for name in ('warm_core_lp.py', 'solve_core_radius_ipm.py', 'search_core_ipm_branches_v2.py'):
        path = Path(__file__).with_name(name)
        out['dependencies'][str(path)] = sha(path)
    basis = None
    for index, node in enumerate(tree['rows'][:args.nodes]):
        forbidden = propagate(pool, old, neighborhoods, node['inside'], node['outside'], tree['radius'])
        assert forbidden is not None
        variable_lo, variable_hi = np.zeros(len(pool)), variable_upper.copy()
        for v in node['inside']:
            variable_lo[positions[v]] = 1
        for v in forbidden:
            variable_hi[positions[v]] = 0
        row, values, basis = solve_node(matrix, lower, upper, variable_lo, variable_hi, args.seconds, basis)
        row.update(node=index, previous_status=node['status'], previous_seconds=node['seconds'],
                   same_numerical_status=row['status'] == node['status'])
        out['rows'].append(row)
        args.output.write_text(json.dumps(out, indent=2) + '\n')
        print(row, flush=True)
    out['status'] = 'complete_attempt'
    args.output.write_text(json.dumps(out, indent=2) + '\n')


if __name__ == '__main__':
    main()
