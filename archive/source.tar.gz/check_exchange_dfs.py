"""Compare C++ with the pinned Python traversal, then export public C7 inputs."""
import ast
import contextlib
import io
import itertools
import json
from pathlib import Path
import random
import subprocess
import time

HERE = Path(__file__).parent


def graph_text(cb, comp, radius, bw):
    n = len(cb)
    cw = (n + 63) // 64
    mask = (1 << 64) - 1
    rows = [f'{n} {bw} {radius}']
    for b, c in zip(cb, comp):
        rows.append(' '.join(f'{(b >> (64*j)) & mask:x}' for j in range(bw)) + ' ' +
                    ' '.join(f'{(c >> (64*j)) & mask:x}' for j in range(cw)))
    return '\n'.join(rows) + '\n'


def controls(executable, extra_args=()):
    source = (HERE / 'sources/fabius-43487-d5-posted.py').read_text()
    node = next(x for x in ast.parse(source).body if isinstance(x, ast.FunctionDef) and x.name == 'dfs')
    code = compile(ast.Module(body=[node], type_ignores=[]), '<pinned DFS>', 'exec')
    rng = random.Random(20260917)
    found = 0
    sizes = [rng.randrange(1, 11) for _ in range(120)] + [63, 64, 65, 127, 128, 129]*3
    for n in sizes:
        d = rng.randrange(1, 4) if n < 11 else 1
        bw = rng.randrange(1, 4)
        cb = [sum(1 << rng.randrange(bw*64) for _ in range(rng.randrange(0, 4))) for i in range(n)]
        comp = [0]*n
        for i in range(n):
            for j in range(i):
                if rng.randrange(2):
                    comp[i] |= 1 << j
                    comp[j] |= 1 << i
        ns = dict(D=d, CB=cb, COMP=comp, nodes_started=0, nodes_completed=0,
                  last_branch=(), next_ckpt=float('inf'), deadline=float('inf'),
                  time=time, ckpt=lambda tag: None, Deadline=TimeoutError)
        exec(code, ns)
        reference = ns['dfs'](0, [], 0, (1 << n)-1)
        out = subprocess.run([str(executable.resolve()), '5', *extra_args], input=graph_text(cb, comp, d, bw),
                             text=True, capture_output=True, check=True, timeout=7)
        actual = json.loads(out.stdout)
        assert actual['status'] == ('witness' if reference else 'exhausted')
        assert actual['chosen'] == (reference or [])
        if not extra_args:
            assert actual['nodes_started'] == ns['nodes_started']
            assert actual['nodes_completed'] == ns['nodes_completed']
        brute = any(sum(1 for j in range(bw*64) if any(cb[i] & (1 << j) for i in sub)) <= d and
                    all(comp[i] & (1 << j) for i, j in itertools.combinations(sub, 2))
                    for sub in itertools.combinations(range(n), d+1))
        assert brute == bool(reference)
        found += bool(reference)
    result = dict(controls=len(sizes), witness_cases=found, exhausted_cases=len(sizes)-found,
                  seed=20260917, options=list(extra_args),
                  comparison='Exact witness and existence match pinned Python DFS and exhaustive subsets; baseline mode also compares exact counters')
    print(json.dumps(result))
    return result


def export(words, expected_hash, name):
    source = (HERE / 'sources/fabius-43487-d5-posted.py').read_text().split('nodes_started=0;')[0]
    source = source.replace("sys.path.insert(0,'/tmp')\n", '').replace(
        'from c7_replay import WORDS, EXPECTED_SHA256, conflict',
        f'WORDS={words!r}\nEXPECTED_SHA256={expected_hash!r}')
    ns = {}
    with contextlib.redirect_stdout(io.StringIO()):
        exec(compile(source, '<reviewed public graph preparation>', 'exec'), ns)
    path = HERE / f'exchange-dfs-{name}.txt'
    path.write_text(graph_text(ns['CB'], ns['COMP'], 5, 6))
    (HERE / f'exchange-dfs-{name}-pool.json').write_text(json.dumps(ns['pool'])+'\n')
    print(name, 'pool', len(ns['pool']), 'input', path)


if __name__ == '__main__':
    import sys
    executable = Path(sys.argv[1]) if len(sys.argv) > 1 else HERE / 'exchange_dfs'
    report = controls(executable, sys.argv[2:])
    if len(sys.argv) == 1:
        (HERE / 'exchange-dfs-controls.json').write_text(json.dumps(report, indent=2)+'\n')
        assignments = ast.parse((HERE / 'shared_exchange_pool_replay.py').read_text()).body
        values = {n.targets[0].id: ast.literal_eval(n.value) for n in assignments
                  if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name) and
                  n.targets[0].id in {'WORDS', 'EXPECTED_SHA256'}}
        export(values['WORDS'], values['EXPECTED_SHA256'], 'original')
        family = json.loads((HERE / 'exchange-family-c-input.json').read_text())['words']
        export(' '.join(''.join(map(str, w)) for w in family),
               '7fed46596bf35cb433d9e81c7a13f3b1fb3d6cfe31f1d8905f286556b87cb21c', 'family-c')
