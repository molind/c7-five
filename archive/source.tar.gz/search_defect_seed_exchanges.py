"""Use the frozen exchange kernel on saved maximal 366-word hybrid seeds.

Construct complete bounded-blocker domains by neighborhood enumeration. Before
running, rebuild every blocker and compatibility row using coordinate masks.
All returned full codes receive direct pair checks. A timeout excludes nothing.
"""
import argparse
from collections import Counter
import hashlib
from itertools import product
import json
from pathlib import Path
import subprocess
import time

import numpy as np

from run_seed_exchanges_fast import coordinate_masks, nearby
from search_exchanges import verify

HERE = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--seeds',type=Path,required=True)
    p.add_argument('--selection',type=Path,required=True)
    p.add_argument('--prefix',type=Path,required=True)
    p.add_argument('--radii',type=int,nargs='+',default=[3])
    p.add_argument('--seconds',type=float,default=5)
    args = p.parse_args()
    assert __debug__ and args.seconds > 0 and all(1 <= r <= 10 for r in args.radii)
    out = args.prefix.with_suffix('.json')
    assert not out.exists() and not list(args.prefix.parent.glob(args.prefix.name+'-seed*'))
    data = json.loads(args.seeds.read_text())
    selection = json.loads(args.selection.read_text())
    assert selection['input_sha256'] == sha(args.seeds)
    indices = [r['seed'] for r in selection['rows'] if not r['previously_visited_exact']]
    coords = np.array(list(product(range(7),repeat=5)),dtype=np.int16)
    words = [tuple(map(int,w)) for w in coords.tolist()]
    powers = np.array([2401,343,49,7,1],dtype=np.int32)
    shifts = np.array(list(product((-1,0,1),repeat=5)),dtype=np.int16)
    neighbors = np.zeros((16807,243),dtype=np.int32)
    for k in range(5):
        neighbors += ((coords[:,k,None]+shifts[None,:,k])%7)*powers[k]
    kernel = HERE/'exchange_dfs_residual_two'
    report = dict(status='running',seed_file=str(args.seeds),seed_sha256=sha(args.seeds),
                  selection_file=str(args.selection),selection_sha256=sha(args.selection),
                  selected_indices=indices,radii=args.radii,seconds_per_query=args.seconds,
                  kernel=str(kernel),kernel_sha256=sha(kernel),
                  kernel_source_sha256=sha(kernel.with_suffix('.cpp')),
                  driver_sha256=sha(__file__),
                  helper_sha256={str(HERE/n):sha(HERE/n) for n in ['run_seed_exchanges_fast.py','search_exchanges.py']},
                  rows=[],candidates=[],improved_words=None,
                  scope='Selected 366 seeds and bounded removal radii only; independently rebuilt native inputs.')

    def save():
        temp = out.with_suffix('.tmp')
        temp.write_text(json.dumps(report,indent=2)+'\n')
        temp.replace(out)

    save()
    archived = set()
    for seed_index in indices:
        old = data['sample_366_seeds'][seed_index]['words']
        assert old == sorted(set(old)) and len(old) == 366
        assert all(type(v) is int and 0 <= v < 16807 for v in old)
        oldset = set(old)
        seed_words = [words[v] for v in old]
        seed_pairs = verify(seed_words)
        blockers = [0]*16807
        for i,v in enumerate(old):
            for w in neighbors[v]:
                blockers[w] |= 1 << i
        masks = coordinate_masks(seed_words)
        # Independent domain check over all words, not just the exported pool.
        assert all(blockers[v] == nearby(w,masks,366) for v,w in enumerate(words))
        assert all(blockers), 'These inputs must be maximal 366-word sets'
        for radius in args.radii:
            pool = sorted((v for v in range(16807) if v not in oldset and blockers[v].bit_count() <= radius),
                          key=lambda v:(blockers[v].bit_count(),v))
            assert pool
            n = len(pool)
            full = (1 << n)-1
            index = {v:i for i,v in enumerate(pool)}
            pm = coordinate_masks([words[v] for v in pool])
            graph = Path(str(args.prefix)+f'-seed{seed_index}-r{radius}.txt')
            pool_path = graph.with_suffix('.pool.json')
            pool_path.write_text(json.dumps(pool)+'\n')
            mask64 = (1 << 64)-1
            with graph.open('x') as f:
                f.write(f'{n} 6 {radius}\n')
                for v in pool:
                    conflict = sum(1 << index[int(w)] for w in neighbors[v] if int(w) in index)
                    compatible = full ^ conflict
                    values = [(blockers[v] >> (64*j)) & mask64 for j in range(6)]
                    values += [(compatible >> (64*j)) & mask64 for j in range((n+63)//64)]
                    f.write(' '.join(f'{x:x}' for x in values)+'\n')
            with graph.open() as f:
                assert list(map(int,next(f).split())) == [n,6,radius]
                for v in pool:
                    row = [int(x,16) for x in next(f).split()]
                    assert len(row) == 6+(n+63)//64
                    assert sum(x << (64*j) for j,x in enumerate(row[:6])) == nearby(words[v],masks,366)
                    assert sum(x << (64*j) for j,x in enumerate(row[6:])) == full ^ nearby(words[v],pm,n)
                assert not f.read().strip()
            command = [str(kernel),str(args.seconds),'--subset','--budget-bitsets','--binary-budget','--residual-budget']
            started = time.monotonic()
            with graph.open() as f:
                run = subprocess.run(command,stdin=f,capture_output=True,text=True,check=True)
            assert not run.stderr
            result = json.loads(run.stdout)
            native = graph.with_suffix('.native.json')
            native.write_text(run.stdout)
            assert result['status'] in ('exhausted','timeout','witness')
            if result['status'] == 'exhausted':
                assert result['nodes_started'] == result['nodes_completed']
                assert result['next_root'] == len(pool)
            row = dict(seed=seed_index,radius=radius,seed_pair_checks=seed_pairs,pool=len(pool),
                       graph=str(graph),graph_sha256=sha(graph),pool_file=str(pool_path),pool_sha256=sha(pool_path),
                       complete_domain_verified=True,verified_input_rows=n,
                       command=command,native_file=str(native),native_sha256=sha(native),result=result,
                       seconds=time.monotonic()-started)
            if result['status'] == 'witness':
                chosen = result['chosen']
                assert len(chosen) == len(set(chosen)) == radius+1
                assert all(type(i) is int and 0 <= i < n for i in chosen)
                removed = 0
                for i in chosen:
                    removed |= blockers[pool[i]]
                assert removed.bit_count() <= radius
                added = [pool[i] for i in chosen]
                child = tuple(sorted({v for i,v in enumerate(old) if not(removed >> i & 1)}|set(added)))
                assert len(child) == 366-removed.bit_count()+len(added) >= 367
                checks = verify([words[v] for v in child])
                row['witness_pair_checks'] = checks
                row['witness_size'] = len(child)
                if child not in archived:
                    archived.add(child)
                    report['candidates'].append(dict(step=seed_index,radius=radius,size=len(child),
                        words=[''.join(map(str,words[v])) for v in child],
                        removed=[v for i,v in enumerate(old) if removed >> i & 1],added=added,pair_checks=checks))
                if len(child) >= 368:
                    report['improved_words'] = [list(words[v]) for v in child]
                    report['status'] = 'verified_improvement'
            report['rows'].append(row)
            save()
            print(json.dumps(dict(seed=seed_index,radius=radius,pool=n,status=result['status'],
                                  seconds=result['seconds'],size=row.get('witness_size'))),flush=True)
            if report['improved_words']:
                return
    report['status'] = 'complete'
    report['status_counts'] = dict(Counter(r['result']['status'] for r in report['rows']))
    save()
    print(json.dumps(report['status_counts']))


if __name__ == '__main__':
    main()
