"""Check selected saved pair-domain LP certificates without the solver."""
from pathlib import Path
from itertools import product
from fractions import Fraction
import contextlib, hashlib, io, json, runpy
from check_one_core_covers import check

P = Path(__file__).parent
if not __debug__:
    raise RuntimeError('Run without -O')
with contextlib.redirect_stdout(io.StringIO()):
    c = runpy.run_path(str(P / 'shared_u2_compact_replay.py'))
# Reconstruct U2 from core incidence masks independently of the LP generator.
coord = [[0]*7 for _ in range(5)]
for i,w in enumerate(c['core']):
    for k,x in enumerate(w):
        coord[k][x] |= 1 << i
u2 = set()
for w in product(range(7), repeat=5):
    mask = (1 << 308)-1
    for k,x in enumerate(w):
        mask &= coord[k][(x-1)%7] | coord[k][x] | coord[k][(x+1)%7]
    if mask.bit_count() <= 2:
        u2.add(w)
assert u2 == c['U2']
report = []
for a,b in [('04205','14456'),('34556','52300'),('11020','14621'),('00240','00300')]:
    r = json.loads((P/f'pair-{a}-{b}-lp.json').read_text())
    assert r['stage'] == 'complete'
    anchors = [tuple(map(int,t)) for t in [a,b]]
    assert all(w not in u2 for w in anchors)
    assert any((x-y)%7 in (2,3,4,5) for x,y in zip(*anchors))
    allowed = u2.copy()
    for anchor in anchors:
        allowed -= set(product(*[((x-1)%7,x,(x+1)%7) for x in anchor]))
    assert len(allowed) == r['vertices']
    digest = hashlib.sha256(' '.join(''.join(map(str,w)) for w in sorted(allowed)).encode()).hexdigest()
    assert digest == r['domain_sha256']
    den = r['denominator']
    weights = [dict(origin=x['origin'],weight=str(Fraction(x['units'],den))) for x in r['cover']]
    total = check(weights, allowed, Fraction(366))
    assert total == Fraction(r['cover_units'], den)
    try:
        check([], allowed, Fraction(366))
    except AssertionError:
        pass
    else:
        raise AssertionError('Empty cover accepted')
    dual = {tuple(x['word']):x['units'] for x in r['dual']}
    assert set(dual) <= allowed and all(type(v) is int and v >= 0 for v in dual.values())
    peak = max(sum(dual.get(w,0) for w in product(*[(x,(x+1)%7) for x in origin])) for origin in c['W'])
    assert peak <= den and sum(dual.values()) == r['dual_units']
    report.append(dict(anchors=[a,b],vertices=len(allowed),total=str(total),
                       alpha_upper=r['cover_units']//den,
                       minimum_outside=368-r['cover_units']//den,
                       dual_total=str(Fraction(sum(dual.values()),den)),
                       all_16807_dual_boxes_checked=True))
(P/'pair-lp-verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report),flush=True)
