"""Strengthen trade LPs with checked odd cycles of candidates and retained words.

This reuses shortest-odd-walk separation. LP objectives are numerical diagnostics,
not exact certificates. Each exported cut is valid for every independent set in
the supplied finite domain; finding no sampled violation proves no completeness.
"""
import argparse
import copy
import hashlib
from itertools import product
import json
from pathlib import Path
import random
import time

import numpy as np
from scipy.optimize import linprog

from probe_odd_cycle_cuts import separate
from solve_two_blocker_mip import build_model


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--rounds', type=int, default=3)
    p.add_argument('--roots', type=int, default=256)
    p.add_argument('--seconds', type=float, default=30)
    a = p.parse_args()
    assert __debug__ and not a.output.exists() and a.rounds>0 and a.roots>0 and a.seconds>0
    sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
    data = json.loads(a.input.read_text()); assert data['status']=='complete'
    source = Path(data['input']); assert sha(source)==data['input_sha256']
    bases = json.loads(source.read_text())['bases']; coords=list(product(range(7),repeat=5))
    out = copy.deepcopy(data); out['status']='running'
    out['cycle_probe']=dict(input=str(a.input),input_sha256=sha(a.input),source_sha256=sha(__file__),
        builder_sha256=sha(Path(__file__).with_name('solve_two_blocker_mip.py')),
        separator_sha256=sha(Path(__file__).with_name('probe_odd_cycle_cuts.py')),
        rounds=a.rounds,roots=a.roots,seconds_per_lp=a.seconds,rows=[],scope=__doc__)
    def save():
        temp=a.output.with_suffix('.tmp');temp.write_text(json.dumps(out,separators=(',',':'))+'\n');temp.replace(a.output)
    save()
    for domain in out['rows']:
        pool=domain['pool_ids'];n=len(pool);active=domain['active_old_indices'];old=bases[domain['base']]['words']
        y={v:n+i for i,v in enumerate(active)};ids=pool+[old[i] for i in active]
        blocked=domain.get('blocker_sets',domain.get('blocker_pairs'))
        edges=[tuple(e) for e in domain['conflict_edges']]+[(i,y[j]) for i,group in enumerate(blocked) for j in group]
        cycles=domain.setdefault('odd_cycles',[]);seen={tuple(sorted(c['vertices'])) for c in cycles}
        for step in range(a.rounds+1):
            A,lo,hi,c=build_model(domain,'improve');assert np.all(np.isneginf(lo))
            start=time.monotonic()
            lp=linprog(c,A_ub=A,b_ub=hi,bounds=(0,1),method='highs-ipm',options={'time_limit':a.seconds})
            rec=dict(base=domain['base'],round=step,status=int(lp.status),seconds=time.monotonic()-start,
                     existing_cuts=len(cycles),gain_bound=-float(lp.fun) if lp.success else None)
            if lp.success and step<a.rounds:
                assert np.all(A@lp.x<=hi+1e-6)
                retained=np.r_[lp.x[:n],1-lp.x[n:]]
                roots=[i for i,v in enumerate(retained) if 1e-6<v<1-1e-6]
                random.Random(2026092148+step).shuffle(roots);roots=roots[:a.roots]
                cuts=separate(len(ids),edges,retained,roots) if roots else []
                added=0
                for cut in cuts:
                    path=cut['cycle'];vertices=[ids[i] for i in path];key=tuple(sorted(vertices))
                    assert len(path)==len(set(path)) and len(path)>=3 and len(path)%2
                    for u,v in zip(vertices,vertices[1:]+vertices[:1]):
                        assert all((x-z)%7 in (0,1,6) for x,z in zip(coords[u],coords[v]))
                    if key in seen: continue
                    seen.add(key);added+=1
                    cycles.append(dict(vertices=vertices,candidates=sorted(i for i in path if i<n),
                        old_indices=sorted(active[i-n] for i in path if i>=n),
                        discovered_round=step,primal_violation=cut['violation']))
                rec.update(roots=len(roots),added_cuts=added)
            out['cycle_probe']['rows'].append(rec);save();print(json.dumps(rec),flush=True)
            if not lp.success or step==a.rounds or rec.get('added_cuts',0)==0:break
    out['status']='complete';save()


if __name__=='__main__':main()
