"""Replay rooted orbit search with homogeneous matrices and unpruned endpoint pairs.

This checker imports neither the orbit search nor its rotation/composition code.
The complete relative-neighbor table is separately verified by the coverage
artifact. Every boundary pair is checked, not only pairs passing score pruning.
"""
import argparse
import hashlib
from itertools import combinations, permutations, product
import json
from pathlib import Path

import numpy as np


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    r = json.loads(args.input.read_text())
    assert r['status'] in ('complete', 'candidate_found')
    source_path, coverage_path = Path(r['input']), Path(r['coverage'])
    assert sha(source_path) == r['input_sha256'] and sha(coverage_path) == r['coverage_sha256']
    coverage = json.loads(coverage_path.read_text())
    assert coverage['input_sha256'] == r['input_sha256'] and coverage['complete_relative_placement_coverage']
    source = json.loads(source_path.read_text())
    assert source['count'] == coverage['transforms'] == 384
    bp = Path(source['input'])
    assert sha(bp) == source['input_sha256']
    original = json.loads(bp.read_text())
    base = original['slices']
    arrays = [np.array(sl, dtype=np.int64) for sl in base]
    transforms = [(p, s) for p in permutations(range(4)) for s in product((-1, 1), repeat=4)]
    strides = np.array([343, 49, 7, 1], dtype=np.int64)
    points = np.array(list(product(range(7), repeat=4)), dtype=np.int64)
    allowed = []
    for sl in arrays:
        d = (points[:, None, :]-sl[None, :, :]) % 7
        allowed.append(points[~np.any(np.all((d == 0) | (d == 1) | (d == 6), axis=2), axis=1)])

    def matrix(perm, signs, shift):
        m = np.zeros((5, 5), dtype=np.int64)
        for k in range(4):
            m[k, perm[k]] = signs[k]
            m[k, 4] = shift[k]
        m[4, 4] = 1
        return m

    templates = [[] for _ in base]
    for pl in source['placements']:
        perm, signs = transforms[pl['transform']]
        m = matrix(perm, signs, pl['shift'])
        for left, position in pl['cross_edges']:
            templates[left].append((original['parents'][pl['parent']]['slices'][position], m))
    assert sum(map(len, templates)) == coverage['compatible_relative_slice_placements']
    assert 0 <= r['start'] < len(base) and 1 <= r['count'] <= len(base)-r['start']
    assert [row['root'] for row in r['roots']] == list(range(r['start'], r['start']+len(r['roots'])))
    if r['status'] == 'complete':
        assert len(r['roots']) == r['count']
    results = []
    for row in r['roots']:
        nodes, keys, edges = [], {}, {}

        def node(b, m):
            w = (arrays[b] @ m[:4, :4].T+m[:4, 4]) % 7
            key = tuple(sorted(map(int, w @ strides)))
            if key in keys:
                return keys[key]
            good = (allowed[b] @ m[:4, :4].T+m[:4, 4]) % 7
            allowed_mask = sum(1 << int(v) for v in good @ strides)
            idx = len(nodes)
            keys[key] = idx
            nodes.append((b, m, key, sum(1 << v for v in key), allowed_mask))
            return idx

        root = row['root']
        begin = node(root, np.eye(5, dtype=np.int64))
        scores = {begin: len(base[root])}
        for _ in range(3):
            newer = {}
            for u, score in scores.items():
                if u not in edges:
                    b, m = nodes[u][:2]
                    edges[u] = {node(v, (m @ relative) % 7) for v, relative in templates[b]}
                for v in edges[u]:
                    assert nodes[v][3] & nodes[u][4] == nodes[v][3]
                    newer[v] = max(newer.get(v, -1), score+len(nodes[v][2]))
            scores = newer
        state = sorted((nodes[v][2], score) for v, score in scores.items())
        assert hashlib.sha256(json.dumps(state, separators=(',', ':')).encode()).hexdigest() == row['endpoint_scores_sha256']
        assert len(nodes) == row['nodes'] and len(edges) == row['expanded_nodes'] and len(scores) == row['endpoints']
        best = -1
        for u, v in combinations(scores, 2):
            if nodes[v][3] & nodes[u][4] == nodes[v][3]:
                best = max(best, scores[u]+scores[v]-len(base[root]))
        parent_lower = max(sum(len(base[v]) for v in parent['slices'])
                           for parent in original['parents'] if root in parent['slices'])
        assert best == row['best'] >= parent_lower
        words = []
        for layer, item in enumerate(row['cycle']):
            perm, signs, shift = item['transform']
            assert sorted(perm) == list(range(4)) and all(v in (-1, 1) for v in signs)
            assert len(signs) == len(shift) == 4 and all(type(v) is int and 0 <= v < 7 for v in shift)
            assert 0 <= item['base'] < len(base)
            w = (arrays[item['base']][:, perm]*np.array(signs)+np.array(shift)) % 7
            words += [(layer, *map(int, point)) for point in w]
        assert len(row['cycle']) == 7 and len(words) == len(set(words)) == best
        assert all(any((x-y) % 7 in (2, 3, 4, 5) for x, y in zip(a, b)) for a, b in combinations(words, 2))
        assert row['verified_pairs'] == best*(best-1)//2
        results.append(dict(root=root, nodes=len(nodes), endpoints=len(scores), best=best,
                            boundary_pairs=len(scores)*(len(scores)-1)//2, witness_pairs=best*(best-1)//2))
        if len(results) % 25 == 0:
            print(json.dumps(dict(roots_checked=len(results))), flush=True)
    for c in r['candidates']:
        words = [tuple(map(int, w)) for w in c['words']]
        assert len(words) == len(set(words)) == c['size'] >= 368
        assert all(len(w) == 5 and all(0 <= x < 7 for x in w) for w in words)
        assert all(any((x-y) % 7 in (2, 3, 4, 5) for x, y in zip(a, b)) for a, b in combinations(words, 2))
    target = any(row['best'] >= 368 for row in results)
    assert bool(r['candidates']) == target == (r['status'] == 'candidate_found')
    result = dict(input_sha256=sha(args.input), checker_sha256=sha(Path(__file__)),
        roots=results, roots_checked=len(results), best=max(row['best'] for row in results),
        endpoint_pairs=sum(row['boundary_pairs'] for row in results), witness_pairs=sum(row['witness_pairs'] for row in results),
        target_witness_found=target, all_roots_complete=len(results) == len(base), base_slices=len(base),
        scope='Orbit-slice seven-walk model only; relies on separately replayed complete relative-neighbor table.')
    args.output.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k != 'roots'}), flush=True)


if __name__ == '__main__':
    main()
