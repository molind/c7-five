"""Check complete native rooted results, witnesses, and Python cross-checks.

Witness verification is complete. Search-exhaustion evidence is the native
algorithm, its completed root range, controls, and the specified Python subset;
this script does not independently enumerate every native search tree.
"""
import argparse
from collections import Counter
from itertools import permutations,product
import json
from pathlib import Path

from check_orbit_two_new import check_words
from direct_slice_neighbors import sha


def main():
    if not __debug__:raise RuntimeError('Run without -O')
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--neighbors',type=Path,required=True)
    p.add_argument('--coverage',type=Path,required=True)
    p.add_argument('--results',type=Path,required=True)
    p.add_argument('--log',type=Path,required=True)
    p.add_argument('--python-prefix',type=Path,required=True)
    p.add_argument('--start',type=int,required=True)
    p.add_argument('--count',type=int,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--candidates',type=Path,required=True)
    args=p.parse_args()
    if args.output.exists()or args.candidates.exists():raise FileExistsError('Use fresh outputs')
    n=json.loads(args.neighbors.read_text());coverage=json.loads(args.coverage.read_text())
    assert coverage['input_sha256']==sha(args.neighbors) and coverage['complete_relative_placement_coverage']
    source=json.loads(Path(n['input']).read_text());assert n['input_sha256']==sha(n['input'])
    base=[source['slices'][i] for i in n['base_indices']]
    rows=[json.loads(line) for line in args.results.read_text().splitlines()]
    end=json.loads(args.log.read_text().splitlines()[-1]);assert end['status'] in ('complete','candidate_found')
    assert end['completed']==len(rows) and [r['root'] for r in rows]==list(range(args.start,args.start+len(rows)))
    if end['status']=='complete':assert len(rows)==args.count
    transforms=list(product(permutations(range(4)),product((-1,1),repeat=4)))
    checked_pairs=0;candidate_rows=[];by_root={}
    for row in rows:
        assert len(row['cycle'])==7
        words=[]
        for layer,(b,t,shift_id) in enumerate(row['cycle']):
            assert type(b)is int and 0<=b<len(base) and 0<=t<384 and 0<=shift_id<2401
            perm,signs=transforms[t];shift=[shift_id//7**i%7 for i in range(3,-1,-1)]
            words.extend((layer,*(int((signs[i]*w[perm[i]]+shift[i])%7) for i in range(4))) for w in base[b])
        words.sort();pairs=check_words(words);checked_pairs+=pairs
        ids=[sum(x*7**(4-i) for i,x in enumerate(w)) for w in words]
        assert row['words']==ids and row['best']==len(words)
        assert row['cycle'][0]==[row['root'],15,0]
        assert row['nodes']>=row['endpoints']>0 and row['comparisons']>0
        by_root[row['root']]=row
        if len(words)>=367:candidate_rows.append(dict(step=row['root'],size=len(words),words=[''.join(map(str,w))for w in words],verified_pairs=pairs))
    assert (end['status']=='candidate_found')==any(r['best']>=368 for r in rows)
    py=json.loads(args.python_prefix.read_text());assert py['input_sha256']==sha(args.neighbors)
    assert py['start']==args.start and [r['root'] for r in py['roots']]==list(range(args.start,args.start+len(py['roots'])))
    for r in py['roots']:
        native=by_root[r['root']]
        for field in ['nodes','endpoints','comparisons','best']:assert r[field]==native[field],(r['root'],field)
    result=dict(input_sha256=sha(args.results),log_sha256=sha(args.log),neighbors_sha256=sha(args.neighbors),
        coverage_sha256=sha(args.coverage),python_prefix_sha256=sha(args.python_prefix),checker_sha256=sha(__file__),
        native_source_sha256=sha(Path(__file__).with_name('search_direct_slice_orbits.cpp')),
        native_binary_sha256=sha(Path(__file__).with_name('search_direct_slice_orbits')),
        status=end['status'],roots=len(rows),start=args.start,best=max(r['best'] for r in rows),
        best_histogram=dict(Counter(r['best'] for r in rows)),full_pair_checks=checked_pairs,
        python_crosschecked_roots=len(py['roots']),candidate367_or_more=len(candidate_rows),
        target_witness_found=any(r['best']>=368 for r in rows),elapsed_seconds=rows[-1]['elapsed_seconds'],
        scope='All saved witnesses verified. Complete native rooted traversal; matching Python counts on prefix only, not an independent full search replay.')
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    args.candidates.write_text(json.dumps(dict(candidates=candidate_rows,input_sha256=sha(args.results)),indent=2)+'\n')
    print(json.dumps(result),flush=True)


if __name__=='__main__':main()
