"""Lift structurally distinct maximal366 codes to368 words with two disjoint conflicts."""
import argparse
from collections import Counter
from itertools import combinations
import json
from pathlib import Path
import numpy as np
from breakout_conflicts import graph
from check_orbit_two_new import check_words
from direct_slice_neighbors import sha


def signature(words):
    marginals=[]
    for axis in range(5):
        h=Counter(w[axis]for w in words);images=[]
        for sign in (-1,1):
            for shift in range(7):
                image=[0]*7
                for x in range(7):image[(sign*x+shift)%7]=h[x]
                images.append(tuple(image))
        marginals.append(min(images))
    return tuple(sorted(marginals))


def main():
    if not __debug__:raise RuntimeError('Run without -O')
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True)
    p.add_argument('--original',type=Path,required=True)
    p.add_argument('--verification',type=Path,required=True)
    p.add_argument('--prefix',type=Path,required=True)
    p.add_argument('--count',type=int,default=8)
    args=p.parse_args();output=Path(str(args.prefix)+'.json')
    if output.exists()or list(output.parent.glob(args.prefix.name+'-start-*.json')):raise FileExistsError(args.prefix)
    source=json.loads(args.input.read_text());check=json.loads(args.verification.read_text())
    assert check['input_sha256']==sha(args.input) and check['all_residual_optima_verified'] and source['input_sha256']==sha(args.original)
    originals={r['root']:r for r in map(json.loads,args.original.read_text().splitlines())}
    words,adj=graph(5);selected=[];seen=set()
    for row in source['results']:
        if row['full_size']!=366:continue
        fixed=list(originals[row['root']]['words'])
        if row['status']!='no_free_words':fixed += [row['pool'][i]for i in row['result']['vertices']]
        fixed.sort();code=[tuple(map(int,words[v]))for v in fixed];assert len(fixed)==366;check_words(code)
        sig=signature(code)
        if sig in seen:continue
        mask=np.zeros(16807,dtype=bool);mask[fixed]=True
        counts=np.bincount(adj[fixed].ravel(),minlength=16807)
        assert not np.any((counts==0)&~mask),'Input is not maximal'
        one=np.flatnonzero((counts==1)&~mask).tolist()
        blockers={v:int(adj[v][mask[adj[v]]][0])for v in one}
        pair=next(((a,b)for a,b in combinations(one,2)if blockers[a]!=blockers[b]and b not in adj[a]),None)
        if pair is None:continue
        full=sorted(fixed+list(pair));chosen=np.zeros(16807,dtype=bool);chosen[full]=True
        degree=np.count_nonzero(chosen[adj[full]],axis=1)
        assert int(degree.sum())==4 and int(degree.max())==1
        index=len(selected);path=Path(str(args.prefix)+f'-start-{index:02d}.json')
        data=dict(final_words=[''.join(map(str,words[v]))for v in full],independent366=[''.join(map(str,w))for w in code],
            root=row['root'],added_words=[''.join(map(str,words[v]))for v in pair],blockers=[blockers[v]for v in pair],
            initial_energy=2,conflict_edges_disjoint=True,marginal_signature=sig,
            source_sha256=sha(args.input),preparer_sha256=sha(__file__))
        path.write_text(json.dumps(data,indent=2)+'\n')
        selected.append(dict(index=index,root=row['root'],file=str(path),sha256=sha(path),one_blocker_candidates=len(one)))
        seen.add(sig)
        if len(selected)==args.count:break
    result=dict(input_sha256=sha(args.input),verification_sha256=sha(args.verification),selected=selected,
        original_sha256=sha(args.original),source_sha256=sha(__file__),all_start_sizes=368,all_initial_energies=2,
        distinct_marginal_signatures=len(seen),scope='Heuristic starts from maximal366codes inequivalent under coordinate permutations, independent signs and shifts; conflicts remain, so these are not solutions.')
    output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)


if __name__=='__main__':main()
