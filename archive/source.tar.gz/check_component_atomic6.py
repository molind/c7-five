"""Check six-removal scan intervals, outputs and an exact width-five premise.

Proper insertion subsets of up to five words that have at most as many blockers
reduce to an earlier augmentation or a neutral step inside the checked component.
Only irreducible six/seven-insertion trades therefore remain. A nonzero start is
an explicitly partial scan. Exhaustion relies on the tested native enumerator.
"""
import argparse
import gzip
import hashlib
from itertools import combinations, product
import json
from pathlib import Path
import struct

import numpy as np


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--runs', required=True, nargs='+', type=Path)
    p.add_argument('--width-five-proof', required=True, type=Path)
    p.add_argument('--output', required=True, type=Path)
    p.add_argument('--start-state', type=int, default=0)
    args = p.parse_args()
    assert __debug__ and not args.output.exists()
    here = Path(__file__).resolve().parent
    sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
    dependencies = {}

    def read(path):
        dependencies[str(path)] = sha(path)
        return json.loads(Path(path).read_text())

    records = [(path, read(path)) for path in args.runs]
    first = records[0][1]
    manifest = read(first['input_manifest'])
    assert manifest['source_sha256'] == sha(manifest['source'])
    assert manifest['input_sha256'] == sha(manifest['input'])
    with gzip.open(manifest['source'], 'rt') as f:
        meta = json.loads(next(f))
        states = [json.loads(line) for line in f]
    assert all(len(s) == 367 and s == sorted(set(s)) and all(type(v) is int and 0 <= v < 16807 for v in s) for s in states)
    keys = [struct.pack('<367H', *s) for s in states]
    assert len(keys) == len(set(keys)) == manifest['states'] == meta['states']
    assert hashlib.sha256(b''.join(sorted(keys))).hexdigest() == manifest['component_sha256'] == meta['component_sha256']
    expected = f'{len(states)} 367\n' + '\n'.join(' '.join(map(str, s)) for s in states) + '\n'
    assert Path(manifest['input']).read_text() == expected
    known = set(keys)
    previous = read(args.width_five_proof)
    checker = 'check_atomic5_union.py' if previous.get('width5_component_equals_union') else 'check_component_atomic5.py'
    assert previous['checker_sha256'] == sha(here/checker)
    assert all(sha(p) == h for p, h in previous['dependencies'].items())
    assert previous['dependencies'][manifest['source']] == manifest['source_sha256']
    assert previous['states'] == len(states) and not previous['outside']
    assert previous['complete_atomic5'] and previous['five_removal_augmentations_excluded']
    assert previous.get('width5_component_equals_width4') or previous.get('width5_component_equals_union')
    dependencies[str(here/checker)] = sha(here/checker)
    coords = np.array(list(product(range(7), repeat=5)), dtype=np.int16)
    neutral = internal = improving = pairs = 0
    seen = set()
    outside = []
    cursor = args.start_state
    assert 0 <= cursor < len(states)
    intervals = []
    for path, run in records:
        assert not outside, 'Do not silently continue after a reported escape or improvement'
        assert run['status'] == 'complete'
        assert run['kernel_sha256'] == sha(run['kernel']) == sha(here/'scan_component_atomic6')
        assert run['kernel_source_sha256'] == sha(here/'scan_component_atomic6.cpp')
        assert run['manifest_sha256'] == sha(first['input_manifest']) == sha(run['input_manifest'])
        assert run['input_sha256'] == manifest['input_sha256']
        assert run['native_sha256'] == sha(run['native_file'])
        dependencies[run['native_file']] = sha(run['native_file'])
        rows = [json.loads(line) for line in Path(run['native_file']).read_text().splitlines()]
        assert rows == run['rows']
        footer = rows[-1]
        assert footer['status'] in ('timeout', 'exhausted', 'escape', 'witness')
        assert all(type(footer[k]) is int for k in ('start_state', 'next_state', 'total_states'))
        assert footer['start_state'] == cursor and cursor <= footer['next_state'] <= len(states) == footer['total_states']
        assert int(run['command'][2]) == cursor
        if footer['status'] == 'exhausted':
            assert footer['next_state'] == len(states)
        count = dict(neutral=0, internal_neutral=0, improving=0)
        emitted = []
        for row in rows[:-1]:
            index = row['state']
            assert type(index) is int and cursor <= index < footer['next_state']
            if row['event'] == 'candidate':
                emitted.append(row)
                continue
            assert row['event'] == 'trade'
            old = states[index]
            removed, added = row['removed'], row['added']
            assert len(removed) == len(set(removed)) == 6 and set(removed) <= set(old)
            assert len(added) == len(set(added)) in (6, 7) and not set(added) & set(old)
            assert all(type(v) is int and 0 <= v < 16807 for v in added)
            identity = index, tuple(sorted(added))
            assert identity not in seen
            seen.add(identity)
            delta = (coords[added, None, :] - coords[np.array(old)[None, :], :]) % 7
            bad = np.all((delta == 0) | (delta == 1) | (delta == 6), axis=2)
            blockers = [set(old[i] for i in np.flatnonzero(r)) for r in bad]
            assert all(2 <= len(b) <= 6 for b in blockers)
            assert set.union(*blockers) == set(removed)
            for size in range(2, 6):
                assert all(len(set.union(*subset)) > size for subset in combinations(blockers, size))
            words = sorted((set(old) - set(removed)) | set(added))
            points = coords[words]
            diff = (points[:, None, :] - points[None, :, :]) % 7
            conflicts = np.all((diff == 0) | (diff == 1) | (diff == 6), axis=2)
            assert np.array_equal(conflicts, np.eye(len(words), dtype=bool))
            pairs += len(words)*(len(words)-1)//2
            if len(words) == 367:
                count['neutral'] += 1
                if struct.pack('<367H', *words) in known:
                    count['internal_neutral'] += 1
                else:
                    outside.append(dict(state=index, words=words))
            else:
                assert len(words) == 368
                count['improving'] += 1
                outside.append(dict(state=index, words=words))
        assert all(count[k] == footer[k] for k in count)
        assert bool(outside) == bool(emitted)
        for row in emitted:
            assert row['size'] == len(row['words'])
            assert dict(state=row['state'], words=row['words']) in outside
        if footer['status'] in ('escape', 'witness'):
            assert outside and (footer['status'] == 'witness') == bool(count['improving'])
        else:
            assert not outside
        neutral += count['neutral']
        internal += count['internal_neutral']
        improving += count['improving']
        intervals.append(dict(file=str(path), start=cursor, end=footer['next_state'], status=footer['status']))
        cursor = footer['next_state']

    for file in [manifest['source'], manifest['input'], here/'scan_component_atomic6', here/'scan_component_atomic6.cpp']:
        dependencies[str(file)] = sha(file)
    complete = args.start_state == 0 and cursor == len(states) and intervals[-1]['status'] == 'exhausted' and not outside
    out = dict(checker_sha256=sha(__file__), scope=__doc__, dependencies=dependencies,
               states=len(states), intervals=intervals, next_state=cursor, checked_trades=len(seen),
               pair_checks=pairs, neutral=neutral, internal_neutral=internal, improving=improving, outside=outside,
               start_state=args.start_state, complete_atomic6=complete, width6_component_equals_width5=complete,
               six_removal_augmentations_excluded=complete)
    args.output.write_text(json.dumps(out, indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k not in ('scope','dependencies','outside','intervals')}))


if __name__ == '__main__':
    main()
