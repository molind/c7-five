"""Add strip/plane capacity cuts to a bounded-blocker trade model.

All non-free coordinates lie in adjacent pairs. Projection of an independent
set onto the free coordinates is injective and independent. One free C7 axis
has capacity3. Two have capacity10: each adjacent-row pair has at most3 columns,
so summing seven such inequalities gives twice the cardinality at most21.

LP objectives are floating-point diagnostics, not exact rational certificates.
"""
import argparse
import copy
import hashlib
from itertools import combinations, product
import json
from pathlib import Path
import time

import numpy as np
from scipy.optimize import linprog

from solve_two_blocker_mip import build_model


def projection_cuts(pool, old, dimensions):
    """Return complete domain memberships, retaining an anchor for each cut."""
    coords = list(product(range(7), repeat=5))
    unique = {}
    for count in dimensions:
        capacity = {1:3, 2:10}[count]
        for free in combinations(range(5), count):
            fixed = [k for k in range(5) if k not in free]
            offsets = list(product((0,1), repeat=len(fixed)))
            groups = {}
            for which, ids in enumerate((pool, old)):
                for index, v in enumerate(ids):
                    for shift in offsets:
                        anchor = tuple((coords[v][k]-s) % 7 for k,s in zip(fixed,shift))
                        groups.setdefault(anchor, [[],[]])[which].append(index)
            for values, (new_indices, old_indices) in groups.items():
                assert len(old_indices) <= capacity
                if not new_indices or len(new_indices)+len(old_indices) <= capacity:
                    continue
                anchor = [0]*5
                for k,v in zip(fixed,values): anchor[k]=v
                key = (capacity,tuple(new_indices),tuple(old_indices))
                unique.setdefault(key, dict(free_coordinates=list(free),anchor=anchor,
                    capacity=capacity,candidates=new_indices,old_indices=old_indices))
    return list(unique.values())


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--dimensions',type=int,choices=(1,2),nargs='+',default=[1,2])
    p.add_argument('--seconds',type=float,default=30)
    a=p.parse_args();assert __debug__ and not a.output.exists() and a.seconds>0
    assert len(set(a.dimensions))==len(a.dimensions)
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    data=json.loads(a.input.read_text());assert data['status']=='complete'
    source=Path(data['input']);assert sha(source)==data['input_sha256']
    bases=json.loads(source.read_text())['bases'];out=copy.deepcopy(data);out['status']='running'
    out['projection_probe']=dict(input=str(a.input),input_sha256=sha(a.input),source_sha256=sha(__file__),
        builder_sha256=sha(Path(__file__).with_name('solve_two_blocker_mip.py')),
        dimensions=a.dimensions,seconds_per_lp=a.seconds,rows=[],scope=__doc__)
    def save():
        temp=a.output.with_suffix('.tmp');temp.write_text(json.dumps(out,separators=(',',':'))+'\n');temp.replace(a.output)
    save()
    for domain in out['rows']:
        assert not domain.get('projection_cuts')
        cuts=projection_cuts(domain['pool_ids'],bases[domain['base']]['words'],a.dimensions)
        for label in ('base','projection'):
            if label=='projection':domain['projection_cuts']=cuts
            A,lo,hi,c=build_model(domain,'improve');assert np.all(np.isneginf(lo))
            assert np.all(hi>=0)  # The unchanged independent366 start remains feasible.
            start=time.monotonic()
            lp=linprog(c,A_ub=A,b_ub=hi,bounds=(0,1),method='highs-ipm',options={'time_limit':a.seconds})
            row=dict(base=domain['base'],label=label,status=int(lp.status),seconds=time.monotonic()-start,
                gain_bound=-float(lp.fun) if lp.success else None,
                cut_counts={str(k):sum(len(c['free_coordinates'])==k for c in domain.get('projection_cuts',[])) for k in a.dimensions})
            if lp.success:assert np.all(A@lp.x<=hi+1e-6)
            out['projection_probe']['rows'].append(row);save();print(json.dumps(row),flush=True)
    out['status']='complete';save()


if __name__=='__main__':main()
