"""Order an exact cache by one-word BFS trees for incremental trade scanning."""
import argparse
import gzip
import hashlib
from itertools import product
import json
from pathlib import Path
import struct

import numpy as np


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--manifest', type=Path, required=True)
    p.add_argument('--output-prefix', type=Path, required=True)
    p.add_argument('--root-index', type=int, required=True)
    args = p.parse_args()
    assert __debug__
    sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
    manifest = json.loads(args.manifest.read_text())
    assert sha(manifest['source']) == manifest['source_sha256']
    assert sha(manifest['input']) == manifest['input_sha256']
    with gzip.open(manifest['source'], 'rt') as f:
        meta = json.loads(next(f))
        states = [tuple(json.loads(line)) for line in f]
    assert len(states) == len(set(states)) == meta['states'] == manifest['states']
    assert all(len(s) == 367 and s == tuple(sorted(set(s))) and all(type(v) is int and 0 <= v < 16807 for v in s) for s in states)
    digest = hashlib.sha256(b''.join(sorted(struct.pack('<367H', *s) for s in states))).hexdigest()
    assert digest == meta['component_sha256'] == manifest['component_sha256']
    assert Path(manifest['input']).read_text() == f'{len(states)} 367\n' + '\n'.join(' '.join(map(str, s)) for s in states) + '\n'
    indices = {s: i for i, s in enumerate(states)}
    coords = np.array(list(product(range(7), repeat=5)), dtype=np.int16)
    powers = np.array([2401, 343, 49, 7, 1], dtype=np.int32)
    neighbors = np.empty((16807, 243), dtype=np.int32)
    for i, shift in enumerate(product((-1, 0, 1), repeat=5)):
        neighbors[:, i] = ((coords + shift) % 7) @ powers
    order, parents, position = [], [], {}
    edges = roots = cursor = 0
    assert 0 <= args.root_index < len(states)
    for root in [args.root_index] + [i for i in range(len(states)) if i != args.root_index]:
        if root in position:
            continue
        roots += 1
        position[root] = len(order)
        order.append(root)
        parents.append(-1)
        while cursor < len(order):
            state = states[order[cursor]]
            chosen = np.zeros(16807, dtype=bool)
            chosen[list(state)] = True
            counts = np.bincount(neighbors[list(state)].ravel(), minlength=16807)
            assert np.all(counts[list(state)] == 1) and counts.min() > 0
            for word in np.flatnonzero((counts == 1) & ~chosen):
                blocked = neighbors[word][chosen[neighbors[word]]]
                assert len(blocked) == 1
                target = tuple(sorted((set(state) - {int(blocked[0])}) | {int(word)}))
                index = indices[target]  # Missing target refutes width-one closure.
                edges += 1
                if index not in position:
                    position[index] = len(order)
                    order.append(index)
                    parents.append(cursor)
            cursor += 1
    assert len(order) == len(set(order)) == len(states)
    ordered = [states[i] for i in order]
    cache = Path(str(args.output_prefix) + '-cache.jsonl.gz')
    inp = Path(str(args.output_prefix) + '-input.txt')
    out = Path(str(args.output_prefix) + '-input.json')
    assert not any(p.exists() for p in (cache, inp, out))
    with gzip.open(cache, 'wt') as f:
        f.write(json.dumps(dict(states=len(states), cardinality=367, component_sha256=digest)) + '\n')
        for s in ordered:
            f.write(json.dumps(s) + '\n')
    inp.write_text(f'{len(states)} 367\n' + '\n'.join(' '.join(map(str, s)) for s in ordered)
                   + '\nparents\n' + ' '.join(map(str, parents)) + '\n')
    result = dict(source=str(cache), source_sha256=sha(cache), states=len(states),
                  component_sha256=digest, input=str(inp), input_sha256=sha(inp),
                  reference_manifest=str(args.manifest), reference_manifest_sha256=sha(args.manifest),
                  roots=roots, directed_width1_edges=edges, parents=parents,
                  source_indices=order, selected_root=args.root_index, preparer_sha256=sha(__file__))
    out.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('parents', 'source_indices')}))


if __name__ == '__main__':
    main()
