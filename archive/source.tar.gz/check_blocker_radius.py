"""Check exact radius bounds against geometrically verified trade inequalities.

Imports no solver or model builder. The proof is limited to the model's candidate
pool and the specified number of removed reference words. When present, the
max_four_insertions condition additionally limits insertions with exactly four
reference blockers. This is not a global C7^5 upper bound.
"""
import argparse
import copy
import hashlib
import json
from pathlib import Path


def check(certificate,domain):
    n=len(domain['pool_ids']);active=domain['active_old_indices'];position={v:n+i for i,v in enumerate(active)}
    size=n+len(active);allowed=set()
    def key(terms,rhs):return tuple(sorted(map(tuple,terms))),rhs
    def allow(terms,rhs):allowed.add(key(terms,rhs))
    for i,blocked in enumerate(domain.get('blocker_sets',domain.get('blocker_pairs'))):
        for j in blocked:allow([(i,1),(position[j],-1)],0)
    for i,j in domain['conflict_edges']:allow([(i,1),(j,1)],1)
    for box in domain.get('box_cliques',[]):
        terms=[(i,1) for i in box['candidates']];j=box['old_index']
        if j>=0:allow(terms+[(position[j],-1)],0)
        else:allow(terms,1)
    for cycle in domain.get('odd_cycles',[]):
        allow([(i,1) for i in cycle['candidates']]+[(position[j],-1) for j in cycle['old_indices']],
              len(cycle['vertices'])//2-len(cycle['old_indices']))
    for cut in domain.get('projection_cuts',[]):
        allow([(i,1) for i in cut['candidates']]+[(position[j],-1) for j in cut['old_indices'] if j in position],
              cut['capacity']-len(cut['old_indices']))
    cap=certificate['max_removals'];assert type(cap) is int and cap>=0
    allow([(i,1) for i in range(n,size)],cap)
    four_cap=certificate.get('max_four_insertions')
    if 'max_four_insertions' in certificate:
        assert type(four_cap) is int and four_cap>=0
        blocked=domain.get('blocker_sets',domain.get('blocker_pairs'))
        allow([(i,1) for i,b in enumerate(blocked) if len(b)==4],four_cap)
    den=certificate['denominator'];assert type(den) is int and den>0
    upper=certificate['upper_units'];assert len(upper)==certificate['variables']==size
    assert all(type(u) is int and u>=0 for u in upper)
    coefficients=list(upper);total=sum(upper)
    for row in certificate['constraints']:
        weight=row['weight'];assert type(weight) is int and weight>0
        assert type(row['rhs']) is int
        assert all(type(j) is int and type(v) is int and 0<=j<size for j,v in row['terms'])
        assert key(row['terms'],row['rhs']) in allowed
        total+=weight*row['rhs']
        for j,v in row['terms']:coefficients[j]+=weight*v
    assert all(value>=den*(1 if j<n else -1) for j,value in enumerate(coefficients))
    assert total==certificate['total_units'] and 0<=total<den
    assert certificate['integer_gain_upper']==total//den==0
    result=dict(base=domain['base'],max_removals=cap,total_units=total,denominator=den,
                checked_weighted_constraints=len(certificate['constraints']),integer_gain_upper=0)
    if four_cap is not None:
        result.update(max_four_insertions=four_cap,minimum_four_insertions_for_gain=four_cap+1)
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',required=True,type=Path)
    p.add_argument('--geometry-proof',required=True,type=Path)
    p.add_argument('--output',required=True,type=Path)
    a=p.parse_args();assert __debug__ and not a.output.exists()
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    cert=json.loads(a.input.read_text());mp=Path(cert['input']);assert sha(mp)==cert['input_sha256']
    model=json.loads(mp.read_text());assert cert['status']==model['status']=='complete'
    proof=json.loads(a.geometry_proof.read_text());assert proof['model_sha256']==sha(mp)
    assert proof['checker_sha256']==sha(Path(__file__).with_name('check_blocker_trade_results.py'))
    assert sorted(r['base'] for r in proof['rows'])==sorted(r['base'] for r in model['rows'])
    assert [r['base'] for r in cert['rows']]==[r['base'] for r in model['rows']]
    rows=[check(c,d) for c,d in zip(cert['rows'],model['rows'])]
    rejected=[]
    for kind in ('total','unknown_constraint','negative_upper'):
        damaged=copy.deepcopy(cert['rows'][0])
        if kind=='total':damaged['total_units']+=1
        elif kind=='unknown_constraint':damaged['constraints'][0]['terms']=[[damaged['variables'],1]]
        else:damaged['upper_units'][0]=-1
        try:check(damaged,model['rows'][0])
        except AssertionError:rejected.append(kind)
        else:raise AssertionError('Damaged certificate accepted: '+kind)
    out=dict(input=str(a.input),input_sha256=sha(a.input),checker_sha256=sha(__file__),
             geometry_proof=str(a.geometry_proof),geometry_proof_sha256=sha(a.geometry_proof),
             rows=rows,negative_controls_rejected=rejected,scope=__doc__)
    a.output.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))


if __name__=='__main__':main()
