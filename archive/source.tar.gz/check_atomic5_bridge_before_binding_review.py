"""Replay the C-to-B five-word bridge and rebuild canonical B independently.

No search/classification module is imported. Width-four closure remains a
computational premise from the separately tested enumerator, not a formal proof.
"""
import gzip
import hashlib
from itertools import product
import json
from pathlib import Path
import struct

import numpy as np


ROOT = Path('research/c7')


def main():
    assert __debug__
    out = ROOT / 'component-CB-atomic5-bridge-verification-sep22.json'
    assert not out.exists()
    dependencies = {}

    def bind(path):
        path = Path(path)
        dependencies[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
        return path

    def read(path):
        return json.loads(bind(path).read_text())

    def cache(path):
        with gzip.open(bind(path), 'rt') as f:
            meta = json.loads(next(f))
            states = [tuple(json.loads(line)) for line in f]
        assert len(states) == len(set(states)) == meta['states']
        assert all(len(s) == 367 and tuple(sorted(set(s))) == s for s in states)
        assert digest(states) == meta['component_sha256']
        return states

    def digest(states):
        return hashlib.sha256(b''.join(sorted(struct.pack('<367H', *s) for s in states))).hexdigest()

    def premise(name):
        result = read(ROOT / name)
        for p, h in result['dependencies'].items():
            assert hashlib.sha256(bind(p).read_bytes()).hexdigest() == h
        return result

    cproof = premise('component-C-atomic4-verification-sep22.json')
    bproof = premise('component-B78-atomic4-verification-sep22.json')
    bridge = premise('component-C-atomic5-escape-verification-sep22.json')
    for p in (cproof, bproof):
        assert p['complete_atomic4'] and p['width4_component_equals_width3']
        assert p['four_removal_augmentations_excluded'] and not p['outside']
    cs = cache(ROOT / 'family-f-c-frontier-classified-sep21-component-0.jsonl.gz')
    bs = cache(ROOT / 'component-C-atomic5-escape-sep22-component-0.jsonl.gz')
    assert len(cs) == cproof['states'] == 5971
    assert len(bs) == bproof['states'] == 78
    assert not set(cs) & set(bs)
    assert len(bridge['outside']) == 1
    row = bridge['outside'][0]
    old, new = cs[row['state']], tuple(row['words'])
    assert row['state'] == 5861 and new in bs and new not in cs
    removed, added = sorted(set(old) - set(new)), sorted(set(new) - set(old))
    assert removed == [1596, 2000, 16294, 16727, 16763]
    assert added == [1994, 2007, 16295, 16678, 16770]
    coords = np.array(list(product(range(7), repeat=5)), dtype=np.int16)
    powers = np.array([2401, 343, 49, 7, 1], dtype=np.int32)

    def check_pairs(words):
        assert len(words) == len(set(words)) == 367
        assert all(type(v) is int and 0 <= v < 16807 for v in words)
        a = coords[list(words)]
        diff = (a[:, None, :] - a[None, :, :]) % 7
        conflicts = np.all((diff == 0) | (diff == 1) | (diff == 6), axis=2)
        assert np.array_equal(conflicts, np.eye(len(words), dtype=bool))
        return len(words) * (len(words) - 1) // 2

    pairs = check_pairs(old) + check_pairs(new)
    canonical_path = bind(ROOT / 'family-b-seed-words.txt')
    seed = tuple(sorted(int(w, 7) for w in canonical_path.read_text().split()))
    pairs += check_pairs(seed)
    shifts = np.array(list(product((-1, 0, 1), repeat=5)), dtype=np.int16)
    neighbors = np.empty((16807, 243), dtype=np.int32)
    for i, shift in enumerate(shifts):
        neighbors[:, i] = ((coords + shift) % 7) @ powers
    queue, seen = [seed], {seed}
    edges = 0
    for state in queue:
        chosen = np.zeros(16807, dtype=bool)
        chosen[list(state)] = True
        count = np.bincount(neighbors[list(state)].ravel(), minlength=16807)
        assert np.all(count[list(state)] == 1) and count.min() > 0
        for word in np.flatnonzero((count == 1) & ~chosen):
            blocked = neighbors[word][chosen[neighbors[word]]]
            assert len(blocked) == 1
            target = tuple(sorted((set(state) - {int(blocked[0])}) | {int(word)}))
            edges += 1
            if target not in seen:
                seen.add(target)
                queue.append(target)
        assert len(queue) <= 78, 'Canonical B is larger than the claimed component'
    assert len(queue) == 78 and edges == 326
    classification = read(ROOT / 'component-C-atomic5-escape-sep22-classification.json')['components'][0]['classification']
    perm, signs, shift = (classification[k] for k in ('permutation', 'signs', 'shift'))
    assert sorted(perm) == list(range(5))
    assert len(signs) == 5 and set(signs) <= {-1, 1}
    assert len(shift) == 5 and all(type(v) is int and 0 <= v < 7 for v in shift)
    mapped = {tuple(sorted(int(v) for v in (((coords[list(s)][:, perm] * signs + shift) % 7) @ powers))) for s in bs}
    assert mapped == seen
    assert digest(queue) == classification['reference_component_sha256']
    result = dict(checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  dependencies=dependencies, passed=True,
                  source_state=row['state'], removed=removed, added=added,
                  checked_endpoint_pairs=pairs, source_component_states=len(cs),
                  destination_component_states=len(bs), rebuilt_canonical_B_states=len(queue),
                  rebuilt_canonical_B_directed_width1_edges=edges,
                  exact_full_component_map_checked=True, map=classification,
                  minimum_escape_width_from_exact_C_component=5,
                  target_368_found=False,
                  scope='Exact C cache has width-four closure; this directly checked width-five trade leaves it. The destination width-one component maps bijectively onto an independently rebuilt canonical B component. No new family or 368 construction is claimed.')
    out.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('dependencies', 'map', 'scope')}))


if __name__ == '__main__':
    main()
