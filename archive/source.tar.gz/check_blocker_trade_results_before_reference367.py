"""Rebuild finite trade domains and validate every saved positive/cached result.

Uses direct coordinate matrices for blockers, candidate conflicts and box cuts.
Checks exact-pattern exclusions and cache membership. Numerical infeasibility
and timeout responses are recorded, not independently certified.
"""
import argparse
import gzip
import hashlib
from itertools import combinations,product
import json
from pathlib import Path
import struct

import numpy as np

from check_farthest_exchange_inputs import conflict_rows


def box_rows(anchors,points):
    for start in range(0,len(anchors),128):
        aa=anchors[start:start+128];inside=np.ones((len(aa),len(points)),dtype=bool)
        for k in range(5):inside&=((points[None,:,k]-aa[:,k,None])%7<=1)
        yield start,inside


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--model',required=True,type=Path)
    p.add_argument('--result',type=Path,nargs='*',default=[]);p.add_argument('--output',required=True,type=Path)
    a=p.parse_args();assert __debug__ and not a.output.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    data=json.loads(a.model.read_text());assert data['status']=='complete'
    capacities=[1]
    for _ in range(5):capacities.append(7*capacities[-1]//2)
    dependency=data.get('projection_dependency')
    if dependency:
        assert dependency['url']=='https://math.mit.edu/~rstan/pubs/pubfiles/17.pdf' and dependency['theorem']==4
        assert dependency['printed_page']==102 and dependency['local_computation_replayed'] is False
        assert sha(dependency['pdf'])==dependency['pdf_sha256']
        capacities=[1,3,10,33]
        for _ in range(2):capacities.append(7*capacities[-1]//2)
    assert data.get('projection_capacities',capacities)==capacities
    source=Path(data['input']);assert sha(source)==data['input_sha256'];bases=json.loads(source.read_text())['bases']
    coords=np.array(list(product(range(7),repeat=5)),dtype=np.int16);rows=[];domains={}
    for domain in data['rows']:
        bi=domain['base'];ids=bases[bi]['words'];assert ids==sorted(set(ids)) and len(ids)==366
        blockers=[]
        for start,bad in conflict_rows(coords,coords[ids]):blockers.extend(int.from_bytes(v.tobytes(),'little') for v in np.packbits(bad,axis=1,bitorder='little'))
        assert all(blockers[v]==1<<i for i,v in enumerate(ids))
        occupied=set(ids)
        pool=[v for v,b in enumerate(blockers) if data.get('min_blockers',2)<=b.bit_count()<=data.get('max_blockers',2) and v not in occupied];assert pool==domain['pool_ids']
        blocked=[[i for i in range(366) if blockers[v]>>i&1] for v in pool]
        assert blocked==domain.get('blocker_sets',domain.get('blocker_pairs'))
        assert sorted({i for group in blocked for i in group})==domain['active_old_indices']
        edges=[]
        for start,bad in conflict_rows(coords[pool],coords[pool]):
            for offset,row in enumerate(bad):edges.extend((start+offset,j) for j in range(start+offset+1,len(pool)) if row[j])
        assert edges==list(map(tuple,domain['conflict_edges']))
        boxes=domain.get('box_cliques',[]);covered=set()
        if boxes:
            anchors=[box['anchor'] for box in boxes];assert all(type(v) is int and 0<=v<16807 for v in anchors)
            for start,inside in box_rows(coords[anchors],coords[pool]):
                for offset,members in enumerate(inside):assert np.flatnonzero(members).tolist()==boxes[start+offset]['candidates']
            for start,inside in box_rows(coords[anchors],coords[ids]):
                for offset,members in enumerate(inside):
                    old=np.flatnonzero(members).tolist();assert len(old)<=1
                    assert (old[0] if old else -1)==boxes[start+offset]['old_index']
            for box in boxes:covered.update(combinations(box['candidates'],2))
            assert covered<=set(edges)
            if domain.get('box_cliques_cover_all_edges'):assert covered==set(edges)
        cycles=domain.get('odd_cycles',[])
        for cycle in cycles:
            vs=cycle['vertices'];assert len(vs)>=3 and len(vs)%2 and len(vs)==len(set(vs))
            assert set(vs)=={pool[i] for i in cycle['candidates']}|{ids[i] for i in cycle['old_indices']}
            assert len(vs)==len(cycle['candidates'])+len(cycle['old_indices'])
            for u,v in zip(vs,vs[1:]+vs[:1]):
                delta=(coords[u]-coords[v])%7;assert np.all((delta==0)|(delta==1)|(delta==6))
        projections=domain.get('projection_cuts',[])
        for cut in projections:
            free=cut['free_coordinates'];anchor=cut['anchor'];assert free==sorted(set(free)) and len(free) in (1,2,3,4)
            assert all(type(k) is int and 0<=k<5 for k in free)
            assert len(anchor)==5 and all(type(v) is int and 0<=v<7 for v in anchor)
            assert cut['capacity']==capacities[len(free)]
            fixed=[k for k in range(5) if k not in free]
            for points,expected in ((pool,cut['candidates']),(ids,cut['old_indices'])):
                inside=np.all((coords[points][:,fixed]-np.array(anchor)[fixed])%7<=1,axis=1)
                assert np.flatnonzero(inside).tolist()==expected
            assert len(cut['old_indices'])<=cut['capacity']
        rows.append(dict(base=bi,pool=len(pool),conflicts=len(edges),boxes=len(boxes),odd_cycles=len(cycles),projection_cuts=len(projections),all_16807_blocker_rows_checked=True,pair_rows_redundant=bool(domain.get('box_cliques_cover_all_edges'))))
        domains[bi]=(ids,pool,blocked)
    results=[]
    for path in a.result:
        report=json.loads(path.read_text());assert report['status'] in ('complete','verified_target')
        assert report['input']==str(a.model) and report['input_sha256']==sha(a.model)
        known=set();ref=report.get('known366')
        if ref:
            mp=Path(ref['manifest']);assert sha(mp)==ref['sha256'];meta=json.loads(mp.read_text());assert sha(meta['file'])==meta['sha256']
            with gzip.open(meta['file'],'rb') as f:raw=f.read()
            assert hashlib.sha256(raw).hexdigest()==meta['uncompressed_sha256'] and len(raw)==meta['states']*732
            known={raw[i:i+732] for i in range(0,len(raw),732)};assert len(known)==meta['states']==ref['states']
        patterns={};accepted=[];checks=0;rejections=0
        for row in report['rows']:
            ids,pool,blocked=domains[row['base']];key=(row['base'],row['mode']);previous=patterns.setdefault(key,[])
            assert row.get('excluded_patterns',0)==len(previous)
            if 'chosen_indices' not in row:continue
            chosen=row['chosen_indices'];assert len(chosen)==len(set(chosen))>=(0 if row['mode']=='improve' else 3) and all(type(i) is int and 0<=i<len(pool) for i in chosen)
            assert set(chosen) not in previous
            removed=sorted({v for i in chosen for v in blocked[i]});assert removed==row['removed_indices']
            if row['mode']=='long_cycle':
                assert not any(len(blocked[i])==2 and blocked[i]==blocked[j] for i,j in combinations(chosen,2))
                if report.get('require_three_blocker'):assert any(len(blocked[i])==3 for i in chosen)
            else:assert row['mode'] in ('gain_two','improve') and not previous
            full=sorted((set(ids)-{ids[i] for i in removed})|{pool[i] for i in chosen})
            assert len(full)==len(set(full))==row['size'] and len(full)>=366+(2 if row['mode']=='gain_two' else 0)
            for start,bad in conflict_rows(coords[full],coords[full]):assert int(bad.sum())==len(bad)
            count=len(full)*(len(full)-1)//2;assert row['pair_checks']==count;checks+=count
            is_known=len(full)==366 and struct.pack('<366H',*full) in known
            assert row.get('rejected_known366',False)==is_known
            if is_known:previous.append(set(chosen));rejections+=1
            else:accepted.append((row['base'],full))
        assert len(accepted)==len(report['candidates'])
        for index,((bi,full),candidate) in enumerate(zip(accepted,report['candidates'])):
            assert candidate['step']==index and candidate['source_base']==bi and candidate['size']==len(full)
            assert [int(w,7) for w in candidate['words']]==full
        assert (report['status']=='verified_target')==any(len(ids)>=368 for bi,ids in accepted)
        results.append(dict(file=str(path),sha256=sha(path),positive_pair_checks=checks,rejected_known=rejections,accepted_sizes=[len(ids) for bi,ids in accepted]))
    out=dict(model=str(a.model),model_sha256=sha(a.model),checker_sha256=sha(__file__),projection_dependency=dependency,rows=rows,results=results,scope=__doc__)
    a.output.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))


if __name__=='__main__':main()
