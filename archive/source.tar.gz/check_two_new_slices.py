"""Replay two-new-slice domains, witnesses, covers, and completed searches."""
import argparse
from collections import Counter
import hashlib
from itertools import product
import json
from pathlib import Path
import subprocess

import numpy as np

from check_slice_library import check as check_library
from check_two_slice_covers import check_cover, HERE


def main():
    if not __debug__:raise RuntimeError('Run without -O')
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--search',type=Path,required=True);p.add_argument('--covers',type=Path,nargs='*',default=[])
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args()
    if args.output.exists():raise FileExistsError(args.output)
    r=json.loads(args.search.read_text());sp=Path(r['input']);vp=Path(r['verification'])
    assert hashlib.sha256(sp.read_bytes()).hexdigest()==r['input_sha256']
    assert hashlib.sha256(vp.read_bytes()).hexdigest()==r['verification_sha256']
    assert json.loads(vp.read_text())['input_sha256']==r['input_sha256']
    s=json.loads(sp.read_text());library_check=check_library(s)
    assert not library_check['target_witness_found']
    assert hashlib.sha256((HERE/'slice_clique').read_bytes()).hexdigest()==r['kernel_sha256']
    slices=s['slices'];weights=s['weights'];adj=s['adjacency']
    maxima={};walks=0
    for start in range(len(slices)):
        stack=[([start],weights[start])]
        while stack:
            path,score=stack.pop()
            if len(path)==5:
                pair=tuple(sorted((start,path[-1])));maxima[pair]=max(score,maxima.get(pair,-1));walks+=1
            else:stack.extend((path+[v],score+weights[v])for v in adj[path[-1]])
    vertices=np.array(list(product(range(7),repeat=4)),dtype=np.int16)
    blocked=[]
    for sl in slices:
        diff=(vertices[:,None,:]-np.array(sl,dtype=np.int16)[None,:,:])%7
        blocked.append(np.any(np.all((diff==0)|(diff==1)|(diff==6),axis=2),axis=1))
    assert len(r['jobs'])==len(maxima)
    seen=set()
    for job in r['jobs']:
        a,b=job['endpoints'];pair=(a,b);assert pair in maxima and pair not in seen;seen.add(pair)
        path=job['path'];assert len(path)==5 and path[0]==a and path[-1]==b
        assert all(v in adj[u]for u,v in zip(path,path[1:]))
        assert job['path_size']==sum(weights[v]for v in path)==maxima[pair]
        assert job['target']==368-maxima[pair]>0
        assert job['pool']==np.flatnonzero(~blocked[a]|~blocked[b]).tolist()
        hint_pair=job['hint_pair']
        if hint_pair:
            assert len(hint_pair)==2
            u,v=hint_pair;assert u in adj[b]and v in adj[u]and a in adj[v]
        hint=sorted({sum(int(x)*7**(3-i)for i,x in enumerate(w))for h in hint_pair for w in slices[h]})
        assert job['hint']==hint and set(hint)<=set(job['pool']) and len(hint)+job['path_size']<=367

    def full_words(job,selected):
        a,b=job['endpoints']
        words=[(layer,*w)for layer,i in enumerate(job['path'])for w in slices[i]]
        for v in selected:
            assert 0<=v<len(vertices)
            layer=5 if not blocked[b][v]else 6
            assert not blocked[b if layer==5 else a][v]
            words.append((layer,*vertices[v].tolist()))
        words.sort();arr=np.array(words,dtype=np.int16);delta=(arr[:,None,:]-arr[None,:,:])%7
        assert not np.any(np.triu(np.all((delta==0)|(delta==1)|(delta==6),axis=2),k=1))
        return [''.join(map(str,w))for w in words]

    control=r['control'];job=r['jobs'][control['index']]
    assert control['words']==full_words(job,job['hint']) and control['size']==len(control['words'])==367
    assert control['verified_pairs']==67161
    assert r['status']in ('complete','budget_reached')and not r['candidates']
    assert [q['index']for q in r['results']]==list(range(len(r['results'])))
    assert (r['status']=='complete')==(len(r['results'])==len(r['jobs']))
    assert r['statistics']==dict(Counter(q['status']for q in r['results']))
    closed={};search_results={};witness_pairs=0;replayed=0
    for q in r['results']:
        index=q['index'];job=r['jobs'][index];pool=job['pool'];search_results[index]=q
        if q['status']=='parent_timeout':continue
        if q['status']=='cardinality_closed':
            assert len(pool)<job['target'];closed[index]='cardinality';continue
        assert q['status']in ('exhausted','timeout')
        selected=q['vertices'];assert len(selected)==len(set(selected))==q['best_size']<job['target']
        assert all(type(i)is int and 0<=i<len(pool)for i in selected)
        full=full_words(job,[pool[i]for i in selected]);assert q['full_size']==len(full)<368
        assert q['verified_pairs']==len(full)*(len(full)-1)//2;witness_pairs+=q['verified_pairs']
        if q['status']=='exhausted':
            points=vertices[pool];diff=(points[:,None,:]-points[None,:,:])%7
            edges=np.argwhere(np.triu(np.all((diff==0)|(diff==1)|(diff==6),axis=2),k=1)).tolist()
            data=f'{len(pool)} {len(edges)} {q["best_size"]+1} 2000 {len(selected)}\n'+' '.join(map(str,selected))+'\n'+''.join(f'{u} {v}\n'for u,v in edges)
            rerun=subprocess.run([str(HERE/'slice_clique')],input=data,text=True,capture_output=True,check=True,timeout=7)
            exact=json.loads(rerun.stdout);assert exact['status']=='exhausted'and exact['best_size']==q['best_size']
            closed[index]='exact_search';replayed+=1
    cover_indices=set();upper_bounds={};cover_closed=0;cover_hashes={}
    for path in args.covers:
        c=json.loads(path.read_text());cover_hashes[str(path)]=hashlib.sha256(path.read_bytes()).hexdigest()
        assert c['input_sha256']==r['input_sha256']and c['verification_sha256']==r['verification_sha256']
        assert c['status']=='complete'and not c['candidates']and c['total_jobs']==len(r['jobs'])
        expected=list(range(c['start'],min(len(r['jobs']),c['start']+c['limit'])))
        assert [row['index']for row in c['results']]==expected
        for row in c['results']:
            i=row['index'];assert i not in cover_indices;cover_indices.add(i)
            job=r['jobs'][i];assert row['job']==job
            if row['status']=='cardinality_closed':
                total,den=len(job['pool']),1;assert total<job['target']
            elif row['status']=='certified_cover':
                total,den=check_cover(row['cover'],set(job['pool']),{v:1 for v in job['pool']})
                assert row['cover']['integer_upper_bound']==total//den
            else:
                assert row['status']=='unresolved'and not row['excludes368']and 'full_upper'not in row;continue
            assert row['full_upper']==job['path_size']+total//den
            assert row['excludes368']==(total<job['target']*den)
            upper_bounds[i]=row['full_upper']
            if row['excludes368']:closed[i]='integer_cover';cover_closed+=1
            if 'integral_full_size'in row:
                xs=row['cover']['primal'];assert all(abs(x['value']-round(x['value']))<1e-7 for x in xs)
                chosen=[x['vertex']for x in xs if x['value']>.5]
                assert len(full_words(job,chosen))==row['integral_full_size']<368
        assert c['statistics']==dict(Counter('closed'if row['excludes368']else'open'for row in c['results']))
    open_domains=[dict(index=i,endpoints=job['endpoints'],path_size=job['path_size'],target=job['target'],pool=len(job['pool']),
        full_upper=upper_bounds.get(i),search_status=search_results.get(i,{}).get('status','not_run'))
        for i,job in enumerate(r['jobs'])if i not in closed]
    result=dict(input_sha256=hashlib.sha256(args.search.read_bytes()).hexdigest(),cover_files=cover_hashes,
        checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),kernel_sha256=r['kernel_sha256'],
        library_reconstructed=library_check,enumerated_five_slice_walks=walks,domains=len(r['jobs']),
        positive_control_size=367,returned_witness_pairs=witness_pairs,exact_searches_replayed=replayed,
        covers_checked=len(cover_indices),cover_closed=cover_closed,closed_domains=len(closed),open_domains=open_domains,
        optimum367=not open_domains,target_witness_found=False,
        scope='Five slices from the supplied library plus two unrestricted adjacent slices; no global bound.')
    args.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)


if __name__=='__main__':main()
