"""Produce small exhaustive Boolean branch trees for the two cover faces.

Leaves are unit-propagation contradictions. Internal nodes split a Boolean
variable both ways. The saved tree can be replayed without this search code.
"""
import argparse
from collections import Counter
import hashlib
from itertools import combinations
import json
from pathlib import Path
import time

from check_two_slice_covers import HERE, conflict


class Incomplete(Exception):
    pass


def propagate(clauses):
    while True:
        if any(not c for c in clauses):
            return None
        units = {c[0] for c in clauses if len(c) == 1}
        if any(-u in units for u in units):
            return None
        if not units:
            return clauses
        clauses = [tuple(v for v in c if -v not in units) for c in clauses if not any(v in units for v in c)]


def prove(clauses, seconds):
    began = time.monotonic()
    stats = Counter()

    def visit(cs):
        stats['nodes'] += 1
        if time.monotonic()-began > seconds:
            raise Incomplete('time budget')
        cs = propagate(cs)
        if cs is None:
            stats['leaves'] += 1
            return None
        if not cs:
            raise Incomplete('CNF has a satisfying assignment; not an exclusion')
        positive = [c for c in cs if all(v > 0 for v in c)]
        choices = min(positive or cs, key=lambda c: (len(c), c))
        freq = Counter(abs(v) for c in cs for v in c)
        v = max(map(abs, choices), key=lambda v: (freq[v], -v))
        return {'variable': v, 'true': visit(cs+[(v,)]), 'false': visit(cs+[(-v,)])}

    tree = visit(clauses)
    return tree, dict(stats, seconds=time.monotonic()-began)


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--seconds', type=float, default=10)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.seconds <= 0:
        parser.error('Positive budget required')
    if args.output.exists():
        raise FileExistsError(args.output)
    source = HERE/'two-slice-face-sat-sep21.json'
    data = json.loads(source.read_text())
    report = dict(results=[], source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  input_sha256=hashlib.sha256(source.read_bytes()).hexdigest())
    for row in data['results']:
        local = {v: i+1 for i, v in enumerate(row['pool'])}
        clauses = [(-local[a], -local[b]) for a, b in combinations(row['pool'], 2) if conflict(a, b)]
        clauses += [tuple(local[v] for v in c) for c in row['mandatory_cliques']]
        result = dict(index=row['index'], forbidden=row['forbidden'], variable_vertices=row['pool'],
                      clauses=clauses, status='running')
        try:
            tree, stats = prove(clauses, args.seconds)
            result.update(status='proved_unsat', tree=tree, statistics=stats)
        except Incomplete as e:
            result.update(status='incomplete', reason=str(e))
        report['results'].append(result)
        args.output.write_text(json.dumps(report, indent=2)+'\n')
        print(json.dumps({k: v for k, v in result.items() if k not in ('variable_vertices', 'clauses', 'tree')}), flush=True)


if __name__ == '__main__':
    main()
