"""Sample violated odd-cycle inequalities using shortest odd closed walks.

For an odd cycle of length L, summing its edge inequalities gives
2*sum(x) <= L, hence integer sum(x) <= floor(L/2). Every exported cycle is
checked geometrically; failure to find a cut in sampled roots proves nothing.
"""
import argparse
import hashlib
import json
from pathlib import Path
import random
import time

import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import dijkstra
from scipy.optimize import linprog
from check_two_slice_covers import closed, conflict


def separate(n, edges, values, roots):
    u, v = np.asarray(edges, dtype=int).T
    weights = 1-values[u]-values[v]
    assert np.min(weights) >= -1e-6
    weights = np.maximum(weights, 0)
    graph = coo_matrix((np.tile(weights,4),
                       (np.concatenate([u,v,u+n,v+n]), np.concatenate([v+n,u+n,v,u]))),
                      shape=(2*n,2*n)).tocsr()
    distances, predecessors = dijkstra(graph, directed=True, indices=roots,
                                      return_predecessors=True, limit=1.0)
    cuts = {}
    for row, root in enumerate(roots):
        if distances[row,root+n] >= 1-1e-6:
            continue
        path, at = [], root+n
        while at != root:
            assert at >= 0 and len(path) <= 2*n
            path.append(int(at % n))
            at = int(predecessors[row,at])
        path.append(root)
        path.reverse()
        while len(set(path[:-1])) != len(path)-1:
            seen = {}
            for j, vertex in enumerate(path[:-1]):
                if vertex in seen:
                    i = seen[vertex]
                    path = path[i:j+1] if (j-i) % 2 else path[:i]+path[j:]
                    break
                seen[vertex] = j
        cycle = path[:-1]
        assert path[0] == path[-1] and len(cycle) >= 3 and len(cycle) % 2
        capacity = len(cycle)//2
        value = float(sum(values[v] for v in cycle))
        if value > capacity+1e-6:
            cuts.setdefault(tuple(sorted(cycle)), dict(cycle=cycle, capacity=capacity,
                                                       primal_sum=value, violation=value-capacity))
    return list(cuts.values())


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--model', type=Path, required=True)
    p.add_argument('--root-limit', type=int, default=256)
    p.add_argument('--seconds', type=float, default=10)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    assert __debug__ and args.root_limit > 0 and args.seconds > 0 and not args.output.exists()
    positive = separate(5,[(i,(i+1)%5) for i in range(5)],np.full(5,.5),list(range(5)))
    assert len(positive) == 1 and positive[0]['capacity'] == 2
    assert separate(7,[(i,(i+1)%7) for i in range(7)],np.full(7,3/7),list(range(7))) == []
    report = json.loads(args.model.read_text())
    model = report['model']
    source_path = Path(report['input'])
    assert hashlib.sha256(source_path.read_bytes()).hexdigest() == report['input_sha256']
    source = json.loads(source_path.read_text())
    pool, local = model['pool'], {v:i for i,v in enumerate(model['pool'])}
    assert pool == source['pool']
    values = np.zeros(len(pool))
    for v,x in source['primal']:
        values[local[v]] = x
    assert np.min(values) >= -1e-6 and np.max(values) <= 1+1e-6
    edges = [(i,local[w]) for i,v in enumerate(pool) for w in closed(v) if w in local and i < local[w]]
    roots = [i for i,x in enumerate(values) if 1e-6 < x < 1-1e-6]
    random.Random(20260921).shuffle(roots)
    roots = roots[:args.root_limit]
    assert roots
    start = time.monotonic()
    cuts = separate(len(pool),edges,values,roots)
    for c in cuts:
        cycle = [pool[i] for i in c['cycle']]
        assert len(cycle) == len(set(cycle)) and len(cycle) % 2
        assert all(conflict(a,b) for a,b in zip(cycle,cycle[1:]+cycle[:1]))
        c['cycle_words'] = cycle
    members = list(model['members'])
    capacities = list(model['capacities'])
    output = dict(input=str(args.model), input_sha256=hashlib.sha256(args.model.read_bytes()).hexdigest(),
                  source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  pool=len(pool), edges=len(edges), roots=[pool[i] for i in roots], cuts=cuts,
                  controls=dict(violated_C5=True, feasible_C7=True), results=[],
                  scope='Sampled odd-cycle separation. Each saved inequality is geometrically checked; absence of sampled cuts is not a completeness claim.')
    for label in ('base','with_odd_cycles'):
        if label == 'with_odd_cycles':
            members += [c['cycle'] for c in cuts]
            capacities += [c['capacity'] for c in cuts]
        rows = [i for i,c in enumerate(members) for _ in c]
        cols = [v for c in members for v in c]
        matrix = coo_matrix((np.ones(len(rows)),(rows,cols)),shape=(len(members),len(pool))).tocsr()
        if label == 'base':
            assert np.all(matrix@values <= np.asarray(capacities)+1e-6)
        hint = np.zeros(len(pool));hint[model['hint']] = 1
        assert np.all(matrix@hint <= capacities)
        lp = linprog(-np.ones(len(pool)),A_ub=matrix,b_ub=capacities,bounds=(0,1),
                     method='highs-ipm',options={'time_limit':args.seconds})
        output['results'].append(dict(label=label,status=int(lp.status),message=lp.message,
                                      floating_full_bound=len(model['fixed'])-float(lp.fun) if lp.success else None))
    output['seconds'] = time.monotonic()-start
    args.output.write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps(dict(cuts=len(cuts),roots=len(roots),results=output['results'],seconds=output['seconds'])),flush=True)


if __name__ == '__main__':
    main()
