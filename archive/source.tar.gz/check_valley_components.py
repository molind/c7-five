"""Independent single-exchange replay of the new 367-word components.

Use integer masks over the core's free graph, not the walk's mutable counters.
Also check every outside word with one core blocker: none may replace a core
word in any reached completion. That makes the fixed-core BFS a complete
single-exchange component, rather than a search that assumes its conclusion.
"""
import hashlib
import itertools
import json
import struct
from collections import deque
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def conflict(a, b):
    return all((x-y) % 7 in (0, 1, 6) for x, y in zip(a, b))


def replay(label, seed_path, component_path):
    words = list(itertools.product(range(7), repeat=5))
    index = {w: i for i, w in enumerate(words)}
    seed = [tuple(w) for w in json.loads(seed_path.read_text())["words"]]
    source = json.loads(component_path.read_text())
    core = set(map(tuple, source["fixed_across_visited_words"]))
    if len(seed) != 367 or len(set(seed)) != 367 or not core <= set(seed):
        raise ArithmeticError("Malformed seed/core")
    if any(conflict(a, b) for a, b in itertools.combinations(seed, 2)):
        raise ArithmeticError("Invalid independent seed")
    free, one_core = [], []
    for w in words:
        if w in core:
            continue
        blockers = 0
        for u in core:
            if conflict(w, u):
                blockers += 1
                if blockers > 1:
                    break
        if blockers == 0:
            free.append(w)
        elif blockers == 1:
            one_core.append(w)
    local = {w: i for i, w in enumerate(free)}
    adj = [sum(1 << j for j, u in enumerate(free) if conflict(w, u)) for w in free]
    core_escape_masks = [sum(1 << j for j, u in enumerate(free) if conflict(w, u))
                         for w in one_core]
    initial = sum(1 << local[w] for w in seed if w not in core)
    seen, pending = {initial}, deque([initial])
    all_free = (1 << len(free))-1
    directed = 0
    while pending:
        chosen = pending.popleft()
        if any(mask & chosen == 0 for mask in core_escape_masks):
            raise ArithmeticError("Single exchange can remove a claimed core word")
        remaining = all_free ^ chosen
        groups = {}
        while remaining:
            bit = remaining & -remaining
            remaining ^= bit
            v = bit.bit_length()-1
            blockers = adj[v] & chosen
            if not blockers:
                raise ArithmeticError("Free insertion found")
            if blockers.bit_count() == 1:
                group = groups.get(blockers, 0)
                if group & ~adj[v]:
                    raise ArithmeticError("One-for-two augmentation found")
                groups[blockers] = group | bit
                new = chosen ^ blockers ^ bit
                directed += 1
                if new not in seen:
                    seen.add(new)
                    pending.append(new)
    fixed_ids = [index[w] for w in core]
    packed = []
    for mask in seen:
        ids = fixed_ids + [index[w] for j, w in enumerate(free) if mask >> j & 1]
        if len(ids) != 367:
            raise ArithmeticError("Wrong completion size")
        packed.append(struct.pack("<367H", *sorted(ids)))
    digest = hashlib.sha256(b"".join(sorted(packed))).hexdigest()
    if len(seen) != source["states_visited"] or digest != source["component_sha256"]:
        raise ArithmeticError("Independent component reconstruction disagrees")
    return {"label": label, "core_size": len(core), "free_vertices": len(free),
            "one_core_blocker_words_checked_each_state": len(one_core),
            "component_size": len(seen), "directed_single_exchanges": directed,
            "component_sha256": digest,
            "claim": "Complete single-exchange component; no zero- or one-removal augmentation"}


if __name__ == "__main__":
    results = []
    for floor, seed in [(365, 2), (363, 3)]:
        result = replay(f"floor{floor}", ROOT/f"valley-floor{floor}-seed{seed}-farthest.json",
                        ROOT/f"valley-floor{floor}-plateau.json")
        results.append(result)
        print(json.dumps(result), flush=True)
    (ROOT/"valley-component-replay-results.json").write_text(json.dumps(results, indent=2)+"\n")
