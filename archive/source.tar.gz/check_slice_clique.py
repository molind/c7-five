"""Exhaustive small-graph and machine-word-boundary controls for slice_clique."""
import argparse
import hashlib
from itertools import combinations
import json
from pathlib import Path
import random
import subprocess

from search_slices import kernel, components


def main():
    if not __debug__:raise RuntimeError('Run without -O')
    parser=argparse.ArgumentParser()
    parser.add_argument('--binary',type=Path,default=Path(__file__).with_name('slice_clique'))
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();binary=args.binary.resolve()
    if args.output.exists():raise FileExistsError(args.output)
    cases=positive=negative=0
    for n in range(1,6):
        pairs=list(combinations(range(n),2))
        for mask in range(1<<len(pairs)):
            adj=[[] for _ in range(n)]
            for k,(u,v) in enumerate(pairs):
                if mask>>k&1:adj[u].append(v);adj[v].append(u)
            optimum=max(m.bit_count() for m in range(1<<n)
                        if all(not(m>>u&1 and m>>v&1) for u,v in pairs if v in adj[u]))
            for target in (optimum,optimum+1):
                result=kernel(binary,adj,[],target,1)
                assert result['best_size']==optimum
                assert result['status']==('target_found' if target==optimum else 'exhausted')
                positive+=target==optimum;negative+=target>optimum;cases+=1
            # The independently found optimum also exercises pruning from a hint.
            result=kernel(binary,adj,result['vertices'],optimum+1,1)
            assert result['status']=='exhausted' and result['best_size']==optimum;cases+=1
    for n in (63,64,65,127,128,129):
        for complete in (False,True):
            adj=[[v for v in range(n) if v!=u] if complete else [] for u in range(n)]
            optimum=1 if complete else n
            r=kernel(binary,adj,[],optimum+1,2)
            assert r['status']=='exhausted' and r['best_size']==optimum;cases+=1
    # A disconnected graph where only a non-largest component improves.
    adj=[[1,2],[0,2],[0,1],[],[]]
    parts=components(adj);assert parts==[[0,1,2],[3],[4]]
    # Input rejection must be a failure, never a successful exclusion.
    invalid=['2 1 2 100 2\n0 1\n0 1\n','2 0 1 100 2\n0 0\n',
             '2 1 2 100 0\n0 2\n','3 2 3 100 0\n0 1\n0 1\n']
    for data in invalid:
        run=subprocess.run([str(binary)],input=data,text=True,capture_output=True)
        assert run.returncode==2 and not run.stdout
    # A deliberately short budget must not manufacture an exclusion.
    rng=random.Random(20260921);n=180;adj=[[] for _ in range(n)]
    for u,v in combinations(range(n),2):
        if rng.random()<.5:adj[u].append(v);adj[v].append(u)
    r=kernel(binary,adj,[],181,.001)
    assert r['status']=='timeout'
    report={'decision_cases':cases,'positive_empty_hint_cases':positive,
            'negative_empty_hint_cases':negative,'word_boundaries':[63,64,65,127,128,129],
            'invalid_inputs_rejected':len(invalid),'timeout_preserved':True,
            'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest()}
    args.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))


if __name__=='__main__':main()
