"""Brute-force controls for the actual two-phase LP/binary solver pipeline."""
import argparse
from itertools import combinations
import json
from pathlib import Path
import random

import numpy as np
from scipy.sparse import csc_matrix, vstack

from search_core_radius_cut import radius_rows, sha
from solve_core_radius_ipm import solve_two_phase


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output', required=True, type=Path)
    args = p.parse_args()
    assert __debug__ and not args.output.exists()
    rng = random.Random(922201)
    queries = improvements = checked = 0
    for case in range(40):
        n = rng.randrange(5, 11)
        edges = [pair for pair in combinations(range(n), 2) if rng.random() < .28]
        independent = [s for s in range(1 << n) if all(not ((s >> a & 1) and (s >> b & 1)) for a, b in edges)]
        old = rng.choice([s for s in independent if 1 <= s.bit_count() < n])
        m = old.bit_count()
        larger = [s for s in independent if s.bit_count() > m]
        q = min(((old & ~s).bit_count() for s in larger), default=m + 1)
        q = max(1, q)
        # Some random old sets admit a zero-deletion augmentation: those cannot
        # justify even q=1, so use a maximal old set instead.
        if any((old & ~s).bit_count() == 0 for s in larger):
            old = max(independent, key=lambda s: (bool((s & old) == old), s.bit_count()))
            m = old.bit_count()
            larger = [s for s in independent if s.bit_count() > m]
            q = min(((old & ~s).bit_count() for s in larger), default=m + 1)
        initial = np.array([float(old >> i & 1) for i in range(n)])
        a = np.zeros((len(edges), n))
        for j, (u, v) in enumerate(edges):
            a[j, u] = a[j, v] = 1
        for radius in sorted({0, min(q, m), m}):
            extra, lo, hi = radius_rows(initial, q, radius)
            matrix = vstack((csc_matrix(a), extra), format='csc')
            lower, upper = np.r_[np.zeros(len(edges)), lo], np.r_[np.ones(len(edges)), hi]
            allowed = np.ones(n)
            expected = max(s.bit_count() for s in independent if (old & ~s).bit_count() <= radius)
            expected = min(expected, m + 1)
            phases = solve_two_phase(matrix, lower, upper, allowed, initial, 3, 3, m + 1)
            assert phases['lp']['status'] == 'Optimal'
            assert phases['lp']['integer'] is False and phases['mip']['integer'] is True
            assert phases['mip']['basis_supplied']
            values = phases['mip']['values']
            mask = sum(int(x) << i for i, x in enumerate(values))
            assert mask in independent and (old & ~mask).bit_count() <= radius
            assert sum(values) == expected, (case, radius, phases)
            queries += 1
            improvements += expected > m
            checked += len(independent)
    out = dict(passed=True, graphs=40, queries=queries, improvements=improvements,
               independent_sets_considered=checked, source_sha256=sha(__file__),
               dependencies={str(Path(__file__).with_name(n)): sha(Path(__file__).with_name(n))
                             for n in ('solve_core_radius_ipm.py', 'search_core_radius_cut.py')})
    args.output.write_text(json.dumps(out, indent=2) + '\n')
    print(out)


if __name__ == '__main__':
    main()
