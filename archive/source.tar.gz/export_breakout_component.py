"""Build a compact membership cache and match its full known-component hash."""
from collections import deque
import gzip
import hashlib
import json
from pathlib import Path
import struct

import numpy as np

from breakout_conflicts import graph

HERE = Path(__file__).resolve().parent


def reconstruct(source, start, adj):
    core = {int(''.join(map(str, w)), 7) for w in source['fixed_across_visited_words']}
    blocked = np.zeros(len(adj), dtype=bool)
    blocked[list(core)] = True
    blocked[adj[list(core)].ravel()] = True
    free = np.flatnonzero(~blocked).tolist()
    local = {v: i for i,v in enumerate(free)}
    masks = [sum(1 << local[int(u)] for u in adj[v] if int(u) in local) for v in free]
    root = sum(1 << local[v] for v in start-core)
    seen = {root}; pending = deque([root]); directed = 0
    all_free = (1 << len(free))-1
    while pending:
        state = pending.popleft()
        outside = all_free ^ state
        while outside:
            bit = outside & -outside; outside ^= bit
            v = bit.bit_length()-1
            blockers = state & masks[v]
            assert blockers, 'Unexpected free insertion'
            if blockers.bit_count() != 1:
                continue
            directed += 1
            nxt = state ^ blockers ^ bit
            if nxt not in seen:
                seen.add(nxt); pending.append(nxt)
    keys = sorted(struct.pack('<367H', *sorted(core | {free[i] for i in range(len(free)) if s >> i & 1})) for s in seen)
    digest = hashlib.sha256(b''.join(keys)).hexdigest()
    # The reference traversal did not assume this core was fixed. Equality with
    # its complete state hash is what makes this restricted reconstruction safe.
    assert source['status'] == 'exhausted'
    assert len(keys) == source['states_visited'] and digest == source['component_sha256']
    return keys, directed


def main():
    if not __debug__:
        raise RuntimeError('Run without -O')
    source = json.loads((HERE/'breakout-unweighted-component.json').read_text())
    endpoint = json.loads((HERE/'breakout-unweighted-certificate.json').read_text())
    start = {int(w, 7) for w in endpoint['independent_words']}
    _, adj = graph(5)
    keys, directed = reconstruct(source, start, adj)
    digest = hashlib.sha256(b''.join(keys)).hexdigest()
    metadata = dict(states=len(keys), component_sha256=digest, cardinality=367,
                    family='C copy', directed_edges=directed,
                    reference='research/c7/breakout-unweighted-component.json',
                    classification='research/c7/breakout-path-verification.json')
    output = HERE/'breakout-known-c-component.jsonl.gz'
    with gzip.open(output, 'wt') as f:
        f.write(json.dumps(metadata)+'\n')
        for key in keys:
            f.write(json.dumps(list(struct.unpack('<367H', key)))+'\n')
    (HERE/'breakout-known-c-export.json').write_text(json.dumps(metadata, indent=2)+'\n')
    print(json.dumps(metadata))


if __name__ == '__main__':
    main()
