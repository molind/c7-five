"""Independent controls for count caps and the existing anchor DFS option."""
import copy
import hashlib
import importlib.util
from itertools import combinations, product
import json
from pathlib import Path
import random
import subprocess
import sys

import numpy as np

from check_blocker_radius import check
from solve_two_blocker_mip import build_model


def main():
    here=Path(__file__).resolve().parent
    output=Path(sys.argv[1]);assert __debug__ and not output.exists()
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    model=json.loads((here/'reference367-four-radius7-models-sep21.json').read_text())
    cert=json.loads((here/'reference367-four-count3-certificates-sep21.json').read_text())
    spec=importlib.util.spec_from_file_location('before_count',here/'solve_two_blocker_mip_before_four_count.py')
    old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
    defaults=0;negative=[]
    for d,c in zip(model['rows'],cert['rows']):
        for radius in (None,6,7):
            a=build_model(d,'improve',max_removals=radius)
            b=old.build_model(d,'improve',max_removals=radius)
            assert (a[0]!=b[0]).nnz==0
            assert all(np.array_equal(x,y) for x,y in zip(a[1:],b[1:]));defaults+=1
        check(c,d)
        for kind in ('missing_count','weaker_count','negative_count','radius_too_large'):
            bad=copy.deepcopy(c)
            if kind=='missing_count':del bad['max_four_insertions']
            elif kind=='weaker_count':bad['max_four_insertions']+=1
            elif kind=='negative_count':bad['max_four_insertions']=-1
            else:bad['max_removals']+=1
            try:check(bad,d)
            except AssertionError:negative.append([d['base'],kind])
            else:raise AssertionError(('Accepted changed condition',kind))
    # Every assignment, including redundant old removals: the new cap must
    # affect exactly candidates with four ORIGINAL reference blockers.
    d=dict(pool_ids=list(range(4)),active_old_indices=list(range(4)),
           blocker_sets=[[0],[0,1],[0,1,2,3],[0,1,2,3]],conflict_edges=[[0,1],[2,3]])
    assignments=0
    for cap in (0,1,2):
        A,lo,hi,cost=build_model(d,'improve',max_removals=4,max_four_insertions=cap)
        for value in product((0,1),repeat=8):
            x=value[:4];y=value[4:]
            expected=(all(not x[i] or all(y[j] for j in b) for i,b in enumerate(d['blocker_sets']))
                      and not x[0]*x[1] and not x[2]*x[3] and x[2]+x[3]<=cap)
            assert bool(np.all(A@value<=hi))==expected;assignments+=1
    rng=random.Random(219704);kernel=here/'exchange_dfs';records=[]
    for case in range(40):
        n=12 if case<32 else 70;radius=2+case%3 if case<32 else 2
        prefix=(case%11)+1 if case<32 else (63,64,65,70)[case%4]
        need=1+case%(radius+2);target=radius+1
        blocked=[sum(1<<i for i in rng.sample(range(7),rng.randint(1,min(radius,3)))) for _ in range(n)]
        compat=[0]*n
        for i,j in combinations(range(n),2):
            if rng.random()<0.78:
                compat[i]|=1<<j;compat[j]|=1<<i
        expected=None;checked=0
        for chosen in combinations(range(n),target):
            checked+=1
            if sum(i<prefix for i in chosen)<need:continue
            if any(not (compat[i]>>j)&1 for i,j in combinations(chosen,2)):continue
            union=0
            for i in chosen:union|=blocked[i]
            if union.bit_count()<=radius:expected=chosen;break
        cw=(n+63)//64;mask=(1<<64)-1
        lines=[f'{n} 1 {radius}']
        for i in range(n):lines.append(' '.join(format(v,'x') for v in [blocked[i]]+[(compat[i]>>(64*j))&mask for j in range(cw)]))
        lines.append(' '.join([str(need)]*n))
        run=subprocess.run([str(kernel),'3','--subset','--root-prefix',str(prefix),'--anchor-bounds',str(prefix)],
                           input='\n'.join(lines)+'\n',text=True,capture_output=True,check=True,timeout=5)
        r=json.loads(run.stdout);assert r['status'] in ('witness','exhausted'),r
        assert (r['status']=='witness')==(expected is not None)
        if expected is not None:assert r['chosen']==list(expected)
        else:assert r['nodes_started']==r['nodes_completed']
        records.append(dict(case=case,n=n,prefix=prefix,need=need,radius=radius,subsets_checked=checked,status=r['status']))
    result=dict(source_sha256=sha(__file__),builder_sha256=sha(here/'solve_two_blocker_mip.py'),
                checker_sha256=sha(here/'check_blocker_radius.py'),kernel_sha256=sha(kernel),
                default_matrices_unchanged=defaults,rejected_changed_conditions=negative,
                full_boolean_assignments_checked=assignments,kernel_cases=records)
    output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='kernel_cases'}))
    print('kernel_cases',len(records),'positive',sum(r['status']=='witness' for r in records))


if __name__=='__main__':main()
