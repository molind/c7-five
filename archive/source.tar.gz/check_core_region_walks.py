"""Replay every core-domain walk by direct coordinate conflict counts.

Also inspect every one-conflict state for uncached367 repairs, without the
search driver's distance filter. Does not re-execute weighted move selection.
"""
import argparse
import gzip
import hashlib
from itertools import combinations, product
import json
from pathlib import Path

import numpy as np

from check_common314_covers import decode


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True)
    p.add_argument('--base',type=Path,required=True)
    p.add_argument('--cache',type=Path,nargs='+',required=True)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();assert __debug__ and not args.output.exists()
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    data=json.loads(args.input.read_text());assert data['status']!='running'
    assert all(sha(f)==h for f,h in data['dependencies'].items())
    base=json.loads(args.base.read_text());assert sha(base['input'])==base['input_sha256']
    parents=json.loads(Path(base['input']).read_text())['bases']
    core=set(parents[0]['words'])&set(parents[1]['words']);assert len(core)==315 and core==set(base['fixed'])
    coords=np.array(list(product(range(7),repeat=5)),dtype=np.int16)
    known=set();dependencies={str(args.input):sha(args.input),str(args.base):sha(args.base),base['input']:sha(base['input'])}
    for path in args.cache:
        with gzip.open(path,'rt') as f:
            header=json.loads(next(f));states=[tuple(json.loads(line)) for line in f]
        assert len(states)==header['states'];known.update(states);dependencies[str(path)]=sha(path)
    candidates=[];seen=set();domains={};checked=[];pair_tests=one_edge_states=0
    def neighbors(v,selected):
        delta=(coords[list(selected)]-coords[v])%7
        return np.array(list(selected))[np.all((delta==0)|(delta==1)|(delta==6),axis=1)].tolist()
    def conflicts(words):
        nonlocal pair_tests
        count=0
        for i,v in enumerate(words):count+=len(neighbors(v,words[i+1:]));pair_tests+=len(words)-i-1
        return count
    for ordinal,run in enumerate(data['runs']):
        fixed=set(run['fixed']);assert len(fixed)==len(run['fixed']) and fixed<=core
        if run['domain'] not in domains:
            allowed=np.ones(16807,dtype=bool)
            for v in fixed:
                delta=(coords-coords[v])%7;allowed &= ~np.all((delta==0)|(delta==1)|(delta==6),axis=1)
            domains[run['domain']]=(fixed,set(np.flatnonzero(allowed).tolist()))
        expected_fixed,pool=domains[run['domain']];assert fixed==expected_fixed and pool==set(run['pool']) and len(pool)==len(run['pool'])
        selected=set(run['start']);assert len(selected)==len(run['start'])==368
        assert fixed<=selected<=fixed|pool
        assert selected==set(parents[run['parent']]['words'])|{run['extra']}
        energy=conflicts(sorted(selected));best=energy;best_words=sorted(selected);initial_energy=energy
        assert run['steps']==len(run['moves'])==run['replayed_moves']
        for step,(old,new,stored) in enumerate(run['moves']):
            assert old in selected-fixed and new in pool-selected
            selected.remove(old);energy-=len(neighbors(old,selected))
            energy+=len(neighbors(new,selected));selected.add(new);pair_tests+=734
            assert energy==stored
            if energy<best:best=energy;best_words=sorted(selected)
            if energy==1:
                one_edge_states+=1
                # Stop at the first edge: the directly replayed energy is1.
                edge=None
                for v in sorted(selected):
                    ns=neighbors(v,selected-{v})
                    if ns:assert len(ns)==1;edge=(v,ns[0]);break
                assert edge is not None
                for v in edge:
                    child=tuple(sorted(selected-{v}))
                    if child in known or child in seen:continue
                    seen.add(child);assert not conflicts(list(child))
                    candidates.append(dict(step=step,run=ordinal,seed=run['seed'],domain=run['domain'],size=367,
                        words=coords[list(child)].tolist(),parent_distances=[len(set(child)-set(p['words'])) for p in parents],pair_checks=67161))
        assert sorted(selected)==run['final_words'] and best_words==run['best_words'] and best==run['best_conflicts']
        assert conflicts(sorted(selected))==energy and conflicts(best_words)==best
        assert (run['status']=='independent')==(best==0)
        checked.append(dict(run=ordinal,domain=run['domain'],moves=len(run['moves']),initial_conflicts=initial_energy,best_conflicts=best,final_conflicts=energy))
    if data['verified368'] is not None:
        assert len(data['verified368'])==368 and not conflicts(data['verified368'])
    assert (data['verified368'] is not None)==any(r['best_conflicts']==0 for r in data['runs'])
    out=dict(passed=True,runs=checked,one_edge_states=one_edge_states,candidates=candidates,
        checked_coordinate_pairs=pair_tests,verified368=data['verified368'],checker_sha256=sha(__file__),dependencies=dependencies,
        scope='Every saved move and every one-edge repair checked; exact labeled cache only, no graph-isomorphism novelty claim.')
    args.output.write_text(json.dumps(out,indent=2)+'\n')
    print(dict(passed=True,runs=len(checked),moves=sum(r['moves'] for r in checked),one_edge_states=one_edge_states,uncached367=len(candidates),pair_tests=pair_tests))


if __name__=='__main__':main()
